import { AtralumeIcon, provideAtralumeIcons, userIcon } from "@osmanjimenez/atralume/icon";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, ViewEncapsulation, computed, input, signal } from "@angular/core";
import * as i1 from "@taiga-ui/kit";
import { TuiAvatar, TuiAvatarStack } from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeAvatar = class AtralumeAvatar {
	src = input(null, ...ngDevMode ? [{ debugName: "src" }] : /* istanbul ignore next */ []);
	alt = input("", ...ngDevMode ? [{ debugName: "alt" }] : /* istanbul ignore next */ []);
	name = input(null, ...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	initials = input(null, ...ngDevMode ? [{ debugName: "initials" }] : /* istanbul ignore next */ []);
	size = input("medium", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	shape = input("circle", ...ngDevMode ? [{ debugName: "shape" }] : /* istanbul ignore next */ []);
	loading = input("lazy", ...ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []);
	failedSrc = signal(null, ...ngDevMode ? [{ debugName: "failedSrc" }] : /* istanbul ignore next */ []);
	hasImage = computed(() => !!this.src() && this.src() !== this.failedSrc(), ...ngDevMode ? [{ debugName: "hasImage" }] : /* istanbul ignore next */ []);
	displayInitials = computed(() => {
		const explicit = this.initials()?.trim();
		if (explicit) return Array.from(explicit).slice(0, 2).join("");
		const words = this.name()?.trim().split(/\s+/).filter(Boolean) ?? [];
		return [words[0], words.length > 1 ? words[words.length - 1] : void 0].filter((word) => !!word).map((word) => Array.from(word)[0]).join("").toLocaleUpperCase();
	}, ...ngDevMode ? [{ debugName: "displayInitials" }] : /* istanbul ignore next */ []);
	imageFailed() {
		this.failedSrc.set(this.src());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeAvatar,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeAvatar,
		isStandalone: true,
		selector: "atr-avatar",
		inputs: {
			src: {
				classPropertyName: "src",
				publicName: "src",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			alt: {
				classPropertyName: "alt",
				publicName: "alt",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			initials: {
				classPropertyName: "initials",
				publicName: "initials",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			shape: {
				classPropertyName: "shape",
				publicName: "shape",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			loading: {
				classPropertyName: "loading",
				publicName: "loading",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: {
				"attr.tuiAvatar": "\"\"",
				"attr.data-name": "name()",
				"attr.data-initials": "displayInitials()",
				"attr.data-size": "size()",
				"attr.data-shape": "shape()",
				"attr.role": "alt() ? \"img\" : null",
				"attr.aria-label": "alt() || null",
				"attr.aria-hidden": "alt() ? null : \"true\""
			},
			classAttribute: "atr-avatar"
		},
		providers: [provideAtralumeIcons([userIcon])],
		hostDirectives: [{
			directive: i1.TuiAvatar,
			inputs: ["size", "tuiSize"]
		}],
		ngImport: i0,
		template: "@if (hasImage()) {\n  <img\n    [src]=\"src()\"\n    alt=\"\"\n    [loading]=\"loading()\"\n    width=\"64\"\n    height=\"64\"\n    (error)=\"imageFailed()\"\n  />\n} @else if (displayInitials()) {\n  <span aria-hidden=\"true\">{{ displayInitials() }}</span>\n} @else {\n  <atr-icon name=\"user\" />\n}\n",
		styles: ["[tuiAvatar].atr-avatar{display:inline-flex;align-items:center;justify-content:center;flex:none;box-sizing:border-box;overflow:hidden;inline-size:var(--atr-comp-avatar-size-medium);block-size:var(--atr-comp-avatar-size-medium);border:var(--atr-comp-avatar-border-width) solid var(--atr-comp-avatar-border-color);border-radius:var(--atr-comp-avatar-shape);background:var(--atr-comp-avatar-container-color);color:var(--atr-comp-avatar-label-color);font-family:var(--atr-comp-avatar-font-family);font-size:var(--atr-comp-avatar-font-size)}[tuiAvatar].atr-avatar[data-size=small]{inline-size:var(--atr-comp-avatar-size-small);block-size:var(--atr-comp-avatar-size-small)}[tuiAvatar].atr-avatar[data-size=large]{inline-size:var(--atr-comp-avatar-size-large);block-size:var(--atr-comp-avatar-size-large)}[tuiAvatar].atr-avatar[data-size=x-large]{inline-size:var(--atr-comp-avatar-size-x-large);block-size:var(--atr-comp-avatar-size-x-large)}[tuiAvatar].atr-avatar[data-shape=rounded]{border-radius:var(--atr-comp-avatar-rounded-shape)}[tuiAvatar].atr-avatar img{display:block;inline-size:100%;block-size:100%;object-fit:cover}[tuiAvatar].atr-avatar atr-icon{inline-size:60%;block-size:60%;color:var(--atr-comp-avatar-fallback-icon-color)}@media(forced-colors:active){[tuiAvatar].atr-avatar{border-color:CanvasText}}\n"],
		dependencies: [{
			kind: "component",
			type: AtralumeIcon,
			selector: "atr-icon",
			inputs: [
				"name",
				"size",
				"decorative",
				"label",
				"engine"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush,
		encapsulation: i0.ViewEncapsulation.None
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeAvatar,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-avatar",
			standalone: true,
			imports: [AtralumeIcon],
			providers: [provideAtralumeIcons([userIcon])],
			hostDirectives: [{
				directive: TuiAvatar,
				inputs: ["size: tuiSize"]
			}],
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			host: {
				class: "atr-avatar",
				"[attr.tuiAvatar]": "\"\"",
				"[attr.data-name]": "name()",
				"[attr.data-initials]": "displayInitials()",
				"[attr.data-size]": "size()",
				"[attr.data-shape]": "shape()",
				"[attr.role]": "alt() ? \"img\" : null",
				"[attr.aria-label]": "alt() || null",
				"[attr.aria-hidden]": "alt() ? null : \"true\""
			},
			template: "@if (hasImage()) {\n  <img\n    [src]=\"src()\"\n    alt=\"\"\n    [loading]=\"loading()\"\n    width=\"64\"\n    height=\"64\"\n    (error)=\"imageFailed()\"\n  />\n} @else if (displayInitials()) {\n  <span aria-hidden=\"true\">{{ displayInitials() }}</span>\n} @else {\n  <atr-icon name=\"user\" />\n}\n",
			styles: ["[tuiAvatar].atr-avatar{display:inline-flex;align-items:center;justify-content:center;flex:none;box-sizing:border-box;overflow:hidden;inline-size:var(--atr-comp-avatar-size-medium);block-size:var(--atr-comp-avatar-size-medium);border:var(--atr-comp-avatar-border-width) solid var(--atr-comp-avatar-border-color);border-radius:var(--atr-comp-avatar-shape);background:var(--atr-comp-avatar-container-color);color:var(--atr-comp-avatar-label-color);font-family:var(--atr-comp-avatar-font-family);font-size:var(--atr-comp-avatar-font-size)}[tuiAvatar].atr-avatar[data-size=small]{inline-size:var(--atr-comp-avatar-size-small);block-size:var(--atr-comp-avatar-size-small)}[tuiAvatar].atr-avatar[data-size=large]{inline-size:var(--atr-comp-avatar-size-large);block-size:var(--atr-comp-avatar-size-large)}[tuiAvatar].atr-avatar[data-size=x-large]{inline-size:var(--atr-comp-avatar-size-x-large);block-size:var(--atr-comp-avatar-size-x-large)}[tuiAvatar].atr-avatar[data-shape=rounded]{border-radius:var(--atr-comp-avatar-rounded-shape)}[tuiAvatar].atr-avatar img{display:block;inline-size:100%;block-size:100%;object-fit:cover}[tuiAvatar].atr-avatar atr-icon{inline-size:60%;block-size:60%;color:var(--atr-comp-avatar-fallback-icon-color)}@media(forced-colors:active){[tuiAvatar].atr-avatar{border-color:CanvasText}}\n"]
		}]
	}],
	propDecorators: {
		src: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "src",
				required: false
			}]
		}],
		alt: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "alt",
				required: false
			}]
		}],
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}],
		initials: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "initials",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		shape: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "shape",
				required: false
			}]
		}],
		loading: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "loading",
				required: false
			}]
		}]
	}
});
var AtralumeAvatarGroup = class AtralumeAvatarGroup {
	direction = input("end", ...ngDevMode ? [{ debugName: "direction" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeAvatarGroup,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeAvatarGroup,
		isStandalone: true,
		selector: "atr-avatar-group",
		inputs: { direction: {
			classPropertyName: "direction",
			publicName: "direction",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: { classAttribute: "atr-avatar-group" },
		ngImport: i0,
		template: "<tui-avatar-stack [direction]=\"direction()\">\n  <ng-content />\n</tui-avatar-stack>\n",
		styles: [".atr-avatar-group{display:inline-flex}.atr-avatar-group tui-avatar-stack{display:flex}\n"],
		dependencies: [{
			kind: "component",
			type: TuiAvatarStack,
			selector: "tui-avatar-stack",
			inputs: ["direction"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush,
		encapsulation: i0.ViewEncapsulation.None
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeAvatarGroup,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-avatar-group",
			standalone: true,
			imports: [TuiAvatarStack],
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			host: { class: "atr-avatar-group" },
			template: "<tui-avatar-stack [direction]=\"direction()\">\n  <ng-content />\n</tui-avatar-stack>\n",
			styles: [".atr-avatar-group{display:inline-flex}.atr-avatar-group tui-avatar-stack{display:flex}\n"]
		}]
	}],
	propDecorators: { direction: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "direction",
			required: false
		}]
	}] }
});
var AtralumeAvatarImageHarness = class extends ComponentHarness {
	static hostSelector = "img";
};
var AtralumeAvatarHarness = class extends ComponentHarness {
	static hostSelector = ".atr-avatar";
	async getName() {
		return (await this.host()).getAttribute("data-name");
	}
	async getInitials() {
		return (await this.host()).getAttribute("data-initials");
	}
	async getSize() {
		return (await this.host()).getAttribute("data-size");
	}
	async hasImage() {
		return await this.locatorForOptional(AtralumeAvatarImageHarness)() !== null;
	}
};
var AtralumeAvatarGroupHarness = class extends ComponentHarness {
	static hostSelector = "atr-avatar-group.atr-avatar-group";
	async getDirection() {
		const stack = await this.locatorForOptional("tui-avatar-stack")();
		return stack ? stack.getAttribute("data-direction") : null;
	}
	async getAvatars() {
		return this.locatorForAll(AtralumeAvatarHarness)();
	}
};
export { AtralumeAvatar, AtralumeAvatarGroup, AtralumeAvatarGroupHarness, AtralumeAvatarHarness };

//# sourceMappingURL=osmanjimenez-atralume-avatar.mjs.map