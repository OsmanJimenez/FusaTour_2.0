import * as i0 from "@angular/core";
import { Directive, booleanAttribute, input } from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
import * as i1 from "@taiga-ui/layout";
import { TuiList } from "@taiga-ui/layout";
var AtralumeListHeadline = class AtralumeListHeadline {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeListHeadline,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeListHeadline,
		isStandalone: true,
		selector: "[atrListHeadline]",
		host: { classAttribute: "atr-list-headline" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeListHeadline,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrListHeadline]",
			standalone: true,
			host: { class: "atr-list-headline" }
		}]
	}]
});
var AtralumeListHeadlineHarness = class extends ComponentHarness {
	static hostSelector = ".atr-list-headline";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeListItem = class AtralumeListItem {
	selected = input(false, {
		...ngDevMode ? { debugName: "selected" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeListItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeListItem,
		isStandalone: true,
		selector: "li[atrListItem], a[atrListItem], button[atrListItem]",
		inputs: { selected: {
			classPropertyName: "selected",
			publicName: "selected",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			properties: { "attr.data-selected": "selected()" },
			classAttribute: "atr-list-item"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeListItem,
	decorators: [{
		type: Directive,
		args: [{
			selector: "li[atrListItem], a[atrListItem], button[atrListItem]",
			standalone: true,
			host: {
				class: "atr-list-item",
				"[attr.data-selected]": "selected()"
			}
		}]
	}],
	propDecorators: { selected: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "selected",
			required: false
		}]
	}] }
});
var AtralumeListItemHarness = class extends ComponentHarness {
	static hostSelector = ".atr-list-item";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeListLeading = class AtralumeListLeading {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeListLeading,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeListLeading,
		isStandalone: true,
		selector: "[atrListLeading]",
		host: { classAttribute: "atr-list-leading" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeListLeading,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrListLeading]",
			standalone: true,
			host: { class: "atr-list-leading" }
		}]
	}]
});
var AtralumeListLeadingHarness = class extends ComponentHarness {
	static hostSelector = ".atr-list-leading";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeListMetadata = class AtralumeListMetadata {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeListMetadata,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeListMetadata,
		isStandalone: true,
		selector: "[atrListMetadata]",
		host: { classAttribute: "atr-list-metadata" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeListMetadata,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrListMetadata]",
			standalone: true,
			host: { class: "atr-list-metadata" }
		}]
	}]
});
var AtralumeListMetadataHarness = class extends ComponentHarness {
	static hostSelector = ".atr-list-metadata";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeListSupporting = class AtralumeListSupporting {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeListSupporting,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeListSupporting,
		isStandalone: true,
		selector: "[atrListSupporting]",
		host: { classAttribute: "atr-list-supporting" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeListSupporting,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrListSupporting]",
			standalone: true,
			host: { class: "atr-list-supporting" }
		}]
	}]
});
var AtralumeListSupportingHarness = class extends ComponentHarness {
	static hostSelector = ".atr-list-supporting";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeListTrailing = class AtralumeListTrailing {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeListTrailing,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeListTrailing,
		isStandalone: true,
		selector: "[atrListTrailing]",
		host: { classAttribute: "atr-list-trailing" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeListTrailing,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrListTrailing]",
			standalone: true,
			host: { class: "atr-list-trailing" }
		}]
	}]
});
var AtralumeListTrailingHarness = class extends ComponentHarness {
	static hostSelector = ".atr-list-trailing";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeList = class AtralumeList {
	density = input("comfortable", ...ngDevMode ? [{ debugName: "density" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeList,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeList,
		isStandalone: true,
		selector: "ul[atrList], ol[atrList]",
		inputs: { density: {
			classPropertyName: "density",
			publicName: "density",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			properties: {
				"attr.tuiList": "\"\"",
				"attr.data-density": "density()"
			},
			classAttribute: "atr-list"
		},
		hostDirectives: [{
			directive: i1.TuiList,
			inputs: ["tuiList", "tuiSize"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeList,
	decorators: [{
		type: Directive,
		args: [{
			selector: "ul[atrList], ol[atrList]",
			standalone: true,
			hostDirectives: [{
				directive: TuiList,
				inputs: ["tuiList: tuiSize"]
			}],
			host: {
				class: "atr-list",
				"[attr.tuiList]": "\"\"",
				"[attr.data-density]": "density()"
			}
		}]
	}],
	propDecorators: { density: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "density",
			required: false
		}]
	}] }
});
var AtralumeListHarness = class extends ComponentHarness {
	static hostSelector = ".atr-list";
	async getText() {
		return (await this.host()).text();
	}
};
export { AtralumeList, AtralumeListHarness, AtralumeListHeadline, AtralumeListHeadlineHarness, AtralumeListItem, AtralumeListItemHarness, AtralumeListLeading, AtralumeListLeadingHarness, AtralumeListMetadata, AtralumeListMetadataHarness, AtralumeListSupporting, AtralumeListSupportingHarness, AtralumeListTrailing, AtralumeListTrailingHarness };

//# sourceMappingURL=osmanjimenez-atralume-list.mjs.map