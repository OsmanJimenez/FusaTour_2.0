import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, booleanAttribute, forwardRef, input, model } from "@angular/core";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { ɵAtralumeValueControl } from "@osmanjimenez/atralume/internal/forms";
import { AtralumeCombobox, AtralumeComboboxHarness } from "@osmanjimenez/atralume/combobox";
var AtralumeAutocomplete = class AtralumeAutocomplete extends ɵAtralumeValueControl {
	options = input([], ...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	query = model("", ...ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []);
	placeholder = input("Search", ...ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []);
	clearable = input(false, {
		...ngDevMode ? { debugName: "clearable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	compareWith = input(Object.is, ...ngDevMode ? [{ debugName: "compareWith" }] : /* istanbul ignore next */ []);
	displayWith = input(null, ...ngDevMode ? [{ debugName: "displayWith" }] : /* istanbul ignore next */ []);
	strict = input(false, {
		...ngDevMode ? { debugName: "strict" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	emptyText = input("No results", ...ngDevMode ? [{ debugName: "emptyText" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeAutocomplete,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeAutocomplete,
		isStandalone: true,
		selector: "atr-autocomplete",
		inputs: {
			options: {
				classPropertyName: "options",
				publicName: "options",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			query: {
				classPropertyName: "query",
				publicName: "query",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			clearable: {
				classPropertyName: "clearable",
				publicName: "clearable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			compareWith: {
				classPropertyName: "compareWith",
				publicName: "compareWith",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			displayWith: {
				classPropertyName: "displayWith",
				publicName: "displayWith",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			strict: {
				classPropertyName: "strict",
				publicName: "strict",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			emptyText: {
				classPropertyName: "emptyText",
				publicName: "emptyText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { query: "queryChange" },
		host: { classAttribute: "atr-autocomplete" },
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => AtralumeAutocomplete),
			multi: true
		}],
		usesInheritance: true,
		ngImport: i0,
		template: "<atr-combobox\n  [label]=\"label()\"\n  [controlId]=\"controlId()\"\n  [hint]=\"hint()\"\n  [error]=\"error()\"\n  [required]=\"required()\"\n  [invalid]=\"displayInvalid()\"\n  [disabled]=\"blocked()\"\n  [readonly]=\"readonly()\"\n  [value]=\"value()\"\n  (valueChange)=\"commit($event)\"\n  [options]=\"options()\"\n  [(query)]=\"query\"\n  [placeholder]=\"placeholder()\"\n  [clearable]=\"clearable()\"\n  [compareWith]=\"compareWith()\"\n  [displayWith]=\"displayWith()\"\n  [strict]=\"strict()\"\n  [filterOptions]=\"true\"\n  [emptyText]=\"emptyText()\"\n/>\n",
		styles: [":host{--atr-comp-combobox-container-color: var( --atr-comp-autocomplete-container-color );--atr-comp-combobox-label-color: var(--atr-comp-autocomplete-label-color);--atr-comp-combobox-border-color: var(--atr-comp-autocomplete-border-color);--atr-comp-combobox-shape: var(--atr-comp-autocomplete-shape);display:block;min-inline-size:0}\n"],
		dependencies: [{
			kind: "component",
			type: AtralumeCombobox,
			selector: "atr-combobox",
			inputs: [
				"options",
				"query",
				"placeholder",
				"clearable",
				"emptyText",
				"strict",
				"filterOptions",
				"compareWith",
				"displayWith"
			],
			outputs: ["queryChange"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeAutocomplete,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-autocomplete",
			standalone: true,
			imports: [AtralumeCombobox],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => AtralumeAutocomplete),
				multi: true
			}],
			host: { class: "atr-autocomplete" },
			template: "<atr-combobox\n  [label]=\"label()\"\n  [controlId]=\"controlId()\"\n  [hint]=\"hint()\"\n  [error]=\"error()\"\n  [required]=\"required()\"\n  [invalid]=\"displayInvalid()\"\n  [disabled]=\"blocked()\"\n  [readonly]=\"readonly()\"\n  [value]=\"value()\"\n  (valueChange)=\"commit($event)\"\n  [options]=\"options()\"\n  [(query)]=\"query\"\n  [placeholder]=\"placeholder()\"\n  [clearable]=\"clearable()\"\n  [compareWith]=\"compareWith()\"\n  [displayWith]=\"displayWith()\"\n  [strict]=\"strict()\"\n  [filterOptions]=\"true\"\n  [emptyText]=\"emptyText()\"\n/>\n",
			styles: [":host{--atr-comp-combobox-container-color: var( --atr-comp-autocomplete-container-color );--atr-comp-combobox-label-color: var(--atr-comp-autocomplete-label-color);--atr-comp-combobox-border-color: var(--atr-comp-autocomplete-border-color);--atr-comp-combobox-shape: var(--atr-comp-autocomplete-shape);display:block;min-inline-size:0}\n"]
		}]
	}],
	propDecorators: {
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: false
			}]
		}],
		query: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "query",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["queryChange"]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		clearable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "clearable",
				required: false
			}]
		}],
		compareWith: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "compareWith",
				required: false
			}]
		}],
		displayWith: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "displayWith",
				required: false
			}]
		}],
		strict: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "strict",
				required: false
			}]
		}],
		emptyText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "emptyText",
				required: false
			}]
		}]
	}
});
var AtralumeAutocompleteHarness = class extends AtralumeComboboxHarness {
	static hostSelector = "atr-autocomplete";
};
export { AtralumeAutocomplete, AtralumeAutocompleteHarness };

//# sourceMappingURL=osmanjimenez-atralume-autocomplete.mjs.map