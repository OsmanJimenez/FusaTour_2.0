import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, ElementRef, InjectionToken, ViewEncapsulation, booleanAttribute, computed, contentChildren, forwardRef, inject, input, model, output, viewChild } from "@angular/core";
import { AtralumeButton } from "@osmanjimenez/atralume/button";
import { AtralumeIconButton } from "@osmanjimenez/atralume/icon-button";
import { AtralumeIcon, closeIcon, provideAtralumeIcons } from "@osmanjimenez/atralume/icon";
import * as i1 from "@taiga-ui/kit";
import { TuiChip } from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
const CHIP_SET = new InjectionToken("Atralume chip set");
var AtralumeChip = class AtralumeChip {
	kind = input("assist", ...ngDevMode ? [{ debugName: "kind" }] : /* istanbul ignore next */ []);
	value = input("", ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	selected = model(false, ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	removable = input(false, {
		...ngDevMode ? { debugName: "removable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	removed = output();
	invoked = output();
	owner = inject(CHIP_SET, { optional: true });
	blocked = computed(() => this.disabled() || (this.owner?.disabled() ?? false), ...ngDevMode ? [{ debugName: "blocked" }] : /* istanbul ignore next */ []);
	button = viewChild.required("action", {
		...ngDevMode ? { debugName: "button" } : /* istanbul ignore next */ {},
		read: ElementRef
	});
	activate() {
		if (this.blocked()) return;
		if (this.kind() === "filter") {
			this.selected.update((value) => !value);
			this.owner?.choose(this.value(), this.selected());
		}
		this.invoked.emit(this.value());
	}
	focus() {
		this.button().nativeElement.focus();
	}
	remove() {
		if (!this.blocked()) this.removed.emit(this.value());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeChip,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeChip,
		isStandalone: true,
		selector: "atr-chip",
		inputs: {
			kind: {
				classPropertyName: "kind",
				publicName: "kind",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			selected: {
				classPropertyName: "selected",
				publicName: "selected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			removable: {
				classPropertyName: "removable",
				publicName: "removable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			selected: "selectedChange",
			removed: "removed",
			invoked: "invoked"
		},
		host: {
			properties: {
				"attr.tuiChip": "\"\"",
				"attr.data-selected": "selected()",
				"attr.data-value": "value()"
			},
			classAttribute: "atr-chip"
		},
		providers: [provideAtralumeIcons([closeIcon])],
		viewQueries: [{
			propertyName: "button",
			first: true,
			predicate: ["action"],
			descendants: true,
			read: ElementRef,
			isSignal: true
		}],
		hostDirectives: [{
			directive: i1.TuiChip,
			inputs: ["size", "tuiSize"]
		}],
		ngImport: i0,
		template: "<button\n  atrButton\n  appearance=\"text\"\n  #action\n  class=\"action\"\n  type=\"button\"\n  [disabled]=\"blocked()\"\n  [attr.aria-pressed]=\"kind() === 'filter' ? selected() : null\"\n  (click)=\"activate()\"\n>\n  <ng-content select=\"[atrChipLeading]\" />{{ label() }}<ng-content />\n</button>\n@if (removable()) {\n  <button\n    atrIconButton\n    class=\"remove\"\n    type=\"button\"\n    [disabled]=\"blocked()\"\n    [attr.aria-label]=\"'Remove ' + label()\"\n    (click)=\"remove()\"\n  >\n    <atr-icon name=\"close\" size=\"small\" />\n  </button>\n}\n",
		styles: ["[tuiChip].atr-chip{--atr-comp-button-container-radius: var(--atr-comp-chip-shape);--atr-comp-button-container-padding-inline: var(--atr-comp-chip-padding);--atr-comp-button-text-label-color: currentcolor;--atr-comp-icon-button-icon-color: currentcolor;display:inline-flex;align-items:center;box-sizing:border-box;border:var(--atr-ref-border-width-thin) solid var(--atr-comp-chip-border-color);border-radius:var(--atr-comp-chip-shape);background:var(--atr-comp-chip-container-color);color:var(--atr-comp-chip-label-color);overflow:hidden}[tuiChip].atr-chip[data-selected=true]{background:var(--atr-comp-chip-selected-container-color);color:var(--atr-comp-chip-selected-label-color)}@media(forced-colors:active){[tuiChip].atr-chip{border-color:ButtonText}[tuiChip].atr-chip[data-selected=true]{border-color:Highlight}}\n"],
		dependencies: [
			{
				kind: "component",
				type: AtralumeButton,
				selector: "button[atrButton], a[atrButton]",
				inputs: [
					"appearance",
					"size",
					"disabled",
					"loading",
					"fullWidth",
					"tabindex"
				]
			},
			{
				kind: "directive",
				type: AtralumeIconButton,
				selector: "button[atrIconButton]",
				inputs: ["appearance", "size"]
			},
			{
				kind: "component",
				type: AtralumeIcon,
				selector: "atr-icon",
				inputs: [
					"name",
					"size",
					"decorative",
					"label",
					"engine"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush,
		encapsulation: i0.ViewEncapsulation.None
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeChip,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-chip",
			standalone: true,
			imports: [
				AtralumeButton,
				AtralumeIconButton,
				AtralumeIcon
			],
			providers: [provideAtralumeIcons([closeIcon])],
			hostDirectives: [{
				directive: TuiChip,
				inputs: ["size: tuiSize"]
			}],
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			host: {
				class: "atr-chip",
				"[attr.tuiChip]": "\"\"",
				"[attr.data-selected]": "selected()",
				"[attr.data-value]": "value()"
			},
			template: "<button\n  atrButton\n  appearance=\"text\"\n  #action\n  class=\"action\"\n  type=\"button\"\n  [disabled]=\"blocked()\"\n  [attr.aria-pressed]=\"kind() === 'filter' ? selected() : null\"\n  (click)=\"activate()\"\n>\n  <ng-content select=\"[atrChipLeading]\" />{{ label() }}<ng-content />\n</button>\n@if (removable()) {\n  <button\n    atrIconButton\n    class=\"remove\"\n    type=\"button\"\n    [disabled]=\"blocked()\"\n    [attr.aria-label]=\"'Remove ' + label()\"\n    (click)=\"remove()\"\n  >\n    <atr-icon name=\"close\" size=\"small\" />\n  </button>\n}\n",
			styles: ["[tuiChip].atr-chip{--atr-comp-button-container-radius: var(--atr-comp-chip-shape);--atr-comp-button-container-padding-inline: var(--atr-comp-chip-padding);--atr-comp-button-text-label-color: currentcolor;--atr-comp-icon-button-icon-color: currentcolor;display:inline-flex;align-items:center;box-sizing:border-box;border:var(--atr-ref-border-width-thin) solid var(--atr-comp-chip-border-color);border-radius:var(--atr-comp-chip-shape);background:var(--atr-comp-chip-container-color);color:var(--atr-comp-chip-label-color);overflow:hidden}[tuiChip].atr-chip[data-selected=true]{background:var(--atr-comp-chip-selected-container-color);color:var(--atr-comp-chip-selected-label-color)}@media(forced-colors:active){[tuiChip].atr-chip{border-color:ButtonText}[tuiChip].atr-chip[data-selected=true]{border-color:Highlight}}\n"]
		}]
	}],
	propDecorators: {
		kind: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "kind",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		selected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selected",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["selectedChange"]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		removable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "removable",
				required: false
			}]
		}],
		removed: [{
			type: i0.Output,
			args: ["removed"]
		}],
		invoked: [{
			type: i0.Output,
			args: ["invoked"]
		}],
		button: [{
			type: i0.ViewChild,
			args: ["action", {
				read: ElementRef,
				isSignal: true
			}]
		}]
	}
});
var AtralumeChipSet = class AtralumeChipSet {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	selection = input("multiple", ...ngDevMode ? [{ debugName: "selection" }] : /* istanbul ignore next */ []);
	orientation = input("horizontal", ...ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	selectionChange = output();
	chips = contentChildren(AtralumeChip, ...ngDevMode ? [{ debugName: "chips" }] : /* istanbul ignore next */ []);
	element = inject(ElementRef);
	choose(value, selected) {
		if (this.selection() === "single" && selected) {
			for (const chip of this.chips()) if (chip.value() !== value) chip.selected.set(false);
		}
		this.selectionChange.emit(this.chips().filter((chip) => chip.selected()).map((chip) => chip.value()));
	}
	onKey(event) {
		const available = this.chips().filter((chip) => !chip.disabled());
		const active = available.findIndex((chip) => chip.value() === event.target.closest("atr-chip")?.getAttribute("data-value"));
		if (!available.length) return;
		const vertical = this.orientation() === "vertical", rtl = this.element.nativeElement.matches(":dir(rtl)");
		let index = active;
		if (event.key === "Home") index = 0;
		else if (event.key === "End") index = available.length - 1;
		else if (event.key === (vertical ? "ArrowDown" : rtl ? "ArrowLeft" : "ArrowRight")) index = (active + 1) % available.length;
		else if (event.key === (vertical ? "ArrowUp" : rtl ? "ArrowRight" : "ArrowLeft")) index = (active - 1 + available.length) % available.length;
		else return;
		event.preventDefault();
		available[index].focus();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeChipSet,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.4",
		type: AtralumeChipSet,
		isStandalone: true,
		selector: "atr-chip-set",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			selection: {
				classPropertyName: "selection",
				publicName: "selection",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { selectionChange: "selectionChange" },
		host: {
			attributes: { "role": "group" },
			listeners: { "keydown": "onKey($event)" },
			properties: {
				"attr.aria-label": "label()",
				"attr.data-orientation": "orientation()"
			},
			classAttribute: "atr-chip-set"
		},
		providers: [{
			provide: CHIP_SET,
			useExisting: forwardRef(() => AtralumeChipSet)
		}],
		queries: [{
			propertyName: "chips",
			predicate: AtralumeChip,
			isSignal: true
		}],
		ngImport: i0,
		template: "<ng-content />\n",
		styles: [":host{display:flex;flex-wrap:wrap;gap:var(--atr-comp-chip-gap);font-family:var(--atr-comp-chip-font-family)}:host([data-orientation=vertical]){flex-direction:column;align-items:flex-start}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeChipSet,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-chip-set",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: CHIP_SET,
				useExisting: forwardRef(() => AtralumeChipSet)
			}],
			host: {
				class: "atr-chip-set",
				role: "group",
				"[attr.aria-label]": "label()",
				"[attr.data-orientation]": "orientation()",
				"(keydown)": "onKey($event)"
			},
			template: "<ng-content />\n",
			styles: [":host{display:flex;flex-wrap:wrap;gap:var(--atr-comp-chip-gap);font-family:var(--atr-comp-chip-font-family)}:host([data-orientation=vertical]){flex-direction:column;align-items:flex-start}\n"]
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		selection: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selection",
				required: false
			}]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		selectionChange: [{
			type: i0.Output,
			args: ["selectionChange"]
		}],
		chips: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => AtralumeChip), { isSignal: true }]
		}]
	}
});
var AtralumeChipSetHarness = class extends ComponentHarness {
	static hostSelector = "atr-chip-set";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeChipHarness = class extends ComponentHarness {
	static hostSelector = "atr-chip";
	async getText() {
		return (await this.host()).text();
	}
	async isSelected() {
		return await (await this.host()).getAttribute("data-selected") === "true";
	}
	async select() {
		await (await this.locatorFor("button.action")()).click();
	}
	async remove() {
		await (await this.locatorFor("button.remove")()).click();
	}
};
export { AtralumeChip, AtralumeChipHarness, AtralumeChipSet, AtralumeChipSetHarness };

//# sourceMappingURL=osmanjimenez-atralume-chip.mjs.map