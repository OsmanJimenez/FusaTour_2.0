import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, computed, forwardRef, input, output, signal } from "@angular/core";
import * as i1 from "@angular/forms";
import { FormsModule, NG_VALUE_ACCESSOR } from "@angular/forms";
import { TuiFilter } from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeFilter = class AtralumeFilter {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	options = input([], ...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	size = input("m", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	optionTemplate = input(null, ...ngDevMode ? [{ debugName: "optionTemplate" }] : /* istanbul ignore next */ []);
	selectionChange = output();
	cleared = output();
	selected = signal([], ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	disabled = signal(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	content = computed(() => this.optionTemplate() ?? ((context) => context.$implicit.label), ...ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []);
	badgeHandler = (option) => option.badge ?? null;
	disabledItemHandler = (option) => !!option.disabled || this.disabled();
	onChange = () => void 0;
	onTouched = () => void 0;
	writeValue(value) {
		const selected = new Set(value ?? []);
		this.selected.set(this.options().filter((option) => selected.has(option.value)));
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	setDisabledState(disabled) {
		this.disabled.set(disabled);
	}
	update(value) {
		this.selected.set(value);
		const selection = value.map((option) => option.value);
		this.onChange(selection);
		this.onTouched();
		this.selectionChange.emit(selection);
	}
	clear() {
		if (this.disabled()) return;
		this.update([]);
		this.cleared.emit();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeFilter,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeFilter,
		isStandalone: true,
		selector: "atr-filter",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			options: {
				classPropertyName: "options",
				publicName: "options",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			optionTemplate: {
				classPropertyName: "optionTemplate",
				publicName: "optionTemplate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			selectionChange: "selectionChange",
			cleared: "cleared"
		},
		host: {
			properties: { "attr.aria-label": "label()" },
			classAttribute: "atr-filter"
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => AtralumeFilter),
			multi: true
		}],
		ngImport: i0,
		template: "<div class=\"atr-filter__header\">\n  <span>{{ label() }}</span\n  ><button\n    type=\"button\"\n    class=\"atr-filter__clear\"\n    [disabled]=\"disabled() || !selected().length\"\n    (click)=\"clear()\"\n  >\n    Clear\n  </button>\n</div>\n<tui-filter\n  [items]=\"options()\"\n  [size]=\"size()\"\n  [content]=\"content()\"\n  [badgeHandler]=\"badgeHandler\"\n  [disabledItemHandler]=\"disabledItemHandler\"\n  [ngModel]=\"selected()\"\n  [ngModelOptions]=\"{ standalone: true }\"\n  (ngModelChange)=\"update($event)\"\n/>\n",
		styles: [":host{color:var(--atr-comp-filter-label-color);display:block}.atr-filter__header{align-items:center;display:flex;font-weight:600;gap:var(--atr-comp-filter-gap);justify-content:space-between;margin-block-end:var(--atr-comp-filter-gap)}.atr-filter__clear{background:transparent;border:0;color:var(--atr-sys-color-primary);cursor:pointer;font:inherit;min-block-size:var(--atr-sys-touch-target-minimum);padding-inline:var(--atr-sys-spacing-sm)}.atr-filter__clear:focus-visible{outline:var(--atr-sys-focus-ring-width) var(--atr-sys-focus-ring-style) var(--atr-sys-color-focus);outline-offset:var(--atr-sys-focus-ring-offset)}.atr-filter__clear:disabled{color:var(--atr-sys-color-on-surface-variant);cursor:not-allowed}\n"],
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "component",
				type: TuiFilter,
				selector: "tui-filter",
				inputs: [
					"items",
					"size",
					"badgeHandler",
					"content"
				],
				outputs: ["toggledItem"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeFilter,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-filter",
			standalone: true,
			imports: [FormsModule, TuiFilter],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => AtralumeFilter),
				multi: true
			}],
			host: {
				class: "atr-filter",
				"[attr.aria-label]": "label()"
			},
			template: "<div class=\"atr-filter__header\">\n  <span>{{ label() }}</span\n  ><button\n    type=\"button\"\n    class=\"atr-filter__clear\"\n    [disabled]=\"disabled() || !selected().length\"\n    (click)=\"clear()\"\n  >\n    Clear\n  </button>\n</div>\n<tui-filter\n  [items]=\"options()\"\n  [size]=\"size()\"\n  [content]=\"content()\"\n  [badgeHandler]=\"badgeHandler\"\n  [disabledItemHandler]=\"disabledItemHandler\"\n  [ngModel]=\"selected()\"\n  [ngModelOptions]=\"{ standalone: true }\"\n  (ngModelChange)=\"update($event)\"\n/>\n",
			styles: [":host{color:var(--atr-comp-filter-label-color);display:block}.atr-filter__header{align-items:center;display:flex;font-weight:600;gap:var(--atr-comp-filter-gap);justify-content:space-between;margin-block-end:var(--atr-comp-filter-gap)}.atr-filter__clear{background:transparent;border:0;color:var(--atr-sys-color-primary);cursor:pointer;font:inherit;min-block-size:var(--atr-sys-touch-target-minimum);padding-inline:var(--atr-sys-spacing-sm)}.atr-filter__clear:focus-visible{outline:var(--atr-sys-focus-ring-width) var(--atr-sys-focus-ring-style) var(--atr-sys-color-focus);outline-offset:var(--atr-sys-focus-ring-offset)}.atr-filter__clear:disabled{color:var(--atr-sys-color-on-surface-variant);cursor:not-allowed}\n"]
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		optionTemplate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "optionTemplate",
				required: false
			}]
		}],
		selectionChange: [{
			type: i0.Output,
			args: ["selectionChange"]
		}],
		cleared: [{
			type: i0.Output,
			args: ["cleared"]
		}]
	}
});
var AtralumeFilterHarness = class extends ComponentHarness {
	static hostSelector = "atr-filter";
	async select(label) {
		await (await this.locatorFor(`label:has-text("${label}") input`)()).click();
	}
	async clear() {
		await (await this.locatorFor(".atr-filter__clear")()).click();
	}
};
export { AtralumeFilter, AtralumeFilterHarness };

//# sourceMappingURL=osmanjimenez-atralume-filter.mjs.map