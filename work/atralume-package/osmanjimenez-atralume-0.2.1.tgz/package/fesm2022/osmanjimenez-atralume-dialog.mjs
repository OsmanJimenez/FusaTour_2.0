import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, Directive, Injectable, InjectionToken, Injector, TemplateRef, inject, input } from "@angular/core";
import { NgTemplateOutlet } from "@angular/common";
import { Subject } from "rxjs";
import { TuiDialogService } from "@taiga-ui/core";
import { PolymorpheusComponent } from "@taiga-ui/polymorpheus";
import { ɵAtralumeOverlayInfrastructure } from "@osmanjimenez/atralume";
import { ComponentHarness, TestKey } from "@angular/cdk/testing";
var AtralumeDialogActions = class AtralumeDialogActions {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeDialogActions,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeDialogActions,
		isStandalone: true,
		selector: "[atrDialogActions]",
		host: { classAttribute: "atr-dialog-actions" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeDialogActions,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrDialogActions]",
			standalone: true,
			host: { class: "atr-dialog-actions" }
		}]
	}]
});
const ATR_DIALOG_DATA = new InjectionToken("AtralumeDialog data");
const ATR_DIALOG_TEMPLATE = new InjectionToken("AtralumeDialog template");
var AtralumeDialogRef = class {
	afterClosed;
	closeFn;
	constructor(afterClosed, closeFn) {
		this.afterClosed = afterClosed;
		this.closeFn = closeFn;
	}
	close(result) {
		this.closeFn(result);
	}
};
var AtralumeDialogTemplateHost = class AtralumeDialogTemplateHost {
	template = inject(ATR_DIALOG_TEMPLATE);
	injector = inject(Injector);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeDialogTemplateHost,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeDialogTemplateHost,
		isStandalone: true,
		selector: "atr-dialog-template-host",
		ngImport: i0,
		template: `<ng-container *ngTemplateOutlet="template; injector: injector" />`,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: NgTemplateOutlet,
			selector: "[ngTemplateOutlet]",
			inputs: [
				"ngTemplateOutletContext",
				"ngTemplateOutlet",
				"ngTemplateOutletInjector"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeDialogTemplateHost,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-dialog-template-host",
			standalone: true,
			imports: [NgTemplateOutlet],
			template: `<ng-container *ngTemplateOutlet="template; injector: injector" />`,
			changeDetection: ChangeDetectionStrategy.OnPush
		}]
	}]
});
var AtralumeDialog = class AtralumeDialog {
	dialogs = inject(TuiDialogService);
	injector = inject(Injector);
	overlays = inject(ɵAtralumeOverlayInfrastructure);
	open(content, config = {}) {
		const afterClosed = new Subject();
		let subscription;
		let closed = false;
		const finish = (result) => {
			if (closed) return;
			closed = true;
			subscription?.unsubscribe();
			subscription = void 0;
			afterClosed.next(result);
			afterClosed.complete();
		};
		const dialogRef = new AtralumeDialogRef(afterClosed.asObservable(), (result) => finish(result));
		const providers = [{
			provide: AtralumeDialogRef,
			useValue: dialogRef
		}, {
			provide: ATR_DIALOG_DATA,
			useValue: config.data
		}];
		let polyContent;
		if (content instanceof TemplateRef) {
			const templateInjector = Injector.create({
				parent: config.injector ?? this.injector,
				providers: [...providers, {
					provide: ATR_DIALOG_TEMPLATE,
					useValue: content
				}]
			});
			polyContent = new PolymorpheusComponent(AtralumeDialogTemplateHost, templateInjector);
		} else polyContent = new PolymorpheusComponent(content, Injector.create({
			parent: config.injector ?? this.injector,
			providers
		}));
		subscription = this.dialogs.open(polyContent, {
			label: config.label ?? "",
			dismissible: !config.disableClose,
			closable: config.closable ?? !config.disableClose,
			size: config.size === void 0 ? "m" : config.size,
			data: config.data,
			appearance: config.appearance ?? "atr-dialog"
		}).subscribe({
			next: (result) => finish(result),
			complete: () => finish(void 0),
			error: () => finish(void 0)
		});
		queueMicrotask(() => this.applyPortalChrome(config));
		config.owner?.onDestroy(() => dialogRef.close());
		return dialogRef;
	}
	applyPortalChrome(config) {
		if (!this.overlays.browser) return;
		let seen = false;
		const bind = () => {
			const dialogs = document.querySelectorAll("tui-modal[role=\"dialog\"], tui-modal[role=\"alertdialog\"]");
			const modal = dialogs.item(dialogs.length - 1);
			if (!modal) return false;
			seen = true;
			const panel = modal.querySelector(`tui-dialog[data-appearance="${config.appearance ?? "atr-dialog"}"]`) ?? modal;
			this.overlays.decorate(panel, config.origin, "dialog", config.contextClasses ?? []);
			this.overlays.decorate(modal, config.origin, "dialog");
			if (config.labelledBy && modal.ownerDocument.getElementById(config.labelledBy)) modal.setAttribute("aria-labelledby", config.labelledBy);
			if (config.describedBy && modal.ownerDocument.getElementById(config.describedBy)) modal.setAttribute("aria-describedby", config.describedBy);
			if (config.role) modal.setAttribute("role", config.role);
			return modal.isConnected;
		};
		bind();
		let attempts = 0;
		const timer = globalThis.setInterval(() => {
			attempts += 1;
			const connected = bind();
			if (attempts >= 60 || seen && !connected) globalThis.clearInterval(timer);
		}, 16);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeDialog,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeDialog,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeDialog,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
var AtralumeDialogClose = class AtralumeDialogClose {
	atrDialogClose = input(...ngDevMode ? [void 0, { debugName: "atrDialogClose" }] : /* istanbul ignore next */ []);
	ref = inject(AtralumeDialogRef);
	close() {
		this.ref.close(this.atrDialogClose());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeDialogClose,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeDialogClose,
		isStandalone: true,
		selector: "button[atrDialogClose]",
		inputs: { atrDialogClose: {
			classPropertyName: "atrDialogClose",
			publicName: "atrDialogClose",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: { listeners: { "click": "close()" } },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeDialogClose,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[atrDialogClose]",
			standalone: true,
			host: { "(click)": "close()" }
		}]
	}],
	propDecorators: { atrDialogClose: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "atrDialogClose",
			required: false
		}]
	}] }
});
var AtralumeDialogContent = class AtralumeDialogContent {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeDialogContent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeDialogContent,
		isStandalone: true,
		selector: "[atrDialogContent]",
		host: { classAttribute: "atr-dialog-content" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeDialogContent,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrDialogContent]",
			standalone: true,
			host: { class: "atr-dialog-content" }
		}]
	}]
});
var AtralumeDialogTitle = class AtralumeDialogTitle {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeDialogTitle,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeDialogTitle,
		isStandalone: true,
		selector: "[atrDialogTitle]",
		host: { classAttribute: "atr-dialog-title" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeDialogTitle,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrDialogTitle]",
			standalone: true,
			host: { class: "atr-dialog-title" }
		}]
	}]
});
var AtralumeDialogHarness = class extends ComponentHarness {
	static hostSelector = ".atr-dialog-panel [role=\"dialog\"],.atr-dialog-panel [role=\"alertdialog\"]";
	async getText() {
		return (await this.host()).text();
	}
	async getAccessibleName() {
		return (await this.host()).getAttribute("aria-label");
	}
	async pressEscape() {
		await (await this.host()).sendKeys(TestKey.ESCAPE);
	}
};
var AtralumeDialogActionsHarness = class extends ComponentHarness {
	static hostSelector = ".atr-dialog-actions";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeDialogCloseHarness = class extends ComponentHarness {
	static hostSelector = ".atr-dialog-close";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeDialogContentHarness = class extends ComponentHarness {
	static hostSelector = ".atr-dialog-content";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeDialogTitleHarness = class extends ComponentHarness {
	static hostSelector = ".atr-dialog-title";
	async getText() {
		return (await this.host()).text();
	}
};
export { ATR_DIALOG_DATA, AtralumeDialog, AtralumeDialogActions, AtralumeDialogActionsHarness, AtralumeDialogClose, AtralumeDialogCloseHarness, AtralumeDialogContent, AtralumeDialogContentHarness, AtralumeDialogHarness, AtralumeDialogRef, AtralumeDialogTitle, AtralumeDialogTitleHarness };

//# sourceMappingURL=osmanjimenez-atralume-dialog.mjs.map