import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, booleanAttribute, computed, effect, input, model, untracked } from "@angular/core";
import { TuiPagination } from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumePagination = class AtralumePagination {
	label = input("Pagination", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	page = model(1, ...ngDevMode ? [{ debugName: "page" }] : /* istanbul ignore next */ []);
	pageCount = input(1, ...ngDevMode ? [{ debugName: "pageCount" }] : /* istanbul ignore next */ []);
	siblingCount = input(1, ...ngDevMode ? [{ debugName: "siblingCount" }] : /* istanbul ignore next */ []);
	loading = input(false, {
		...ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	href = input(null, ...ngDevMode ? [{ debugName: "href" }] : /* istanbul ignore next */ []);
	total = computed(() => {
		const count = this.pageCount();
		if (!Number.isInteger(count) || count < 1) throw new Error("Pagination pageCount must be a positive integer.");
		return count;
	}, ...ngDevMode ? [{ debugName: "total" }] : /* istanbul ignore next */ []);
	index = computed(() => Math.max(0, Math.min(this.total() - 1, (Math.trunc(this.page()) || 1) - 1)), ...ngDevMode ? [{ debugName: "index" }] : /* istanbul ignore next */ []);
	activePadding = computed(() => Math.max(0, Math.trunc(this.siblingCount())), ...ngDevMode ? [{ debugName: "activePadding" }] : /* istanbul ignore next */ []);
	blocked = computed(() => this.disabled() || this.loading(), ...ngDevMode ? [{ debugName: "blocked" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			const next = this.index() + 1;
			untracked(() => {
				if (this.page() !== next) this.page.set(next);
			});
		});
	}
	onIndex(index) {
		this.page.set(index + 1);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumePagination,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumePagination,
		isStandalone: true,
		selector: "atr-pagination",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			page: {
				classPropertyName: "page",
				publicName: "page",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pageCount: {
				classPropertyName: "pageCount",
				publicName: "pageCount",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			siblingCount: {
				classPropertyName: "siblingCount",
				publicName: "siblingCount",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			loading: {
				classPropertyName: "loading",
				publicName: "loading",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			href: {
				classPropertyName: "href",
				publicName: "href",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { page: "pageChange" },
		host: { classAttribute: "atr-pagination" },
		ngImport: i0,
		template: "<nav [attr.aria-label]=\"label()\" [attr.aria-busy]=\"loading() ? 'true' : null\">\n  <tui-pagination\n    [length]=\"total()\"\n    [index]=\"index()\"\n    (indexChange)=\"onIndex($event)\"\n    [disabled]=\"blocked()\"\n    [activePadding]=\"activePadding()\"\n    [sidePadding]=\"1\"\n  />\n</nav>\n",
		styles: [":host{display:block;min-inline-size:0}\n"],
		dependencies: [{
			kind: "component",
			type: TuiPagination,
			selector: "tui-pagination",
			inputs: [
				"length",
				"focusable",
				"size",
				"disabled",
				"activePadding",
				"sidePadding",
				"content",
				"index"
			],
			outputs: ["indexChange"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumePagination,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-pagination",
			standalone: true,
			imports: [TuiPagination],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "atr-pagination" },
			template: "<nav [attr.aria-label]=\"label()\" [attr.aria-busy]=\"loading() ? 'true' : null\">\n  <tui-pagination\n    [length]=\"total()\"\n    [index]=\"index()\"\n    (indexChange)=\"onIndex($event)\"\n    [disabled]=\"blocked()\"\n    [activePadding]=\"activePadding()\"\n    [sidePadding]=\"1\"\n  />\n</nav>\n",
			styles: [":host{display:block;min-inline-size:0}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		page: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "page",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["pageChange"]
		}],
		pageCount: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pageCount",
				required: false
			}]
		}],
		siblingCount: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "siblingCount",
				required: false
			}]
		}],
		loading: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "loading",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		href: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "href",
				required: false
			}]
		}]
	}
});
var AtralumePaginationHarness = class extends ComponentHarness {
	static hostSelector = "atr-pagination";
	async getText() {
		return (await this.host()).text();
	}
	async getCurrentPage() {
		return Number(await (await this.locatorFor("[aria-current=page]")()).text());
	}
};
export { AtralumePagination, AtralumePaginationHarness };

//# sourceMappingURL=osmanjimenez-atralume-pagination.mjs.map