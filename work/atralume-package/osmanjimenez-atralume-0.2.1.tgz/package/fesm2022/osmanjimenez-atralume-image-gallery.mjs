import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, ElementRef, booleanAttribute, computed, inject, input, model, output, viewChild } from "@angular/core";
import * as i2 from "@taiga-ui/cdk/directives/item";
import { TuiItem } from "@taiga-ui/cdk/directives/item";
import * as i1 from "@taiga-ui/core";
import { TuiCarousel } from "@taiga-ui/core";
import { AtralumeButton } from "@osmanjimenez/atralume/button";
import { AtralumeEmptyState } from "@osmanjimenez/atralume/empty-state";
import { AtralumeImage } from "@osmanjimenez/atralume/image";
import { AtralumeImagePreview } from "@osmanjimenez/atralume/image-preview";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeImageGallery = class AtralumeImageGallery {
	images = input([], ...ngDevMode ? [{ debugName: "images" }] : /* istanbul ignore next */ []);
	label = input("Image gallery", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	layout = input("carousel", ...ngDevMode ? [{ debugName: "layout" }] : /* istanbul ignore next */ []);
	activeIndex = model(0, ...ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []);
	loop = input(false, {
		...ngDevMode ? { debugName: "loop" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	showThumbnails = input(true, {
		...ngDevMode ? { debugName: "showThumbnails" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	showCaptions = input(true, {
		...ngDevMode ? { debugName: "showCaptions" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	previewable = input(true, {
		...ngDevMode ? { debugName: "previewable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	activeChange = output();
	preview = viewChild(AtralumeImagePreview, ...ngDevMode ? [{ debugName: "preview" }] : /* istanbul ignore next */ []);
	element = inject(ElementRef);
	max = computed(() => Math.max(0, this.images().length - 1), ...ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []);
	current = computed(() => this.images()[this.activeIndex()] ?? null, ...ngDevMode ? [{ debugName: "current" }] : /* istanbul ignore next */ []);
	previewImages = computed(() => this.images(), ...ngDevMode ? [{ debugName: "previewImages" }] : /* istanbul ignore next */ []);
	isMosaic = computed(() => this.layout() === "mosaic", ...ngDevMode ? [{ debugName: "isMosaic" }] : /* istanbul ignore next */ []);
	onIndex(index) {
		const next = Math.min(Math.max(0, index), this.max());
		this.activeIndex.set(next);
		this.activeChange.emit(next);
	}
	previous() {
		this.onIndex(this.activeIndex() <= 0 ? this.loop() ? this.max() : 0 : this.activeIndex() - 1);
	}
	next() {
		this.onIndex(this.activeIndex() >= this.max() ? this.loop() ? 0 : this.max() : this.activeIndex() + 1);
	}
	openPreview(index, origin) {
		this.onIndex(index);
		this.preview()?.open(origin.currentTarget instanceof HTMLElement ? origin.currentTarget : this.element.nativeElement);
	}
	selectTile(index, event) {
		this.onIndex(index);
		if (this.previewable()) this.openPreview(index, event);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeImageGallery,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeImageGallery,
		isStandalone: true,
		selector: "atr-image-gallery",
		inputs: {
			images: {
				classPropertyName: "images",
				publicName: "images",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			layout: {
				classPropertyName: "layout",
				publicName: "layout",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			activeIndex: {
				classPropertyName: "activeIndex",
				publicName: "activeIndex",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			loop: {
				classPropertyName: "loop",
				publicName: "loop",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showThumbnails: {
				classPropertyName: "showThumbnails",
				publicName: "showThumbnails",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showCaptions: {
				classPropertyName: "showCaptions",
				publicName: "showCaptions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			previewable: {
				classPropertyName: "previewable",
				publicName: "previewable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			activeIndex: "activeIndexChange",
			activeChange: "activeChange"
		},
		host: {
			properties: {
				"attr.aria-label": "label()",
				"attr.data-layout": "layout()"
			},
			classAttribute: "atr-image-gallery"
		},
		viewQueries: [{
			propertyName: "preview",
			first: true,
			predicate: AtralumeImagePreview,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "@if (images().length) {\n  <section role=\"region\" [attr.aria-label]=\"label()\">\n    @if (isMosaic()) {\n      <ul class=\"atr-image-gallery__mosaic\">\n        @for (image of images(); track image.id; let index = $index) {\n          <li\n            class=\"atr-image-gallery__tile\"\n            [class.atr-image-gallery__tile--active]=\"index === activeIndex()\"\n          >\n            <article>\n              <atr-image\n                [src]=\"image.src\"\n                [fallbackSrc]=\"image.fallbackSrc ?? null\"\n                [alt]=\"image.alt\"\n                [width]=\"image.width ?? null\"\n                [height]=\"image.height ?? null\"\n                aspectRatio=\"landscape\"\n                [previewable]=\"previewable()\"\n                [previewLabel]=\"'Open preview for ' + (image.title || image.alt)\"\n                (previewRequested)=\"selectTile(index, $event)\"\n              />\n              @if (showCaptions() && (image.title || image.location || image.description || image.tags?.length)) {\n                <div class=\"atr-image-gallery__caption\">\n                  @if (image.location) {\n                    <p class=\"atr-image-gallery__location\">{{ image.location }}</p>\n                  }\n                  @if (image.title) {\n                    <h3>{{ image.title }}</h3>\n                  }\n                  @if (image.description) {\n                    <p class=\"atr-image-gallery__description\">\n                      {{ image.description }}\n                    </p>\n                  }\n                  @if (image.tags?.length) {\n                    <ul class=\"atr-image-gallery__tags\" aria-label=\"Tags\">\n                      @for (tag of image.tags; track tag) {\n                        <li>{{ tag }}</li>\n                      }\n                    </ul>\n                  }\n                </div>\n              }\n            </article>\n          </li>\n        }\n      </ul>\n    } @else {\n      <tui-carousel\n        [index]=\"activeIndex()\"\n        (indexChange)=\"onIndex($event)\"\n        [min]=\"0\"\n        [max]=\"max()\"\n      >\n        @for (image of images(); track image.id; let index = $index) {\n          <div *tuiItem class=\"atr-image-gallery__slide\">\n            <atr-image\n              [src]=\"image.src\"\n              [fallbackSrc]=\"image.fallbackSrc ?? null\"\n              [alt]=\"image.alt\"\n              [width]=\"image.width ?? null\"\n              [height]=\"image.height ?? null\"\n              aspectRatio=\"landscape\"\n              [previewable]=\"previewable()\"\n              [previewLabel]=\"'Open preview for ' + (image.title || image.alt)\"\n              (previewRequested)=\"openPreview(index, $event)\"\n            />\n            @if (showCaptions() && (image.title || image.location || image.description)) {\n              <div class=\"atr-image-gallery__caption atr-image-gallery__caption--slide\">\n                @if (image.location) {\n                  <p class=\"atr-image-gallery__location\">{{ image.location }}</p>\n                }\n                @if (image.title) {\n                  <h3>{{ image.title }}</h3>\n                }\n                @if (image.description) {\n                  <p class=\"atr-image-gallery__description\">\n                    {{ image.description }}\n                  </p>\n                }\n              </div>\n            }\n          </div>\n        }\n      </tui-carousel>\n      <div class=\"atr-image-gallery__controls\">\n        <button\n          atrButton\n          type=\"button\"\n          appearance=\"text\"\n          [disabled]=\"activeIndex() === 0 && !loop()\"\n          (click)=\"previous()\"\n        >\n          Previous\n        </button>\n        <span>{{ activeIndex() + 1 }} / {{ images().length }}</span>\n        <button\n          atrButton\n          type=\"button\"\n          appearance=\"text\"\n          [disabled]=\"activeIndex() === max() && !loop()\"\n          (click)=\"next()\"\n        >\n          Next\n        </button>\n      </div>\n      @if (showThumbnails()) {\n        <div\n          class=\"atr-image-gallery__thumbnails\"\n          role=\"tablist\"\n          [attr.aria-label]=\"'Choose ' + label()\"\n        >\n          @for (image of images(); track image.id; let index = $index) {\n            <button\n              type=\"button\"\n              role=\"tab\"\n              [attr.aria-selected]=\"index === activeIndex()\"\n              [attr.aria-label]=\"'View ' + image.alt\"\n              (click)=\"onIndex(index)\"\n            >\n              <img [src]=\"image.src\" [alt]=\"\" />\n            </button>\n          }\n        </div>\n      }\n    }\n  </section>\n  <atr-image-preview\n    [images]=\"previewImages()\"\n    [(activeIndex)]=\"activeIndex\"\n    [label]=\"label()\"\n    [showTrigger]=\"false\"\n  />\n} @else {\n  <atr-empty-state\n    title=\"No images available\"\n    description=\"Add image data to show a gallery.\"\n    appearance=\"compact\"\n  />\n}\n",
		styles: [":host{color:var(--atr-comp-image-gallery-label-color);display:block}tui-carousel{display:block}atr-image{inline-size:100%}.atr-image-gallery__slide{display:grid;gap:var(--atr-comp-image-gallery-gap)}.atr-image-gallery__controls{align-items:center;display:flex;gap:var(--atr-comp-image-gallery-gap);justify-content:space-between;margin-block:var(--atr-comp-image-gallery-gap)}.atr-image-gallery__thumbnails{display:flex;gap:var(--atr-comp-image-gallery-gap);overflow-x:auto;padding-block-end:var(--atr-comp-image-gallery-gap)}.atr-image-gallery__thumbnails button{background:transparent;border:0;border-radius:var(--atr-comp-image-gallery-shape);cursor:pointer;flex:0 0 4.5rem;min-block-size:var(--atr-sys-touch-target-minimum);overflow:hidden;padding:0}.atr-image-gallery__thumbnails button[aria-selected=true]{outline:var(--atr-comp-image-gallery-focus-ring-width) var(--atr-sys-focus-ring-style) var(--atr-comp-image-gallery-focus-ring-color);outline-offset:calc(-1 * var(--atr-comp-image-gallery-focus-ring-width))}.atr-image-gallery__thumbnails img{aspect-ratio:1;display:block;inline-size:100%;object-fit:cover}.atr-image-gallery__mosaic{display:grid;gap:var(--atr-comp-image-gallery-gap);grid-template-columns:repeat(auto-fit,minmax(min(100%,16rem),1fr));list-style:none;margin:0;padding:0}.atr-image-gallery__tile article{border-radius:var(--atr-comp-image-gallery-shape);display:grid;overflow:hidden}.atr-image-gallery__tile atr-image{background:var(--atr-sys-color-surface-variant)}.atr-image-gallery__tile--active article{outline:var(--atr-comp-image-gallery-focus-ring-width) var(--atr-sys-focus-ring-style) var(--atr-comp-image-gallery-focus-ring-color);outline-offset:calc(-1 * var(--atr-comp-image-gallery-focus-ring-width))}.atr-image-gallery__caption{display:grid;gap:.35rem;padding:var(--atr-sys-spacing-md)}.atr-image-gallery__tile article:has(.atr-image-gallery__caption){grid-template-rows:auto auto}.atr-image-gallery__caption h3{font-size:var(--atr-ref-font-size-18, 1.125rem);font-weight:var(--atr-ref-font-weight-bold, 700);letter-spacing:-.02em;line-height:1.2;margin:0}.atr-image-gallery__location{color:var(--atr-sys-color-primary);font-size:var(--atr-ref-font-size-12, .75rem);font-weight:var(--atr-ref-font-weight-bold, 700);letter-spacing:.04em;margin:0;text-transform:uppercase}.atr-image-gallery__description{color:var(--atr-sys-color-on-surface-variant);font-size:var(--atr-ref-font-size-14, .875rem);line-height:1.45;margin:0}.atr-image-gallery__tags{display:flex;flex-wrap:wrap;gap:.4rem;list-style:none;margin:.35rem 0 0;padding:0}.atr-image-gallery__tags li{background:var(--atr-sys-color-secondary-container);border-radius:var(--atr-sys-shape-full);color:var(--atr-sys-color-on-secondary-container);font-size:var(--atr-ref-font-size-12, .75rem);line-height:1;min-block-size:1.75rem;padding:.45rem .7rem}@media(width>=64rem){.atr-image-gallery__mosaic{grid-template-columns:repeat(12,minmax(0,1fr))}.atr-image-gallery__tile:nth-child(6n+1){grid-column:span 7;grid-row:span 2}.atr-image-gallery__tile:nth-child(6n+2),.atr-image-gallery__tile:nth-child(6n+3){grid-column:span 5}.atr-image-gallery__tile:nth-child(6n+4),.atr-image-gallery__tile:nth-child(6n+5),.atr-image-gallery__tile:nth-child(6n+6){grid-column:span 4}}@media(prefers-reduced-motion:reduce){.atr-image-gallery__tile article{transition:none}}@media(forced-colors:active){.atr-image-gallery__tile article,.atr-image-gallery__tags li{border:1px solid CanvasText}}\n"],
		dependencies: [
			{
				kind: "component",
				type: i1.TuiCarouselComponent,
				selector: "tui-carousel",
				inputs: [
					"index",
					"min",
					"max"
				],
				outputs: ["indexChange"]
			},
			{
				kind: "directive",
				type: i2.TuiItem,
				selector: "[tuiItem]"
			},
			{
				kind: "component",
				type: AtralumeButton,
				selector: "button[atrButton], a[atrButton]",
				inputs: [
					"appearance",
					"size",
					"disabled",
					"loading",
					"fullWidth",
					"tabindex"
				]
			},
			{
				kind: "component",
				type: AtralumeEmptyState,
				selector: "atr-empty-state",
				inputs: [
					"title",
					"description",
					"appearance"
				]
			},
			{
				kind: "component",
				type: AtralumeImage,
				selector: "atr-image",
				inputs: [
					"src",
					"alt",
					"fallbackSrc",
					"loading",
					"fit",
					"position",
					"aspectRatio",
					"width",
					"height",
					"previewable",
					"previewLabel"
				],
				outputs: ["stateChange", "previewRequested"]
			},
			{
				kind: "component",
				type: AtralumeImagePreview,
				selector: "atr-image-preview",
				inputs: [
					"images",
					"activeIndex",
					"label",
					"triggerLabel",
					"zoomable",
					"rotatable",
					"disabled",
					"showTrigger"
				],
				outputs: ["activeIndexChange", "closed"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeImageGallery,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-image-gallery",
			standalone: true,
			imports: [
				TuiCarousel,
				TuiItem,
				AtralumeButton,
				AtralumeEmptyState,
				AtralumeImage,
				AtralumeImagePreview
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "atr-image-gallery",
				"[attr.aria-label]": "label()",
				"[attr.data-layout]": "layout()"
			},
			template: "@if (images().length) {\n  <section role=\"region\" [attr.aria-label]=\"label()\">\n    @if (isMosaic()) {\n      <ul class=\"atr-image-gallery__mosaic\">\n        @for (image of images(); track image.id; let index = $index) {\n          <li\n            class=\"atr-image-gallery__tile\"\n            [class.atr-image-gallery__tile--active]=\"index === activeIndex()\"\n          >\n            <article>\n              <atr-image\n                [src]=\"image.src\"\n                [fallbackSrc]=\"image.fallbackSrc ?? null\"\n                [alt]=\"image.alt\"\n                [width]=\"image.width ?? null\"\n                [height]=\"image.height ?? null\"\n                aspectRatio=\"landscape\"\n                [previewable]=\"previewable()\"\n                [previewLabel]=\"'Open preview for ' + (image.title || image.alt)\"\n                (previewRequested)=\"selectTile(index, $event)\"\n              />\n              @if (showCaptions() && (image.title || image.location || image.description || image.tags?.length)) {\n                <div class=\"atr-image-gallery__caption\">\n                  @if (image.location) {\n                    <p class=\"atr-image-gallery__location\">{{ image.location }}</p>\n                  }\n                  @if (image.title) {\n                    <h3>{{ image.title }}</h3>\n                  }\n                  @if (image.description) {\n                    <p class=\"atr-image-gallery__description\">\n                      {{ image.description }}\n                    </p>\n                  }\n                  @if (image.tags?.length) {\n                    <ul class=\"atr-image-gallery__tags\" aria-label=\"Tags\">\n                      @for (tag of image.tags; track tag) {\n                        <li>{{ tag }}</li>\n                      }\n                    </ul>\n                  }\n                </div>\n              }\n            </article>\n          </li>\n        }\n      </ul>\n    } @else {\n      <tui-carousel\n        [index]=\"activeIndex()\"\n        (indexChange)=\"onIndex($event)\"\n        [min]=\"0\"\n        [max]=\"max()\"\n      >\n        @for (image of images(); track image.id; let index = $index) {\n          <div *tuiItem class=\"atr-image-gallery__slide\">\n            <atr-image\n              [src]=\"image.src\"\n              [fallbackSrc]=\"image.fallbackSrc ?? null\"\n              [alt]=\"image.alt\"\n              [width]=\"image.width ?? null\"\n              [height]=\"image.height ?? null\"\n              aspectRatio=\"landscape\"\n              [previewable]=\"previewable()\"\n              [previewLabel]=\"'Open preview for ' + (image.title || image.alt)\"\n              (previewRequested)=\"openPreview(index, $event)\"\n            />\n            @if (showCaptions() && (image.title || image.location || image.description)) {\n              <div class=\"atr-image-gallery__caption atr-image-gallery__caption--slide\">\n                @if (image.location) {\n                  <p class=\"atr-image-gallery__location\">{{ image.location }}</p>\n                }\n                @if (image.title) {\n                  <h3>{{ image.title }}</h3>\n                }\n                @if (image.description) {\n                  <p class=\"atr-image-gallery__description\">\n                    {{ image.description }}\n                  </p>\n                }\n              </div>\n            }\n          </div>\n        }\n      </tui-carousel>\n      <div class=\"atr-image-gallery__controls\">\n        <button\n          atrButton\n          type=\"button\"\n          appearance=\"text\"\n          [disabled]=\"activeIndex() === 0 && !loop()\"\n          (click)=\"previous()\"\n        >\n          Previous\n        </button>\n        <span>{{ activeIndex() + 1 }} / {{ images().length }}</span>\n        <button\n          atrButton\n          type=\"button\"\n          appearance=\"text\"\n          [disabled]=\"activeIndex() === max() && !loop()\"\n          (click)=\"next()\"\n        >\n          Next\n        </button>\n      </div>\n      @if (showThumbnails()) {\n        <div\n          class=\"atr-image-gallery__thumbnails\"\n          role=\"tablist\"\n          [attr.aria-label]=\"'Choose ' + label()\"\n        >\n          @for (image of images(); track image.id; let index = $index) {\n            <button\n              type=\"button\"\n              role=\"tab\"\n              [attr.aria-selected]=\"index === activeIndex()\"\n              [attr.aria-label]=\"'View ' + image.alt\"\n              (click)=\"onIndex(index)\"\n            >\n              <img [src]=\"image.src\" [alt]=\"\" />\n            </button>\n          }\n        </div>\n      }\n    }\n  </section>\n  <atr-image-preview\n    [images]=\"previewImages()\"\n    [(activeIndex)]=\"activeIndex\"\n    [label]=\"label()\"\n    [showTrigger]=\"false\"\n  />\n} @else {\n  <atr-empty-state\n    title=\"No images available\"\n    description=\"Add image data to show a gallery.\"\n    appearance=\"compact\"\n  />\n}\n",
			styles: [":host{color:var(--atr-comp-image-gallery-label-color);display:block}tui-carousel{display:block}atr-image{inline-size:100%}.atr-image-gallery__slide{display:grid;gap:var(--atr-comp-image-gallery-gap)}.atr-image-gallery__controls{align-items:center;display:flex;gap:var(--atr-comp-image-gallery-gap);justify-content:space-between;margin-block:var(--atr-comp-image-gallery-gap)}.atr-image-gallery__thumbnails{display:flex;gap:var(--atr-comp-image-gallery-gap);overflow-x:auto;padding-block-end:var(--atr-comp-image-gallery-gap)}.atr-image-gallery__thumbnails button{background:transparent;border:0;border-radius:var(--atr-comp-image-gallery-shape);cursor:pointer;flex:0 0 4.5rem;min-block-size:var(--atr-sys-touch-target-minimum);overflow:hidden;padding:0}.atr-image-gallery__thumbnails button[aria-selected=true]{outline:var(--atr-comp-image-gallery-focus-ring-width) var(--atr-sys-focus-ring-style) var(--atr-comp-image-gallery-focus-ring-color);outline-offset:calc(-1 * var(--atr-comp-image-gallery-focus-ring-width))}.atr-image-gallery__thumbnails img{aspect-ratio:1;display:block;inline-size:100%;object-fit:cover}.atr-image-gallery__mosaic{display:grid;gap:var(--atr-comp-image-gallery-gap);grid-template-columns:repeat(auto-fit,minmax(min(100%,16rem),1fr));list-style:none;margin:0;padding:0}.atr-image-gallery__tile article{border-radius:var(--atr-comp-image-gallery-shape);display:grid;overflow:hidden}.atr-image-gallery__tile atr-image{background:var(--atr-sys-color-surface-variant)}.atr-image-gallery__tile--active article{outline:var(--atr-comp-image-gallery-focus-ring-width) var(--atr-sys-focus-ring-style) var(--atr-comp-image-gallery-focus-ring-color);outline-offset:calc(-1 * var(--atr-comp-image-gallery-focus-ring-width))}.atr-image-gallery__caption{display:grid;gap:.35rem;padding:var(--atr-sys-spacing-md)}.atr-image-gallery__tile article:has(.atr-image-gallery__caption){grid-template-rows:auto auto}.atr-image-gallery__caption h3{font-size:var(--atr-ref-font-size-18, 1.125rem);font-weight:var(--atr-ref-font-weight-bold, 700);letter-spacing:-.02em;line-height:1.2;margin:0}.atr-image-gallery__location{color:var(--atr-sys-color-primary);font-size:var(--atr-ref-font-size-12, .75rem);font-weight:var(--atr-ref-font-weight-bold, 700);letter-spacing:.04em;margin:0;text-transform:uppercase}.atr-image-gallery__description{color:var(--atr-sys-color-on-surface-variant);font-size:var(--atr-ref-font-size-14, .875rem);line-height:1.45;margin:0}.atr-image-gallery__tags{display:flex;flex-wrap:wrap;gap:.4rem;list-style:none;margin:.35rem 0 0;padding:0}.atr-image-gallery__tags li{background:var(--atr-sys-color-secondary-container);border-radius:var(--atr-sys-shape-full);color:var(--atr-sys-color-on-secondary-container);font-size:var(--atr-ref-font-size-12, .75rem);line-height:1;min-block-size:1.75rem;padding:.45rem .7rem}@media(width>=64rem){.atr-image-gallery__mosaic{grid-template-columns:repeat(12,minmax(0,1fr))}.atr-image-gallery__tile:nth-child(6n+1){grid-column:span 7;grid-row:span 2}.atr-image-gallery__tile:nth-child(6n+2),.atr-image-gallery__tile:nth-child(6n+3){grid-column:span 5}.atr-image-gallery__tile:nth-child(6n+4),.atr-image-gallery__tile:nth-child(6n+5),.atr-image-gallery__tile:nth-child(6n+6){grid-column:span 4}}@media(prefers-reduced-motion:reduce){.atr-image-gallery__tile article{transition:none}}@media(forced-colors:active){.atr-image-gallery__tile article,.atr-image-gallery__tags li{border:1px solid CanvasText}}\n"]
		}]
	}],
	propDecorators: {
		images: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "images",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		layout: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "layout",
				required: false
			}]
		}],
		activeIndex: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "activeIndex",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["activeIndexChange"]
		}],
		loop: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "loop",
				required: false
			}]
		}],
		showThumbnails: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showThumbnails",
				required: false
			}]
		}],
		showCaptions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showCaptions",
				required: false
			}]
		}],
		previewable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "previewable",
				required: false
			}]
		}],
		activeChange: [{
			type: i0.Output,
			args: ["activeChange"]
		}],
		preview: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => AtralumeImagePreview), { isSignal: true }]
		}]
	}
});
var AtralumeImageGalleryHarness = class extends ComponentHarness {
	static hostSelector = "atr-image-gallery";
	async next() {
		await (await this.locatorFor("button:has-text(\"Next\")")()).click();
	}
	async getIndex() {
		return (await this.locatorFor(".atr-image-gallery__controls span")()).text();
	}
	async getTileCount() {
		return (await this.locatorForAll(".atr-image-gallery__tile")()).length;
	}
	async getCaptionText() {
		const captions = await this.locatorForAll(".atr-image-gallery__caption")();
		return (await Promise.all(captions.map((caption) => caption.text()))).join(" ").trim();
	}
};
export { AtralumeImageGallery, AtralumeImageGalleryHarness };

//# sourceMappingURL=osmanjimenez-atralume-image-gallery.mjs.map