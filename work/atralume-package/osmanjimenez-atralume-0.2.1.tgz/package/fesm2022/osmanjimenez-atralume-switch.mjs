import * as i0 from "@angular/core";
import { Directive, afterNextRender, inject } from "@angular/core";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";
import { NgControl } from "@angular/forms";
import { tuiInjectElement } from "@taiga-ui/cdk/utils/dom";
import * as i1 from "@taiga-ui/core/directives/appearance";
import { TuiAppearance, tuiAppearance } from "@taiga-ui/core/directives/appearance";
import { fromEvent } from "rxjs";
import { ComponentHarness } from "@angular/cdk/testing";
function switchAppearance(el) {
	return el.checked ? "primary" : "secondary";
}
var AtralumeSwitch = class AtralumeSwitch {
	el = tuiInjectElement();
	appearance = tuiAppearance(switchAppearance(this.el));
	control = inject(NgControl, {
		optional: true,
		self: true
	});
	constructor() {
		const sync = () => this.appearance.set(switchAppearance(this.el));
		afterNextRender(() => {
			sync();
			setTimeout(sync);
		});
		this.control?.valueChanges?.pipe(takeUntilDestroyed()).subscribe(() => sync());
		fromEvent(this.el, "change").pipe(takeUntilDestroyed()).subscribe(sync);
		fromEvent(this.el, "click").pipe(takeUntilDestroyed()).subscribe(sync);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeSwitch,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeSwitch,
		isStandalone: true,
		selector: "input[type=\"checkbox\"][atrSwitch]",
		host: {
			attributes: { "role": "switch" },
			properties: { "attr.tuiSwitch": "\"\"" },
			classAttribute: "atr-switch"
		},
		hostDirectives: [{
			directive: i1.TuiAppearance,
			inputs: [
				"tuiAppearanceState",
				"tuiAppearanceState",
				"tuiAppearanceFocus",
				"tuiAppearanceFocus",
				"tuiAppearanceMode",
				"tuiAppearanceMode"
			]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeSwitch,
	decorators: [{
		type: Directive,
		args: [{
			selector: "input[type=\"checkbox\"][atrSwitch]",
			standalone: true,
			hostDirectives: [{
				directive: TuiAppearance,
				inputs: [
					"tuiAppearanceState",
					"tuiAppearanceFocus",
					"tuiAppearanceMode"
				]
			}],
			host: {
				class: "atr-switch",
				role: "switch",
				"[attr.tuiSwitch]": "\"\""
			}
		}]
	}],
	ctorParameters: () => []
});
var AtralumeSwitchHarness = class extends ComponentHarness {
	static hostSelector = ".atr-switch";
	async isChecked() {
		return (await this.host()).getProperty("checked");
	}
	async toggle() {
		if (!await this.isDisabled()) await (await this.host()).click();
	}
	async check() {
		if (!await this.isChecked()) await this.toggle();
	}
	async isDisabled() {
		return (await this.host()).getProperty("disabled");
	}
};
export { AtralumeSwitch, AtralumeSwitchHarness };

//# sourceMappingURL=osmanjimenez-atralume-switch.mjs.map