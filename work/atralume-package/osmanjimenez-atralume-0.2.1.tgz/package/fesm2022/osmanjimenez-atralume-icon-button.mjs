import * as i0 from "@angular/core";
import { Directive, input } from "@angular/core";
import * as i1 from "@taiga-ui/core";
import { TuiButton } from "@taiga-ui/core";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeIconButton = class AtralumeIconButton {
	appearance = input("standard", ...ngDevMode ? [{ debugName: "appearance" }] : /* istanbul ignore next */ []);
	size = input("medium", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeIconButton,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeIconButton,
		isStandalone: true,
		selector: "button[atrIconButton]",
		inputs: {
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: {
				"attr.tuiIconButton": "\"\"",
				"attr.data-appearance": "appearance()",
				"attr.data-size": "size()"
			},
			classAttribute: "atr-icon-button"
		},
		hostDirectives: [{
			directive: i1.TuiButton,
			inputs: ["size", "tuiSize"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeIconButton,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[atrIconButton]",
			standalone: true,
			hostDirectives: [{
				directive: TuiButton,
				inputs: ["size: tuiSize"]
			}],
			host: {
				class: "atr-icon-button",
				"[attr.tuiIconButton]": "\"\"",
				"[attr.data-appearance]": "appearance()",
				"[attr.data-size]": "size()"
			}
		}]
	}],
	propDecorators: {
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}]
	}
});
var AtralumeIconButtonHarness = class extends ComponentHarness {
	static hostSelector = ".atr-icon-button";
	async isDisabled() {
		return (await this.host()).getProperty("disabled");
	}
	async click() {
		await (await this.host()).click();
	}
	async getAccessibleName() {
		const host = await this.host();
		const ids = (await host.getAttribute("aria-labelledby"))?.split(/\s+/);
		if (ids?.length) return (await Promise.all(ids.filter(Boolean).map(async (id) => {
			const label = await this.documentRootLocatorFactory().locatorForOptional("[id=" + JSON.stringify(id) + "]")();
			return label ? label.text() : "";
		}))).join(" ");
		return await host.getAttribute("aria-label") ?? await host.text();
	}
};
export { AtralumeIconButton, AtralumeIconButtonHarness };

//# sourceMappingURL=osmanjimenez-atralume-icon-button.mjs.map