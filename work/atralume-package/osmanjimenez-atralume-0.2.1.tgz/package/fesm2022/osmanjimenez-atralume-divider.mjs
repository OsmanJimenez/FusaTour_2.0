import * as i0 from "@angular/core";
import { Directive, booleanAttribute, input } from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeDivider = class AtralumeDivider {
	orientation = input("horizontal", ...ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []);
	inset = input("none", ...ngDevMode ? [{ debugName: "inset" }] : /* istanbul ignore next */ []);
	decorative = input(false, {
		...ngDevMode ? { debugName: "decorative" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeDivider,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeDivider,
		isStandalone: true,
		selector: "[atrDivider]",
		inputs: {
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			inset: {
				classPropertyName: "inset",
				publicName: "inset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			decorative: {
				classPropertyName: "decorative",
				publicName: "decorative",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: {
				"attr.data-orientation": "orientation()",
				"attr.data-inset": "inset()",
				"attr.role": "decorative() ? \"presentation\" : \"separator\"",
				"attr.aria-orientation": "decorative() ? null : orientation()",
				"attr.aria-hidden": "decorative() ? \"true\" : null"
			},
			classAttribute: "atr-divider"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeDivider,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrDivider]",
			standalone: true,
			host: {
				class: "atr-divider",
				"[attr.data-orientation]": "orientation()",
				"[attr.data-inset]": "inset()",
				"[attr.role]": "decorative() ? \"presentation\" : \"separator\"",
				"[attr.aria-orientation]": "decorative() ? null : orientation()",
				"[attr.aria-hidden]": "decorative() ? \"true\" : null"
			}
		}]
	}],
	propDecorators: {
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		inset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "inset",
				required: false
			}]
		}],
		decorative: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "decorative",
				required: false
			}]
		}]
	}
});
var AtralumeDividerHarness = class extends ComponentHarness {
	static hostSelector = ".atr-divider";
	async getOrientation() {
		return (await this.host()).getAttribute("data-orientation");
	}
	async isDecorative() {
		return await (await this.host()).getAttribute("aria-hidden") === "true";
	}
};
export { AtralumeDivider, AtralumeDividerHarness };

//# sourceMappingURL=osmanjimenez-atralume-divider.mjs.map