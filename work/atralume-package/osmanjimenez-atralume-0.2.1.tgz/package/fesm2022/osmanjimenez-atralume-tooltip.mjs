import * as i0 from "@angular/core";
import { Directive, booleanAttribute, input } from "@angular/core";
import * as i1 from "@taiga-ui/core";
import { TuiHintDirective } from "@taiga-ui/core";
import { ComponentHarness, TestKey } from "@angular/cdk/testing";
var AtralumeTooltip = class AtralumeTooltip {
	atrTooltip = input.required(...ngDevMode ? [{ debugName: "atrTooltip" }] : /* istanbul ignore next */ []);
	tooltipId = input.required(...ngDevMode ? [{ debugName: "tooltipId" }] : /* istanbul ignore next */ []);
	position = input("above", ...ngDevMode ? [{ debugName: "position" }] : /* istanbul ignore next */ []);
	showDelay = input(500, ...ngDevMode ? [{ debugName: "showDelay" }] : /* istanbul ignore next */ []);
	hideDelay = input(150, ...ngDevMode ? [{ debugName: "hideDelay" }] : /* istanbul ignore next */ []);
	tooltipDisabled = input(false, {
		...ngDevMode ? { debugName: "tooltipDisabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeTooltip,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeTooltip,
		isStandalone: true,
		selector: "[atrTooltip]",
		inputs: {
			atrTooltip: {
				classPropertyName: "atrTooltip",
				publicName: "atrTooltip",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			tooltipId: {
				classPropertyName: "tooltipId",
				publicName: "tooltipId",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			position: {
				classPropertyName: "position",
				publicName: "position",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showDelay: {
				classPropertyName: "showDelay",
				publicName: "showDelay",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hideDelay: {
				classPropertyName: "hideDelay",
				publicName: "hideDelay",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tooltipDisabled: {
				classPropertyName: "tooltipDisabled",
				publicName: "tooltipDisabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "atr-tooltip-trigger" },
		exportAs: ["atrTooltip"],
		hostDirectives: [{
			directive: i1.TuiHintDirective,
			inputs: ["tuiHint", "atrTooltip"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeTooltip,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrTooltip]",
			standalone: true,
			exportAs: "atrTooltip",
			hostDirectives: [{
				directive: TuiHintDirective,
				inputs: ["tuiHint: atrTooltip"]
			}],
			host: { class: "atr-tooltip-trigger" }
		}]
	}],
	propDecorators: {
		atrTooltip: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "atrTooltip",
				required: true
			}]
		}],
		tooltipId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tooltipId",
				required: true
			}]
		}],
		position: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "position",
				required: false
			}]
		}],
		showDelay: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showDelay",
				required: false
			}]
		}],
		hideDelay: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideDelay",
				required: false
			}]
		}],
		tooltipDisabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tooltipDisabled",
				required: false
			}]
		}]
	}
});
var AtralumeTooltipHarness = class extends ComponentHarness {
	static hostSelector = "[role=\"tooltip\"]";
	async getText() {
		return (await this.host()).text();
	}
	async getAccessibleName() {
		return (await this.host()).getAttribute("aria-label");
	}
	async pressEscape() {
		await (await this.host()).sendKeys(TestKey.ESCAPE);
	}
};
export { AtralumeTooltip, AtralumeTooltipHarness };

//# sourceMappingURL=osmanjimenez-atralume-tooltip.mjs.map