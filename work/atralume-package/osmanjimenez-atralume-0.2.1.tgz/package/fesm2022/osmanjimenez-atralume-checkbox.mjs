import * as i0 from "@angular/core";
import { Directive, afterNextRender, booleanAttribute, effect, inject, input } from "@angular/core";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";
import { NgControl } from "@angular/forms";
import { tuiInjectElement } from "@taiga-ui/cdk/utils/dom";
import * as i1 from "@taiga-ui/core/directives/appearance";
import { TuiAppearance, tuiAppearance } from "@taiga-ui/core/directives/appearance";
import * as i2 from "@taiga-ui/core/directives/icons";
import { TuiIcons, tuiIconEnd, tuiIconStart } from "@taiga-ui/core/directives/icons";
import { fromEvent } from "rxjs";
import { ComponentHarness } from "@angular/cdk/testing";
function checkboxAppearance(el) {
	return el.checked || el.indeterminate ? "primary" : "outline-grayscale";
}
var AtralumeCheckbox = class AtralumeCheckbox {
	indeterminate = input(false, {
		...ngDevMode ? { debugName: "indeterminate" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	el = tuiInjectElement();
	appearance = tuiAppearance(checkboxAppearance(this.el));
	control = inject(NgControl, {
		optional: true,
		self: true
	});
	checkIcon = tuiIconStart("@tui.check");
	indeterminateIcon = tuiIconEnd("@tui.minus");
	constructor() {
		const sync = () => this.appearance.set(checkboxAppearance(this.el));
		afterNextRender(() => {
			sync();
			setTimeout(sync);
		});
		this.control?.valueChanges?.pipe(takeUntilDestroyed()).subscribe(() => sync());
		fromEvent(this.el, "change").pipe(takeUntilDestroyed()).subscribe(sync);
		fromEvent(this.el, "click").pipe(takeUntilDestroyed()).subscribe(sync);
		effect(() => {
			this.indeterminate();
			queueMicrotask(sync);
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeCheckbox,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeCheckbox,
		isStandalone: true,
		selector: "input[type=\"checkbox\"][atrCheckbox]",
		inputs: { indeterminate: {
			classPropertyName: "indeterminate",
			publicName: "indeterminate",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			properties: {
				"attr.tuiCheckbox": "\"\"",
				"indeterminate": "indeterminate()"
			},
			classAttribute: "atr-checkbox"
		},
		hostDirectives: [{
			directive: i1.TuiAppearance,
			inputs: [
				"tuiAppearanceState",
				"tuiAppearanceState",
				"tuiAppearanceFocus",
				"tuiAppearanceFocus",
				"tuiAppearanceMode",
				"tuiAppearanceMode"
			]
		}, { directive: i2.TuiIcons }],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeCheckbox,
	decorators: [{
		type: Directive,
		args: [{
			selector: "input[type=\"checkbox\"][atrCheckbox]",
			standalone: true,
			hostDirectives: [{
				directive: TuiAppearance,
				inputs: [
					"tuiAppearanceState",
					"tuiAppearanceFocus",
					"tuiAppearanceMode"
				]
			}, TuiIcons],
			host: {
				class: "atr-checkbox",
				"[attr.tuiCheckbox]": "\"\"",
				"[indeterminate]": "indeterminate()"
			}
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { indeterminate: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "indeterminate",
			required: false
		}]
	}] }
});
var AtralumeCheckboxHarness = class extends ComponentHarness {
	static hostSelector = ".atr-checkbox";
	async isChecked() {
		return (await this.host()).getProperty("checked");
	}
	async toggle() {
		if (!await this.isDisabled()) await (await this.host()).click();
	}
	async check() {
		if (!await this.isChecked()) await this.toggle();
	}
	async uncheck() {
		if (await this.isChecked()) await this.toggle();
	}
	async isIndeterminate() {
		return (await this.host()).getProperty("indeterminate");
	}
	async isDisabled() {
		return (await this.host()).getProperty("disabled");
	}
};
export { AtralumeCheckbox, AtralumeCheckboxHarness };

//# sourceMappingURL=osmanjimenez-atralume-checkbox.mjs.map