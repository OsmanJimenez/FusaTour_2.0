import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, effect, forwardRef, inject, input, untracked } from "@angular/core";
import * as i1 from "@angular/forms";
import { FormControl, NG_VALIDATORS, NG_VALUE_ACCESSOR, ReactiveFormsModule } from "@angular/forms";
import { TuiRating } from "@taiga-ui/kit";
import { ɵAtralumeValueControl } from "@osmanjimenez/atralume/internal/forms";
import { ComponentHarness } from "@angular/cdk/testing";
function toInner(value) {
	return value ?? 0;
}
function fromInner(value) {
	return !value ? null : value;
}
var AtralumeRating = class AtralumeRating extends ɵAtralumeValueControl {
	max = input(5, {
		...ngDevMode ? { debugName: "max" } : /* istanbul ignore next */ {},
		transform: (value) => value ?? 5
	});
	inner = new FormControl(0, { nonNullable: true });
	validatorChanged = () => void 0;
	constructor() {
		super();
		const destroyRef = inject(DestroyRef);
		const sub = this.inner.valueChanges.subscribe((value) => {
			this.commit(fromInner(value));
		});
		destroyRef.onDestroy(() => sub.unsubscribe());
		effect(() => {
			const next = toInner(this.value());
			untracked(() => {
				if (this.inner.value !== next) this.inner.setValue(next, { emitEvent: false });
			});
		});
		effect(() => {
			const inactive = this.blocked() || this.readonly();
			untracked(() => {
				if (inactive) this.inner.disable({ emitEvent: false });
				else this.inner.enable({ emitEvent: false });
			});
		});
		effect(() => {
			this.value();
			this.max();
			this.required();
			untracked(() => this.validatorChanged());
		});
	}
	validate() {
		const value = this.value();
		return value === null ? this.required() ? { required: true } : null : value < 1 || value > this.max() ? { ratingBounds: true } : null;
	}
	registerOnValidatorChange(fn) {
		this.validatorChanged = fn;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeRating,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeRating,
		isStandalone: true,
		selector: "atr-rating",
		inputs: { max: {
			classPropertyName: "max",
			publicName: "max",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			properties: { "attr.aria-label": "label()" },
			classAttribute: "atr-rating"
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => AtralumeRating),
			multi: true
		}, {
			provide: NG_VALIDATORS,
			useExisting: forwardRef(() => AtralumeRating),
			multi: true
		}],
		usesInheritance: true,
		ngImport: i0,
		template: "<tui-rating [max]=\"max()\" [formControl]=\"inner\" />\n",
		styles: [":host{display:inline-block;min-inline-size:0;color:var(--atr-comp-rating-active-color, var(--atr-sys-color-primary))}tui-rating{color:inherit}\n"],
		dependencies: [
			{
				kind: "ngmodule",
				type: ReactiveFormsModule
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.FormControlDirective,
				selector: "[formControl]",
				inputs: [
					"formControl",
					"disabled",
					"ngModel"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngForm"]
			},
			{
				kind: "component",
				type: TuiRating,
				selector: "tui-rating",
				inputs: ["icon", "max"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeRating,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-rating",
			standalone: true,
			imports: [ReactiveFormsModule, TuiRating],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => AtralumeRating),
				multi: true
			}, {
				provide: NG_VALIDATORS,
				useExisting: forwardRef(() => AtralumeRating),
				multi: true
			}],
			host: {
				class: "atr-rating",
				"[attr.aria-label]": "label()"
			},
			template: "<tui-rating [max]=\"max()\" [formControl]=\"inner\" />\n",
			styles: [":host{display:inline-block;min-inline-size:0;color:var(--atr-comp-rating-active-color, var(--atr-sys-color-primary))}tui-rating{color:inherit}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { max: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "max",
			required: false
		}]
	}] }
});
var AtralumeRatingHarness = class extends ComponentHarness {
	static hostSelector = "atr-rating";
	range = this.locatorFor("input[type=\"range\"]");
	async getValue() {
		return Number(await (await this.range()).getProperty("value"));
	}
	async isDisabled() {
		return await (await this.range()).getProperty("disabled");
	}
};
export { AtralumeRating, AtralumeRatingHarness };

//# sourceMappingURL=osmanjimenez-atralume-rating.mjs.map