import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, booleanAttribute, computed, input, output, signal } from "@angular/core";
import { AtralumeSkeleton } from "@osmanjimenez/atralume/skeleton";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeImage = class AtralumeImage {
	src = input(null, ...ngDevMode ? [{ debugName: "src" }] : /* istanbul ignore next */ []);
	alt = input.required(...ngDevMode ? [{ debugName: "alt" }] : /* istanbul ignore next */ []);
	fallbackSrc = input(null, ...ngDevMode ? [{ debugName: "fallbackSrc" }] : /* istanbul ignore next */ []);
	loading = input("lazy", ...ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []);
	fit = input("cover", ...ngDevMode ? [{ debugName: "fit" }] : /* istanbul ignore next */ []);
	position = input("center", ...ngDevMode ? [{ debugName: "position" }] : /* istanbul ignore next */ []);
	aspectRatio = input("auto", ...ngDevMode ? [{ debugName: "aspectRatio" }] : /* istanbul ignore next */ []);
	width = input(null, ...ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []);
	height = input(null, ...ngDevMode ? [{ debugName: "height" }] : /* istanbul ignore next */ []);
	previewable = input(false, {
		...ngDevMode ? { debugName: "previewable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	previewLabel = input("Open image preview", ...ngDevMode ? [{ debugName: "previewLabel" }] : /* istanbul ignore next */ []);
	stateChange = output();
	previewRequested = output();
	state = signal("loading", ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	failedPrimary = signal(null, ...ngDevMode ? [{ debugName: "failedPrimary" }] : /* istanbul ignore next */ []);
	failedFallback = signal(null, ...ngDevMode ? [{ debugName: "failedFallback" }] : /* istanbul ignore next */ []);
	activeSrc = computed(() => {
		const source = this.src();
		if (!source) return null;
		const fallback = this.fallbackSrc();
		return this.failedPrimary() === source && fallback ? fallback : source;
	}, ...ngDevMode ? [{ debugName: "activeSrc" }] : /* istanbul ignore next */ []);
	imageAvailable = computed(() => !!this.activeSrc() && this.failedFallback() !== this.activeSrc(), ...ngDevMode ? [{ debugName: "imageAvailable" }] : /* istanbul ignore next */ []);
	isEmpty = computed(() => !this.src(), ...ngDevMode ? [{ debugName: "isEmpty" }] : /* istanbul ignore next */ []);
	displayState = computed(() => this.isEmpty() ? "empty" : this.state(), ...ngDevMode ? [{ debugName: "displayState" }] : /* istanbul ignore next */ []);
	resolvedAspectRatio = computed(() => {
		const ratio = this.aspectRatio();
		if (typeof ratio === "number") return ratio > 0 ? String(ratio) : null;
		if (ratio === "auto") return null;
		return {
			square: "1",
			landscape: "16 / 9",
			portrait: "3 / 4"
		}[ratio];
	}, ...ngDevMode ? [{ debugName: "resolvedAspectRatio" }] : /* istanbul ignore next */ []);
	aspectRatioName = computed(() => typeof this.aspectRatio() === "number" ? "custom" : this.aspectRatio(), ...ngDevMode ? [{ debugName: "aspectRatioName" }] : /* istanbul ignore next */ []);
	loaded() {
		this.state.set("loaded");
		this.stateChange.emit("loaded");
	}
	failed() {
		const source = this.activeSrc();
		if (!source) return;
		if (source === this.src() && this.fallbackSrc()) {
			this.failedPrimary.set(source);
			this.state.set("loading");
			this.stateChange.emit("loading");
			return;
		}
		this.failedFallback.set(source);
		this.state.set("error");
		this.stateChange.emit("error");
	}
	requestPreview(event) {
		this.previewRequested.emit(event);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeImage,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeImage,
		isStandalone: true,
		selector: "atr-image",
		inputs: {
			src: {
				classPropertyName: "src",
				publicName: "src",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			alt: {
				classPropertyName: "alt",
				publicName: "alt",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			fallbackSrc: {
				classPropertyName: "fallbackSrc",
				publicName: "fallbackSrc",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			loading: {
				classPropertyName: "loading",
				publicName: "loading",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fit: {
				classPropertyName: "fit",
				publicName: "fit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			position: {
				classPropertyName: "position",
				publicName: "position",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			aspectRatio: {
				classPropertyName: "aspectRatio",
				publicName: "aspectRatio",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			height: {
				classPropertyName: "height",
				publicName: "height",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			previewable: {
				classPropertyName: "previewable",
				publicName: "previewable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			previewLabel: {
				classPropertyName: "previewLabel",
				publicName: "previewLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			stateChange: "stateChange",
			previewRequested: "previewRequested"
		},
		host: {
			properties: {
				"attr.data-state": "displayState()",
				"attr.data-aspect-ratio": "aspectRatioName()",
				"style.aspect-ratio": "resolvedAspectRatio()"
			},
			classAttribute: "atr-image"
		},
		ngImport: i0,
		template: "@if (isEmpty()) {\n  <div class=\"atr-image__error\" role=\"img\" [attr.aria-label]=\"alt()\">\n    No image\n  </div>\n} @else if (imageAvailable()) {\n  @if (previewable()) {\n    <button\n      type=\"button\"\n      class=\"atr-image__trigger\"\n      [attr.aria-label]=\"previewLabel()\"\n      (click)=\"requestPreview($event)\"\n    >\n      <img\n        [src]=\"activeSrc()\"\n        [alt]=\"alt()\"\n        [loading]=\"loading()\"\n        [attr.width]=\"width()\"\n        [attr.height]=\"height()\"\n        [style.object-fit]=\"fit()\"\n        [style.object-position]=\"position()\"\n        (load)=\"loaded()\"\n        (error)=\"failed()\"\n      />\n    </button>\n  } @else {\n    <img\n      [src]=\"activeSrc()\"\n      [alt]=\"alt()\"\n      [loading]=\"loading()\"\n      [attr.width]=\"width()\"\n      [attr.height]=\"height()\"\n      [style.object-fit]=\"fit()\"\n      [style.object-position]=\"position()\"\n      (load)=\"loaded()\"\n      (error)=\"failed()\"\n    />\n  }\n} @else {\n  <div class=\"atr-image__error\" role=\"img\" [attr.aria-label]=\"alt()\">\n    Image unavailable\n  </div>\n}\n@if (state() === \"loading\" && imageAvailable()) {\n  <atr-skeleton class=\"atr-image__skeleton\" appearance=\"rounded\" />\n}\n",
		styles: [":host{background:var(--atr-comp-image-container-color);border-radius:var(--atr-comp-image-shape);display:block;overflow:hidden;position:relative}img,.atr-image__trigger{block-size:100%;display:block;inline-size:100%}img{color:transparent}.atr-image__trigger{appearance:none;background:transparent;border:0;cursor:zoom-in;padding:0}.atr-image__trigger:focus-visible{outline:var(--atr-comp-image-focus-ring-width) var(--atr-sys-focus-ring-style) var(--atr-comp-image-focus-ring-color);outline-offset:calc(-1 * var(--atr-comp-image-focus-ring-width))}.atr-image__skeleton{inset:0;position:absolute}.atr-image__error{align-items:center;background:var(--atr-comp-image-error-color);color:var(--atr-comp-image-error-label-color);display:grid;min-block-size:var(--atr-sys-touch-target-minimum);padding:var(--atr-sys-spacing-sm);text-align:center}@media(forced-colors:active){:host{border:1px solid CanvasText}}\n"],
		dependencies: [{
			kind: "component",
			type: AtralumeSkeleton,
			selector: "atr-skeleton",
			inputs: [
				"active",
				"appearance",
				"animation"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeImage,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-image",
			standalone: true,
			imports: [AtralumeSkeleton],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "atr-image",
				"[attr.data-state]": "displayState()",
				"[attr.data-aspect-ratio]": "aspectRatioName()",
				"[style.aspect-ratio]": "resolvedAspectRatio()"
			},
			template: "@if (isEmpty()) {\n  <div class=\"atr-image__error\" role=\"img\" [attr.aria-label]=\"alt()\">\n    No image\n  </div>\n} @else if (imageAvailable()) {\n  @if (previewable()) {\n    <button\n      type=\"button\"\n      class=\"atr-image__trigger\"\n      [attr.aria-label]=\"previewLabel()\"\n      (click)=\"requestPreview($event)\"\n    >\n      <img\n        [src]=\"activeSrc()\"\n        [alt]=\"alt()\"\n        [loading]=\"loading()\"\n        [attr.width]=\"width()\"\n        [attr.height]=\"height()\"\n        [style.object-fit]=\"fit()\"\n        [style.object-position]=\"position()\"\n        (load)=\"loaded()\"\n        (error)=\"failed()\"\n      />\n    </button>\n  } @else {\n    <img\n      [src]=\"activeSrc()\"\n      [alt]=\"alt()\"\n      [loading]=\"loading()\"\n      [attr.width]=\"width()\"\n      [attr.height]=\"height()\"\n      [style.object-fit]=\"fit()\"\n      [style.object-position]=\"position()\"\n      (load)=\"loaded()\"\n      (error)=\"failed()\"\n    />\n  }\n} @else {\n  <div class=\"atr-image__error\" role=\"img\" [attr.aria-label]=\"alt()\">\n    Image unavailable\n  </div>\n}\n@if (state() === \"loading\" && imageAvailable()) {\n  <atr-skeleton class=\"atr-image__skeleton\" appearance=\"rounded\" />\n}\n",
			styles: [":host{background:var(--atr-comp-image-container-color);border-radius:var(--atr-comp-image-shape);display:block;overflow:hidden;position:relative}img,.atr-image__trigger{block-size:100%;display:block;inline-size:100%}img{color:transparent}.atr-image__trigger{appearance:none;background:transparent;border:0;cursor:zoom-in;padding:0}.atr-image__trigger:focus-visible{outline:var(--atr-comp-image-focus-ring-width) var(--atr-sys-focus-ring-style) var(--atr-comp-image-focus-ring-color);outline-offset:calc(-1 * var(--atr-comp-image-focus-ring-width))}.atr-image__skeleton{inset:0;position:absolute}.atr-image__error{align-items:center;background:var(--atr-comp-image-error-color);color:var(--atr-comp-image-error-label-color);display:grid;min-block-size:var(--atr-sys-touch-target-minimum);padding:var(--atr-sys-spacing-sm);text-align:center}@media(forced-colors:active){:host{border:1px solid CanvasText}}\n"]
		}]
	}],
	propDecorators: {
		src: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "src",
				required: false
			}]
		}],
		alt: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "alt",
				required: true
			}]
		}],
		fallbackSrc: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fallbackSrc",
				required: false
			}]
		}],
		loading: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "loading",
				required: false
			}]
		}],
		fit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fit",
				required: false
			}]
		}],
		position: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "position",
				required: false
			}]
		}],
		aspectRatio: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "aspectRatio",
				required: false
			}]
		}],
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		height: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "height",
				required: false
			}]
		}],
		previewable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "previewable",
				required: false
			}]
		}],
		previewLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "previewLabel",
				required: false
			}]
		}],
		stateChange: [{
			type: i0.Output,
			args: ["stateChange"]
		}],
		previewRequested: [{
			type: i0.Output,
			args: ["previewRequested"]
		}]
	}
});
var AtralumeImageHarness = class extends ComponentHarness {
	static hostSelector = "atr-image";
	async getState() {
		return (await this.host()).getAttribute("data-state");
	}
	async getAlt() {
		return (await this.locatorForOptional("img")())?.getAttribute("alt") ?? null;
	}
	async requestPreview() {
		const trigger = await this.locatorForOptional("button")();
		if (trigger) await trigger.click();
	}
};
export { AtralumeImage, AtralumeImageHarness };

//# sourceMappingURL=osmanjimenez-atralume-image.mjs.map