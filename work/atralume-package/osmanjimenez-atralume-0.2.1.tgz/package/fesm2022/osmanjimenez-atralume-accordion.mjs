import * as i0 from "@angular/core";
import { Directive } from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeAccordion = class AtralumeAccordion {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeAccordion,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeAccordion,
		isStandalone: true,
		selector: "tui-accordion[atrAccordion]",
		host: { classAttribute: "atr-accordion" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeAccordion,
	decorators: [{
		type: Directive,
		args: [{
			selector: "tui-accordion[atrAccordion]",
			standalone: true,
			host: { class: "atr-accordion" }
		}]
	}]
});
var AtralumeAccordionHeader = class AtralumeAccordionHeader {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeAccordionHeader,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeAccordionHeader,
		isStandalone: true,
		selector: "button[tuiAccordion][atrAccordionHeader]",
		host: { classAttribute: "atr-accordion-header" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeAccordionHeader,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[tuiAccordion][atrAccordionHeader]",
			standalone: true,
			host: { class: "atr-accordion-header" }
		}]
	}]
});
var AtralumeAccordionHeaderHarness = class extends ComponentHarness {
	static hostSelector = "button[tuiAccordion].atr-accordion-header";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeAccordionItem = class AtralumeAccordionItem {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeAccordionItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeAccordionItem,
		isStandalone: true,
		selector: "button[tuiAccordion][atrAccordionItem]",
		host: { classAttribute: "atr-accordion-item" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeAccordionItem,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[tuiAccordion][atrAccordionItem]",
			standalone: true,
			host: { class: "atr-accordion-item" }
		}]
	}]
});
var AtralumeAccordionItemHarness = class extends ComponentHarness {
	static hostSelector = "button[tuiAccordion].atr-accordion-item";
	async getText() {
		return (await this.host()).text();
	}
	async isExpanded() {
		return await (await this.host()).getAttribute("aria-expanded") === "true";
	}
	async toggle() {
		await (await this.locatorFor("button")()).click();
	}
};
var AtralumeAccordionPanel = class AtralumeAccordionPanel {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeAccordionPanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeAccordionPanel,
		isStandalone: true,
		selector: "tui-expand[atrAccordionPanel]",
		host: { classAttribute: "atr-accordion-panel" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeAccordionPanel,
	decorators: [{
		type: Directive,
		args: [{
			selector: "tui-expand[atrAccordionPanel]",
			standalone: true,
			host: { class: "atr-accordion-panel" }
		}]
	}]
});
var AtralumeAccordionPanelHarness = class extends ComponentHarness {
	static hostSelector = "tui-expand.atr-accordion-panel";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeAccordionHarness = class extends ComponentHarness {
	static hostSelector = "tui-accordion.atr-accordion";
	async getText() {
		return (await this.host()).text();
	}
};
export { AtralumeAccordion, AtralumeAccordionHarness, AtralumeAccordionHeader, AtralumeAccordionHeaderHarness, AtralumeAccordionItem, AtralumeAccordionItemHarness, AtralumeAccordionPanel, AtralumeAccordionPanelHarness };

//# sourceMappingURL=osmanjimenez-atralume-accordion.mjs.map