import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, Directive, booleanAttribute, computed, input, model } from "@angular/core";
import { TuiAsideComponent, TuiMainComponent } from "@taiga-ui/layout";
import { ComponentHarness } from "@angular/cdk/testing";
import * as i1 from "@taiga-ui/core";
import { TuiButton } from "@taiga-ui/core";
import { tuiAppearance } from "@taiga-ui/core/directives/appearance";
var AtralumeSideNavigationContainer = class AtralumeSideNavigationContainer {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeSideNavigationContainer,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeSideNavigationContainer,
		isStandalone: true,
		selector: "atr-side-navigation-container",
		host: { classAttribute: "atr-side-navigation-container" },
		ngImport: i0,
		template: "<ng-content select=\"atr-side-navigation, aside\" />\n<main tuiNavigationMain>\n  <ng-content />\n</main>\n",
		styles: [":host{display:flex;position:relative;overflow:hidden;min-block-size:var(--atr-ref-spacing-16);align-items:stretch}main[tuiNavigationMain]{flex:1;min-inline-size:0}\n"],
		dependencies: [{
			kind: "component",
			type: TuiMainComponent,
			selector: "main[tuiNavigationMain]"
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeSideNavigationContainer,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-side-navigation-container",
			standalone: true,
			imports: [TuiMainComponent],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "atr-side-navigation-container" },
			template: "<ng-content select=\"atr-side-navigation, aside\" />\n<main tuiNavigationMain>\n  <ng-content />\n</main>\n",
			styles: [":host{display:flex;position:relative;overflow:hidden;min-block-size:var(--atr-ref-spacing-16);align-items:stretch}main[tuiNavigationMain]{flex:1;min-inline-size:0}\n"]
		}]
	}]
});
var AtralumeSideNavigationContainerHarness = class extends ComponentHarness {
	static hostSelector = "atr-side-navigation-container";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeSideNavigationContent = class AtralumeSideNavigationContent {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeSideNavigationContent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeSideNavigationContent,
		isStandalone: true,
		selector: "[atrSideNavigationContent]",
		host: { classAttribute: "atr-side-navigation-content" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeSideNavigationContent,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrSideNavigationContent]",
			standalone: true,
			host: { class: "atr-side-navigation-content" }
		}]
	}]
});
var AtralumeSideNavigationContentHarness = class extends ComponentHarness {
	static hostSelector = ".atr-side-navigation-content";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeSideNavigationGroup = class AtralumeSideNavigationGroup {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeSideNavigationGroup,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeSideNavigationGroup,
		isStandalone: true,
		selector: "[atrSideNavigationGroup]",
		host: { classAttribute: "atr-side-navigation-group" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeSideNavigationGroup,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrSideNavigationGroup]",
			standalone: true,
			host: { class: "atr-side-navigation-group" }
		}]
	}]
});
var AtralumeSideNavigationGroupHarness = class extends ComponentHarness {
	static hostSelector = ".atr-side-navigation-group";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeSideNavigationHeader = class AtralumeSideNavigationHeader {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeSideNavigationHeader,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeSideNavigationHeader,
		isStandalone: true,
		selector: "[atrSideNavigationHeader]",
		host: { classAttribute: "atr-side-navigation-header" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeSideNavigationHeader,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrSideNavigationHeader]",
			standalone: true,
			host: { class: "atr-side-navigation-header" }
		}]
	}]
});
var AtralumeSideNavigationHeaderHarness = class extends ComponentHarness {
	static hostSelector = ".atr-side-navigation-header";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeSideNavigationItem = class AtralumeSideNavigationItem {
	active = input(false, {
		...ngDevMode ? { debugName: "active" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	_tuiAppearance = tuiAppearance("flat");
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeSideNavigationItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeSideNavigationItem,
		isStandalone: true,
		selector: "a[atrSideNavigationItem], button[atrSideNavigationItem]",
		inputs: { active: {
			classPropertyName: "active",
			publicName: "active",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			properties: {
				"attr.tuiButton": "\"\"",
				"attr.aria-current": "active() ? \"page\" : null",
				"class._active": "active()"
			},
			classAttribute: "atr-side-navigation-item"
		},
		hostDirectives: [{
			directive: i1.TuiButton,
			inputs: ["size", "tuiSize"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeSideNavigationItem,
	decorators: [{
		type: Directive,
		args: [{
			selector: "a[atrSideNavigationItem], button[atrSideNavigationItem]",
			standalone: true,
			hostDirectives: [{
				directive: TuiButton,
				inputs: ["size: tuiSize"]
			}],
			host: {
				class: "atr-side-navigation-item",
				"[attr.tuiButton]": "\"\"",
				"[attr.aria-current]": "active() ? \"page\" : null",
				"[class._active]": "active()"
			}
		}]
	}],
	propDecorators: { active: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "active",
			required: false
		}]
	}] }
});
var AtralumeSideNavigationItemHarness = class extends ComponentHarness {
	static hostSelector = ".atr-side-navigation-item";
	async getText() {
		return (await this.host()).text();
	}
	async isSelected() {
		const h = await this.host();
		return await h.getAttribute("aria-selected") === "true" || await h.getAttribute("aria-current") === "page";
	}
};
var AtralumeSideNavigationLabel = class AtralumeSideNavigationLabel {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeSideNavigationLabel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeSideNavigationLabel,
		isStandalone: true,
		selector: "[atrSideNavigationLabel]",
		host: { classAttribute: "atr-side-navigation-label" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeSideNavigationLabel,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrSideNavigationLabel]",
			standalone: true,
			host: { class: "atr-side-navigation-label" }
		}]
	}]
});
var AtralumeSideNavigationLabelHarness = class extends ComponentHarness {
	static hostSelector = ".atr-side-navigation-label";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeSideNavigation = class AtralumeSideNavigation {
	panelId = input.required(...ngDevMode ? [{ debugName: "panelId" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	mode = input("side", ...ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []);
	opened = model(true, ...ngDevMode ? [{ debugName: "opened" }] : /* istanbul ignore next */ []);
	collapsed = input(false, {
		...ngDevMode ? { debugName: "collapsed" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	origin = input(null, ...ngDevMode ? [{ debugName: "origin" }] : /* istanbul ignore next */ []);
	expanded = computed(() => !this.collapsed(), ...ngDevMode ? [{ debugName: "expanded" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeSideNavigation,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeSideNavigation,
		isStandalone: true,
		selector: "atr-side-navigation",
		inputs: {
			panelId: {
				classPropertyName: "panelId",
				publicName: "panelId",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			mode: {
				classPropertyName: "mode",
				publicName: "mode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			opened: {
				classPropertyName: "opened",
				publicName: "opened",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			collapsed: {
				classPropertyName: "collapsed",
				publicName: "collapsed",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			origin: {
				classPropertyName: "origin",
				publicName: "origin",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { opened: "openedChange" },
		host: {
			properties: {
				"attr.data-mode": "mode()",
				"attr.data-opened": "opened()",
				"attr.data-collapsed": "collapsed()"
			},
			classAttribute: "atr-side-navigation"
		},
		ngImport: i0,
		template: "@if (opened()) {\n  <aside\n    [tuiNavigationAside]=\"expanded()\"\n    [attr.id]=\"panelId()\"\n    [attr.aria-label]=\"label()\"\n  >\n    <ng-content select=\"header\" />\n    <ng-content />\n    <ng-content select=\"footer\" />\n  </aside>\n}\n",
		styles: [":host{display:contents;color:var(--atr-comp-side-navigation-label-color);font-family:var(--atr-comp-side-navigation-font-family)}:host([data-opened=false]){display:none}\n"],
		dependencies: [{
			kind: "component",
			type: TuiAsideComponent,
			selector: "aside[tuiNavigationAside]",
			inputs: ["tuiNavigationAside"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeSideNavigation,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-side-navigation",
			standalone: true,
			imports: [TuiAsideComponent],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "atr-side-navigation",
				"[attr.data-mode]": "mode()",
				"[attr.data-opened]": "opened()",
				"[attr.data-collapsed]": "collapsed()"
			},
			template: "@if (opened()) {\n  <aside\n    [tuiNavigationAside]=\"expanded()\"\n    [attr.id]=\"panelId()\"\n    [attr.aria-label]=\"label()\"\n  >\n    <ng-content select=\"header\" />\n    <ng-content />\n    <ng-content select=\"footer\" />\n  </aside>\n}\n",
			styles: [":host{display:contents;color:var(--atr-comp-side-navigation-label-color);font-family:var(--atr-comp-side-navigation-font-family)}:host([data-opened=false]){display:none}\n"]
		}]
	}],
	propDecorators: {
		panelId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "panelId",
				required: true
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		mode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mode",
				required: false
			}]
		}],
		opened: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "opened",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["openedChange"]
		}],
		collapsed: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "collapsed",
				required: false
			}]
		}],
		origin: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "origin",
				required: false
			}]
		}]
	}
});
var AtralumeSideNavigationHarness = class extends ComponentHarness {
	static hostSelector = "atr-side-navigation";
	async getText() {
		return (await this.host()).text();
	}
	async isOpen() {
		return await (await this.host()).getAttribute("data-opened") === "true";
	}
};
export { AtralumeSideNavigation, AtralumeSideNavigationContainer, AtralumeSideNavigationContainerHarness, AtralumeSideNavigationContent, AtralumeSideNavigationContentHarness, AtralumeSideNavigationGroup, AtralumeSideNavigationGroupHarness, AtralumeSideNavigationHarness, AtralumeSideNavigationHeader, AtralumeSideNavigationHeaderHarness, AtralumeSideNavigationItem, AtralumeSideNavigationItemHarness, AtralumeSideNavigationLabel, AtralumeSideNavigationLabelHarness };

//# sourceMappingURL=osmanjimenez-atralume-side-navigation.mjs.map