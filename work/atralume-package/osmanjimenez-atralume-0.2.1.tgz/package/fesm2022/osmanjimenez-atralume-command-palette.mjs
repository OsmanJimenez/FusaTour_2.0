import { DOCUMENT, isPlatformBrowser } from "@angular/common";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, PLATFORM_ID, Renderer2, ViewContainerRef, booleanAttribute, computed, effect, inject, input, model, output, signal, untracked, viewChild } from "@angular/core";
import { AtralumeDialog } from "@osmanjimenez/atralume/dialog";
import { AtralumeCombobox, AtralumeComboboxHarness } from "@osmanjimenez/atralume/combobox";
import { AtralumeButton } from "@osmanjimenez/atralume/button";
import { arrowRightIcon, provideAtralumeIcons } from "@osmanjimenez/atralume/icon";
import { ComponentHarness, TestKey } from "@angular/cdk/testing";
var AtralumeCommandPalette = class AtralumeCommandPalette {
	label = input("Commands", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	commands = input([], ...ngDevMode ? [{ debugName: "commands" }] : /* istanbul ignore next */ []);
	recentCommands = input([], ...ngDevMode ? [{ debugName: "recentCommands" }] : /* istanbul ignore next */ []);
	opened = model(false, ...ngDevMode ? [{ debugName: "opened" }] : /* istanbul ignore next */ []);
	query = model("", ...ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []);
	loading = input(false, {
		...ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	loadError = input(null, ...ngDevMode ? [{ debugName: "loadError" }] : /* istanbul ignore next */ []);
	shortcut = input(null, ...ngDevMode ? [{ debugName: "shortcut" }] : /* istanbul ignore next */ []);
	closeAfterAction = input(true, {
		...ngDevMode ? { debugName: "closeAfterAction" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	invoked = output();
	levels = signal([], ...ngDevMode ? [{ debugName: "levels" }] : /* istanbul ignore next */ []);
	canGoBack = computed(() => this.levels().length > 0, ...ngDevMode ? [{ debugName: "canGoBack" }] : /* istanbul ignore next */ []);
	options = computed(() => {
		const levels = this.levels();
		const commands = levels.length ? levels[levels.length - 1].children ?? [] : this.commands();
		const recent = levels.length || this.query() ? [] : this.recentCommands();
		const ids = /* @__PURE__ */ new Set();
		return [...recent, ...commands].filter((command) => {
			if (ids.has(command.id)) return false;
			ids.add(command.id);
			return true;
		}).map((command) => ({
			id: command.id,
			value: command,
			label: command.label,
			disabled: command.disabled,
			group: command.group,
			keywords: command.keywords
		}));
	}, ...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	content = viewChild.required("content", ...ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []);
	combobox = viewChild(AtralumeCombobox, ...ngDevMode ? [{ debugName: "combobox" }] : /* istanbul ignore next */ []);
	dialog = inject(AtralumeDialog);
	views = inject(ViewContainerRef);
	owner = inject(DestroyRef);
	document = inject(DOCUMENT);
	renderer = inject(Renderer2);
	browser = isPlatformBrowser(inject(PLATFORM_ID));
	ref = null;
	origin;
	constructor() {
		effect((onCleanup) => {
			if (!this.opened()) return;
			const template = this.content();
			const ref = untracked(() => this.dialog.open(template, {
				label: this.label(),
				origin: this.origin,
				owner: this.owner,
				viewContainerRef: this.views
			}));
			this.ref = ref;
			const subscription = ref.afterClosed.subscribe(() => {
				if (this.ref === ref) {
					this.ref = null;
					this.opened.set(false);
					this.levels.set([]);
					this.query.set("");
				}
			});
			onCleanup(() => {
				subscription.unsubscribe();
				if (this.ref === ref) this.ref = null;
				ref.close();
			});
		});
		if (this.browser) {
			const unlisten = this.renderer.listen(this.document, "keydown", (event) => {
				const shortcut = this.shortcut();
				if (!shortcut || event.repeat || event.isComposing || event.altKey || event.shiftKey || event.defaultPrevented || event.key.toLowerCase() !== shortcut.key.toLowerCase()) return;
				const match = shortcut.modifier === "either" ? event.ctrlKey || event.metaKey : shortcut.modifier === "meta" ? event.metaKey : event.ctrlKey;
				const target = event.target;
				if (!match || !shortcut.allowInEditable && target?.closest("input,textarea,select,[contenteditable=\"true\"]")) return;
				event.preventDefault();
				this.open(target ?? void 0);
			});
			this.owner.onDestroy(unlisten);
		}
	}
	open(origin) {
		this.origin = origin;
		this.opened.set(true);
	}
	close() {
		this.opened.set(false);
	}
	choose(value) {
		if (!value || typeof value === "string") return;
		const command = value;
		if (command.disabled) return;
		if (command.children) {
			this.levels.update((levels) => [...levels, command]);
			this.query.set("");
			this.combobox()?.query.set("");
			return;
		}
		this.invoked.emit(command);
		if (this.closeAfterAction()) this.close();
	}
	back() {
		this.levels.update((levels) => levels.slice(0, -1));
		this.query.set("");
	}
	displayCommand = (command) => command.label;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeCommandPalette,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeCommandPalette,
		isStandalone: true,
		selector: "atr-command-palette",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			commands: {
				classPropertyName: "commands",
				publicName: "commands",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			recentCommands: {
				classPropertyName: "recentCommands",
				publicName: "recentCommands",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			opened: {
				classPropertyName: "opened",
				publicName: "opened",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			query: {
				classPropertyName: "query",
				publicName: "query",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			loading: {
				classPropertyName: "loading",
				publicName: "loading",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			loadError: {
				classPropertyName: "loadError",
				publicName: "loadError",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			shortcut: {
				classPropertyName: "shortcut",
				publicName: "shortcut",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			closeAfterAction: {
				classPropertyName: "closeAfterAction",
				publicName: "closeAfterAction",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			opened: "openedChange",
			query: "queryChange",
			invoked: "invoked"
		},
		host: { classAttribute: "atr-command-palette" },
		providers: [provideAtralumeIcons([arrowRightIcon])],
		viewQueries: [{
			propertyName: "content",
			first: true,
			predicate: ["content"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "combobox",
			first: true,
			predicate: AtralumeCombobox,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<ng-template #content>\n  <section class=\"atr-command-palette-content\">\n    @if (canGoBack()) {\n      <button atrButton appearance=\"text\" type=\"button\" (click)=\"back()\">\n        Back\n      </button>\n    }\n    <atr-combobox\n      label=\"Search\"\n      [options]=\"options()\"\n      [(query)]=\"query\"\n      [displayWith]=\"displayCommand\"\n      [value]=\"null\"\n      (valueChange)=\"choose($event)\"\n      [strict]=\"true\"\n      [filterOptions]=\"true\"\n      emptyText=\"No commands\"\n    />\n  </section>\n</ng-template>\n",
		styles: [".atr-command-palette-content{padding:var(--atr-comp-command-palette-padding);inline-size:min(34rem,100vw - 4rem)}kbd{margin-inline-start:auto;font:inherit}\n"],
		dependencies: [{
			kind: "component",
			type: AtralumeCombobox,
			selector: "atr-combobox",
			inputs: [
				"options",
				"query",
				"placeholder",
				"clearable",
				"emptyText",
				"strict",
				"filterOptions",
				"compareWith",
				"displayWith"
			],
			outputs: ["queryChange"]
		}, {
			kind: "component",
			type: AtralumeButton,
			selector: "button[atrButton], a[atrButton]",
			inputs: [
				"appearance",
				"size",
				"disabled",
				"loading",
				"fullWidth",
				"tabindex"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeCommandPalette,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-command-palette",
			standalone: true,
			imports: [AtralumeCombobox, AtralumeButton],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [provideAtralumeIcons([arrowRightIcon])],
			host: { class: "atr-command-palette" },
			template: "<ng-template #content>\n  <section class=\"atr-command-palette-content\">\n    @if (canGoBack()) {\n      <button atrButton appearance=\"text\" type=\"button\" (click)=\"back()\">\n        Back\n      </button>\n    }\n    <atr-combobox\n      label=\"Search\"\n      [options]=\"options()\"\n      [(query)]=\"query\"\n      [displayWith]=\"displayCommand\"\n      [value]=\"null\"\n      (valueChange)=\"choose($event)\"\n      [strict]=\"true\"\n      [filterOptions]=\"true\"\n      emptyText=\"No commands\"\n    />\n  </section>\n</ng-template>\n",
			styles: [".atr-command-palette-content{padding:var(--atr-comp-command-palette-padding);inline-size:min(34rem,100vw - 4rem)}kbd{margin-inline-start:auto;font:inherit}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		commands: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "commands",
				required: false
			}]
		}],
		recentCommands: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "recentCommands",
				required: false
			}]
		}],
		opened: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "opened",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["openedChange"]
		}],
		query: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "query",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["queryChange"]
		}],
		loading: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "loading",
				required: false
			}]
		}],
		loadError: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "loadError",
				required: false
			}]
		}],
		shortcut: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "shortcut",
				required: false
			}]
		}],
		closeAfterAction: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "closeAfterAction",
				required: false
			}]
		}],
		invoked: [{
			type: i0.Output,
			args: ["invoked"]
		}],
		content: [{
			type: i0.ViewChild,
			args: ["content", { isSignal: true }]
		}],
		combobox: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => AtralumeCombobox), { isSignal: true }]
		}]
	}
});
var AtralumeCommandPaletteHarness = class extends ComponentHarness {
	static hostSelector = ".atr-command-palette-content";
	combobox = this.locatorFor(AtralumeComboboxHarness);
	async search(query) {
		await (await this.combobox()).enterText(query);
	}
	async invoke(label) {
		await (await this.combobox()).selectOption(label);
	}
	async back() {
		await (await this.locatorFor("button")()).click();
	}
	async close() {
		await (await this.host()).sendKeys(TestKey.ESCAPE);
	}
};
export { AtralumeCommandPalette, AtralumeCommandPaletteHarness };

//# sourceMappingURL=osmanjimenez-atralume-command-palette.mjs.map