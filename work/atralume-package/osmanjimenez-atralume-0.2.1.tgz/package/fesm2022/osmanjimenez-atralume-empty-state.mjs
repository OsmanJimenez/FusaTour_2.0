import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, input } from "@angular/core";
import * as i1 from "@taiga-ui/layout";
import { TuiBlockStatus } from "@taiga-ui/layout";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeEmptyState = class AtralumeEmptyState {
	title = input.required(...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	description = input(null, ...ngDevMode ? [{ debugName: "description" }] : /* istanbul ignore next */ []);
	appearance = input("standard", ...ngDevMode ? [{ debugName: "appearance" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeEmptyState,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeEmptyState,
		isStandalone: true,
		selector: "atr-empty-state",
		inputs: {
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			description: {
				classPropertyName: "description",
				publicName: "description",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: { "attr.data-appearance": "appearance()" },
			classAttribute: "atr-empty-state"
		},
		ngImport: i0,
		template: "<tui-block-status [card]=\"appearance() === 'standard'\" size=\"l\">\n  <div tuiSlot=\"top\" class=\"atr-empty-state__visual\">\n    <ng-content select=\"[atrEmptyStateIcon]\" />\n  </div>\n  <h2>{{ title() }}</h2>\n  @if (description()) {\n    <p>{{ description() }}</p>\n  }\n  <ng-content />\n  <div class=\"atr-empty-state__actions\">\n    <ng-content select=\"[atrEmptyStatePrimary]\" /><ng-content\n      select=\"[atrEmptyStateSecondary]\"\n    />\n  </div>\n</tui-block-status>\n",
		styles: [":host{color:var(--atr-comp-empty-state-label-color);display:block}tui-block-status{background:var(--atr-comp-empty-state-container-color);border-radius:var(--atr-comp-empty-state-shape);padding:var(--atr-comp-empty-state-padding)}p{color:var(--atr-comp-empty-state-description-color);margin:0}.atr-empty-state__visual:empty,.atr-empty-state__actions:empty{display:none}.atr-empty-state__actions{display:flex;flex-wrap:wrap;gap:var(--atr-comp-empty-state-gap);justify-content:center}:host([data-appearance=compact]) tui-block-status{padding:var(--atr-sys-spacing-md)}\n"],
		dependencies: [{
			kind: "component",
			type: i1.TuiBlockStatusComponent,
			selector: "tui-block-status",
			inputs: ["card", "size"]
		}, {
			kind: "directive",
			type: i1.TuiBlockStatusDirective,
			selector: "[tuiSlot]",
			inputs: ["tuiSlot"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeEmptyState,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-empty-state",
			standalone: true,
			imports: [TuiBlockStatus],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "atr-empty-state",
				"[attr.data-appearance]": "appearance()"
			},
			template: "<tui-block-status [card]=\"appearance() === 'standard'\" size=\"l\">\n  <div tuiSlot=\"top\" class=\"atr-empty-state__visual\">\n    <ng-content select=\"[atrEmptyStateIcon]\" />\n  </div>\n  <h2>{{ title() }}</h2>\n  @if (description()) {\n    <p>{{ description() }}</p>\n  }\n  <ng-content />\n  <div class=\"atr-empty-state__actions\">\n    <ng-content select=\"[atrEmptyStatePrimary]\" /><ng-content\n      select=\"[atrEmptyStateSecondary]\"\n    />\n  </div>\n</tui-block-status>\n",
			styles: [":host{color:var(--atr-comp-empty-state-label-color);display:block}tui-block-status{background:var(--atr-comp-empty-state-container-color);border-radius:var(--atr-comp-empty-state-shape);padding:var(--atr-comp-empty-state-padding)}p{color:var(--atr-comp-empty-state-description-color);margin:0}.atr-empty-state__visual:empty,.atr-empty-state__actions:empty{display:none}.atr-empty-state__actions{display:flex;flex-wrap:wrap;gap:var(--atr-comp-empty-state-gap);justify-content:center}:host([data-appearance=compact]) tui-block-status{padding:var(--atr-sys-spacing-md)}\n"]
		}]
	}],
	propDecorators: {
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: true
			}]
		}],
		description: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "description",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}]
	}
});
var AtralumeEmptyStateHarness = class extends ComponentHarness {
	static hostSelector = "atr-empty-state";
	async getTitle() {
		return (await this.locatorFor("h2")()).text();
	}
	async getDescription() {
		return (await this.locatorForOptional("p")())?.text() ?? null;
	}
};
export { AtralumeEmptyState, AtralumeEmptyStateHarness };

//# sourceMappingURL=osmanjimenez-atralume-empty-state.mjs.map