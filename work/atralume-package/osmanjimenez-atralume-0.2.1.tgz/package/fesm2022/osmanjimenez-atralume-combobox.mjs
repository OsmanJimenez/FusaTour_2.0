import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, Directive, booleanAttribute, computed, effect, forwardRef, inject, input, model, untracked } from "@angular/core";
import * as i1 from "@angular/forms";
import { FormControl, NG_VALUE_ACCESSOR, ReactiveFormsModule } from "@angular/forms";
import { TuiFilterByInputPipe } from "@taiga-ui/core";
import * as i1$1 from "@taiga-ui/kit";
import { TuiComboBox, TuiComboBoxDirective, TuiDataListWrapper } from "@taiga-ui/kit";
import { TuiChevron } from "@taiga-ui/kit/directives/chevron";
import { AtralumeFormField } from "@osmanjimenez/atralume/form-field";
import { ɵAtralumeValueControl } from "@osmanjimenez/atralume/internal/forms";
import * as i2 from "@taiga-ui/core/components/label";
import * as i3 from "@taiga-ui/core/components/textfield";
import * as i4 from "@taiga-ui/core/portals/dropdown";
import { ComponentHarness, TestKey } from "@angular/cdk/testing";
var AtralumeComboBoxDirective = class AtralumeComboBoxDirective {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeComboBoxDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeComboBoxDirective,
		isStandalone: true,
		selector: "input[atrComboBox]",
		host: {
			properties: { "attr.tuiComboBox": "\"\"" },
			classAttribute: "atr-combobox-input"
		},
		hostDirectives: [{
			directive: i1$1.TuiComboBoxDirective,
			inputs: [
				"strict",
				"strict",
				"matcher",
				"matcher"
			]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeComboBoxDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "input[atrComboBox]",
			standalone: true,
			hostDirectives: [{
				directive: TuiComboBoxDirective,
				inputs: ["strict", "matcher"]
			}],
			host: {
				class: "atr-combobox-input",
				"[attr.tuiComboBox]": "\"\""
			}
		}]
	}]
});
var AtralumeCombobox = class AtralumeCombobox extends ɵAtralumeValueControl {
	options = input([], ...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	query = model("", ...ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []);
	placeholder = input("Choose an option", ...ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []);
	clearable = input(false, {
		...ngDevMode ? { debugName: "clearable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	emptyText = input("No results", ...ngDevMode ? [{ debugName: "emptyText" }] : /* istanbul ignore next */ []);
	strict = input(true, {
		...ngDevMode ? { debugName: "strict" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	filterOptions = input(true, {
		...ngDevMode ? { debugName: "filterOptions" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	compareWith = input(Object.is, ...ngDevMode ? [{ debugName: "compareWith" }] : /* istanbul ignore next */ []);
	displayWith = input(null, ...ngDevMode ? [{ debugName: "displayWith" }] : /* istanbul ignore next */ []);
	items = computed(() => this.options().map((option) => option.value), ...ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []);
	stringify = computed(() => {
		const display = this.displayWith();
		const options = this.options();
		return (value) => display?.(value) ?? options.find((option) => this.compareWith()(option.value, value))?.label ?? String(value ?? "");
	}, ...ngDevMode ? [{ debugName: "stringify" }] : /* istanbul ignore next */ []);
	identityMatcher = computed(() => (a, b) => this.compareWith()(a, b), ...ngDevMode ? [{ debugName: "identityMatcher" }] : /* istanbul ignore next */ []);
	disabledItemHandler = computed(() => {
		const options = this.options();
		const compare = this.compareWith();
		return (value) => !!options.find((option) => compare(option.value, value))?.disabled;
	}, ...ngDevMode ? [{ debugName: "disabledItemHandler" }] : /* istanbul ignore next */ []);
	inner = new FormControl(null);
	constructor() {
		super();
		const destroyRef = inject(DestroyRef);
		const sub = this.inner.valueChanges.subscribe((value) => this.commit(value));
		destroyRef.onDestroy(() => sub.unsubscribe());
		effect(() => {
			const next = this.value();
			untracked(() => {
				if (!Object.is(this.inner.value, next)) this.inner.setValue(next);
			});
		});
		effect(() => {
			if (this.blocked()) this.inner.disable({ emitEvent: false });
			else this.inner.enable({ emitEvent: false });
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeCombobox,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeCombobox,
		isStandalone: true,
		selector: "atr-combobox",
		inputs: {
			options: {
				classPropertyName: "options",
				publicName: "options",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			query: {
				classPropertyName: "query",
				publicName: "query",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			clearable: {
				classPropertyName: "clearable",
				publicName: "clearable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			emptyText: {
				classPropertyName: "emptyText",
				publicName: "emptyText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			strict: {
				classPropertyName: "strict",
				publicName: "strict",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			filterOptions: {
				classPropertyName: "filterOptions",
				publicName: "filterOptions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			compareWith: {
				classPropertyName: "compareWith",
				publicName: "compareWith",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			displayWith: {
				classPropertyName: "displayWith",
				publicName: "displayWith",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { query: "queryChange" },
		host: { classAttribute: "atr-combobox" },
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => AtralumeCombobox),
			multi: true
		}],
		usesInheritance: true,
		ngImport: i0,
		template: "<atr-form-field [hint]=\"hint()\" [error]=\"error()\">\n  <tui-textfield\n    tuiChevron\n    [invalid]=\"displayInvalid()\"\n    [stringify]=\"stringify()\"\n    [identityMatcher]=\"identityMatcher()\"\n    [disabledItemHandler]=\"disabledItemHandler()\"\n    [tuiTextfieldCleaner]=\"clearable()\"\n    tuiTextfieldSize=\"m\"\n  >\n    <label tuiLabel [attr.for]=\"controlId()\">\n      {{ label() }}\n      @if (required()) {\n        *\n      }\n    </label>\n    <input\n      atrComboBox\n      [id]=\"controlId()\"\n      [placeholder]=\"placeholder()\"\n      [readOnly]=\"readonly()\"\n      [strict]=\"strict()\"\n      [formControl]=\"inner\"\n    />\n    <ng-template tuiDropdown>\n      @if (filterOptions()) {\n        <tui-data-list-wrapper\n          [items]=\"items() | tuiFilterByInput\"\n          [emptyContent]=\"emptyText()\"\n        />\n      } @else {\n        <tui-data-list-wrapper [items]=\"items()\" [emptyContent]=\"emptyText()\" />\n      }\n    </ng-template>\n  </tui-textfield>\n</atr-form-field>\n",
		styles: [":host{display:block}\n"],
		dependencies: [
			{
				kind: "ngmodule",
				type: ReactiveFormsModule
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.FormControlDirective,
				selector: "[formControl]",
				inputs: [
					"formControl",
					"disabled",
					"ngModel"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngForm"]
			},
			{
				kind: "component",
				type: AtralumeFormField,
				selector: "atr-form-field",
				inputs: [
					"hint",
					"error",
					"appearance",
					"density",
					"label",
					"required",
					"optional",
					"optionalText"
				]
			},
			{
				kind: "directive",
				type: i2.TuiLabel,
				selector: "label[tuiLabel]"
			},
			{
				kind: "component",
				type: i3.TuiTextfieldComponent,
				selector: "tui-textfield:not([multi])",
				inputs: [
					"content",
					"filler",
					"invalid",
					"tuiAppearanceFocus",
					"tuiAppearanceState"
				]
			},
			{
				kind: "directive",
				type: i3.TuiTextfieldOptionsDirective,
				selector: "[tuiTextfieldAppearance],[tuiTextfieldSize],[tuiTextfieldCleaner]",
				inputs: [
					"tuiTextfieldAppearance",
					"tuiTextfieldSize",
					"tuiTextfieldCleaner"
				]
			},
			{
				kind: "directive",
				type: i4.TuiDropdownContent,
				selector: "ng-template[tuiDropdown]"
			},
			{
				kind: "directive",
				type: TuiChevron,
				selector: "[tuiChevron]",
				inputs: ["tuiChevron"]
			},
			{
				kind: "component",
				type: i1$1.TuiDataListWrapperComponent,
				selector: "tui-data-list-wrapper:not([labels])",
				inputs: [
					"items",
					"emptyContent",
					"size",
					"itemContent"
				],
				outputs: ["itemClick"]
			},
			{
				kind: "directive",
				type: AtralumeComboBoxDirective,
				selector: "input[atrComboBox]"
			},
			{
				kind: "pipe",
				type: TuiFilterByInputPipe,
				name: "tuiFilterByInput"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeCombobox,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-combobox",
			standalone: true,
			imports: [
				ReactiveFormsModule,
				AtralumeFormField,
				TuiComboBox,
				TuiChevron,
				TuiDataListWrapper,
				TuiFilterByInputPipe,
				AtralumeComboBoxDirective
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => AtralumeCombobox),
				multi: true
			}],
			host: { class: "atr-combobox" },
			template: "<atr-form-field [hint]=\"hint()\" [error]=\"error()\">\n  <tui-textfield\n    tuiChevron\n    [invalid]=\"displayInvalid()\"\n    [stringify]=\"stringify()\"\n    [identityMatcher]=\"identityMatcher()\"\n    [disabledItemHandler]=\"disabledItemHandler()\"\n    [tuiTextfieldCleaner]=\"clearable()\"\n    tuiTextfieldSize=\"m\"\n  >\n    <label tuiLabel [attr.for]=\"controlId()\">\n      {{ label() }}\n      @if (required()) {\n        *\n      }\n    </label>\n    <input\n      atrComboBox\n      [id]=\"controlId()\"\n      [placeholder]=\"placeholder()\"\n      [readOnly]=\"readonly()\"\n      [strict]=\"strict()\"\n      [formControl]=\"inner\"\n    />\n    <ng-template tuiDropdown>\n      @if (filterOptions()) {\n        <tui-data-list-wrapper\n          [items]=\"items() | tuiFilterByInput\"\n          [emptyContent]=\"emptyText()\"\n        />\n      } @else {\n        <tui-data-list-wrapper [items]=\"items()\" [emptyContent]=\"emptyText()\" />\n      }\n    </ng-template>\n  </tui-textfield>\n</atr-form-field>\n",
			styles: [":host{display:block}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: false
			}]
		}],
		query: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "query",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["queryChange"]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		clearable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "clearable",
				required: false
			}]
		}],
		emptyText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "emptyText",
				required: false
			}]
		}],
		strict: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "strict",
				required: false
			}]
		}],
		filterOptions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filterOptions",
				required: false
			}]
		}],
		compareWith: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "compareWith",
				required: false
			}]
		}],
		displayWith: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "displayWith",
				required: false
			}]
		}]
	}
});
var AtralumeComboboxHarness = class extends ComponentHarness {
	static hostSelector = "atr-combobox";
	control = this.locatorFor("input[atrComboBox], input[tuiComboBox], input[role=\"combobox\"], input");
	async isOpen() {
		return (await this.control()).getAttribute("aria-expanded").then((value) => value === "true");
	}
	async open() {
		if (!await this.isOpen()) await (await this.control()).sendKeys(TestKey.DOWN_ARROW);
	}
	async close() {
		await (await this.control()).sendKeys(TestKey.ESCAPE);
	}
	async isDisabled() {
		return !!await (await this.control()).getProperty("disabled");
	}
	async getValue() {
		const control = await this.control();
		return await control.getProperty("value") || await control.text();
	}
	async enterText(value) {
		const input = await this.control();
		await input.clear();
		await input.sendKeys(value);
	}
	async clear() {
		const button = await this.locatorForOptional("button[tuiButtonX], [tuiButtonX]")();
		if (button) await button.click();
	}
	async selectOption(label) {
		await this.open();
		const options = await this.documentRootLocatorFactory().locatorForAll("button[tuiOption], button[atrOption], [role=\"option\"]")();
		for (const option of options) if ((await option.text()).trim() === label) {
			await option.click();
			return;
		}
		throw new Error("Option not found: " + label);
	}
};
export { AtralumeComboBoxDirective, AtralumeCombobox, AtralumeComboboxHarness };

//# sourceMappingURL=osmanjimenez-atralume-combobox.mjs.map