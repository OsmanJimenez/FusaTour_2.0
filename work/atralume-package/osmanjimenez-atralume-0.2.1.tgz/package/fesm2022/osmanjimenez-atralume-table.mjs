import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, booleanAttribute, computed, input, model, output } from "@angular/core";
import * as i1 from "@taiga-ui/addon-table";
import { TuiTable } from "@taiga-ui/addon-table";
import { AtralumeCheckbox } from "@osmanjimenez/atralume/checkbox";
import { AtralumeIcon, chevronDownIcon, provideAtralumeIcons } from "@osmanjimenez/atralume/icon";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeTable = class AtralumeTable {
	label = input("Data table", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	rows = input([], ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	columns = input([], ...ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []);
	trackBy = input((row) => row, ...ngDevMode ? [{ debugName: "trackBy" }] : /* istanbul ignore next */ []);
	selectionMode = input("none", ...ngDevMode ? [{ debugName: "selectionMode" }] : /* istanbul ignore next */ []);
	selected = model([], ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	expanded = model([], ...ngDevMode ? [{ debugName: "expanded" }] : /* istanbul ignore next */ []);
	sort = model({
		active: "",
		direction: ""
	}, ...ngDevMode ? [{ debugName: "sort" }] : /* istanbul ignore next */ []);
	loading = input(false, {
		...ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	error = input(null, ...ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []);
	emptyText = input("No rows", ...ngDevMode ? [{ debugName: "emptyText" }] : /* istanbul ignore next */ []);
	zebra = input(false, {
		...ngDevMode ? { debugName: "zebra" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	hover = input(true, {
		...ngDevMode ? { debugName: "hover" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	expandable = input(false, {
		...ngDevMode ? { debugName: "expandable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	detail = input(() => null, ...ngDevMode ? [{ debugName: "detail" }] : /* istanbul ignore next */ []);
	selectionChange = output();
	expansionChange = output();
	columnIds = computed(() => this.columns().map((column) => column.id), ...ngDevMode ? [{ debugName: "columnIds" }] : /* istanbul ignore next */ []);
	allSelected = computed(() => {
		const rows = this.rows();
		return rows.length > 0 && rows.every((row, index) => this.isSelected(row, index));
	}, ...ngDevMode ? [{ debugName: "allSelected" }] : /* istanbul ignore next */ []);
	colspan = computed(() => this.columns().length + (this.selectionMode() === "none" ? 0 : 1) + (this.expandable() ? 1 : 0), ...ngDevMode ? [{ debugName: "colspan" }] : /* istanbul ignore next */ []);
	same(a, b, index = 0) {
		return Object.is(this.trackBy()(a, index), this.trackBy()(b, index));
	}
	isSelected(row, index) {
		return this.selected().some((item) => this.same(item, row, index));
	}
	isExpanded(row, index) {
		return this.expanded().some((item) => this.same(item, row, index));
	}
	select(row, index) {
		if (this.selectionMode() === "none") return;
		const present = this.isSelected(row, index);
		const next = this.selectionMode() === "single" ? present ? [] : [row] : present ? this.selected().filter((item) => !this.same(item, row, index)) : [...this.selected(), row];
		this.selected.set(next);
		this.selectionChange.emit({
			selected: next,
			changed: row
		});
	}
	selectAll() {
		if (this.selectionMode() !== "multiple") return;
		const next = this.allSelected() ? [] : [...this.rows()];
		this.selected.set(next);
		if (this.rows().length) this.selectionChange.emit({
			selected: next,
			changed: this.rows()[0]
		});
	}
	toggleExpanded(row, index) {
		if (!this.expandable()) return;
		const next = this.isExpanded(row, index) ? this.expanded().filter((item) => !this.same(item, row, index)) : [...this.expanded(), row];
		this.expanded.set(next);
		this.expansionChange.emit(next);
	}
	requestSort(column) {
		if (!column.sortable) return;
		const current = this.sort();
		const direction = current.active !== column.id ? "asc" : current.direction === "asc" ? "desc" : current.direction === "desc" ? "" : "asc";
		const next = {
			active: direction ? column.id : "",
			direction
		};
		this.sort.set(next);
	}
	sortLabel(column) {
		const sort = this.sort();
		return sort.active === column.id && sort.direction ? `Sort ${column.header}: ${sort.direction}` : `Sort ${column.header}`;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeTable,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeTable,
		isStandalone: true,
		selector: "atr-table",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rows: {
				classPropertyName: "rows",
				publicName: "rows",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			columns: {
				classPropertyName: "columns",
				publicName: "columns",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			trackBy: {
				classPropertyName: "trackBy",
				publicName: "trackBy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selectionMode: {
				classPropertyName: "selectionMode",
				publicName: "selectionMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selected: {
				classPropertyName: "selected",
				publicName: "selected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			expanded: {
				classPropertyName: "expanded",
				publicName: "expanded",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			sort: {
				classPropertyName: "sort",
				publicName: "sort",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			loading: {
				classPropertyName: "loading",
				publicName: "loading",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			error: {
				classPropertyName: "error",
				publicName: "error",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			emptyText: {
				classPropertyName: "emptyText",
				publicName: "emptyText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			zebra: {
				classPropertyName: "zebra",
				publicName: "zebra",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hover: {
				classPropertyName: "hover",
				publicName: "hover",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			expandable: {
				classPropertyName: "expandable",
				publicName: "expandable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			detail: {
				classPropertyName: "detail",
				publicName: "detail",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			selected: "selectedChange",
			expanded: "expandedChange",
			sort: "sortChange",
			selectionChange: "selectionChange",
			expansionChange: "expansionChange"
		},
		host: { classAttribute: "atr-table" },
		providers: [provideAtralumeIcons([chevronDownIcon])],
		ngImport: i0,
		template: "<div class=\"atr-table__scroll\">\n  <table\n    tuiTable\n    [columns]=\"columnIds()\"\n    [attr.aria-label]=\"label()\"\n    [class.atr-table--zebra]=\"zebra()\"\n    [class.atr-table--hover]=\"hover()\"\n  >\n    <thead>\n      <tr>\n        @if (selectionMode() !== \"none\") {\n          <th tuiTh scope=\"col\" class=\"atr-table__selection\" [sorter]=\"null\">\n            @if (selectionMode() === \"multiple\") {\n              <input\n                atrCheckbox\n                type=\"checkbox\"\n                aria-label=\"Select all visible rows\"\n                [checked]=\"allSelected()\"\n                (change)=\"selectAll()\"\n              />\n            }\n          </th>\n        }\n        @if (expandable()) {\n          <th tuiTh scope=\"col\" [sorter]=\"null\">\n            <span class=\"atr-sr-only\">Expand row</span>\n          </th>\n        }\n        @for (column of columns(); track column.id) {\n          <th\n            tuiTh\n            scope=\"col\"\n            [sorter]=\"null\"\n            [sticky]=\"column.sticky === 'start'\"\n            [attr.data-sticky]=\"column.sticky ?? null\"\n            [attr.aria-sort]=\"\n              sort().active === column.id\n                ? sort().direction === 'asc'\n                  ? 'ascending'\n                  : sort().direction === 'desc'\n                    ? 'descending'\n                    : 'none'\n                : null\n            \"\n          >\n            @if (column.sortable) {\n              <button\n                type=\"button\"\n                (click)=\"requestSort(column)\"\n                [attr.aria-label]=\"sortLabel(column)\"\n              >\n                {{ column.header }}\n              </button>\n            } @else {\n              {{ column.header }}\n            }\n          </th>\n        }\n      </tr>\n    </thead>\n    <tbody tuiTbody [data]=\"rows()\">\n      @if (loading()) {\n        <tr>\n          <td tuiTd [attr.colspan]=\"colspan()\" role=\"status\">Loading rows…</td>\n        </tr>\n      } @else if (error()) {\n        <tr>\n          <td tuiTd [attr.colspan]=\"colspan()\" role=\"alert\">{{ error() }}</td>\n        </tr>\n      } @else if (!rows().length) {\n        <tr>\n          <td tuiTd [attr.colspan]=\"colspan()\">{{ emptyText() }}</td>\n        </tr>\n      } @else {\n        @for (row of rows(); track trackBy()(row, $index); let index = $index) {\n          <tr\n            [attr.aria-selected]=\"\n              selectionMode() === 'none' ? null : isSelected(row, index)\n            \"\n            [class.atr-table__row--selected]=\"isSelected(row, index)\"\n          >\n            @if (selectionMode() !== \"none\") {\n              <td tuiTd class=\"atr-table__selection\">\n                <input\n                  atrCheckbox\n                  type=\"checkbox\"\n                  [attr.aria-label]=\"'Select row ' + (index + 1)\"\n                  [checked]=\"isSelected(row, index)\"\n                  (change)=\"select(row, index)\"\n                />\n              </td>\n            }\n            @if (expandable()) {\n              <td tuiTd>\n                <button\n                  type=\"button\"\n                  class=\"atr-table__expander\"\n                  [class.atr-table__expander--open]=\"isExpanded(row, index)\"\n                  [attr.aria-label]=\"\n                    (isExpanded(row, index) ? 'Collapse' : 'Expand') +\n                    ' row ' +\n                    (index + 1)\n                  \"\n                  [attr.aria-expanded]=\"isExpanded(row, index)\"\n                  (click)=\"toggleExpanded(row, index)\"\n                >\n                  <atr-icon name=\"chevron-down\" size=\"small\" aria-hidden=\"true\" />\n                </button>\n              </td>\n            }\n            @for (column of columns(); track column.id) {\n              <td tuiTd [attr.data-sticky]=\"column.sticky ?? null\">\n                {{ column.cell(row) }}\n              </td>\n            }\n          </tr>\n          @if (isExpanded(row, index)) {\n            <tr class=\"atr-table__detail\">\n              <td tuiTd [attr.colspan]=\"colspan()\">{{ detail()(row) }}</td>\n            </tr>\n          }\n        }\n      }\n    </tbody>\n  </table>\n</div>\n",
		styles: [":host{display:block;color:var(--atr-comp-table-label-color);font-family:var(--atr-ref-font-family-plain)}.atr-table__scroll{overflow:auto;border:1px solid var(--atr-comp-table-border-color);border-radius:var(--atr-comp-table-shape);background:var(--atr-comp-table-container-color)}table{inline-size:100%;border-collapse:collapse;text-align:start}th,td{padding:var(--atr-comp-table-padding);border-block-end:1px solid var(--atr-comp-table-border-color);white-space:nowrap}th{font-weight:650}th button,.atr-table__expander{display:inline-flex;align-items:center;justify-content:center;gap:var(--atr-sys-spacing-xs);min-block-size:var(--atr-sys-touch-target-minimum);min-inline-size:var(--atr-sys-touch-target-minimum);padding-inline:var(--atr-sys-spacing-sm);border:0;border-radius:var(--atr-sys-shape-small);background:transparent;color:inherit;font:inherit;cursor:pointer}.atr-table__expander{inline-size:var(--atr-sys-touch-target-minimum);padding-inline:0}.atr-table__expander atr-icon{transition:transform var(--atr-sys-motion-duration-short, .15s) var(--atr-sys-motion-easing-standard, ease)}.atr-table__expander--open atr-icon{transform:rotate(180deg)}th:has(.atr-sr-only),td:has(.atr-table__expander){inline-size:calc(var(--atr-sys-touch-target-minimum) + 1rem);max-inline-size:calc(var(--atr-sys-touch-target-minimum) + 1rem);padding-inline:var(--atr-sys-spacing-xs)}th button:focus-visible,input:focus-visible,.atr-table__expander:focus-visible{outline:var(--atr-sys-focus-ring-width) solid var(--atr-comp-table-focus-color);outline-offset:var(--atr-sys-focus-ring-offset)}.atr-table--zebra tbody tr:nth-child(2n){background:color-mix(in srgb,var(--atr-comp-table-container-color),var(--atr-comp-table-label-color) 4%)}.atr-table--hover tbody tr:hover{background:var(--atr-comp-table-selected-container-color)}.atr-table__row--selected{background:var(--atr-comp-table-selected-container-color);color:var(--atr-comp-table-selected-label-color)}.atr-table__detail td{white-space:normal}[data-sticky=start],[data-sticky=end]{position:sticky;background:inherit}[data-sticky=start]{inset-inline-start:0}[data-sticky=end]{inset-inline-end:0}.atr-sr-only{position:absolute;inline-size:1px;block-size:1px;overflow:hidden;clip-path:inset(50%)}@media(forced-colors:active){.atr-table__scroll{border-color:CanvasText}.atr-table__row--selected{outline:2px solid Highlight}}\n"],
		dependencies: [
			{
				kind: "directive",
				type: i1.TuiTableDirective,
				selector: "table[tuiTable]",
				inputs: [
					"columns",
					"size",
					"direction",
					"sorter"
				],
				outputs: [
					"directionChange",
					"sorterChange",
					"sortChange"
				]
			},
			{
				kind: "component",
				type: i1.TuiTableTbody,
				selector: "tbody[tuiTbody]",
				inputs: ["heading", "open"],
				outputs: ["openChange"]
			},
			{
				kind: "component",
				type: i1.TuiTableTh,
				selector: "th[tuiTh]",
				inputs: [
					"minWidth",
					"maxWidth",
					"sorter",
					"resizable",
					"sticky",
					"requiredSort"
				],
				outputs: ["sorterChange"]
			},
			{
				kind: "component",
				type: i1.TuiTableTd,
				selector: "th[tuiTd], td[tuiTd]"
			},
			{
				kind: "directive",
				type: AtralumeCheckbox,
				selector: "input[type=\"checkbox\"][atrCheckbox]",
				inputs: ["indeterminate"]
			},
			{
				kind: "component",
				type: AtralumeIcon,
				selector: "atr-icon",
				inputs: [
					"name",
					"size",
					"decorative",
					"label",
					"engine"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeTable,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-table",
			standalone: true,
			imports: [
				TuiTable,
				AtralumeCheckbox,
				AtralumeIcon
			],
			providers: [provideAtralumeIcons([chevronDownIcon])],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "atr-table" },
			template: "<div class=\"atr-table__scroll\">\n  <table\n    tuiTable\n    [columns]=\"columnIds()\"\n    [attr.aria-label]=\"label()\"\n    [class.atr-table--zebra]=\"zebra()\"\n    [class.atr-table--hover]=\"hover()\"\n  >\n    <thead>\n      <tr>\n        @if (selectionMode() !== \"none\") {\n          <th tuiTh scope=\"col\" class=\"atr-table__selection\" [sorter]=\"null\">\n            @if (selectionMode() === \"multiple\") {\n              <input\n                atrCheckbox\n                type=\"checkbox\"\n                aria-label=\"Select all visible rows\"\n                [checked]=\"allSelected()\"\n                (change)=\"selectAll()\"\n              />\n            }\n          </th>\n        }\n        @if (expandable()) {\n          <th tuiTh scope=\"col\" [sorter]=\"null\">\n            <span class=\"atr-sr-only\">Expand row</span>\n          </th>\n        }\n        @for (column of columns(); track column.id) {\n          <th\n            tuiTh\n            scope=\"col\"\n            [sorter]=\"null\"\n            [sticky]=\"column.sticky === 'start'\"\n            [attr.data-sticky]=\"column.sticky ?? null\"\n            [attr.aria-sort]=\"\n              sort().active === column.id\n                ? sort().direction === 'asc'\n                  ? 'ascending'\n                  : sort().direction === 'desc'\n                    ? 'descending'\n                    : 'none'\n                : null\n            \"\n          >\n            @if (column.sortable) {\n              <button\n                type=\"button\"\n                (click)=\"requestSort(column)\"\n                [attr.aria-label]=\"sortLabel(column)\"\n              >\n                {{ column.header }}\n              </button>\n            } @else {\n              {{ column.header }}\n            }\n          </th>\n        }\n      </tr>\n    </thead>\n    <tbody tuiTbody [data]=\"rows()\">\n      @if (loading()) {\n        <tr>\n          <td tuiTd [attr.colspan]=\"colspan()\" role=\"status\">Loading rows…</td>\n        </tr>\n      } @else if (error()) {\n        <tr>\n          <td tuiTd [attr.colspan]=\"colspan()\" role=\"alert\">{{ error() }}</td>\n        </tr>\n      } @else if (!rows().length) {\n        <tr>\n          <td tuiTd [attr.colspan]=\"colspan()\">{{ emptyText() }}</td>\n        </tr>\n      } @else {\n        @for (row of rows(); track trackBy()(row, $index); let index = $index) {\n          <tr\n            [attr.aria-selected]=\"\n              selectionMode() === 'none' ? null : isSelected(row, index)\n            \"\n            [class.atr-table__row--selected]=\"isSelected(row, index)\"\n          >\n            @if (selectionMode() !== \"none\") {\n              <td tuiTd class=\"atr-table__selection\">\n                <input\n                  atrCheckbox\n                  type=\"checkbox\"\n                  [attr.aria-label]=\"'Select row ' + (index + 1)\"\n                  [checked]=\"isSelected(row, index)\"\n                  (change)=\"select(row, index)\"\n                />\n              </td>\n            }\n            @if (expandable()) {\n              <td tuiTd>\n                <button\n                  type=\"button\"\n                  class=\"atr-table__expander\"\n                  [class.atr-table__expander--open]=\"isExpanded(row, index)\"\n                  [attr.aria-label]=\"\n                    (isExpanded(row, index) ? 'Collapse' : 'Expand') +\n                    ' row ' +\n                    (index + 1)\n                  \"\n                  [attr.aria-expanded]=\"isExpanded(row, index)\"\n                  (click)=\"toggleExpanded(row, index)\"\n                >\n                  <atr-icon name=\"chevron-down\" size=\"small\" aria-hidden=\"true\" />\n                </button>\n              </td>\n            }\n            @for (column of columns(); track column.id) {\n              <td tuiTd [attr.data-sticky]=\"column.sticky ?? null\">\n                {{ column.cell(row) }}\n              </td>\n            }\n          </tr>\n          @if (isExpanded(row, index)) {\n            <tr class=\"atr-table__detail\">\n              <td tuiTd [attr.colspan]=\"colspan()\">{{ detail()(row) }}</td>\n            </tr>\n          }\n        }\n      }\n    </tbody>\n  </table>\n</div>\n",
			styles: [":host{display:block;color:var(--atr-comp-table-label-color);font-family:var(--atr-ref-font-family-plain)}.atr-table__scroll{overflow:auto;border:1px solid var(--atr-comp-table-border-color);border-radius:var(--atr-comp-table-shape);background:var(--atr-comp-table-container-color)}table{inline-size:100%;border-collapse:collapse;text-align:start}th,td{padding:var(--atr-comp-table-padding);border-block-end:1px solid var(--atr-comp-table-border-color);white-space:nowrap}th{font-weight:650}th button,.atr-table__expander{display:inline-flex;align-items:center;justify-content:center;gap:var(--atr-sys-spacing-xs);min-block-size:var(--atr-sys-touch-target-minimum);min-inline-size:var(--atr-sys-touch-target-minimum);padding-inline:var(--atr-sys-spacing-sm);border:0;border-radius:var(--atr-sys-shape-small);background:transparent;color:inherit;font:inherit;cursor:pointer}.atr-table__expander{inline-size:var(--atr-sys-touch-target-minimum);padding-inline:0}.atr-table__expander atr-icon{transition:transform var(--atr-sys-motion-duration-short, .15s) var(--atr-sys-motion-easing-standard, ease)}.atr-table__expander--open atr-icon{transform:rotate(180deg)}th:has(.atr-sr-only),td:has(.atr-table__expander){inline-size:calc(var(--atr-sys-touch-target-minimum) + 1rem);max-inline-size:calc(var(--atr-sys-touch-target-minimum) + 1rem);padding-inline:var(--atr-sys-spacing-xs)}th button:focus-visible,input:focus-visible,.atr-table__expander:focus-visible{outline:var(--atr-sys-focus-ring-width) solid var(--atr-comp-table-focus-color);outline-offset:var(--atr-sys-focus-ring-offset)}.atr-table--zebra tbody tr:nth-child(2n){background:color-mix(in srgb,var(--atr-comp-table-container-color),var(--atr-comp-table-label-color) 4%)}.atr-table--hover tbody tr:hover{background:var(--atr-comp-table-selected-container-color)}.atr-table__row--selected{background:var(--atr-comp-table-selected-container-color);color:var(--atr-comp-table-selected-label-color)}.atr-table__detail td{white-space:normal}[data-sticky=start],[data-sticky=end]{position:sticky;background:inherit}[data-sticky=start]{inset-inline-start:0}[data-sticky=end]{inset-inline-end:0}.atr-sr-only{position:absolute;inline-size:1px;block-size:1px;overflow:hidden;clip-path:inset(50%)}@media(forced-colors:active){.atr-table__scroll{border-color:CanvasText}.atr-table__row--selected{outline:2px solid Highlight}}\n"]
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		rows: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rows",
				required: false
			}]
		}],
		columns: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columns",
				required: false
			}]
		}],
		trackBy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "trackBy",
				required: false
			}]
		}],
		selectionMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectionMode",
				required: false
			}]
		}],
		selected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selected",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["selectedChange"]
		}],
		expanded: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "expanded",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["expandedChange"]
		}],
		sort: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sort",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["sortChange"]
		}],
		loading: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "loading",
				required: false
			}]
		}],
		error: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "error",
				required: false
			}]
		}],
		emptyText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "emptyText",
				required: false
			}]
		}],
		zebra: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "zebra",
				required: false
			}]
		}],
		hover: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hover",
				required: false
			}]
		}],
		expandable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "expandable",
				required: false
			}]
		}],
		detail: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "detail",
				required: false
			}]
		}],
		selectionChange: [{
			type: i0.Output,
			args: ["selectionChange"]
		}],
		expansionChange: [{
			type: i0.Output,
			args: ["expansionChange"]
		}]
	}
});
var AtralumeTableHarness = class extends ComponentHarness {
	static hostSelector = "atr-table";
	async getRows() {
		return Promise.all((await this.locatorForAll("tbody tr:not(.atr-table__detail)")()).map(async (row) => [await row.text()]));
	}
	async getCells(row) {
		return [await (await this.locatorForAll("tbody tr:not(.atr-table__detail)")())[row].text()];
	}
	async sort(name) {
		await (await this.locatorFor(`th button[aria-label^="Sort ${name}"]`)()).click();
	}
	async selectRow(row) {
		await (await this.locatorForAll("tbody input[type=\"checkbox\"]")())[row].click();
	}
	async expandRow(row) {
		await (await this.locatorForAll(".atr-table__expander")())[row].click();
	}
	async getState() {
		const text = await this.host().then((h) => h.text());
		return text.includes("Loading rows") ? "loading" : text.includes("No rows") ? "empty" : await this.locatorForOptional("[role=\"alert\"]")() ? "error" : "ready";
	}
};
export { AtralumeTable, AtralumeTableHarness };

//# sourceMappingURL=osmanjimenez-atralume-table.mjs.map