import { AtralumeProgressSpinner } from "@osmanjimenez/atralume/progress";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, ElementRef, Renderer2, ViewEncapsulation, booleanAttribute, computed, inject, input } from "@angular/core";
import * as i1 from "@taiga-ui/core";
import { TuiButton } from "@taiga-ui/core";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeButton = class AtralumeButton {
	appearance = input("filled", ...ngDevMode ? [{ debugName: "appearance" }] : /* istanbul ignore next */ []);
	size = input("medium", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	loading = input(false, {
		...ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	fullWidth = input(false, {
		...ngDevMode ? { debugName: "fullWidth" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	tabindex = input(null, ...ngDevMode ? [{ debugName: "tabindex" }] : /* istanbul ignore next */ []);
	nativeButton = inject(ElementRef).nativeElement.tagName.toLowerCase() === "button";
	blocked = computed(() => this.disabled() || this.loading(), ...ngDevMode ? [{ debugName: "blocked" }] : /* istanbul ignore next */ []);
	constructor() {
		const element = inject(ElementRef).nativeElement;
		const unlisten = inject(Renderer2).listen(element, "click", (event) => {
			if (this.blocked()) {
				event.preventDefault();
				event.stopImmediatePropagation();
			}
		}, { capture: true });
		inject(DestroyRef).onDestroy(unlisten);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeButton,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeButton,
		isStandalone: true,
		selector: "button[atrButton], a[atrButton]",
		inputs: {
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			loading: {
				classPropertyName: "loading",
				publicName: "loading",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fullWidth: {
				classPropertyName: "fullWidth",
				publicName: "fullWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tabindex: {
				classPropertyName: "tabindex",
				publicName: "tabindex",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: {
				"attr.tuiButton": "\"\"",
				"attr.data-appearance": "appearance()",
				"attr.data-size": "size()",
				"class.atr-button--full": "fullWidth()",
				"class.atr-button--loading": "loading()",
				"attr.disabled": "nativeButton && blocked() ? '' : null",
				"attr.aria-disabled": "blocked() ? \"true\" : null",
				"attr.aria-busy": "loading() ? \"true\" : null",
				"attr.tabindex": "blocked() ? -1 : tabindex()"
			},
			classAttribute: "atr-button"
		},
		hostDirectives: [{
			directive: i1.TuiButton,
			inputs: ["size", "tuiSize"]
		}],
		ngImport: i0,
		template: "<span class=\"atr-button__content\"><ng-content /></span>\n@if (loading()) {\n  <atr-progress-spinner\n    class=\"atr-button__spinner\"\n    label=\"Loading\"\n    size=\"small\"\n    aria-hidden=\"true\"\n  />\n}\n",
		styles: ["[tuiButton].atr-button{--atr-button-background: var(--atr-comp-button-container-color);align-items:center;appearance:none;background:var(--atr-button-background);border:var(--atr-ref-border-width-thin) solid transparent;block-size:var(--atr-comp-button-container-height);border-radius:var(--atr-comp-button-container-radius);box-sizing:border-box;color:var(--atr-comp-button-label-color);cursor:pointer;display:inline-flex;font-family:var(--atr-comp-button-label-font-family);font-size:var(--atr-comp-button-label-font-size);font-weight:var(--atr-comp-button-label-font-weight);gap:var(--atr-comp-button-gap);justify-content:center;letter-spacing:var(--atr-comp-button-label-letter-spacing);padding-block:0;min-block-size:var(--atr-comp-button-container-height);padding-inline:var(--atr-comp-button-container-padding-inline);position:relative;text-decoration:none;transition:filter var(--atr-comp-button-motion-duration) var(--atr-comp-button-motion-easing),transform var(--atr-comp-button-motion-duration) var(--atr-comp-button-motion-easing)}[tuiButton].atr-button:hover:not(:disabled,[aria-disabled=true]){background:var(--atr-comp-button-container-hover-color, var(--atr-button-background));filter:brightness(calc(1 + var(--atr-comp-button-hover-opacity)))}[tuiButton].atr-button:active:not(:disabled,[aria-disabled=true]){background:var(--atr-comp-button-container-pressed-color, var(--atr-button-background));filter:brightness(calc(1 - var(--atr-comp-button-pressed-opacity)))}[tuiButton].atr-button:focus-visible{outline:var(--atr-comp-button-focus-ring-width) var(--atr-sys-focus-ring-style) var(--atr-comp-button-focus-ring-color);outline-offset:var(--atr-sys-focus-ring-offset)}.atr-button__content{display:inline-flex;align-items:center;justify-content:center;gap:inherit}[tuiButton].atr-button[data-appearance=tonal]{--atr-button-background: var( --atr-comp-button-tonal-container-color, var(--atr-sys-color-secondary-container) );color:var(--atr-comp-button-tonal-label-color, var(--atr-sys-color-on-secondary-container))}[tuiButton].atr-button[data-appearance=outlined],[tuiButton].atr-button[data-appearance=text]{--atr-button-background: var( --atr-comp-button-text-container-color, transparent );color:var(--atr-comp-button-text-label-color, var(--atr-sys-color-primary))}[tuiButton].atr-button[data-appearance=outlined]{border-color:var(--atr-comp-button-outline-color)}[tuiButton].atr-button[data-size=small]{block-size:var(--atr-comp-button-height-small);min-block-size:var(--atr-comp-button-height-small);padding-inline:var(--atr-sys-spacing-md)}[tuiButton].atr-button[data-size=large]{block-size:var(--atr-comp-button-height-large);min-block-size:var(--atr-comp-button-height-large)}[tuiButton].atr-button.atr-button--full{display:flex;inline-size:100%}[tuiButton].atr-button.atr-button--loading .atr-button__content{opacity:0}.atr-button__spinner{position:absolute;--atr-comp-progress-size-small: var(--atr-ref-spacing-5);--atr-comp-progress-indicator-color: currentcolor;--atr-comp-progress-track-color: transparent;--atr-comp-progress-spinner-duration: var(--atr-comp-button-spinner-duration);--atr-comp-progress-reduced-motion-duration: var( --atr-comp-button-reduced-motion-duration );--atr-comp-progress-motion-easing: var(--atr-comp-button-motion-easing)}@media(prefers-reduced-motion:reduce){[tuiButton].atr-button{transition:none}}@media(forced-colors:active){[tuiButton].atr-button{border-color:ButtonText}[tuiButton].atr-button:disabled{color:GrayText;background:Canvas}}[tuiButton].atr-button[aria-disabled=true]{background:var(--atr-comp-button-disabled-container-color, color-mix(in srgb, var(--atr-sys-color-on-surface) calc(var(--atr-comp-button-disabled-container-opacity) * 100%), transparent));color:var(--atr-comp-button-disabled-label-color, color-mix(in srgb, var(--atr-sys-color-on-surface) calc(var(--atr-comp-button-disabled-content-opacity) * 100%), transparent));cursor:not-allowed}@media(forced-colors:active){[tuiButton].atr-button[aria-disabled=true]{color:GrayText;background:Canvas}}\n"],
		dependencies: [{
			kind: "component",
			type: AtralumeProgressSpinner,
			selector: "atr-progress-spinner",
			inputs: ["size"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush,
		encapsulation: i0.ViewEncapsulation.None
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeButton,
	decorators: [{
		type: Component,
		args: [{
			selector: "button[atrButton], a[atrButton]",
			standalone: true,
			imports: [AtralumeProgressSpinner],
			hostDirectives: [{
				directive: TuiButton,
				inputs: ["size: tuiSize"]
			}],
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			host: {
				class: "atr-button",
				"[attr.tuiButton]": "\"\"",
				"[attr.data-appearance]": "appearance()",
				"[attr.data-size]": "size()",
				"[class.atr-button--full]": "fullWidth()",
				"[class.atr-button--loading]": "loading()",
				"[attr.disabled]": "nativeButton && blocked() ? '' : null",
				"[attr.aria-disabled]": "blocked() ? \"true\" : null",
				"[attr.aria-busy]": "loading() ? \"true\" : null",
				"[attr.tabindex]": "blocked() ? -1 : tabindex()"
			},
			template: "<span class=\"atr-button__content\"><ng-content /></span>\n@if (loading()) {\n  <atr-progress-spinner\n    class=\"atr-button__spinner\"\n    label=\"Loading\"\n    size=\"small\"\n    aria-hidden=\"true\"\n  />\n}\n",
			styles: ["[tuiButton].atr-button{--atr-button-background: var(--atr-comp-button-container-color);align-items:center;appearance:none;background:var(--atr-button-background);border:var(--atr-ref-border-width-thin) solid transparent;block-size:var(--atr-comp-button-container-height);border-radius:var(--atr-comp-button-container-radius);box-sizing:border-box;color:var(--atr-comp-button-label-color);cursor:pointer;display:inline-flex;font-family:var(--atr-comp-button-label-font-family);font-size:var(--atr-comp-button-label-font-size);font-weight:var(--atr-comp-button-label-font-weight);gap:var(--atr-comp-button-gap);justify-content:center;letter-spacing:var(--atr-comp-button-label-letter-spacing);padding-block:0;min-block-size:var(--atr-comp-button-container-height);padding-inline:var(--atr-comp-button-container-padding-inline);position:relative;text-decoration:none;transition:filter var(--atr-comp-button-motion-duration) var(--atr-comp-button-motion-easing),transform var(--atr-comp-button-motion-duration) var(--atr-comp-button-motion-easing)}[tuiButton].atr-button:hover:not(:disabled,[aria-disabled=true]){background:var(--atr-comp-button-container-hover-color, var(--atr-button-background));filter:brightness(calc(1 + var(--atr-comp-button-hover-opacity)))}[tuiButton].atr-button:active:not(:disabled,[aria-disabled=true]){background:var(--atr-comp-button-container-pressed-color, var(--atr-button-background));filter:brightness(calc(1 - var(--atr-comp-button-pressed-opacity)))}[tuiButton].atr-button:focus-visible{outline:var(--atr-comp-button-focus-ring-width) var(--atr-sys-focus-ring-style) var(--atr-comp-button-focus-ring-color);outline-offset:var(--atr-sys-focus-ring-offset)}.atr-button__content{display:inline-flex;align-items:center;justify-content:center;gap:inherit}[tuiButton].atr-button[data-appearance=tonal]{--atr-button-background: var( --atr-comp-button-tonal-container-color, var(--atr-sys-color-secondary-container) );color:var(--atr-comp-button-tonal-label-color, var(--atr-sys-color-on-secondary-container))}[tuiButton].atr-button[data-appearance=outlined],[tuiButton].atr-button[data-appearance=text]{--atr-button-background: var( --atr-comp-button-text-container-color, transparent );color:var(--atr-comp-button-text-label-color, var(--atr-sys-color-primary))}[tuiButton].atr-button[data-appearance=outlined]{border-color:var(--atr-comp-button-outline-color)}[tuiButton].atr-button[data-size=small]{block-size:var(--atr-comp-button-height-small);min-block-size:var(--atr-comp-button-height-small);padding-inline:var(--atr-sys-spacing-md)}[tuiButton].atr-button[data-size=large]{block-size:var(--atr-comp-button-height-large);min-block-size:var(--atr-comp-button-height-large)}[tuiButton].atr-button.atr-button--full{display:flex;inline-size:100%}[tuiButton].atr-button.atr-button--loading .atr-button__content{opacity:0}.atr-button__spinner{position:absolute;--atr-comp-progress-size-small: var(--atr-ref-spacing-5);--atr-comp-progress-indicator-color: currentcolor;--atr-comp-progress-track-color: transparent;--atr-comp-progress-spinner-duration: var(--atr-comp-button-spinner-duration);--atr-comp-progress-reduced-motion-duration: var( --atr-comp-button-reduced-motion-duration );--atr-comp-progress-motion-easing: var(--atr-comp-button-motion-easing)}@media(prefers-reduced-motion:reduce){[tuiButton].atr-button{transition:none}}@media(forced-colors:active){[tuiButton].atr-button{border-color:ButtonText}[tuiButton].atr-button:disabled{color:GrayText;background:Canvas}}[tuiButton].atr-button[aria-disabled=true]{background:var(--atr-comp-button-disabled-container-color, color-mix(in srgb, var(--atr-sys-color-on-surface) calc(var(--atr-comp-button-disabled-container-opacity) * 100%), transparent));color:var(--atr-comp-button-disabled-label-color, color-mix(in srgb, var(--atr-sys-color-on-surface) calc(var(--atr-comp-button-disabled-content-opacity) * 100%), transparent));cursor:not-allowed}@media(forced-colors:active){[tuiButton].atr-button[aria-disabled=true]{color:GrayText;background:Canvas}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		loading: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "loading",
				required: false
			}]
		}],
		fullWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fullWidth",
				required: false
			}]
		}],
		tabindex: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tabindex",
				required: false
			}]
		}]
	}
});
var AtralumeButtonHarness = class extends ComponentHarness {
	static hostSelector = ".atr-button";
	async getText() {
		return (await this.host()).text();
	}
	async getAppearance() {
		return (await this.host()).getAttribute("data-appearance");
	}
	async getSize() {
		return (await this.host()).getAttribute("data-size");
	}
	async isDisabled() {
		return await (await this.host()).getAttribute("aria-disabled") === "true";
	}
	async isLoading() {
		return await (await this.host()).getAttribute("aria-busy") === "true";
	}
	async click() {
		await (await this.host()).click();
	}
};
export { AtralumeButton, AtralumeButtonHarness };

//# sourceMappingURL=osmanjimenez-atralume-button.mjs.map