import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, Injectable, booleanAttribute, computed, input, model } from "@angular/core";
import { TuiDay, TuiDayRange, TuiMonth } from "@taiga-ui/cdk/date-time";
import { TuiCalendar } from "@taiga-ui/core";
import { TuiCalendarRange } from "@taiga-ui/kit";
import { ComponentHarness, HarnessPredicate } from "@angular/cdk/testing";
function toDay(value) {
	return value ? TuiDay.fromLocalNativeDate(value) : null;
}
function fromDay(value) {
	return value ? value.toLocalNativeDate() : null;
}
var AtralumeCalendar = class AtralumeCalendar {
	label = input("Choose date", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	value = model(null, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	rangeValue = model(null, ...ngDevMode ? [{ debugName: "rangeValue" }] : /* istanbul ignore next */ []);
	selectionMode = input("single", ...ngDevMode ? [{ debugName: "selectionMode" }] : /* istanbul ignore next */ []);
	visibleDate = model(null, ...ngDevMode ? [{ debugName: "visibleDate" }] : /* istanbul ignore next */ []);
	today = input(/* @__PURE__ */ new Date(), ...ngDevMode ? [{ debugName: "today" }] : /* istanbul ignore next */ []);
	min = input(null, ...ngDevMode ? [{ debugName: "min" }] : /* istanbul ignore next */ []);
	max = input(null, ...ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []);
	dateFilter = input(() => true, ...ngDevMode ? [{ debugName: "dateFilter" }] : /* istanbul ignore next */ []);
	showAdjacentDays = input(true, {
		...ngDevMode ? { debugName: "showAdjacentDays" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	readonly = input(false, {
		...ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	tuiMin = computed(() => toDay(this.min()) ?? TuiDay.currentLocal().append({ year: -100 }), ...ngDevMode ? [{ debugName: "tuiMin" }] : /* istanbul ignore next */ []);
	tuiMax = computed(() => toDay(this.max()) ?? TuiDay.currentLocal().append({ year: 100 }), ...ngDevMode ? [{ debugName: "tuiMax" }] : /* istanbul ignore next */ []);
	tuiDay = computed(() => toDay(this.value()), ...ngDevMode ? [{ debugName: "tuiDay" }] : /* istanbul ignore next */ []);
	tuiRange = computed(() => {
		const range = this.rangeValue();
		const start = toDay(range?.start ?? null);
		const end = toDay(range?.end ?? null);
		return start && end ? new TuiDayRange(start, end) : null;
	}, ...ngDevMode ? [{ debugName: "tuiRange" }] : /* istanbul ignore next */ []);
	tuiMonth = computed(() => {
		const visible = this.visibleDate() ?? this.value() ?? this.rangeValue()?.start ?? this.today();
		return new TuiMonth(visible.getFullYear(), visible.getMonth());
	}, ...ngDevMode ? [{ debugName: "tuiMonth" }] : /* istanbul ignore next */ []);
	disabledItemHandler = computed(() => {
		const filter = this.dateFilter();
		const blocked = this.disabled() || this.readonly();
		return (day) => blocked || !filter(day.toLocalNativeDate());
	}, ...ngDevMode ? [{ debugName: "disabledItemHandler" }] : /* istanbul ignore next */ []);
	onDayClick(day) {
		if (this.disabled() || this.readonly()) return;
		this.value.set(fromDay(day));
		this.visibleDate.set(fromDay(day));
	}
	onRange(value) {
		if (this.disabled() || this.readonly()) return;
		this.rangeValue.set(value ? {
			start: fromDay(value.from),
			end: fromDay(value.to)
		} : null);
		if (value) this.visibleDate.set(fromDay(value.from));
	}
	onMonth(month) {
		this.visibleDate.set(month.toLocalNativeDate());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeCalendar,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeCalendar,
		isStandalone: true,
		selector: "atr-calendar",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rangeValue: {
				classPropertyName: "rangeValue",
				publicName: "rangeValue",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selectionMode: {
				classPropertyName: "selectionMode",
				publicName: "selectionMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			visibleDate: {
				classPropertyName: "visibleDate",
				publicName: "visibleDate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			today: {
				classPropertyName: "today",
				publicName: "today",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			min: {
				classPropertyName: "min",
				publicName: "min",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			max: {
				classPropertyName: "max",
				publicName: "max",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dateFilter: {
				classPropertyName: "dateFilter",
				publicName: "dateFilter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showAdjacentDays: {
				classPropertyName: "showAdjacentDays",
				publicName: "showAdjacentDays",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readonly: {
				classPropertyName: "readonly",
				publicName: "readonly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			value: "valueChange",
			rangeValue: "rangeValueChange",
			visibleDate: "visibleDateChange"
		},
		host: { classAttribute: "atr-calendar" },
		ngImport: i0,
		template: "@if (selectionMode() === \"range\") {\n  <tui-calendar-range\n    [attr.aria-label]=\"label()\"\n    [value]=\"tuiRange()\"\n    (valueChange)=\"onRange($event)\"\n    [month]=\"tuiMonth()\"\n    (monthChange)=\"onMonth($event)\"\n    [min]=\"tuiMin()\"\n    [max]=\"tuiMax()\"\n    [disabledItemHandler]=\"disabledItemHandler()\"\n  />\n} @else {\n  <tui-calendar\n    [attr.aria-label]=\"label()\"\n    [value]=\"tuiDay()\"\n    [month]=\"tuiMonth()\"\n    (monthChange)=\"onMonth($event)\"\n    [min]=\"tuiMin()\"\n    [max]=\"tuiMax()\"\n    [showAdjacent]=\"showAdjacentDays()\"\n    [disabledItemHandler]=\"disabledItemHandler()\"\n    (dayClick)=\"onDayClick($event)\"\n  />\n}\n",
		styles: [":host{display:block;inline-size:fit-content;max-inline-size:100%;color:var(--atr-comp-calendar-label-color, inherit);font-family:var(--atr-ref-font-family-plain, inherit)}\n"],
		dependencies: [{
			kind: "component",
			type: TuiCalendar,
			selector: "tui-calendar:not([new]):not([months])",
			inputs: [
				"minViewedMonth",
				"maxViewedMonth",
				"showAdjacent",
				"markerHandler",
				"initialView",
				"hoveredItem"
			],
			outputs: ["hoveredItemChange", "dayClick"]
		}, {
			kind: "component",
			type: TuiCalendarRange,
			selector: "tui-calendar-range",
			inputs: [
				"minLength",
				"maxLength",
				"items",
				"listSize",
				"defaultViewedMonth",
				"markerHandler",
				"item"
			],
			outputs: ["itemChange"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeCalendar,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-calendar",
			standalone: true,
			imports: [TuiCalendar, TuiCalendarRange],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "atr-calendar" },
			template: "@if (selectionMode() === \"range\") {\n  <tui-calendar-range\n    [attr.aria-label]=\"label()\"\n    [value]=\"tuiRange()\"\n    (valueChange)=\"onRange($event)\"\n    [month]=\"tuiMonth()\"\n    (monthChange)=\"onMonth($event)\"\n    [min]=\"tuiMin()\"\n    [max]=\"tuiMax()\"\n    [disabledItemHandler]=\"disabledItemHandler()\"\n  />\n} @else {\n  <tui-calendar\n    [attr.aria-label]=\"label()\"\n    [value]=\"tuiDay()\"\n    [month]=\"tuiMonth()\"\n    (monthChange)=\"onMonth($event)\"\n    [min]=\"tuiMin()\"\n    [max]=\"tuiMax()\"\n    [showAdjacent]=\"showAdjacentDays()\"\n    [disabledItemHandler]=\"disabledItemHandler()\"\n    (dayClick)=\"onDayClick($event)\"\n  />\n}\n",
			styles: [":host{display:block;inline-size:fit-content;max-inline-size:100%;color:var(--atr-comp-calendar-label-color, inherit);font-family:var(--atr-ref-font-family-plain, inherit)}\n"]
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}],
		rangeValue: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rangeValue",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["rangeValueChange"]
		}],
		selectionMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectionMode",
				required: false
			}]
		}],
		visibleDate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "visibleDate",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["visibleDateChange"]
		}],
		today: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "today",
				required: false
			}]
		}],
		min: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "min",
				required: false
			}]
		}],
		max: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "max",
				required: false
			}]
		}],
		dateFilter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dateFilter",
				required: false
			}]
		}],
		showAdjacentDays: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showAdjacentDays",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		readonly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readonly",
				required: false
			}]
		}]
	}
});
var AtralumeDateAdapter = class AtralumeDateAdapter {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeDateAdapter,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeDateAdapter,
		providedIn: "root",
		useFactory: () => new AtralumeNativeDateAdapter()
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeDateAdapter,
	decorators: [{
		type: Injectable,
		args: [{
			providedIn: "root",
			useFactory: () => new AtralumeNativeDateAdapter()
		}]
	}]
});
var AtralumeNativeDateAdapter = class extends AtralumeDateAdapter {
	locale;
	weekStart;
	constructor(locale = "en-US", weekStart = 0) {
		super();
		this.locale = locale;
		this.weekStart = weekStart;
		if (!Number.isInteger(weekStart) || weekStart < 0 || weekStart > 6) throw new Error("firstDayOfWeek must be 0..6.");
	}
	today() {
		const value = /* @__PURE__ */ new Date();
		return this.create(value.getFullYear(), value.getMonth(), value.getDate());
	}
	create(year, month, day) {
		const value = /* @__PURE__ */ new Date(0);
		value.setHours(12, 0, 0, 0);
		value.setFullYear(year, month, day);
		return value;
	}
	year(value) {
		return value.getFullYear();
	}
	month(value) {
		return value.getMonth();
	}
	day(value) {
		return value.getDate();
	}
	weekday(value) {
		return value.getDay();
	}
	isValid(value) {
		return value instanceof Date && Number.isFinite(value.getTime());
	}
	firstDayOfWeek() {
		return this.weekStart;
	}
	daysInMonth(year, month) {
		return this.create(year, month + 1, 0).getDate();
	}
	compare(a, b) {
		return this.year(a) - this.year(b) || this.month(a) - this.month(b) || this.day(a) - this.day(b);
	}
	addDays(value, days) {
		return this.create(this.year(value), this.month(value), this.day(value) + days);
	}
	addMonths(value, months) {
		const first = this.create(this.year(value), this.month(value) + months, 1);
		return this.create(this.year(first), this.month(first), Math.min(this.day(value), this.daysInMonth(this.year(first), this.month(first))));
	}
	addYears(value, years) {
		return this.addMonths(value, years * 12);
	}
	parse(text, locale = this.locale) {
		const value = text.trim();
		if (!value) return null;
		let year, month, day;
		const iso = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
		if (iso) {
			year = Number(iso[1]);
			month = Number(iso[2]) - 1;
			day = Number(iso[3]);
		} else {
			const digits = value.match(/\d+/g);
			if (!digits || digits.length !== 3) return null;
			const order = new Intl.DateTimeFormat(locale, {
				year: "numeric",
				month: "numeric",
				day: "numeric",
				numberingSystem: "latn"
			}).formatToParts(this.create(2006, 10, 22)).filter((part) => [
				"year",
				"month",
				"day"
			].includes(part.type));
			const fields = new Map(order.map((part, index) => [part.type, Number(digits[index])]));
			year = fields.get("year");
			month = fields.get("month") - 1;
			day = fields.get("day");
			if (!/^\D*\d+\D+\d+\D+\d+\D*$/.test(value) || year < 100) return null;
		}
		const date = this.create(year, month, day);
		return this.isValid(date) && this.year(date) === year && this.month(date) === month && this.day(date) === day ? date : null;
	}
	format(value, format = "input", locale = this.locale) {
		if (!this.isValid(value)) return "";
		const options = format === "input" ? {
			year: "numeric",
			month: "2-digit",
			day: "2-digit",
			numberingSystem: "latn"
		} : format === "month-year" ? {
			year: "numeric",
			month: "long"
		} : {
			year: "numeric",
			month: "long",
			day: "numeric",
			weekday: "long"
		};
		return new Intl.DateTimeFormat(locale, options).format(value);
	}
	weekdayName(day, locale = this.locale) {
		return new Intl.DateTimeFormat(locale, { weekday: "short" }).format(this.create(2024, 0, 7 + day));
	}
	serialize(value) {
		return String(this.year(value)).padStart(4, "0") + "-" + String(this.month(value) + 1).padStart(2, "0") + "-" + String(this.day(value)).padStart(2, "0");
	}
};
function provideAtralumeNativeDateAdapter(options = {}) {
	return [{
		provide: AtralumeDateAdapter,
		useFactory: () => new AtralumeNativeDateAdapter(options.locale ?? "en-US", options.firstDayOfWeek ?? 0)
	}];
}
var AtralumeCalendarHarness = class AtralumeCalendarHarness extends ComponentHarness {
	static hostSelector = "atr-calendar";
	static with(options = {}) {
		return new HarnessPredicate(AtralumeCalendarHarness, options);
	}
	cells = this.locatorForAll("[automation-id=\"tui-calendar-sheet__cell\"]");
	async getVisibleMonth() {
		const spin = await this.locatorForOptional("tui-calendar-spin, .t-title, button")();
		return spin ? spin.text() : (await this.host()).text();
	}
	async nextMonth() {
		const buttons = await this.locatorForAll("button, [tuiIconButton]")();
		if (buttons.length < 2) throw new Error("Calendar pagination not found");
		await buttons[buttons.length - 1].click();
	}
	async previousMonth() {
		const buttons = await this.locatorForAll("button, [tuiIconButton]")();
		if (!buttons.length) throw new Error("Calendar pagination not found");
		await buttons[0].click();
	}
	async selectDate(id) {
		const day = Number(id.split("-")[2]);
		const cells = await this.cells();
		for (const cell of cells) if ((await cell.text()).trim() === String(day) && !await cell.hasClass("t-cell_unavailable")) {
			await cell.click();
			return;
		}
		throw new Error("Date not in visible calendar: " + id);
	}
	async getSelectedDates() {
		const cells = await this.cells();
		const selected = [];
		for (const cell of cells) {
			const range = await cell.getAttribute("data-range");
			if (range === "active" || range === "start" || range === "end") selected.push((await cell.text()).trim());
		}
		return selected;
	}
};
export { AtralumeCalendar, AtralumeCalendarHarness, AtralumeDateAdapter, AtralumeNativeDateAdapter, provideAtralumeNativeDateAdapter };

//# sourceMappingURL=osmanjimenez-atralume-calendar.mjs.map