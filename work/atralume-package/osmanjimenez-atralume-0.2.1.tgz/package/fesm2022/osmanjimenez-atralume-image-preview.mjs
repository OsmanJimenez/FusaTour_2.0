import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, booleanAttribute, computed, inject, input, model, output, signal, viewChild } from "@angular/core";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";
import { AtralumeButton } from "@osmanjimenez/atralume/button";
import { ATR_DIALOG_DATA, AtralumeDialog, AtralumeDialogRef } from "@osmanjimenez/atralume/dialog";
import * as i1 from "@taiga-ui/kit";
import { TuiPreview } from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeImagePreviewPanel = class AtralumeImagePreviewPanel {
	data = inject(ATR_DIALOG_DATA);
	ref = inject(AtralumeDialogRef);
	activeIndex = signal(this.data.index, ...ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []);
	failedSource = signal(null, ...ngDevMode ? [{ debugName: "failedSource" }] : /* istanbul ignore next */ []);
	image = computed(() => this.data.images[this.activeIndex()] ?? null, ...ngDevMode ? [{ debugName: "image" }] : /* istanbul ignore next */ []);
	hasPrevious = computed(() => this.activeIndex() > 0, ...ngDevMode ? [{ debugName: "hasPrevious" }] : /* istanbul ignore next */ []);
	hasNext = computed(() => this.activeIndex() < this.data.images.length - 1, ...ngDevMode ? [{ debugName: "hasNext" }] : /* istanbul ignore next */ []);
	zoomable = this.data.zoomable;
	rotatable = this.data.rotatable;
	label = this.data.label;
	previous() {
		if (this.hasPrevious()) this.activeIndex.update((index) => index - 1);
	}
	next() {
		if (this.hasNext()) this.activeIndex.update((index) => index + 1);
	}
	close() {
		this.ref.close();
	}
	failed() {
		this.failedSource.set(this.image()?.src ?? null);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeImagePreviewPanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeImagePreviewPanel,
		isStandalone: true,
		selector: "atr-image-preview-panel",
		host: { classAttribute: "atr-image-preview-panel" },
		ngImport: i0,
		template: "<section class=\"atr-image-preview-panel__shell\" [attr.aria-label]=\"label\">\n  @if (image(); as current) {\n    <header class=\"atr-image-preview-panel__header\">\n      <div class=\"atr-image-preview-panel__meta\">\n        @if (current.title) {\n          <h2>{{ current.title }}</h2>\n        }\n        @if (current.description) {\n          <p>{{ current.description }}</p>\n        }\n      </div>\n      <button\n        atrButton\n        type=\"button\"\n        appearance=\"text\"\n        class=\"atr-image-preview-panel__close\"\n        (click)=\"close()\"\n      >\n        Close\n      </button>\n    </header>\n    <div class=\"atr-image-preview-panel__stage\">\n      <tui-preview\n        [zoomable]=\"zoomable\"\n        [rotatable]=\"rotatable\"\n        [initialScale]=\"1\"\n      >\n        <img\n          [src]=\"\n            failedSource() === current.src ? current.fallbackSrc : current.src\n          \"\n          [alt]=\"current.alt\"\n          (error)=\"failed()\"\n        />\n      </tui-preview>\n    </div>\n  }\n  <footer class=\"atr-image-preview-panel__footer\">\n    @if (hasPrevious()) {\n      <button atrButton type=\"button\" appearance=\"text\" (click)=\"previous()\">\n        Previous\n      </button>\n    } @else {\n      <span></span>\n    }\n    <span>{{ activeIndex() + 1 }} / {{ data.images.length }}</span>\n    @if (hasNext()) {\n      <button atrButton type=\"button\" appearance=\"text\" (click)=\"next()\">\n        Next\n      </button>\n    } @else {\n      <span></span>\n    }\n  </footer>\n</section>\n",
		styles: [":host{color:var(--atr-comp-image-preview-label-color);display:block;inline-size:100%}.atr-image-preview-panel__shell{display:grid;gap:var(--atr-comp-image-preview-gap);padding:var(--atr-sys-spacing-md)}.atr-image-preview-panel__header,.atr-image-preview-panel__footer{align-items:center;display:flex;gap:var(--atr-comp-image-preview-gap);justify-content:space-between}.atr-image-preview-panel__meta{display:grid;gap:.25rem;min-inline-size:0}.atr-image-preview-panel__meta h2{font-size:clamp(1.125rem,2vw,1.5rem);font-weight:var(--atr-ref-font-weight-bold, 700);letter-spacing:-.02em;line-height:1.25;margin:0}.atr-image-preview-panel__meta p{color:var(--atr-sys-color-on-surface-variant);font-size:var(--atr-ref-font-size-14, .875rem);line-height:1.4;margin:0}.atr-image-preview-panel__close{flex:0 0 auto}.atr-image-preview-panel__stage{--atr-image-preview-stage-block-size: min(62vh, 36rem);background:var(--atr-comp-image-preview-scrim-color);border-radius:var(--atr-comp-image-preview-shape);block-size:var(--atr-image-preview-stage-block-size);display:grid;overflow:hidden;place-items:center;position:relative}.atr-image-preview-panel__footer{color:var(--atr-sys-color-on-surface-variant);font-size:var(--atr-ref-font-size-14, .875rem)}@media(width<=44rem){.atr-image-preview-panel__shell{padding:var(--atr-sys-spacing-sm)}.atr-image-preview-panel__stage{--atr-image-preview-stage-block-size: min(48vh, 24rem)}}@media(prefers-reduced-motion:reduce){.atr-image-preview-panel__stage tui-preview{transition:none}}\n"],
		dependencies: [{
			kind: "component",
			type: AtralumeButton,
			selector: "button[atrButton], a[atrButton]",
			inputs: [
				"appearance",
				"size",
				"disabled",
				"loading",
				"fullWidth",
				"tabindex"
			]
		}, {
			kind: "component",
			type: i1.TuiPreviewComponent,
			selector: "tui-preview",
			inputs: [
				"zoomable",
				"rotatable",
				"initialScale"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeImagePreviewPanel,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-image-preview-panel",
			standalone: true,
			imports: [AtralumeButton, TuiPreview],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "atr-image-preview-panel" },
			template: "<section class=\"atr-image-preview-panel__shell\" [attr.aria-label]=\"label\">\n  @if (image(); as current) {\n    <header class=\"atr-image-preview-panel__header\">\n      <div class=\"atr-image-preview-panel__meta\">\n        @if (current.title) {\n          <h2>{{ current.title }}</h2>\n        }\n        @if (current.description) {\n          <p>{{ current.description }}</p>\n        }\n      </div>\n      <button\n        atrButton\n        type=\"button\"\n        appearance=\"text\"\n        class=\"atr-image-preview-panel__close\"\n        (click)=\"close()\"\n      >\n        Close\n      </button>\n    </header>\n    <div class=\"atr-image-preview-panel__stage\">\n      <tui-preview\n        [zoomable]=\"zoomable\"\n        [rotatable]=\"rotatable\"\n        [initialScale]=\"1\"\n      >\n        <img\n          [src]=\"\n            failedSource() === current.src ? current.fallbackSrc : current.src\n          \"\n          [alt]=\"current.alt\"\n          (error)=\"failed()\"\n        />\n      </tui-preview>\n    </div>\n  }\n  <footer class=\"atr-image-preview-panel__footer\">\n    @if (hasPrevious()) {\n      <button atrButton type=\"button\" appearance=\"text\" (click)=\"previous()\">\n        Previous\n      </button>\n    } @else {\n      <span></span>\n    }\n    <span>{{ activeIndex() + 1 }} / {{ data.images.length }}</span>\n    @if (hasNext()) {\n      <button atrButton type=\"button\" appearance=\"text\" (click)=\"next()\">\n        Next\n      </button>\n    } @else {\n      <span></span>\n    }\n  </footer>\n</section>\n",
			styles: [":host{color:var(--atr-comp-image-preview-label-color);display:block;inline-size:100%}.atr-image-preview-panel__shell{display:grid;gap:var(--atr-comp-image-preview-gap);padding:var(--atr-sys-spacing-md)}.atr-image-preview-panel__header,.atr-image-preview-panel__footer{align-items:center;display:flex;gap:var(--atr-comp-image-preview-gap);justify-content:space-between}.atr-image-preview-panel__meta{display:grid;gap:.25rem;min-inline-size:0}.atr-image-preview-panel__meta h2{font-size:clamp(1.125rem,2vw,1.5rem);font-weight:var(--atr-ref-font-weight-bold, 700);letter-spacing:-.02em;line-height:1.25;margin:0}.atr-image-preview-panel__meta p{color:var(--atr-sys-color-on-surface-variant);font-size:var(--atr-ref-font-size-14, .875rem);line-height:1.4;margin:0}.atr-image-preview-panel__close{flex:0 0 auto}.atr-image-preview-panel__stage{--atr-image-preview-stage-block-size: min(62vh, 36rem);background:var(--atr-comp-image-preview-scrim-color);border-radius:var(--atr-comp-image-preview-shape);block-size:var(--atr-image-preview-stage-block-size);display:grid;overflow:hidden;place-items:center;position:relative}.atr-image-preview-panel__footer{color:var(--atr-sys-color-on-surface-variant);font-size:var(--atr-ref-font-size-14, .875rem)}@media(width<=44rem){.atr-image-preview-panel__shell{padding:var(--atr-sys-spacing-sm)}.atr-image-preview-panel__stage{--atr-image-preview-stage-block-size: min(48vh, 24rem)}}@media(prefers-reduced-motion:reduce){.atr-image-preview-panel__stage tui-preview{transition:none}}\n"]
		}]
	}]
});
var AtralumeImagePreview = class AtralumeImagePreview {
	images = input.required(...ngDevMode ? [{ debugName: "images" }] : /* istanbul ignore next */ []);
	activeIndex = model(0, ...ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []);
	label = input("Image preview", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	triggerLabel = input("Open image preview", ...ngDevMode ? [{ debugName: "triggerLabel" }] : /* istanbul ignore next */ []);
	zoomable = input(true, {
		...ngDevMode ? { debugName: "zoomable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	rotatable = input(false, {
		...ngDevMode ? { debugName: "rotatable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	showTrigger = input(true, {
		...ngDevMode ? { debugName: "showTrigger" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	closed = output();
	dialog = inject(AtralumeDialog);
	destroyRef = inject(DestroyRef);
	trigger = viewChild("trigger", ...ngDevMode ? [{ debugName: "trigger" }] : /* istanbul ignore next */ []);
	open(origin = this.trigger()?.nativeElement) {
		const images = this.images();
		if (!images.length || this.disabled()) return;
		const index = Math.min(Math.max(0, this.activeIndex()), images.length - 1);
		this.activeIndex.set(index);
		this.dialog.open(AtralumeImagePreviewPanel, {
			data: {
				images,
				index,
				zoomable: this.zoomable(),
				rotatable: this.rotatable(),
				label: this.label()
			},
			label: this.label(),
			appearance: "atr-image-preview",
			size: "l",
			closable: false,
			origin,
			restoreFocus: true
		}).afterClosed.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => this.closed.emit());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeImagePreview,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeImagePreview,
		isStandalone: true,
		selector: "atr-image-preview",
		inputs: {
			images: {
				classPropertyName: "images",
				publicName: "images",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			activeIndex: {
				classPropertyName: "activeIndex",
				publicName: "activeIndex",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			triggerLabel: {
				classPropertyName: "triggerLabel",
				publicName: "triggerLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			zoomable: {
				classPropertyName: "zoomable",
				publicName: "zoomable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rotatable: {
				classPropertyName: "rotatable",
				publicName: "rotatable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showTrigger: {
				classPropertyName: "showTrigger",
				publicName: "showTrigger",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			activeIndex: "activeIndexChange",
			closed: "closed"
		},
		host: { classAttribute: "atr-image-preview" },
		viewQueries: [{
			propertyName: "trigger",
			first: true,
			predicate: ["trigger"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "@if (showTrigger()) {\n  <button\n    #trigger\n    type=\"button\"\n    [disabled]=\"disabled() || !images().length\"\n    (click)=\"open()\"\n  >\n    {{ triggerLabel() }}\n  </button>\n}\n",
		styles: [":host{display:inline-block}button{background:var(--atr-comp-image-preview-container-color);border:0;border-radius:var(--atr-comp-image-preview-shape);color:var(--atr-comp-image-preview-label-color);cursor:pointer;min-block-size:var(--atr-sys-touch-target-minimum);padding-inline:var(--atr-sys-spacing-md)}button:focus-visible{outline:var(--atr-sys-focus-ring-width) var(--atr-sys-focus-ring-style) var(--atr-sys-color-focus);outline-offset:var(--atr-sys-focus-ring-offset)}button:disabled{cursor:not-allowed;opacity:var(--atr-sys-state-disabled-content-opacity)}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeImagePreview,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-image-preview",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "atr-image-preview" },
			template: "@if (showTrigger()) {\n  <button\n    #trigger\n    type=\"button\"\n    [disabled]=\"disabled() || !images().length\"\n    (click)=\"open()\"\n  >\n    {{ triggerLabel() }}\n  </button>\n}\n",
			styles: [":host{display:inline-block}button{background:var(--atr-comp-image-preview-container-color);border:0;border-radius:var(--atr-comp-image-preview-shape);color:var(--atr-comp-image-preview-label-color);cursor:pointer;min-block-size:var(--atr-sys-touch-target-minimum);padding-inline:var(--atr-sys-spacing-md)}button:focus-visible{outline:var(--atr-sys-focus-ring-width) var(--atr-sys-focus-ring-style) var(--atr-sys-color-focus);outline-offset:var(--atr-sys-focus-ring-offset)}button:disabled{cursor:not-allowed;opacity:var(--atr-sys-state-disabled-content-opacity)}\n"]
		}]
	}],
	propDecorators: {
		images: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "images",
				required: true
			}]
		}],
		activeIndex: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "activeIndex",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["activeIndexChange"]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		triggerLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "triggerLabel",
				required: false
			}]
		}],
		zoomable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "zoomable",
				required: false
			}]
		}],
		rotatable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rotatable",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		showTrigger: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showTrigger",
				required: false
			}]
		}],
		closed: [{
			type: i0.Output,
			args: ["closed"]
		}],
		trigger: [{
			type: i0.ViewChild,
			args: ["trigger", { isSignal: true }]
		}]
	}
});
var AtralumeImagePreviewHarness = class extends ComponentHarness {
	static hostSelector = "atr-image-preview";
	async open() {
		await (await this.locatorFor("button")()).click();
	}
	async isTriggerDisabled() {
		return await (await this.locatorFor("button")()).getAttribute("disabled") !== null;
	}
};
export { AtralumeImagePreview, AtralumeImagePreviewHarness };

//# sourceMappingURL=osmanjimenez-atralume-image-preview.mjs.map