import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, booleanAttribute, computed, effect, forwardRef, inject, input, untracked } from "@angular/core";
import * as i1 from "@angular/forms";
import { FormControl, NG_VALIDATORS, NG_VALUE_ACCESSOR, ReactiveFormsModule } from "@angular/forms";
import { TuiTime } from "@taiga-ui/cdk/date-time";
import * as i2 from "@taiga-ui/kit";
import { TuiInputTime } from "@taiga-ui/kit";
import { AtralumeFormField } from "@osmanjimenez/atralume/form-field";
import { ɵAtralumeValueControl } from "@osmanjimenez/atralume/internal/forms";
import * as i3 from "@taiga-ui/core/components/label";
import * as i4 from "@taiga-ui/core/components/textfield";
import { ComponentHarness, TestKey } from "@angular/cdk/testing";
function toTime(value) {
	return value ? new TuiTime(value.hours, value.minutes, value.seconds ?? 0) : null;
}
function fromTime(value, withSeconds) {
	return value ? {
		hours: value.hours,
		minutes: value.minutes,
		...withSeconds ? { seconds: value.seconds } : {}
	} : null;
}
function sameTime(a, b, withSeconds) {
	if (a === b) return true;
	if (!a || !b) return false;
	return a.hours === b.hours && a.minutes === b.minutes && (!withSeconds || a.seconds === b.seconds);
}
var AtralumeTimePicker = class AtralumeTimePicker extends ɵAtralumeValueControl {
	format = input("24h", ...ngDevMode ? [{ debugName: "format" }] : /* istanbul ignore next */ []);
	seconds = input(false, {
		...ngDevMode ? { debugName: "seconds" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	step = input(60, ...ngDevMode ? [{ debugName: "step" }] : /* istanbul ignore next */ []);
	min = input(null, ...ngDevMode ? [{ debugName: "min" }] : /* istanbul ignore next */ []);
	max = input(null, ...ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []);
	clearable = input(false, {
		...ngDevMode ? { debugName: "clearable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	hasSeconds = computed(() => this.seconds() || this.step() % 60 !== 0, ...ngDevMode ? [{ debugName: "hasSeconds" }] : /* istanbul ignore next */ []);
	mode = computed(() => {
		if (this.hasSeconds()) return this.format() === "12h" ? "HH:MM:SS AA" : "HH:MM:SS";
		return this.format() === "12h" ? "HH:MM AA" : "HH:MM";
	}, ...ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []);
	inner = new FormControl(null);
	validatorChanged = () => void 0;
	constructor() {
		super();
		const destroyRef = inject(DestroyRef);
		const sub = this.inner.valueChanges.subscribe((time) => {
			this.commit(fromTime(time, this.hasSeconds()));
		});
		destroyRef.onDestroy(() => sub.unsubscribe());
		effect(() => {
			const next = toTime(this.value());
			const withSeconds = this.hasSeconds();
			untracked(() => {
				if (!sameTime(this.inner.value, next, withSeconds)) this.inner.setValue(next, { emitEvent: false });
			});
		});
		effect(() => {
			if (this.blocked()) this.inner.disable({ emitEvent: false });
			else this.inner.enable({ emitEvent: false });
		});
		effect(() => {
			this.value();
			this.min();
			this.max();
			this.step();
			this.required();
			untracked(() => this.validatorChanged());
		});
	}
	validate() {
		return this.value() === null ? this.required() ? { required: true } : null : null;
	}
	registerOnValidatorChange(fn) {
		this.validatorChanged = fn;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeTimePicker,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeTimePicker,
		isStandalone: true,
		selector: "atr-time-picker",
		inputs: {
			format: {
				classPropertyName: "format",
				publicName: "format",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			seconds: {
				classPropertyName: "seconds",
				publicName: "seconds",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			step: {
				classPropertyName: "step",
				publicName: "step",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			min: {
				classPropertyName: "min",
				publicName: "min",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			max: {
				classPropertyName: "max",
				publicName: "max",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			clearable: {
				classPropertyName: "clearable",
				publicName: "clearable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "atr-time-picker" },
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => AtralumeTimePicker),
			multi: true
		}, {
			provide: NG_VALIDATORS,
			useExisting: forwardRef(() => AtralumeTimePicker),
			multi: true
		}],
		usesInheritance: true,
		ngImport: i0,
		template: "<atr-form-field [hint]=\"hint()\" [error]=\"error()\">\n  <tui-textfield\n    [invalid]=\"displayInvalid()\"\n    [tuiTextfieldCleaner]=\"clearable()\"\n    tuiTextfieldSize=\"m\"\n  >\n    <label tuiLabel [attr.for]=\"controlId()\">\n      {{ label() }}\n      @if (required()) {\n        *\n      }\n    </label>\n    <input\n      tuiInputTime\n      data-atr-value-control\n      [id]=\"controlId()\"\n      [formControl]=\"inner\"\n      [mode]=\"mode()\"\n      [readOnly]=\"readonly()\"\n    />\n  </tui-textfield>\n</atr-form-field>\n",
		styles: [":host{display:block;min-inline-size:0}\n"],
		dependencies: [
			{
				kind: "ngmodule",
				type: ReactiveFormsModule
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.FormControlDirective,
				selector: "[formControl]",
				inputs: [
					"formControl",
					"disabled",
					"ngModel"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngForm"]
			},
			{
				kind: "component",
				type: AtralumeFormField,
				selector: "atr-form-field",
				inputs: [
					"hint",
					"error",
					"appearance",
					"density",
					"label",
					"required",
					"optional",
					"optionalText"
				]
			},
			{
				kind: "directive",
				type: i2.TuiInputTimeDirective,
				selector: "input[tuiInputTime]",
				inputs: [
					"accept",
					"mode",
					"prefix",
					"postfix"
				]
			},
			{
				kind: "directive",
				type: i3.TuiLabel,
				selector: "label[tuiLabel]"
			},
			{
				kind: "component",
				type: i4.TuiTextfieldComponent,
				selector: "tui-textfield:not([multi])",
				inputs: [
					"content",
					"filler",
					"invalid",
					"tuiAppearanceFocus",
					"tuiAppearanceState"
				]
			},
			{
				kind: "directive",
				type: i4.TuiTextfieldOptionsDirective,
				selector: "[tuiTextfieldAppearance],[tuiTextfieldSize],[tuiTextfieldCleaner]",
				inputs: [
					"tuiTextfieldAppearance",
					"tuiTextfieldSize",
					"tuiTextfieldCleaner"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeTimePicker,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-time-picker",
			standalone: true,
			imports: [
				ReactiveFormsModule,
				AtralumeFormField,
				TuiInputTime
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => AtralumeTimePicker),
				multi: true
			}, {
				provide: NG_VALIDATORS,
				useExisting: forwardRef(() => AtralumeTimePicker),
				multi: true
			}],
			host: { class: "atr-time-picker" },
			template: "<atr-form-field [hint]=\"hint()\" [error]=\"error()\">\n  <tui-textfield\n    [invalid]=\"displayInvalid()\"\n    [tuiTextfieldCleaner]=\"clearable()\"\n    tuiTextfieldSize=\"m\"\n  >\n    <label tuiLabel [attr.for]=\"controlId()\">\n      {{ label() }}\n      @if (required()) {\n        *\n      }\n    </label>\n    <input\n      tuiInputTime\n      data-atr-value-control\n      [id]=\"controlId()\"\n      [formControl]=\"inner\"\n      [mode]=\"mode()\"\n      [readOnly]=\"readonly()\"\n    />\n  </tui-textfield>\n</atr-form-field>\n",
			styles: [":host{display:block;min-inline-size:0}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		format: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "format",
				required: false
			}]
		}],
		seconds: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "seconds",
				required: false
			}]
		}],
		step: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "step",
				required: false
			}]
		}],
		min: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "min",
				required: false
			}]
		}],
		max: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "max",
				required: false
			}]
		}],
		clearable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "clearable",
				required: false
			}]
		}]
	}
});
var AtralumeTimePickerHarness = class extends ComponentHarness {
	static hostSelector = "atr-time-picker";
	input = this.locatorFor("input[type=\"time\"]");
	async getValue() {
		return (await this.input()).getProperty("value");
	}
	async setValue(value) {
		const input = await this.input();
		await input.setInputValue(value);
		await input.dispatchEvent("input");
	}
	async open() {
		await (await this.locatorFor("button[aria-haspopup=\"dialog\"]")()).click();
	}
	async close() {
		await (await this.input()).sendKeys(TestKey.ESCAPE);
	}
	async clear() {
		await (await this.locatorFor("button[aria-label^=\"Clear \"]")()).click();
	}
};
export { AtralumeTimePicker, AtralumeTimePickerHarness };

//# sourceMappingURL=osmanjimenez-atralume-time-picker.mjs.map