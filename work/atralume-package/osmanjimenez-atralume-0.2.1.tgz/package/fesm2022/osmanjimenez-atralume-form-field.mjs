import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, Directive, booleanAttribute, input, output } from "@angular/core";
import * as i2 from "@taiga-ui/core";
import { TuiLabel, TuiLabel as TuiLabel$1, TuiTextfield, TuiTextfield as TuiTextfield$1 } from "@taiga-ui/core";
import { AtralumeInput } from "@osmanjimenez/atralume/input";
import * as i1 from "@taiga-ui/core/components/label";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeFormField = class AtralumeFormField {
	hint = input(null, ...ngDevMode ? [{ debugName: "hint" }] : /* istanbul ignore next */ []);
	error = input(null, ...ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []);
	appearance = input("outline", ...ngDevMode ? [{ debugName: "appearance" }] : /* istanbul ignore next */ []);
	density = input("comfortable", ...ngDevMode ? [{ debugName: "density" }] : /* istanbul ignore next */ []);
	label = input("", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	required = input(false, {
		...ngDevMode ? { debugName: "required" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	optional = input(false, {
		...ngDevMode ? { debugName: "optional" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	optionalText = input("Optional", ...ngDevMode ? [{ debugName: "optionalText" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeFormField,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeFormField,
		isStandalone: true,
		selector: "atr-form-field",
		inputs: {
			hint: {
				classPropertyName: "hint",
				publicName: "hint",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			error: {
				classPropertyName: "error",
				publicName: "error",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			density: {
				classPropertyName: "density",
				publicName: "density",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			optional: {
				classPropertyName: "optional",
				publicName: "optional",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			optionalText: {
				classPropertyName: "optionalText",
				publicName: "optionalText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: {
				"attr.data-appearance": "appearance()",
				"attr.data-density": "density()"
			},
			classAttribute: "atr-form-field-host"
		},
		ngImport: i0,
		template: "<ng-content />\n@if (hint()) {\n  <p class=\"atr-form-field__hint\">{{ hint() }}</p>\n}\n@if (error()) {\n  <p class=\"atr-form-field__error\" aria-live=\"polite\">{{ error() }}</p>\n}\n",
		styles: [":host{display:grid;gap:var(--atr-sys-spacing-sm)}.atr-form-field__hint,.atr-form-field__error{margin:0;font-size:var(--atr-sys-typography-body-small-font-size)}.atr-form-field__hint,.atr-form-field__optional{color:var(--atr-comp-form-field-hint-color, var(--atr-sys-color-on-surface-variant))}.atr-form-field__error{color:var(--atr-comp-form-field-error-color, var(--atr-sys-color-error))}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeFormField,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-form-field",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "atr-form-field-host",
				"[attr.data-appearance]": "appearance()",
				"[attr.data-density]": "density()"
			},
			template: "<ng-content />\n@if (hint()) {\n  <p class=\"atr-form-field__hint\">{{ hint() }}</p>\n}\n@if (error()) {\n  <p class=\"atr-form-field__error\" aria-live=\"polite\">{{ error() }}</p>\n}\n",
			styles: [":host{display:grid;gap:var(--atr-sys-spacing-sm)}.atr-form-field__hint,.atr-form-field__error{margin:0;font-size:var(--atr-sys-typography-body-small-font-size)}.atr-form-field__hint,.atr-form-field__optional{color:var(--atr-comp-form-field-hint-color, var(--atr-sys-color-on-surface-variant))}.atr-form-field__error{color:var(--atr-comp-form-field-error-color, var(--atr-sys-color-error))}\n"]
		}]
	}],
	propDecorators: {
		hint: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hint",
				required: false
			}]
		}],
		error: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "error",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		density: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "density",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		optional: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "optional",
				required: false
			}]
		}],
		optionalText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "optionalText",
				required: false
			}]
		}]
	}
});
var AtralumeSearchField = class AtralumeSearchField {
	label = input("Buscar", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	placeholder = input("", ...ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []);
	value = input("", ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	valueChange = output();
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeSearchField,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeSearchField,
		isStandalone: true,
		selector: "atr-search-field",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { valueChange: "valueChange" },
		host: { classAttribute: "atr-search-field" },
		ngImport: i0,
		template: `
    <tui-textfield tuiTextfieldSize="m">
      <label tuiLabel>{{ label() }}</label>
      <input atrInput type="search" [value]="value()" [placeholder]="placeholder()"
        (input)="valueChange.emit($any($event.target).value)" />
    </tui-textfield>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "directive",
				type: i1.TuiLabel,
				selector: "label[tuiLabel]"
			},
			{
				kind: "component",
				type: i2.TuiTextfieldComponent,
				selector: "tui-textfield:not([multi])",
				inputs: [
					"content",
					"filler",
					"invalid",
					"tuiAppearanceFocus",
					"tuiAppearanceState"
				]
			},
			{
				kind: "directive",
				type: i2.TuiTextfieldOptionsDirective,
				selector: "[tuiTextfieldAppearance],[tuiTextfieldSize],[tuiTextfieldCleaner]",
				inputs: [
					"tuiTextfieldAppearance",
					"tuiTextfieldSize",
					"tuiTextfieldCleaner"
				]
			},
			{
				kind: "directive",
				type: AtralumeInput,
				selector: "input[atrInput]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeSearchField,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-search-field",
			standalone: true,
			imports: [
				TuiTextfield$1,
				TuiLabel$1,
				AtralumeInput
			],
			template: `
    <tui-textfield tuiTextfieldSize="m">
      <label tuiLabel>{{ label() }}</label>
      <input atrInput type="search" [value]="value()" [placeholder]="placeholder()"
        (input)="valueChange.emit($any($event.target).value)" />
    </tui-textfield>
  `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "atr-search-field" }
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		valueChange: [{
			type: i0.Output,
			args: ["valueChange"]
		}]
	}
});
var AtralumeControlLabel = class AtralumeControlLabel {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeControlLabel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeControlLabel,
		isStandalone: true,
		selector: "label[atrControlLabel]",
		host: {
			properties: { "attr.tuiLabel": "\"\"" },
			classAttribute: "atr-control-label"
		},
		hostDirectives: [{ directive: i2.TuiLabel }],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeControlLabel,
	decorators: [{
		type: Directive,
		args: [{
			selector: "label[atrControlLabel]",
			standalone: true,
			hostDirectives: [TuiLabel$1],
			host: {
				class: "atr-control-label",
				"[attr.tuiLabel]": "\"\""
			}
		}]
	}]
});
var AtralumeFormFieldHarness = class extends ComponentHarness {
	static hostSelector = "atr-form-field";
	label = this.locatorForOptional("label[tuiLabel], .atr-form-field__label");
	hint = this.locatorForOptional(".atr-form-field__hint");
	error = this.locatorForOptional(".atr-form-field__error");
	async getLabel() {
		return (await this.label())?.text() ?? "";
	}
	async getHint() {
		return (await this.hint())?.text() ?? null;
	}
	async getError() {
		return (await this.error())?.text() ?? null;
	}
	async isRequired() {
		return (await this.getLabel()).includes("*");
	}
	async getAppearance() {
		return (await this.host()).getAttribute("data-appearance");
	}
	getControl = this.locatorFor("input, textarea");
};
export { AtralumeControlLabel, AtralumeFormField, AtralumeFormFieldHarness, AtralumeSearchField, TuiLabel, TuiTextfield };

//# sourceMappingURL=osmanjimenez-atralume-form-field.mjs.map