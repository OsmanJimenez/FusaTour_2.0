import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, Directive, ElementRef, InjectionToken, booleanAttribute, computed, contentChildren, effect, forwardRef, inject, input, model, signal, untracked } from "@angular/core";
import * as i1 from "@taiga-ui/kit";
import { TuiTab, TuiTabsDirective, TuiTabsHorizontal } from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
const TAB_CONTEXT = new InjectionToken("Atralume tabs");
var AtralumeTabList = class AtralumeTabList {
	underline = input(true, {
		...ngDevMode ? { debugName: "underline" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	owner = inject(TAB_CONTEXT);
	tabs = inject(TuiTabsDirective, {
		self: true,
		optional: true
	});
	constructor() {
		effect(() => {
			const activeId = this.owner.activeId();
			const dir = this.tabs;
			if (!dir) return;
			untracked(() => {
				const index = dir.tabs.findIndex((el) => el.id === activeId);
				if (index >= 0 && dir.activeItemIndex() !== index) dir.activeItemIndex.set(index);
			});
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeTabList,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeTabList,
		isStandalone: true,
		selector: "tui-tabs[atrTabList]",
		inputs: { underline: {
			classPropertyName: "underline",
			publicName: "underline",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			attributes: { "role": "tablist" },
			properties: {
				"attr.aria-label": "owner.label()",
				"attr.aria-orientation": "owner.orientation()",
				"attr.vertical": "owner.orientation() === \"vertical\" ? \"\" : null",
				"attr.data-vertical": "owner.orientation() === \"vertical\" ? \"start\" : null"
			},
			classAttribute: "atr-tab-list"
		},
		hostDirectives: [{
			directive: i1.TuiTabsHorizontal,
			inputs: ["underline", "underline"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeTabList,
	decorators: [{
		type: Directive,
		args: [{
			selector: "tui-tabs[atrTabList]",
			standalone: true,
			hostDirectives: [{
				directive: TuiTabsHorizontal,
				inputs: ["underline"]
			}],
			host: {
				class: "atr-tab-list",
				role: "tablist",
				"[attr.aria-label]": "owner.label()",
				"[attr.aria-orientation]": "owner.orientation()",
				"[attr.vertical]": "owner.orientation() === \"vertical\" ? \"\" : null",
				"[attr.data-vertical]": "owner.orientation() === \"vertical\" ? \"start\" : null"
			}
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { underline: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "underline",
			required: false
		}]
	}] }
});
var AtralumeTabListHarness = class extends ComponentHarness {
	static hostSelector = ".atr-tab-list";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeTabPanel = class AtralumeTabPanel {
	id = input.required(...ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []);
	labelledBy = input.required(...ngDevMode ? [{ debugName: "labelledBy" }] : /* istanbul ignore next */ []);
	owner = inject(TAB_CONTEXT);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeTabPanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeTabPanel,
		isStandalone: true,
		selector: "[atrTabPanel]",
		inputs: {
			id: {
				classPropertyName: "id",
				publicName: "id",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			labelledBy: {
				classPropertyName: "labelledBy",
				publicName: "labelledBy",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		host: {
			attributes: { "role": "tabpanel" },
			properties: {
				"attr.id": "id()",
				"attr.aria-labelledby": "labelledBy()",
				"hidden": "owner.activePanel() !== id()",
				"attr.tabindex": "owner.activePanel() === id() ? 0 : -1"
			},
			classAttribute: "atr-tab-panel"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeTabPanel,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrTabPanel]",
			standalone: true,
			host: {
				class: "atr-tab-panel",
				role: "tabpanel",
				"[attr.id]": "id()",
				"[attr.aria-labelledby]": "labelledBy()",
				"[hidden]": "owner.activePanel() !== id()",
				"[attr.tabindex]": "owner.activePanel() === id() ? 0 : -1"
			}
		}]
	}],
	propDecorators: {
		id: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "id",
				required: true
			}]
		}],
		labelledBy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "labelledBy",
				required: true
			}]
		}]
	}
});
var AtralumeTabPanelHarness = class extends ComponentHarness {
	static hostSelector = "[role=tabpanel]";
	async getText() {
		return (await this.host()).text();
	}
	async isSelected() {
		const h = await this.host();
		return await h.getAttribute("aria-selected") === "true" || await h.getAttribute("aria-current") === "page";
	}
};
var AtralumeTab = class AtralumeTab {
	id = input.required(...ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []);
	panel = input.required(...ngDevMode ? [{ debugName: "panel" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	owner = inject(TAB_CONTEXT);
	element = inject(ElementRef);
	activate() {
		if (!this.disabled()) this.owner.activate(this.id());
	}
	focus() {
		this.element.nativeElement.focus();
	}
	belongsTo(owner) {
		return this.owner === owner;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeTab,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeTab,
		isStandalone: true,
		selector: "button[atrTab]",
		inputs: {
			id: {
				classPropertyName: "id",
				publicName: "id",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			panel: {
				classPropertyName: "panel",
				publicName: "panel",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "role": "tab" },
			listeners: { "click": "activate()" },
			properties: {
				"attr.tuiTab": "\"\"",
				"attr.id": "id()",
				"attr.aria-controls": "panel()",
				"attr.aria-selected": "owner.activeId() === id()",
				"attr.tabindex": "(owner.focusId() || owner.activeId()) === id() ? 0 : -1",
				"attr.disabled": "disabled() ? \"\" : null",
				"attr.aria-disabled": "disabled() ? \"true\" : null"
			},
			classAttribute: "atr-tab"
		},
		hostDirectives: [{ directive: i1.TuiTab }],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeTab,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[atrTab]",
			standalone: true,
			hostDirectives: [TuiTab],
			host: {
				class: "atr-tab",
				role: "tab",
				"[attr.tuiTab]": "\"\"",
				"[attr.id]": "id()",
				"[attr.aria-controls]": "panel()",
				"[attr.aria-selected]": "owner.activeId() === id()",
				"[attr.tabindex]": "(owner.focusId() || owner.activeId()) === id() ? 0 : -1",
				"[attr.disabled]": "disabled() ? \"\" : null",
				"[attr.aria-disabled]": "disabled() ? \"true\" : null",
				"(click)": "activate()"
			}
		}]
	}],
	propDecorators: {
		id: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "id",
				required: true
			}]
		}],
		panel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "panel",
				required: true
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}]
	}
});
var AtralumeTabHarness = class extends ComponentHarness {
	static hostSelector = "button[role=tab]";
	async getText() {
		return (await this.host()).text();
	}
	async isSelected() {
		const h = await this.host();
		return await h.getAttribute("aria-selected") === "true" || await h.getAttribute("aria-current") === "page";
	}
	async click() {
		await (await this.host()).click();
	}
	async isDisabled() {
		return (await this.host()).getProperty("disabled");
	}
};
var AtralumeTabs = class AtralumeTabs {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	selected = model("", ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	activation = input("automatic", ...ngDevMode ? [{ debugName: "activation" }] : /* istanbul ignore next */ []);
	orientation = input("horizontal", ...ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []);
	tabs = contentChildren(AtralumeTab, {
		...ngDevMode ? { debugName: "tabs" } : /* istanbul ignore next */ {},
		descendants: true
	});
	focused = signal("", ...ngDevMode ? [{ debugName: "focused" }] : /* istanbul ignore next */ []);
	element = inject(ElementRef);
	activeId = computed(() => {
		const tabs = this.tabs().filter((tab) => tab.belongsTo(this));
		return tabs.find((tab) => tab.id() === this.selected() && !tab.disabled())?.id() ?? tabs.find((tab) => !tab.disabled())?.id() ?? "";
	}, ...ngDevMode ? [{ debugName: "activeId" }] : /* istanbul ignore next */ []);
	activePanel = computed(() => this.tabs().filter((tab) => tab.belongsTo(this)).find((tab) => tab.id() === this.activeId())?.panel() ?? "", ...ngDevMode ? [{ debugName: "activePanel" }] : /* istanbul ignore next */ []);
	focusId = computed(() => this.focused(), ...ngDevMode ? [{ debugName: "focusId" }] : /* istanbul ignore next */ []);
	activate(id) {
		if (this.tabs().filter((tab) => tab.belongsTo(this)).some((tab) => tab.id() === id && !tab.disabled())) {
			this.selected.set(id);
			this.focused.set(id);
		}
	}
	onKey(event) {
		const tabs = this.tabs().filter((tab) => tab.belongsTo(this)).filter((tab) => !tab.disabled());
		const index = tabs.findIndex((tab) => tab.id() === event.target.id);
		if (index < 0) return;
		const vertical = this.orientation() === "vertical", rtl = this.element.nativeElement.matches(":dir(rtl)");
		let next = index;
		if (event.key === "Home") next = 0;
		else if (event.key === "End") next = tabs.length - 1;
		else if (event.key === (vertical ? "ArrowDown" : rtl ? "ArrowLeft" : "ArrowRight")) next = (index + 1) % tabs.length;
		else if (event.key === (vertical ? "ArrowUp" : rtl ? "ArrowRight" : "ArrowLeft")) next = (index - 1 + tabs.length) % tabs.length;
		else return;
		event.preventDefault();
		const tab = tabs[next];
		this.focused.set(tab.id());
		if (this.activation() === "automatic") this.selected.set(tab.id());
		tab.focus();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeTabs,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.4",
		type: AtralumeTabs,
		isStandalone: true,
		selector: "atr-tabs",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			selected: {
				classPropertyName: "selected",
				publicName: "selected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			activation: {
				classPropertyName: "activation",
				publicName: "activation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { selected: "selectedChange" },
		host: {
			listeners: { "keydown": "onKey($event)" },
			classAttribute: "atr-tabs"
		},
		providers: [{
			provide: TAB_CONTEXT,
			useExisting: forwardRef(() => AtralumeTabs)
		}],
		queries: [{
			propertyName: "tabs",
			predicate: AtralumeTab,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<ng-content />\n",
		styles: [":host{display:block;font-family:var(--atr-comp-tabs-font-family);color:var(--atr-comp-tabs-label-color)}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeTabs,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-tabs",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: TAB_CONTEXT,
				useExisting: forwardRef(() => AtralumeTabs)
			}],
			host: {
				class: "atr-tabs",
				"(keydown)": "onKey($event)"
			},
			template: "<ng-content />\n",
			styles: [":host{display:block;font-family:var(--atr-comp-tabs-font-family);color:var(--atr-comp-tabs-label-color)}\n"]
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		selected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selected",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["selectedChange"]
		}],
		activation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "activation",
				required: false
			}]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		tabs: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => AtralumeTab), {
				descendants: true,
				isSignal: true
			}]
		}]
	}
});
var AtralumeTabsHarness = class extends ComponentHarness {
	static hostSelector = "atr-tabs";
	async getText() {
		return (await this.host()).text();
	}
};
export { AtralumeTab, AtralumeTabHarness, AtralumeTabList, AtralumeTabListHarness, AtralumeTabPanel, AtralumeTabPanelHarness, AtralumeTabs, AtralumeTabsHarness };

//# sourceMappingURL=osmanjimenez-atralume-tabs.mjs.map