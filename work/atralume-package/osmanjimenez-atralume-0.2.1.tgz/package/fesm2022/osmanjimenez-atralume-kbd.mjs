import * as i0 from "@angular/core";
import { Directive, input } from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeKbd = class AtralumeKbd {
	size = input("medium", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeKbd,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeKbd,
		isStandalone: true,
		selector: "kbd[atrKbd]",
		inputs: { size: {
			classPropertyName: "size",
			publicName: "size",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			properties: { "attr.data-size": "size()" },
			classAttribute: "atr-kbd"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeKbd,
	decorators: [{
		type: Directive,
		args: [{
			selector: "kbd[atrKbd]",
			standalone: true,
			host: {
				class: "atr-kbd",
				"[attr.data-size]": "size()"
			}
		}]
	}],
	propDecorators: { size: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "size",
			required: false
		}]
	}] }
});
var AtralumeKbdHarness = class extends ComponentHarness {
	static hostSelector = "kbd.atr-kbd";
	async getSize() {
		return (await this.host()).getAttribute("data-size");
	}
	async getText() {
		return (await this.host()).text();
	}
};
export { AtralumeKbd, AtralumeKbdHarness };

//# sourceMappingURL=osmanjimenez-atralume-kbd.mjs.map