import * as i0 from "@angular/core";
import { Directive, computed, input } from "@angular/core";
import * as i1 from "@taiga-ui/kit";
import { TuiStatus } from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeStatus = class AtralumeStatus {
	tone = input("neutral", ...ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []);
	color = input("", ...ngDevMode ? [{ debugName: "color" }] : /* istanbul ignore next */ []);
	size = input("medium", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	dataSize = computed(() => {
		return {
			small: "s",
			medium: "m",
			large: "l"
		}[this.size()];
	}, ...ngDevMode ? [{ debugName: "dataSize" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeStatus,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeStatus,
		isStandalone: true,
		selector: "[atrStatus]",
		inputs: {
			tone: {
				classPropertyName: "tone",
				publicName: "tone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			color: {
				classPropertyName: "color",
				publicName: "color",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: {
				"attr.tuiStatus": "\"\"",
				"attr.data-tone": "tone()",
				"attr.data-size": "dataSize()"
			},
			classAttribute: "atr-status"
		},
		hostDirectives: [{
			directive: i1.TuiStatus,
			inputs: ["tuiStatus", "color"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeStatus,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrStatus]",
			standalone: true,
			hostDirectives: [{
				directive: TuiStatus,
				inputs: ["tuiStatus: color"]
			}],
			host: {
				class: "atr-status",
				"[attr.tuiStatus]": "\"\"",
				"[attr.data-tone]": "tone()",
				"[attr.data-size]": "dataSize()"
			}
		}]
	}],
	propDecorators: {
		tone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tone",
				required: false
			}]
		}],
		color: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "color",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}]
	}
});
var AtralumeStatusHarness = class extends ComponentHarness {
	static hostSelector = ".atr-status";
	async getTone() {
		return (await this.host()).getAttribute("data-tone");
	}
	async getSize() {
		return (await this.host()).getAttribute("data-size");
	}
	async getText() {
		return (await this.host()).text();
	}
};
export { AtralumeStatus, AtralumeStatusHarness };

//# sourceMappingURL=osmanjimenez-atralume-status.mjs.map