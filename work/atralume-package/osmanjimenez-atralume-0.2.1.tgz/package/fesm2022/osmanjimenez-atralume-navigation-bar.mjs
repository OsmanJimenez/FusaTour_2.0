import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, Directive, ViewEncapsulation, booleanAttribute, input } from "@angular/core";
import { TuiNavComponent } from "@taiga-ui/layout";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeNavigationBar = class AtralumeNavigationBar {
	label = input("Primary navigation", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeNavigationBar,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeNavigationBar,
		isStandalone: true,
		selector: "atr-navigation-bar",
		inputs: { label: {
			classPropertyName: "label",
			publicName: "label",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: { classAttribute: "atr-navigation-bar" },
		ngImport: i0,
		template: "<nav tuiNavigationNav [attr.aria-label]=\"label()\">\n  <ng-content />\n</nav>\n",
		styles: [".atr-navigation-bar{display:block}.atr-navigation-bar>nav[tuiNavigationNav]{align-items:center;background:transparent;border:0;border-radius:0;box-shadow:none;display:flex;gap:.125rem;margin:0;min-block-size:auto;padding:0}.atr-navigation-bar .atr-navigation-item{align-items:center;border-radius:var(--atr-sys-shape-full);color:var(--atr-sys-color-on-surface-variant);display:inline-flex;font:var(--atr-sys-typescale-label-large-font, inherit);justify-content:center;min-block-size:2.5rem;padding-inline:.875rem;text-decoration:none;transition:background-color .16s ease,color .16s ease}.atr-navigation-bar .atr-navigation-item:hover{background:var(--atr-sys-color-secondary-container);color:var(--atr-sys-color-on-secondary-container)}.atr-navigation-bar .atr-navigation-item[aria-current=page]{background:var(--atr-sys-color-primary-container);color:var(--atr-sys-color-on-primary-container);font-weight:700}.atr-navigation-bar .atr-navigation-item:focus-visible{outline:2px solid var(--atr-sys-color-primary);outline-offset:2px}@media(max-width:48rem){.atr-navigation-bar>nav[tuiNavigationNav]{overflow-x:auto;scrollbar-width:none}.atr-navigation-bar>nav[tuiNavigationNav]::-webkit-scrollbar{display:none}}\n"],
		dependencies: [{
			kind: "component",
			type: TuiNavComponent,
			selector: "nav[tuiNavigationNav]"
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush,
		encapsulation: i0.ViewEncapsulation.None
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeNavigationBar,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-navigation-bar",
			standalone: true,
			imports: [TuiNavComponent],
			encapsulation: ViewEncapsulation.None,
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "atr-navigation-bar" },
			template: "<nav tuiNavigationNav [attr.aria-label]=\"label()\">\n  <ng-content />\n</nav>\n",
			styles: [".atr-navigation-bar{display:block}.atr-navigation-bar>nav[tuiNavigationNav]{align-items:center;background:transparent;border:0;border-radius:0;box-shadow:none;display:flex;gap:.125rem;margin:0;min-block-size:auto;padding:0}.atr-navigation-bar .atr-navigation-item{align-items:center;border-radius:var(--atr-sys-shape-full);color:var(--atr-sys-color-on-surface-variant);display:inline-flex;font:var(--atr-sys-typescale-label-large-font, inherit);justify-content:center;min-block-size:2.5rem;padding-inline:.875rem;text-decoration:none;transition:background-color .16s ease,color .16s ease}.atr-navigation-bar .atr-navigation-item:hover{background:var(--atr-sys-color-secondary-container);color:var(--atr-sys-color-on-secondary-container)}.atr-navigation-bar .atr-navigation-item[aria-current=page]{background:var(--atr-sys-color-primary-container);color:var(--atr-sys-color-on-primary-container);font-weight:700}.atr-navigation-bar .atr-navigation-item:focus-visible{outline:2px solid var(--atr-sys-color-primary);outline-offset:2px}@media(max-width:48rem){.atr-navigation-bar>nav[tuiNavigationNav]{overflow-x:auto;scrollbar-width:none}.atr-navigation-bar>nav[tuiNavigationNav]::-webkit-scrollbar{display:none}}\n"]
		}]
	}],
	propDecorators: { label: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "label",
			required: false
		}]
	}] }
});
var AtralumeNavigationBarHarness = class extends ComponentHarness {
	static hostSelector = "atr-navigation-bar";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeNavigationItem = class AtralumeNavigationItem {
	active = input(false, {
		...ngDevMode ? { debugName: "active" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeNavigationItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeNavigationItem,
		isStandalone: true,
		selector: "a[atrNavigationItem]",
		inputs: { active: {
			classPropertyName: "active",
			publicName: "active",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			properties: { "attr.aria-current": "active() ? \"page\" : null" },
			classAttribute: "atr-navigation-item"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeNavigationItem,
	decorators: [{
		type: Directive,
		args: [{
			selector: "a[atrNavigationItem]",
			standalone: true,
			host: {
				class: "atr-navigation-item",
				"[attr.aria-current]": "active() ? \"page\" : null"
			}
		}]
	}],
	propDecorators: { active: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "active",
			required: false
		}]
	}] }
});
var AtralumeNavigationItemHarness = class extends ComponentHarness {
	static hostSelector = ".atr-navigation-item";
	async getText() {
		return (await this.host()).text();
	}
	async isSelected() {
		const h = await this.host();
		return await h.getAttribute("aria-selected") === "true" || await h.getAttribute("aria-current") === "page";
	}
};
export { AtralumeNavigationBar, AtralumeNavigationBarHarness, AtralumeNavigationItem, AtralumeNavigationItemHarness };

//# sourceMappingURL=osmanjimenez-atralume-navigation-bar.mjs.map