import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, Directive, booleanAttribute, computed, effect, forwardRef, inject, input, untracked } from "@angular/core";
import * as i1 from "@angular/forms";
import { FormControl, NG_VALIDATORS, NG_VALUE_ACCESSOR, ReactiveFormsModule } from "@angular/forms";
import { TuiSliderComponent } from "@taiga-ui/core";
import { ɵAtralumeValueControl } from "@osmanjimenez/atralume/internal/forms";
import { TuiRange } from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeSliderBase = class AtralumeSliderBase extends ɵAtralumeValueControl {
	step = input(1, ...ngDevMode ? [{ debugName: "step" }] : /* istanbul ignore next */ []);
	continuous = input(false, {
		...ngDevMode ? { debugName: "continuous" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	orientation = input("horizontal", ...ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []);
	inverted = input(false, {
		...ngDevMode ? { debugName: "inverted" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	showTicks = input(false, {
		...ngDevMode ? { debugName: "showTicks" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	displayWith = input(String, ...ngDevMode ? [{ debugName: "displayWith" }] : /* istanbul ignore next */ []);
	validatorChanged = () => void 0;
	ticks = computed(() => this.showTicks() && !this.continuous() && this.upper() > this.lower() && this.step() > 0 ? "repeating-linear-gradient(var(--atr-slider-direction,to right), var(--atr-comp-slider-tick-color) 0 1px, transparent 1px " + 100 * this.step() / (this.upper() - this.lower()) + "%)" : "none", ...ngDevMode ? [{ debugName: "ticks" }] : /* istanbul ignore next */ []);
	constructor() {
		super();
		effect(() => {
			this.value();
			this.lower();
			this.upper();
			this.step();
			this.required();
			untracked(() => this.validatorChanged());
		});
	}
	registerOnValidatorChange(fn) {
		this.validatorChanged = fn;
	}
	normalize(value) {
		const min = this.lower(), max = this.upper(), step = this.step();
		if (!Number.isFinite(min) || !Number.isFinite(max) || max < min || !this.continuous() && (!Number.isFinite(step) || step <= 0)) throw new Error("Slider requires finite ordered bounds and a positive step.");
		const clamped = Math.max(min, Math.min(max, Number.isFinite(value) ? value : min));
		if (this.continuous()) return Number(clamped.toFixed(12));
		const decimal = (n) => {
			const [coefficient, exponent = "0"] = String(n).toLowerCase().split("e");
			return Math.max(0, (coefficient.split(".")[1]?.length ?? 0) - Number(exponent));
		};
		const factor = 10 ** Math.min(12, Math.max(decimal(min), decimal(max), decimal(step)));
		const lo = Math.round(min * factor), hi = Math.round(max * factor), increment = Math.max(1, Math.round(step * factor));
		return (lo + Math.min(Math.floor((hi - lo) / increment), Math.max(0, Math.round((clamped * factor - lo) / increment))) * increment) / factor;
	}
	guard(event) {
		if (this.readonly()) event.preventDefault();
	}
	page(event, current, change) {
		if (this.readonly()) {
			event.preventDefault();
			return;
		}
		if (event.key === "PageUp" || event.key === "PageDown") {
			event.preventDefault();
			change(this.normalize(current + (event.key === "PageUp" ? 1 : -1) * (this.upper() - this.lower()) / 10));
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeSliderBase,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeSliderBase,
		isStandalone: true,
		inputs: {
			step: {
				classPropertyName: "step",
				publicName: "step",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			continuous: {
				classPropertyName: "continuous",
				publicName: "continuous",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			inverted: {
				classPropertyName: "inverted",
				publicName: "inverted",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showTicks: {
				classPropertyName: "showTicks",
				publicName: "showTicks",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			displayWith: {
				classPropertyName: "displayWith",
				publicName: "displayWith",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { properties: { "style.--atr-slider-ticks": "ticks()" } },
		usesInheritance: true,
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeSliderBase,
	decorators: [{
		type: Directive,
		args: [{ host: { "[style.--atr-slider-ticks]": "ticks()" } }]
	}],
	ctorParameters: () => [],
	propDecorators: {
		step: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "step",
				required: false
			}]
		}],
		continuous: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "continuous",
				required: false
			}]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		inverted: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "inverted",
				required: false
			}]
		}],
		showTicks: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showTicks",
				required: false
			}]
		}],
		displayWith: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "displayWith",
				required: false
			}]
		}]
	}
});
var AtralumeSlider = class AtralumeSlider extends AtralumeSliderBase {
	min = input(0, {
		...ngDevMode ? { debugName: "min" } : /* istanbul ignore next */ {},
		transform: (value) => value ?? 0
	});
	max = input(100, {
		...ngDevMode ? { debugName: "max" } : /* istanbul ignore next */ {},
		transform: (value) => value ?? 100
	});
	lower() {
		return this.min();
	}
	upper() {
		return this.max();
	}
	displayed = computed(() => this.normalize(this.value() ?? this.min()), ...ngDevMode ? [{ debugName: "displayed" }] : /* istanbul ignore next */ []);
	fill = computed(() => this.max() === this.min() ? 0 : 100 * (this.displayed() - this.min()) / (this.max() - this.min()), ...ngDevMode ? [{ debugName: "fill" }] : /* istanbul ignore next */ []);
	segments = computed(() => this.showTicks() && !this.continuous() && this.step() > 0 ? Math.max(1, Math.round((this.max() - this.min()) / this.step())) : 1, ...ngDevMode ? [{ debugName: "segments" }] : /* istanbul ignore next */ []);
	input(event) {
		const input = event.target;
		if (!this.blocked() && !this.readonly()) this.commit(this.normalize(Number(input.value)));
		input.value = String(this.displayed());
	}
	key(event) {
		this.page(event, this.displayed(), (value) => this.commit(value));
	}
	validate() {
		const value = this.value();
		return value === null ? this.required() ? { required: true } : null : !Number.isFinite(value) || value < this.min() || value > this.max() ? { sliderBounds: true } : null;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeSlider,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeSlider,
		isStandalone: true,
		selector: "atr-slider",
		inputs: {
			min: {
				classPropertyName: "min",
				publicName: "min",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			max: {
				classPropertyName: "max",
				publicName: "max",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: {
				"attr.data-orientation": "orientation()",
				"attr.data-inverted": "inverted()",
				"class.atr-slider--invalid": "displayInvalid()"
			},
			classAttribute: "atr-slider"
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => AtralumeSlider),
			multi: true
		}, {
			provide: NG_VALIDATORS,
			useExisting: forwardRef(() => AtralumeSlider),
			multi: true
		}],
		usesInheritance: true,
		ngImport: i0,
		template: "<label [for]=\"controlId()\">{{ label() }}</label>\n<input\n  tuiSlider\n  data-atr-value-control\n  type=\"range\"\n  [id]=\"controlId()\"\n  [min]=\"min()\"\n  [max]=\"max()\"\n  [step]=\"continuous() ? 'any' : step()\"\n  [value]=\"displayed()\"\n  [disabled]=\"blocked()\"\n  [segments]=\"segments()\"\n  [attr.aria-valuemin]=\"min()\"\n  [attr.aria-valuemax]=\"max()\"\n  [attr.aria-valuenow]=\"displayed()\"\n  [attr.aria-valuetext]=\"displayWith()(displayed())\"\n  [attr.aria-orientation]=\"orientation()\"\n  [attr.aria-invalid]=\"displayInvalid()\"\n  [attr.aria-readonly]=\"readonly()\"\n  [style.--atr-slider-fill]=\"fill() + '%'\"\n  (input)=\"input($event)\"\n  (keydown)=\"key($event)\"\n  (pointerdown)=\"guard($event)\"\n/>\n<output [attr.for]=\"controlId()\">{{ displayWith()(displayed()) }}</output>\n@if (hint()) {\n  <p>{{ hint() }}</p>\n}\n@if (error()) {\n  <p role=\"status\">{{ error() }}</p>\n}\n",
		styles: [":host{display:block;min-inline-size:0;color:var(--atr-comp-slider-label-color);font-family:var(--atr-ref-font-family-plain)}label,.range-label{display:block}input[type=range]{box-sizing:border-box;appearance:none;inline-size:100%;block-size:var(--atr-sys-touch-target-minimum);margin:0;background:transparent;accent-color:var(--atr-comp-slider-thumb-color);cursor:pointer}input::-webkit-slider-runnable-track{block-size:var(--atr-ref-spacing-1);background:var(--atr-comp-slider-border-color);border-radius:var(--atr-comp-slider-shape);background-image:var(--atr-slider-ticks, none),linear-gradient(var(--atr-slider-direction, to right),var(--atr-comp-slider-active-track-color) 0 var(--atr-slider-fill, 0%),var(--atr-comp-slider-track-color) var(--atr-slider-fill, 0%) 100%)}input::-webkit-slider-thumb{appearance:none;inline-size:var(--atr-ref-spacing-6);block-size:var(--atr-ref-spacing-6);border-radius:var(--atr-sys-shape-full);background:var(--atr-comp-slider-thumb-color);margin-block-start:calc((var(--atr-ref-spacing-1) - var(--atr-ref-spacing-6)) / 2)}input::-moz-range-track{block-size:var(--atr-ref-spacing-1);background:var(--atr-comp-slider-border-color);background-image:var(--atr-slider-ticks, none),linear-gradient(var(--atr-slider-direction, to right),var(--atr-comp-slider-active-track-color) 0 var(--atr-slider-fill, 0%),var(--atr-comp-slider-track-color) var(--atr-slider-fill, 0%) 100%)}input::-moz-range-thumb{inline-size:var(--atr-ref-spacing-6);block-size:var(--atr-ref-spacing-6);border:0;border-radius:var(--atr-sys-shape-full);background:var(--atr-comp-slider-thumb-color)}input:focus-visible{outline:var(--atr-sys-focus-ring-width) solid var(--atr-comp-slider-focus-color);outline-offset:var(--atr-sys-focus-ring-offset)}input:disabled{opacity:var(--atr-sys-state-disabled-content-opacity);cursor:default}.range-track{position:relative;block-size:var(--atr-sys-touch-target-minimum)}.range-track input{position:absolute;inset:0;pointer-events:none}.range-track input::-webkit-slider-thumb{pointer-events:auto}.range-track input::-moz-range-thumb{pointer-events:auto}.range-track input:focus{z-index:1}.track{position:absolute;inset-inline:0;inset-block-start:50%;block-size:var(--atr-ref-spacing-1);background:var(--atr-comp-slider-border-color);background-image:var(--atr-slider-ticks, none),linear-gradient(var(--atr-slider-direction, to right),var(--atr-comp-slider-track-color) 0 var(--atr-slider-start, 0%),var(--atr-comp-slider-active-track-color) var(--atr-slider-start, 0%) var(--atr-slider-end, 100%),var(--atr-comp-slider-track-color) var(--atr-slider-end, 100%) 100%)}:host([data-orientation=vertical]){inline-size:fit-content;--atr-slider-direction: to top}:host([data-orientation=vertical]) input{writing-mode:vertical-lr;direction:rtl;inline-size:12rem;block-size:var(--atr-sys-touch-target-minimum)}:host([data-orientation=vertical]) .range-track{block-size:12rem;inline-size:var(--atr-sys-touch-target-minimum)}:host([data-orientation=vertical]) .track{inset-inline-start:50%;inset-block:0;inline-size:var(--atr-ref-spacing-1);block-size:auto}:host([data-inverted=true]) input{direction:rtl}:host([data-inverted=true]:dir(rtl)) input{direction:ltr}:host([data-orientation=vertical][data-inverted=true]) input{direction:ltr}.range-track input::-webkit-slider-runnable-track{background:none}.range-track input::-moz-range-track{background:none}:host(:dir(rtl)){--atr-slider-direction: to left}:host([data-inverted=true]){--atr-slider-direction: to left}:host([data-inverted=true]:dir(rtl)){--atr-slider-direction: to right}:host([data-orientation=vertical][data-inverted=true]){--atr-slider-direction: to bottom}:host(.atr-slider--invalid){--atr-comp-slider-active-track-color: var(--atr-comp-slider-invalid-color);--atr-comp-slider-thumb-color: var(--atr-comp-slider-invalid-color)}@media(forced-colors:active){input{accent-color:Highlight}input::-webkit-slider-thumb{background:ButtonText}input::-webkit-slider-runnable-track{background:CanvasText}}@media(forced-colors:active){input::-moz-range-thumb{background:ButtonText}input::-moz-range-track,.track{background:CanvasText}}\n"],
		dependencies: [{
			kind: "component",
			type: TuiSliderComponent,
			selector: "input[type=range][tuiSlider]",
			inputs: ["segments"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeSlider,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-slider",
			standalone: true,
			imports: [TuiSliderComponent],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => AtralumeSlider),
				multi: true
			}, {
				provide: NG_VALIDATORS,
				useExisting: forwardRef(() => AtralumeSlider),
				multi: true
			}],
			host: {
				class: "atr-slider",
				"[attr.data-orientation]": "orientation()",
				"[attr.data-inverted]": "inverted()",
				"[class.atr-slider--invalid]": "displayInvalid()"
			},
			template: "<label [for]=\"controlId()\">{{ label() }}</label>\n<input\n  tuiSlider\n  data-atr-value-control\n  type=\"range\"\n  [id]=\"controlId()\"\n  [min]=\"min()\"\n  [max]=\"max()\"\n  [step]=\"continuous() ? 'any' : step()\"\n  [value]=\"displayed()\"\n  [disabled]=\"blocked()\"\n  [segments]=\"segments()\"\n  [attr.aria-valuemin]=\"min()\"\n  [attr.aria-valuemax]=\"max()\"\n  [attr.aria-valuenow]=\"displayed()\"\n  [attr.aria-valuetext]=\"displayWith()(displayed())\"\n  [attr.aria-orientation]=\"orientation()\"\n  [attr.aria-invalid]=\"displayInvalid()\"\n  [attr.aria-readonly]=\"readonly()\"\n  [style.--atr-slider-fill]=\"fill() + '%'\"\n  (input)=\"input($event)\"\n  (keydown)=\"key($event)\"\n  (pointerdown)=\"guard($event)\"\n/>\n<output [attr.for]=\"controlId()\">{{ displayWith()(displayed()) }}</output>\n@if (hint()) {\n  <p>{{ hint() }}</p>\n}\n@if (error()) {\n  <p role=\"status\">{{ error() }}</p>\n}\n",
			styles: [":host{display:block;min-inline-size:0;color:var(--atr-comp-slider-label-color);font-family:var(--atr-ref-font-family-plain)}label,.range-label{display:block}input[type=range]{box-sizing:border-box;appearance:none;inline-size:100%;block-size:var(--atr-sys-touch-target-minimum);margin:0;background:transparent;accent-color:var(--atr-comp-slider-thumb-color);cursor:pointer}input::-webkit-slider-runnable-track{block-size:var(--atr-ref-spacing-1);background:var(--atr-comp-slider-border-color);border-radius:var(--atr-comp-slider-shape);background-image:var(--atr-slider-ticks, none),linear-gradient(var(--atr-slider-direction, to right),var(--atr-comp-slider-active-track-color) 0 var(--atr-slider-fill, 0%),var(--atr-comp-slider-track-color) var(--atr-slider-fill, 0%) 100%)}input::-webkit-slider-thumb{appearance:none;inline-size:var(--atr-ref-spacing-6);block-size:var(--atr-ref-spacing-6);border-radius:var(--atr-sys-shape-full);background:var(--atr-comp-slider-thumb-color);margin-block-start:calc((var(--atr-ref-spacing-1) - var(--atr-ref-spacing-6)) / 2)}input::-moz-range-track{block-size:var(--atr-ref-spacing-1);background:var(--atr-comp-slider-border-color);background-image:var(--atr-slider-ticks, none),linear-gradient(var(--atr-slider-direction, to right),var(--atr-comp-slider-active-track-color) 0 var(--atr-slider-fill, 0%),var(--atr-comp-slider-track-color) var(--atr-slider-fill, 0%) 100%)}input::-moz-range-thumb{inline-size:var(--atr-ref-spacing-6);block-size:var(--atr-ref-spacing-6);border:0;border-radius:var(--atr-sys-shape-full);background:var(--atr-comp-slider-thumb-color)}input:focus-visible{outline:var(--atr-sys-focus-ring-width) solid var(--atr-comp-slider-focus-color);outline-offset:var(--atr-sys-focus-ring-offset)}input:disabled{opacity:var(--atr-sys-state-disabled-content-opacity);cursor:default}.range-track{position:relative;block-size:var(--atr-sys-touch-target-minimum)}.range-track input{position:absolute;inset:0;pointer-events:none}.range-track input::-webkit-slider-thumb{pointer-events:auto}.range-track input::-moz-range-thumb{pointer-events:auto}.range-track input:focus{z-index:1}.track{position:absolute;inset-inline:0;inset-block-start:50%;block-size:var(--atr-ref-spacing-1);background:var(--atr-comp-slider-border-color);background-image:var(--atr-slider-ticks, none),linear-gradient(var(--atr-slider-direction, to right),var(--atr-comp-slider-track-color) 0 var(--atr-slider-start, 0%),var(--atr-comp-slider-active-track-color) var(--atr-slider-start, 0%) var(--atr-slider-end, 100%),var(--atr-comp-slider-track-color) var(--atr-slider-end, 100%) 100%)}:host([data-orientation=vertical]){inline-size:fit-content;--atr-slider-direction: to top}:host([data-orientation=vertical]) input{writing-mode:vertical-lr;direction:rtl;inline-size:12rem;block-size:var(--atr-sys-touch-target-minimum)}:host([data-orientation=vertical]) .range-track{block-size:12rem;inline-size:var(--atr-sys-touch-target-minimum)}:host([data-orientation=vertical]) .track{inset-inline-start:50%;inset-block:0;inline-size:var(--atr-ref-spacing-1);block-size:auto}:host([data-inverted=true]) input{direction:rtl}:host([data-inverted=true]:dir(rtl)) input{direction:ltr}:host([data-orientation=vertical][data-inverted=true]) input{direction:ltr}.range-track input::-webkit-slider-runnable-track{background:none}.range-track input::-moz-range-track{background:none}:host(:dir(rtl)){--atr-slider-direction: to left}:host([data-inverted=true]){--atr-slider-direction: to left}:host([data-inverted=true]:dir(rtl)){--atr-slider-direction: to right}:host([data-orientation=vertical][data-inverted=true]){--atr-slider-direction: to bottom}:host(.atr-slider--invalid){--atr-comp-slider-active-track-color: var(--atr-comp-slider-invalid-color);--atr-comp-slider-thumb-color: var(--atr-comp-slider-invalid-color)}@media(forced-colors:active){input{accent-color:Highlight}input::-webkit-slider-thumb{background:ButtonText}input::-webkit-slider-runnable-track{background:CanvasText}}@media(forced-colors:active){input::-moz-range-thumb{background:ButtonText}input::-moz-range-track,.track{background:CanvasText}}\n"]
		}]
	}],
	propDecorators: {
		min: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "min",
				required: false
			}]
		}],
		max: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "max",
				required: false
			}]
		}]
	}
});
var AtralumeRangeSlider = class AtralumeRangeSlider extends AtralumeSliderBase {
	minimum = input(0, {
		...ngDevMode ? { debugName: "minimum" } : /* istanbul ignore next */ {},
		transform: (value) => value ?? 0
	});
	maximum = input(100, {
		...ngDevMode ? { debugName: "maximum" } : /* istanbul ignore next */ {},
		transform: (value) => value ?? 100
	});
	lower() {
		return this.minimum();
	}
	upper() {
		return this.maximum();
	}
	startLabel = input(null, ...ngDevMode ? [{ debugName: "startLabel" }] : /* istanbul ignore next */ []);
	endLabel = input(null, ...ngDevMode ? [{ debugName: "endLabel" }] : /* istanbul ignore next */ []);
	displayed = computed(() => {
		const value = this.value();
		const start = this.normalize(value?.start ?? this.minimum()), end = this.normalize(value?.end ?? this.maximum());
		return {
			start: Math.min(start, end),
			end: Math.max(start, end)
		};
	}, ...ngDevMode ? [{ debugName: "displayed" }] : /* istanbul ignore next */ []);
	segments = computed(() => this.showTicks() && !this.continuous() && this.step() > 0 ? Math.max(1, Math.round((this.maximum() - this.minimum()) / this.step())) : 1, ...ngDevMode ? [{ debugName: "segments" }] : /* istanbul ignore next */ []);
	rangeStep = computed(() => this.continuous() ? Math.max(.01, (this.maximum() - this.minimum()) / 1e3) : this.step(), ...ngDevMode ? [{ debugName: "rangeStep" }] : /* istanbul ignore next */ []);
	inner = new FormControl([0, 100], { nonNullable: true });
	constructor() {
		super();
		const destroyRef = inject(DestroyRef);
		const sub = this.inner.valueChanges.subscribe((tuple) => {
			const [start, end] = tuple;
			const next = {
				start: this.normalize(start),
				end: this.normalize(end)
			};
			const current = this.displayed();
			if (current.start !== next.start || current.end !== next.end) this.commit({
				start: Math.min(next.start, next.end),
				end: Math.max(next.start, next.end)
			});
		});
		destroyRef.onDestroy(() => sub.unsubscribe());
		effect(() => {
			const next = this.displayed();
			untracked(() => {
				const [a, b] = this.inner.value;
				if (a !== next.start || b !== next.end) this.inner.setValue([next.start, next.end], { emitEvent: false });
			});
		});
		effect(() => {
			if (this.blocked()) this.inner.disable({ emitEvent: false });
			else this.inner.enable({ emitEvent: false });
		});
	}
	validate() {
		const value = this.value();
		return value === null ? this.required() ? { required: true } : null : !Number.isFinite(value.start) || !Number.isFinite(value.end) || value.start < this.minimum() || value.end > this.maximum() || value.start > value.end ? { sliderRange: true } : null;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeRangeSlider,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeRangeSlider,
		isStandalone: true,
		selector: "atr-range-slider",
		inputs: {
			minimum: {
				classPropertyName: "minimum",
				publicName: "minimum",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maximum: {
				classPropertyName: "maximum",
				publicName: "maximum",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			startLabel: {
				classPropertyName: "startLabel",
				publicName: "startLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			endLabel: {
				classPropertyName: "endLabel",
				publicName: "endLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: {
				"attr.data-orientation": "orientation()",
				"attr.data-inverted": "inverted()",
				"class.atr-slider--invalid": "displayInvalid()"
			},
			classAttribute: "atr-slider atr-range-slider"
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => AtralumeRangeSlider),
			multi: true
		}, {
			provide: NG_VALIDATORS,
			useExisting: forwardRef(() => AtralumeRangeSlider),
			multi: true
		}],
		usesInheritance: true,
		ngImport: i0,
		template: "<span class=\"range-label\">{{ label() }}</span>\n<tui-range\n  data-atr-value-control\n  [formControl]=\"inner\"\n  [min]=\"minimum()\"\n  [max]=\"maximum()\"\n  [step]=\"rangeStep()\"\n  [segments]=\"segments()\"\n  [focusable]=\"!readonly()\"\n  [attr.aria-label]=\"label()\"\n  [attr.aria-invalid]=\"displayInvalid()\"\n  [attr.aria-readonly]=\"readonly()\"\n  [attr.aria-orientation]=\"orientation()\"\n/>\n<output\n  >{{ displayWith()(displayed().start) }} –\n  {{ displayWith()(displayed().end) }}</output\n>\n@if (hint()) {\n  <p>{{ hint() }}</p>\n}\n@if (error()) {\n  <p role=\"status\">{{ error() }}</p>\n}\n",
		styles: [":host{display:block;min-inline-size:0;color:var(--atr-comp-slider-label-color);font-family:var(--atr-ref-font-family-plain)}label,.range-label{display:block}input[type=range]{box-sizing:border-box;appearance:none;inline-size:100%;block-size:var(--atr-sys-touch-target-minimum);margin:0;background:transparent;accent-color:var(--atr-comp-slider-thumb-color);cursor:pointer}input::-webkit-slider-runnable-track{block-size:var(--atr-ref-spacing-1);background:var(--atr-comp-slider-border-color);border-radius:var(--atr-comp-slider-shape);background-image:var(--atr-slider-ticks, none),linear-gradient(var(--atr-slider-direction, to right),var(--atr-comp-slider-active-track-color) 0 var(--atr-slider-fill, 0%),var(--atr-comp-slider-track-color) var(--atr-slider-fill, 0%) 100%)}input::-webkit-slider-thumb{appearance:none;inline-size:var(--atr-ref-spacing-6);block-size:var(--atr-ref-spacing-6);border-radius:var(--atr-sys-shape-full);background:var(--atr-comp-slider-thumb-color);margin-block-start:calc((var(--atr-ref-spacing-1) - var(--atr-ref-spacing-6)) / 2)}input::-moz-range-track{block-size:var(--atr-ref-spacing-1);background:var(--atr-comp-slider-border-color);background-image:var(--atr-slider-ticks, none),linear-gradient(var(--atr-slider-direction, to right),var(--atr-comp-slider-active-track-color) 0 var(--atr-slider-fill, 0%),var(--atr-comp-slider-track-color) var(--atr-slider-fill, 0%) 100%)}input::-moz-range-thumb{inline-size:var(--atr-ref-spacing-6);block-size:var(--atr-ref-spacing-6);border:0;border-radius:var(--atr-sys-shape-full);background:var(--atr-comp-slider-thumb-color)}input:focus-visible{outline:var(--atr-sys-focus-ring-width) solid var(--atr-comp-slider-focus-color);outline-offset:var(--atr-sys-focus-ring-offset)}input:disabled{opacity:var(--atr-sys-state-disabled-content-opacity);cursor:default}.range-track{position:relative;block-size:var(--atr-sys-touch-target-minimum)}.range-track input{position:absolute;inset:0;pointer-events:none}.range-track input::-webkit-slider-thumb{pointer-events:auto}.range-track input::-moz-range-thumb{pointer-events:auto}.range-track input:focus{z-index:1}.track{position:absolute;inset-inline:0;inset-block-start:50%;block-size:var(--atr-ref-spacing-1);background:var(--atr-comp-slider-border-color);background-image:var(--atr-slider-ticks, none),linear-gradient(var(--atr-slider-direction, to right),var(--atr-comp-slider-track-color) 0 var(--atr-slider-start, 0%),var(--atr-comp-slider-active-track-color) var(--atr-slider-start, 0%) var(--atr-slider-end, 100%),var(--atr-comp-slider-track-color) var(--atr-slider-end, 100%) 100%)}:host([data-orientation=vertical]){inline-size:fit-content;--atr-slider-direction: to top}:host([data-orientation=vertical]) input{writing-mode:vertical-lr;direction:rtl;inline-size:12rem;block-size:var(--atr-sys-touch-target-minimum)}:host([data-orientation=vertical]) .range-track{block-size:12rem;inline-size:var(--atr-sys-touch-target-minimum)}:host([data-orientation=vertical]) .track{inset-inline-start:50%;inset-block:0;inline-size:var(--atr-ref-spacing-1);block-size:auto}:host([data-inverted=true]) input{direction:rtl}:host([data-inverted=true]:dir(rtl)) input{direction:ltr}:host([data-orientation=vertical][data-inverted=true]) input{direction:ltr}.range-track input::-webkit-slider-runnable-track{background:none}.range-track input::-moz-range-track{background:none}:host(:dir(rtl)){--atr-slider-direction: to left}:host([data-inverted=true]){--atr-slider-direction: to left}:host([data-inverted=true]:dir(rtl)){--atr-slider-direction: to right}:host([data-orientation=vertical][data-inverted=true]){--atr-slider-direction: to bottom}:host(.atr-slider--invalid){--atr-comp-slider-active-track-color: var(--atr-comp-slider-invalid-color);--atr-comp-slider-thumb-color: var(--atr-comp-slider-invalid-color)}@media(forced-colors:active){input{accent-color:Highlight}input::-webkit-slider-thumb{background:ButtonText}input::-webkit-slider-runnable-track{background:CanvasText}}@media(forced-colors:active){input::-moz-range-thumb{background:ButtonText}input::-moz-range-track,.track{background:CanvasText}}\n"],
		dependencies: [
			{
				kind: "ngmodule",
				type: ReactiveFormsModule
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.FormControlDirective,
				selector: "[formControl]",
				inputs: [
					"formControl",
					"disabled",
					"ngModel"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngForm"]
			},
			{
				kind: "component",
				type: TuiRange,
				selector: "tui-range",
				inputs: [
					"min",
					"max",
					"step",
					"segments",
					"keySteps",
					"focusable",
					"margin",
					"limit"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeRangeSlider,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-range-slider",
			standalone: true,
			imports: [ReactiveFormsModule, TuiRange],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => AtralumeRangeSlider),
				multi: true
			}, {
				provide: NG_VALIDATORS,
				useExisting: forwardRef(() => AtralumeRangeSlider),
				multi: true
			}],
			host: {
				class: "atr-slider atr-range-slider",
				"[attr.data-orientation]": "orientation()",
				"[attr.data-inverted]": "inverted()",
				"[class.atr-slider--invalid]": "displayInvalid()"
			},
			template: "<span class=\"range-label\">{{ label() }}</span>\n<tui-range\n  data-atr-value-control\n  [formControl]=\"inner\"\n  [min]=\"minimum()\"\n  [max]=\"maximum()\"\n  [step]=\"rangeStep()\"\n  [segments]=\"segments()\"\n  [focusable]=\"!readonly()\"\n  [attr.aria-label]=\"label()\"\n  [attr.aria-invalid]=\"displayInvalid()\"\n  [attr.aria-readonly]=\"readonly()\"\n  [attr.aria-orientation]=\"orientation()\"\n/>\n<output\n  >{{ displayWith()(displayed().start) }} –\n  {{ displayWith()(displayed().end) }}</output\n>\n@if (hint()) {\n  <p>{{ hint() }}</p>\n}\n@if (error()) {\n  <p role=\"status\">{{ error() }}</p>\n}\n",
			styles: [":host{display:block;min-inline-size:0;color:var(--atr-comp-slider-label-color);font-family:var(--atr-ref-font-family-plain)}label,.range-label{display:block}input[type=range]{box-sizing:border-box;appearance:none;inline-size:100%;block-size:var(--atr-sys-touch-target-minimum);margin:0;background:transparent;accent-color:var(--atr-comp-slider-thumb-color);cursor:pointer}input::-webkit-slider-runnable-track{block-size:var(--atr-ref-spacing-1);background:var(--atr-comp-slider-border-color);border-radius:var(--atr-comp-slider-shape);background-image:var(--atr-slider-ticks, none),linear-gradient(var(--atr-slider-direction, to right),var(--atr-comp-slider-active-track-color) 0 var(--atr-slider-fill, 0%),var(--atr-comp-slider-track-color) var(--atr-slider-fill, 0%) 100%)}input::-webkit-slider-thumb{appearance:none;inline-size:var(--atr-ref-spacing-6);block-size:var(--atr-ref-spacing-6);border-radius:var(--atr-sys-shape-full);background:var(--atr-comp-slider-thumb-color);margin-block-start:calc((var(--atr-ref-spacing-1) - var(--atr-ref-spacing-6)) / 2)}input::-moz-range-track{block-size:var(--atr-ref-spacing-1);background:var(--atr-comp-slider-border-color);background-image:var(--atr-slider-ticks, none),linear-gradient(var(--atr-slider-direction, to right),var(--atr-comp-slider-active-track-color) 0 var(--atr-slider-fill, 0%),var(--atr-comp-slider-track-color) var(--atr-slider-fill, 0%) 100%)}input::-moz-range-thumb{inline-size:var(--atr-ref-spacing-6);block-size:var(--atr-ref-spacing-6);border:0;border-radius:var(--atr-sys-shape-full);background:var(--atr-comp-slider-thumb-color)}input:focus-visible{outline:var(--atr-sys-focus-ring-width) solid var(--atr-comp-slider-focus-color);outline-offset:var(--atr-sys-focus-ring-offset)}input:disabled{opacity:var(--atr-sys-state-disabled-content-opacity);cursor:default}.range-track{position:relative;block-size:var(--atr-sys-touch-target-minimum)}.range-track input{position:absolute;inset:0;pointer-events:none}.range-track input::-webkit-slider-thumb{pointer-events:auto}.range-track input::-moz-range-thumb{pointer-events:auto}.range-track input:focus{z-index:1}.track{position:absolute;inset-inline:0;inset-block-start:50%;block-size:var(--atr-ref-spacing-1);background:var(--atr-comp-slider-border-color);background-image:var(--atr-slider-ticks, none),linear-gradient(var(--atr-slider-direction, to right),var(--atr-comp-slider-track-color) 0 var(--atr-slider-start, 0%),var(--atr-comp-slider-active-track-color) var(--atr-slider-start, 0%) var(--atr-slider-end, 100%),var(--atr-comp-slider-track-color) var(--atr-slider-end, 100%) 100%)}:host([data-orientation=vertical]){inline-size:fit-content;--atr-slider-direction: to top}:host([data-orientation=vertical]) input{writing-mode:vertical-lr;direction:rtl;inline-size:12rem;block-size:var(--atr-sys-touch-target-minimum)}:host([data-orientation=vertical]) .range-track{block-size:12rem;inline-size:var(--atr-sys-touch-target-minimum)}:host([data-orientation=vertical]) .track{inset-inline-start:50%;inset-block:0;inline-size:var(--atr-ref-spacing-1);block-size:auto}:host([data-inverted=true]) input{direction:rtl}:host([data-inverted=true]:dir(rtl)) input{direction:ltr}:host([data-orientation=vertical][data-inverted=true]) input{direction:ltr}.range-track input::-webkit-slider-runnable-track{background:none}.range-track input::-moz-range-track{background:none}:host(:dir(rtl)){--atr-slider-direction: to left}:host([data-inverted=true]){--atr-slider-direction: to left}:host([data-inverted=true]:dir(rtl)){--atr-slider-direction: to right}:host([data-orientation=vertical][data-inverted=true]){--atr-slider-direction: to bottom}:host(.atr-slider--invalid){--atr-comp-slider-active-track-color: var(--atr-comp-slider-invalid-color);--atr-comp-slider-thumb-color: var(--atr-comp-slider-invalid-color)}@media(forced-colors:active){input{accent-color:Highlight}input::-webkit-slider-thumb{background:ButtonText}input::-webkit-slider-runnable-track{background:CanvasText}}@media(forced-colors:active){input::-moz-range-thumb{background:ButtonText}input::-moz-range-track,.track{background:CanvasText}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		minimum: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minimum",
				required: false
			}]
		}],
		maximum: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maximum",
				required: false
			}]
		}],
		startLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "startLabel",
				required: false
			}]
		}],
		endLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "endLabel",
				required: false
			}]
		}]
	}
});
var AtralumeSliderHarness = class extends ComponentHarness {
	static hostSelector = "atr-slider";
	input = this.locatorFor("input[type=\"range\"]");
	async getValue() {
		return Number(await (await this.input()).getProperty("value"));
	}
	async setValue(value) {
		const input = await this.input();
		await input.setInputValue(String(value));
		await input.dispatchEvent("input");
	}
	async increment() {
		await this.setValue(await this.getValue() + (Number(await (await this.input()).getProperty("step")) || 1));
	}
	async decrement() {
		await this.setValue(await this.getValue() - (Number(await (await this.input()).getProperty("step")) || 1));
	}
	async getThumbLabels() {
		return [await (await this.locatorFor("label")()).text()];
	}
	async isDisabled() {
		return (await this.input()).getProperty("disabled");
	}
};
var AtralumeRangeSliderHarness = class extends ComponentHarness {
	static hostSelector = "atr-range-slider";
	range = this.locatorFor("tui-range");
	inputs = this.locatorForAll("tui-range input[type=\"range\"]");
	async getValue() {
		const inputs = await this.inputs();
		return {
			start: Number(await inputs[0].getProperty("value")),
			end: Number(await inputs[1].getProperty("value"))
		};
	}
	async setValue(value) {
		const inputs = await this.inputs();
		await inputs[0].setInputValue(String(value.start));
		await inputs[0].dispatchEvent("input");
		await inputs[1].setInputValue(String(value.end));
		await inputs[1].dispatchEvent("input");
	}
	async increment(thumb = "start") {
		const input = (await this.inputs())[thumb === "start" ? 0 : 1];
		await input.focus();
		await input.dispatchEvent("keydown", { key: "ArrowRight" });
	}
	async decrement(thumb = "start") {
		const input = (await this.inputs())[thumb === "start" ? 0 : 1];
		await input.focus();
		await input.dispatchEvent("keydown", { key: "ArrowLeft" });
	}
	async getThumbLabels() {
		const label = await (await this.range()).getAttribute("aria-label") ?? "";
		return [label + " start", label + " end"];
	}
	async isDisabled() {
		return (await this.range()).hasClass("_disabled");
	}
};
export { AtralumeRangeSlider, AtralumeRangeSliderHarness, AtralumeSlider, AtralumeSliderHarness };

//# sourceMappingURL=osmanjimenez-atralume-slider.mjs.map