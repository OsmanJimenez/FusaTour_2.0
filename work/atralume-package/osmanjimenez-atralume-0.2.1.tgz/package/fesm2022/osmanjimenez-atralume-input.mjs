import * as i0 from "@angular/core";
import { Directive, ElementRef, inject, isDevMode } from "@angular/core";
import * as i1 from "@taiga-ui/core";
import { TuiInputDirective } from "@taiga-ui/core";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeInput = class AtralumeInput {
	constructor() {
		const type = inject(ElementRef).nativeElement.type;
		if (isDevMode() && [
			"checkbox",
			"radio",
			"file",
			"range",
			"color",
			"button",
			"submit",
			"reset",
			"hidden",
			"image"
		].includes(type)) throw new Error("atrInput requires a text-like native input.");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeInput,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeInput,
		isStandalone: true,
		selector: "input[atrInput]",
		host: {
			properties: { "attr.tuiInput": "\"\"" },
			classAttribute: "atr-input"
		},
		hostDirectives: [{
			directive: i1.TuiInputDirective,
			inputs: [
				"readonly",
				"readonly",
				"invalid",
				"invalid",
				"focused",
				"focused",
				"state",
				"state"
			]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeInput,
	decorators: [{
		type: Directive,
		args: [{
			selector: "input[atrInput]",
			standalone: true,
			hostDirectives: [{
				directive: TuiInputDirective,
				inputs: [
					"readonly",
					"invalid",
					"focused",
					"state"
				]
			}],
			host: {
				class: "atr-input",
				"[attr.tuiInput]": "\"\""
			}
		}]
	}],
	ctorParameters: () => []
});
var AtralumeInputHarness = class extends ComponentHarness {
	static hostSelector = ".atr-input";
	async getValue() {
		return (await this.host()).getProperty("value");
	}
	async setValue(value) {
		const host = await this.host();
		await host.clear();
		await host.sendKeys(value);
	}
	async focus() {
		await (await this.host()).focus();
	}
	async blur() {
		await (await this.host()).blur();
	}
	async isReadonly() {
		return (await this.host()).getProperty("readOnly");
	}
	async isInvalid() {
		const h = await this.host();
		return await h.getAttribute("aria-invalid") === "true" || await h.hasClass("ng-invalid") && (await h.hasClass("ng-touched") || await h.hasClass("ng-dirty"));
	}
	async isDisabled() {
		return (await this.host()).getProperty("disabled");
	}
};
export { AtralumeInput, AtralumeInputHarness };

//# sourceMappingURL=osmanjimenez-atralume-input.mjs.map