import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, computed, input, signal } from "@angular/core";
import { NgStyle } from "@angular/common";
import { AtralumeButton } from "@osmanjimenez/atralume/button";
var AtralumeImage360 = class AtralumeImage360 {
	src = input.required(...ngDevMode ? [{ debugName: "src" }] : /* istanbul ignore next */ []);
	alt = input.required(...ngDevMode ? [{ debugName: "alt" }] : /* istanbul ignore next */ []);
	label = input("Vista panorámica 360 grados", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	yaw = signal(50, ...ngDevMode ? [{ debugName: "yaw" }] : /* istanbul ignore next */ []);
	zoom = signal(1, ...ngDevMode ? [{ debugName: "zoom" }] : /* istanbul ignore next */ []);
	sceneStyle = computed(() => ({
		"background-image": `url("${this.src()}")`,
		"background-position": `${this.yaw()}% 50%`,
		"background-size": `${Math.round(200 * this.zoom())}% auto`
	}), ...ngDevMode ? [{ debugName: "sceneStyle" }] : /* istanbul ignore next */ []);
	dragStart = null;
	startDrag(event) {
		const target = event.currentTarget;
		if (!(target instanceof HTMLElement)) return;
		target.setPointerCapture(event.pointerId);
		this.dragStart = {
			x: event.clientX,
			yaw: this.yaw()
		};
	}
	drag(event) {
		if (!this.dragStart) return;
		this.rotate(this.dragStart.yaw - (event.clientX - this.dragStart.x) * .12);
	}
	endDrag() {
		this.dragStart = null;
	}
	onKey(event) {
		const action = {
			ArrowLeft: () => this.rotate(this.yaw() - 3),
			ArrowRight: () => this.rotate(this.yaw() + 3),
			"+": () => this.changeZoom(.1),
			"=": () => this.changeZoom(.1),
			"-": () => this.changeZoom(-.1),
			Home: () => this.reset()
		}[event.key];
		if (!action) return;
		event.preventDefault();
		action();
	}
	onWheel(event) {
		event.preventDefault();
		this.changeZoom(event.deltaY > 0 ? -.1 : .1);
	}
	rotate(value) {
		this.yaw.set((value % 100 + 100) % 100);
	}
	changeZoom(delta) {
		this.zoom.update((value) => Math.max(1, Math.min(2.25, Number((value + delta).toFixed(2)))));
	}
	reset() {
		this.yaw.set(50);
		this.zoom.set(1);
	}
	async fullscreen(event) {
		const host = event.currentTarget?.closest("atr-image-360");
		if (host instanceof HTMLElement && document.fullscreenElement !== host) await host.requestFullscreen?.();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeImage360,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeImage360,
		isStandalone: true,
		selector: "atr-image-360",
		inputs: {
			src: {
				classPropertyName: "src",
				publicName: "src",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			alt: {
				classPropertyName: "alt",
				publicName: "alt",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: { "attr.aria-label": "label()" },
			classAttribute: "atr-image-360"
		},
		ngImport: i0,
		template: "<figure class=\"atr-image-360__frame\">\n  <div\n    class=\"atr-image-360__scene\"\n    [ngStyle]=\"sceneStyle()\"\n    role=\"application\"\n    tabindex=\"0\"\n    [attr.aria-label]=\"label() + '. ' + alt() + '. Arrastra o usa las flechas para mirar alrededor.'\"\n    (pointerdown)=\"startDrag($event)\"\n    (pointermove)=\"drag($event)\"\n    (pointerup)=\"endDrag()\"\n    (pointercancel)=\"endDrag()\"\n    (keydown)=\"onKey($event)\"\n    (wheel)=\"onWheel($event)\"\n  ></div>\n  <figcaption class=\"atr-image-360__caption\">\n    <span>Arrastra para explorar · Flechas para girar</span>\n    <span class=\"atr-image-360__actions\">\n      <button atrButton appearance=\"text\" type=\"button\" (click)=\"rotate(yaw() - 12)\" aria-label=\"Girar a la izquierda\">Izquierda</button>\n      <button atrButton appearance=\"text\" type=\"button\" (click)=\"reset()\">Restablecer</button>\n      <button atrButton appearance=\"text\" type=\"button\" (click)=\"rotate(yaw() + 12)\" aria-label=\"Girar a la derecha\">Derecha</button>\n      <button atrButton appearance=\"text\" type=\"button\" (click)=\"fullscreen($event)\">Pantalla completa</button>\n    </span>\n  </figcaption>\n</figure>\n",
		styles: [":host{display:block}.atr-image-360__frame{margin:0;overflow:hidden;border-radius:var(--atr-sys-shape-corner-large, 1rem);background:var(--atr-sys-color-surface-variant)}.atr-image-360__scene{aspect-ratio:16/9;background-repeat:repeat-x;cursor:grab;touch-action:none;outline:none}.atr-image-360__scene:active{cursor:grabbing}.atr-image-360__scene:focus-visible{outline:3px solid var(--atr-sys-color-primary);outline-offset:-3px}.atr-image-360__caption{align-items:center;color:var(--atr-sys-color-on-surface-variant);display:flex;flex-wrap:wrap;font-size:.875rem;gap:.75rem 1rem;justify-content:space-between;padding:.75rem 1rem}.atr-image-360__actions{display:flex;flex-wrap:wrap;gap:.5rem}.atr-image-360__actions button{background:transparent;border:0;border-radius:var(--atr-sys-shape-full);color:inherit;cursor:pointer;font:inherit;min-block-size:2.5rem;padding-inline:.7rem}.atr-image-360__actions button:hover{background:var(--atr-sys-color-secondary-container);color:var(--atr-sys-color-on-secondary-container)}.atr-image-360__actions button:focus-visible{outline:2px solid var(--atr-sys-color-primary);outline-offset:2px}@media(max-width:40rem){.atr-image-360__caption{align-items:flex-start;flex-direction:column}.atr-image-360__actions{inline-size:100%}.atr-image-360__actions button{flex:1 1 auto}}@media(prefers-reduced-motion:reduce){.atr-image-360__scene{scroll-behavior:auto}}\n"],
		dependencies: [{
			kind: "directive",
			type: NgStyle,
			selector: "[ngStyle]",
			inputs: ["ngStyle"]
		}, {
			kind: "component",
			type: AtralumeButton,
			selector: "button[atrButton], a[atrButton]",
			inputs: [
				"appearance",
				"size",
				"disabled",
				"loading",
				"fullWidth",
				"tabindex"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeImage360,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-image-360",
			standalone: true,
			imports: [NgStyle, AtralumeButton],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "atr-image-360",
				"[attr.aria-label]": "label()"
			},
			template: "<figure class=\"atr-image-360__frame\">\n  <div\n    class=\"atr-image-360__scene\"\n    [ngStyle]=\"sceneStyle()\"\n    role=\"application\"\n    tabindex=\"0\"\n    [attr.aria-label]=\"label() + '. ' + alt() + '. Arrastra o usa las flechas para mirar alrededor.'\"\n    (pointerdown)=\"startDrag($event)\"\n    (pointermove)=\"drag($event)\"\n    (pointerup)=\"endDrag()\"\n    (pointercancel)=\"endDrag()\"\n    (keydown)=\"onKey($event)\"\n    (wheel)=\"onWheel($event)\"\n  ></div>\n  <figcaption class=\"atr-image-360__caption\">\n    <span>Arrastra para explorar · Flechas para girar</span>\n    <span class=\"atr-image-360__actions\">\n      <button atrButton appearance=\"text\" type=\"button\" (click)=\"rotate(yaw() - 12)\" aria-label=\"Girar a la izquierda\">Izquierda</button>\n      <button atrButton appearance=\"text\" type=\"button\" (click)=\"reset()\">Restablecer</button>\n      <button atrButton appearance=\"text\" type=\"button\" (click)=\"rotate(yaw() + 12)\" aria-label=\"Girar a la derecha\">Derecha</button>\n      <button atrButton appearance=\"text\" type=\"button\" (click)=\"fullscreen($event)\">Pantalla completa</button>\n    </span>\n  </figcaption>\n</figure>\n",
			styles: [":host{display:block}.atr-image-360__frame{margin:0;overflow:hidden;border-radius:var(--atr-sys-shape-corner-large, 1rem);background:var(--atr-sys-color-surface-variant)}.atr-image-360__scene{aspect-ratio:16/9;background-repeat:repeat-x;cursor:grab;touch-action:none;outline:none}.atr-image-360__scene:active{cursor:grabbing}.atr-image-360__scene:focus-visible{outline:3px solid var(--atr-sys-color-primary);outline-offset:-3px}.atr-image-360__caption{align-items:center;color:var(--atr-sys-color-on-surface-variant);display:flex;flex-wrap:wrap;font-size:.875rem;gap:.75rem 1rem;justify-content:space-between;padding:.75rem 1rem}.atr-image-360__actions{display:flex;flex-wrap:wrap;gap:.5rem}.atr-image-360__actions button{background:transparent;border:0;border-radius:var(--atr-sys-shape-full);color:inherit;cursor:pointer;font:inherit;min-block-size:2.5rem;padding-inline:.7rem}.atr-image-360__actions button:hover{background:var(--atr-sys-color-secondary-container);color:var(--atr-sys-color-on-secondary-container)}.atr-image-360__actions button:focus-visible{outline:2px solid var(--atr-sys-color-primary);outline-offset:2px}@media(max-width:40rem){.atr-image-360__caption{align-items:flex-start;flex-direction:column}.atr-image-360__actions{inline-size:100%}.atr-image-360__actions button{flex:1 1 auto}}@media(prefers-reduced-motion:reduce){.atr-image-360__scene{scroll-behavior:auto}}\n"]
		}]
	}],
	propDecorators: {
		src: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "src",
				required: true
			}]
		}],
		alt: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "alt",
				required: true
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}]
	}
});
export { AtralumeImage360 };

//# sourceMappingURL=osmanjimenez-atralume-image-360.mjs.map