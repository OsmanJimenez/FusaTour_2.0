import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, booleanAttribute, computed, input, model, output } from "@angular/core";
import * as i1 from "@taiga-ui/core";
import { TuiCarousel } from "@taiga-ui/core";
import { AtralumeButton } from "@osmanjimenez/atralume/button";
import * as i2 from "@taiga-ui/cdk/directives/item";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeCarousel = class AtralumeCarousel {
	label = input("Carousel", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	slides = input([], ...ngDevMode ? [{ debugName: "slides" }] : /* istanbul ignore next */ []);
	activeIndex = model(0, ...ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []);
	loop = input(false, {
		...ngDevMode ? { debugName: "loop" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	autoplay = input(false, {
		...ngDevMode ? { debugName: "autoplay" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	autoplayDelay = input(5e3, ...ngDevMode ? [{ debugName: "autoplayDelay" }] : /* istanbul ignore next */ []);
	showIndicators = input(true, {
		...ngDevMode ? { debugName: "showIndicators" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	activeChange = output();
	duration = computed(() => this.autoplay() ? Math.max(1e3, this.autoplayDelay()) : 0, ...ngDevMode ? [{ debugName: "duration" }] : /* istanbul ignore next */ []);
	max = computed(() => Math.max(0, this.slides().length - 1), ...ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []);
	onIndex(index) {
		this.activeIndex.set(index);
		this.activeChange.emit(index);
	}
	next() {
		const length = this.slides().length;
		if (!length) return;
		const current = this.activeIndex();
		const next = current >= length - 1 ? this.loop() ? 0 : current : current + 1;
		this.onIndex(next);
	}
	previous() {
		const length = this.slides().length;
		if (!length) return;
		const current = this.activeIndex();
		const next = current <= 0 ? this.loop() ? length - 1 : current : current - 1;
		this.onIndex(next);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeCarousel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeCarousel,
		isStandalone: true,
		selector: "atr-carousel",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			slides: {
				classPropertyName: "slides",
				publicName: "slides",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			activeIndex: {
				classPropertyName: "activeIndex",
				publicName: "activeIndex",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			loop: {
				classPropertyName: "loop",
				publicName: "loop",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autoplay: {
				classPropertyName: "autoplay",
				publicName: "autoplay",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			autoplayDelay: {
				classPropertyName: "autoplayDelay",
				publicName: "autoplayDelay",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showIndicators: {
				classPropertyName: "showIndicators",
				publicName: "showIndicators",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			activeIndex: "activeIndexChange",
			activeChange: "activeChange"
		},
		host: { classAttribute: "atr-carousel" },
		ngImport: i0,
		template: "<section\n  role=\"region\"\n  [attr.aria-label]=\"label()\"\n  aria-roledescription=\"carousel\"\n>\n  <tui-carousel\n    [index]=\"activeIndex()\"\n    (indexChange)=\"onIndex($event)\"\n    [duration]=\"duration()\"\n    [min]=\"0\"\n    [max]=\"max()\"\n  >\n    @for (slide of slides(); track slide.id; let index = $index) {\n      <div\n        *tuiItem\n        class=\"atr-carousel__slide\"\n        role=\"group\"\n        aria-roledescription=\"slide\"\n      >\n        <h3>{{ slide.label }}</h3>\n        @if (slide.description) {\n          <p>{{ slide.description }}</p>\n        }\n      </div>\n    }\n  </tui-carousel>\n  <div class=\"atr-carousel__controls\">\n    <button\n      atrButton\n      type=\"button\"\n      appearance=\"text\"\n      aria-label=\"Previous slide\"\n      (click)=\"previous()\"\n    >\n      Previous\n    </button>\n    <button\n      atrButton\n      type=\"button\"\n      appearance=\"text\"\n      aria-label=\"Next slide\"\n      (click)=\"next()\"\n    >\n      Next\n    </button>\n  </div>\n  @if (showIndicators()) {\n    <div\n      class=\"atr-carousel__indicators\"\n      role=\"tablist\"\n      aria-label=\"Choose slide\"\n    >\n      @for (slide of slides(); track slide.id; let index = $index) {\n        <button\n          atrButton\n          type=\"button\"\n          appearance=\"text\"\n          role=\"tab\"\n          [attr.aria-selected]=\"index === activeIndex()\"\n          [attr.aria-label]=\"'Go to slide ' + (index + 1)\"\n          (click)=\"onIndex(index)\"\n        >\n          {{ index + 1 }}\n        </button>\n      }\n    </div>\n  }\n</section>\n",
		styles: [":host{display:block;min-inline-size:0}.atr-carousel__controls,.atr-carousel__indicators{display:flex;flex-wrap:wrap;gap:var(--atr-ref-spacing-2, .5rem);margin-block-start:var(--atr-ref-spacing-3, .75rem)}.atr-carousel__slide{padding:var(--atr-ref-spacing-4, 1rem)}\n"],
		dependencies: [
			{
				kind: "component",
				type: i1.TuiCarouselComponent,
				selector: "tui-carousel",
				inputs: [
					"index",
					"min",
					"max"
				],
				outputs: ["indexChange"]
			},
			{
				kind: "directive",
				type: i1.TuiCarouselDirective,
				selector: "tui-carousel[duration]",
				inputs: ["duration"],
				exportAs: ["tuiCarousel"]
			},
			{
				kind: "directive",
				type: i2.TuiItem,
				selector: "[tuiItem]"
			},
			{
				kind: "component",
				type: AtralumeButton,
				selector: "button[atrButton], a[atrButton]",
				inputs: [
					"appearance",
					"size",
					"disabled",
					"loading",
					"fullWidth",
					"tabindex"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeCarousel,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-carousel",
			standalone: true,
			imports: [TuiCarousel, AtralumeButton],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "atr-carousel" },
			template: "<section\n  role=\"region\"\n  [attr.aria-label]=\"label()\"\n  aria-roledescription=\"carousel\"\n>\n  <tui-carousel\n    [index]=\"activeIndex()\"\n    (indexChange)=\"onIndex($event)\"\n    [duration]=\"duration()\"\n    [min]=\"0\"\n    [max]=\"max()\"\n  >\n    @for (slide of slides(); track slide.id; let index = $index) {\n      <div\n        *tuiItem\n        class=\"atr-carousel__slide\"\n        role=\"group\"\n        aria-roledescription=\"slide\"\n      >\n        <h3>{{ slide.label }}</h3>\n        @if (slide.description) {\n          <p>{{ slide.description }}</p>\n        }\n      </div>\n    }\n  </tui-carousel>\n  <div class=\"atr-carousel__controls\">\n    <button\n      atrButton\n      type=\"button\"\n      appearance=\"text\"\n      aria-label=\"Previous slide\"\n      (click)=\"previous()\"\n    >\n      Previous\n    </button>\n    <button\n      atrButton\n      type=\"button\"\n      appearance=\"text\"\n      aria-label=\"Next slide\"\n      (click)=\"next()\"\n    >\n      Next\n    </button>\n  </div>\n  @if (showIndicators()) {\n    <div\n      class=\"atr-carousel__indicators\"\n      role=\"tablist\"\n      aria-label=\"Choose slide\"\n    >\n      @for (slide of slides(); track slide.id; let index = $index) {\n        <button\n          atrButton\n          type=\"button\"\n          appearance=\"text\"\n          role=\"tab\"\n          [attr.aria-selected]=\"index === activeIndex()\"\n          [attr.aria-label]=\"'Go to slide ' + (index + 1)\"\n          (click)=\"onIndex(index)\"\n        >\n          {{ index + 1 }}\n        </button>\n      }\n    </div>\n  }\n</section>\n",
			styles: [":host{display:block;min-inline-size:0}.atr-carousel__controls,.atr-carousel__indicators{display:flex;flex-wrap:wrap;gap:var(--atr-ref-spacing-2, .5rem);margin-block-start:var(--atr-ref-spacing-3, .75rem)}.atr-carousel__slide{padding:var(--atr-ref-spacing-4, 1rem)}\n"]
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		slides: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "slides",
				required: false
			}]
		}],
		activeIndex: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "activeIndex",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["activeIndexChange"]
		}],
		loop: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "loop",
				required: false
			}]
		}],
		autoplay: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autoplay",
				required: false
			}]
		}],
		autoplayDelay: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "autoplayDelay",
				required: false
			}]
		}],
		showIndicators: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showIndicators",
				required: false
			}]
		}],
		activeChange: [{
			type: i0.Output,
			args: ["activeChange"]
		}]
	}
});
var AtralumeCarouselHarness = class extends ComponentHarness {
	static hostSelector = "atr-carousel";
	async getActiveSlide() {
		return (await this.locatorFor(".atr-carousel__slide:not([hidden])")()).text();
	}
	async next() {
		await (await this.locatorFor("button[aria-label=\"Next slide\"]")()).click();
	}
	async previous() {
		await (await this.locatorFor("button[aria-label=\"Previous slide\"]")()).click();
	}
	async goToSlide(index) {
		await (await this.locatorFor(`button[aria-label="Go to slide ${index + 1}"]`)()).click();
	}
	async pause() {
		const control = await this.locatorForOptional("button[aria-label=\"Pause automatic slides\"]")();
		if (control) await control.click();
	}
	async resume() {
		const control = await this.locatorForOptional("button[aria-label=\"Resume automatic slides\"]")();
		if (control) await control.click();
	}
};
export { AtralumeCarousel, AtralumeCarouselHarness };

//# sourceMappingURL=osmanjimenez-atralume-carousel.mjs.map