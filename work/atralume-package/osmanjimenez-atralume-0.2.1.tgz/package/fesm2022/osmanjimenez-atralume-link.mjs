import * as i0 from "@angular/core";
import { Directive, input } from "@angular/core";
import * as i1 from "@taiga-ui/core";
import { TuiLink } from "@taiga-ui/core";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeLink = class AtralumeLink {
	appearance = input("inline", ...ngDevMode ? [{ debugName: "appearance" }] : /* istanbul ignore next */ []);
	underline = input("always", ...ngDevMode ? [{ debugName: "underline" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeLink,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeLink,
		isStandalone: true,
		selector: "a[atrLink]",
		inputs: {
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			underline: {
				classPropertyName: "underline",
				publicName: "underline",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: {
				"attr.tuiLink": "\"\"",
				"attr.data-appearance": "appearance()",
				"attr.data-underline": "underline()"
			},
			classAttribute: "atr-link"
		},
		hostDirectives: [{ directive: i1.TuiLink }],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeLink,
	decorators: [{
		type: Directive,
		args: [{
			selector: "a[atrLink]",
			standalone: true,
			hostDirectives: [TuiLink],
			host: {
				class: "atr-link",
				"[attr.tuiLink]": "\"\"",
				"[attr.data-appearance]": "appearance()",
				"[attr.data-underline]": "underline()"
			}
		}]
	}],
	propDecorators: {
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		underline: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "underline",
				required: false
			}]
		}]
	}
});
var AtralumeLinkHarness = class extends ComponentHarness {
	static hostSelector = ".atr-link";
	async getText() {
		return (await this.host()).text();
	}
	async getHref() {
		return (await this.host()).getAttribute("href");
	}
	async getAppearance() {
		return (await this.host()).getAttribute("data-appearance");
	}
};
export { AtralumeLink, AtralumeLinkHarness };

//# sourceMappingURL=osmanjimenez-atralume-link.mjs.map