import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, Directive, input } from "@angular/core";
import * as i1 from "@taiga-ui/cdk/directives/item";
import { TuiItem } from "@taiga-ui/cdk/directives/item";
import { TuiBreadcrumbs } from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeBreadcrumbs = class AtralumeBreadcrumbs {
	label = input("Breadcrumb", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	size = input("m", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	itemsLimit = input(4, ...ngDevMode ? [{ debugName: "itemsLimit" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeBreadcrumbs,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeBreadcrumbs,
		isStandalone: true,
		selector: "atr-breadcrumbs, nav[atrBreadcrumbs]",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			itemsLimit: {
				classPropertyName: "itemsLimit",
				publicName: "itemsLimit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: { "attr.aria-label": "label()" },
			classAttribute: "atr-breadcrumbs"
		},
		ngImport: i0,
		template: "<tui-breadcrumbs [size]=\"size()\" [itemsLimit]=\"itemsLimit()\">\n  <ng-content />\n</tui-breadcrumbs>\n",
		styles: [":host{display:block;min-inline-size:0}\n"],
		dependencies: [{
			kind: "component",
			type: TuiBreadcrumbs,
			selector: "tui-breadcrumbs",
			inputs: ["size", "itemsLimit"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeBreadcrumbs,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-breadcrumbs, nav[atrBreadcrumbs]",
			standalone: true,
			imports: [TuiBreadcrumbs, TuiItem],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "atr-breadcrumbs",
				"[attr.aria-label]": "label()"
			},
			template: "<tui-breadcrumbs [size]=\"size()\" [itemsLimit]=\"itemsLimit()\">\n  <ng-content />\n</tui-breadcrumbs>\n",
			styles: [":host{display:block;min-inline-size:0}\n"]
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		itemsLimit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "itemsLimit",
				required: false
			}]
		}]
	}
});
var AtralumeBreadcrumbItem = class AtralumeBreadcrumbItem {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeBreadcrumbItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeBreadcrumbItem,
		isStandalone: true,
		selector: "[atrBreadcrumbItem]",
		host: { classAttribute: "atr-breadcrumb-item" },
		hostDirectives: [{ directive: i1.TuiItem }],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeBreadcrumbItem,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrBreadcrumbItem]",
			standalone: true,
			hostDirectives: [TuiItem],
			host: { class: "atr-breadcrumb-item" }
		}]
	}]
});
var AtralumeBreadcrumbSeparator = class AtralumeBreadcrumbSeparator {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeBreadcrumbSeparator,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeBreadcrumbSeparator,
		isStandalone: true,
		selector: "[atrBreadcrumbSeparator]",
		host: {
			attributes: { "hidden": "true" },
			classAttribute: "atr-breadcrumb-separator"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeBreadcrumbSeparator,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrBreadcrumbSeparator]",
			standalone: true,
			host: {
				class: "atr-breadcrumb-separator",
				hidden: "true"
			}
		}]
	}]
});
var AtralumeBreadcrumbOverflow = class AtralumeBreadcrumbOverflow {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeBreadcrumbOverflow,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeBreadcrumbOverflow,
		isStandalone: true,
		selector: "[atrBreadcrumbOverflow]",
		host: {
			attributes: { "hidden": "true" },
			classAttribute: "atr-breadcrumb-overflow"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeBreadcrumbOverflow,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrBreadcrumbOverflow]",
			standalone: true,
			host: {
				class: "atr-breadcrumb-overflow",
				hidden: "true"
			}
		}]
	}]
});
var AtralumeBreadcrumbsHarness = class extends ComponentHarness {
	static hostSelector = ".atr-breadcrumbs";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeBreadcrumbItemHarness = class extends ComponentHarness {
	static hostSelector = ".atr-breadcrumb-item";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeBreadcrumbSeparatorHarness = class extends ComponentHarness {
	static hostSelector = ".atr-breadcrumb-separator";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeBreadcrumbOverflowHarness = class extends ComponentHarness {
	static hostSelector = ".atr-breadcrumb-overflow";
	async getText() {
		return (await this.host()).text();
	}
};
export { AtralumeBreadcrumbItem, AtralumeBreadcrumbItemHarness, AtralumeBreadcrumbOverflow, AtralumeBreadcrumbOverflowHarness, AtralumeBreadcrumbSeparator, AtralumeBreadcrumbSeparatorHarness, AtralumeBreadcrumbs, AtralumeBreadcrumbsHarness };

//# sourceMappingURL=osmanjimenez-atralume-breadcrumbs.mjs.map