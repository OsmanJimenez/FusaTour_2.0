import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, Directive, ElementRef, Injector, PLATFORM_ID, Renderer2, afterNextRender, booleanAttribute, computed, contentChildren, inject, input, model, viewChild } from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
import { DOCUMENT, isPlatformBrowser } from "@angular/common";
import { AtralumeFab } from "@osmanjimenez/atralume/fab";
var AtralumeSpeedDialAction = class AtralumeSpeedDialAction {
	ref = inject(ElementRef);
	focus() {
		this.ref.nativeElement.focus();
	}
	isDisabled() {
		return this.ref.nativeElement.disabled;
	}
	element() {
		return this.ref.nativeElement;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeSpeedDialAction,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeSpeedDialAction,
		isStandalone: true,
		selector: "button[atrSpeedDialAction]",
		host: { classAttribute: "atr-speed-dial-action" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeSpeedDialAction,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[atrSpeedDialAction]",
			standalone: true,
			host: { class: "atr-speed-dial-action" }
		}]
	}]
});
var AtralumeSpeedDialActionHarness = class extends ComponentHarness {
	static hostSelector = ".atr-speed-dial-action";
	async getText() {
		return (await this.host()).text();
	}
	async click() {
		await (await this.host()).click();
	}
	async isDisabled() {
		return (await this.host()).getProperty("disabled");
	}
};
var AtralumeSpeedDial = class AtralumeSpeedDial {
	id = input.required(...ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	opened = model(false, ...ngDevMode ? [{ debugName: "opened" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	orientation = input("vertical", ...ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []);
	visible = computed(() => this.opened() && !this.disabled(), ...ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []);
	actions = contentChildren(AtralumeSpeedDialAction, ...ngDevMode ? [{ debugName: "actions" }] : /* istanbul ignore next */ []);
	element = inject(ElementRef).nativeElement;
	trigger = viewChild.required("trigger", ...ngDevMode ? [{ debugName: "trigger" }] : /* istanbul ignore next */ []);
	injector = inject(Injector);
	constructor() {
		if (isPlatformBrowser(inject(PLATFORM_ID))) {
			const unlisten = inject(Renderer2).listen(inject(DOCUMENT), "pointerdown", (event) => {
				if (this.visible() && !this.element.contains(event.target)) this.dismiss(false);
			});
			inject(DestroyRef).onDestroy(unlisten);
		}
	}
	toggle() {
		if (!this.disabled()) this.opened.update((value) => !value);
	}
	dismiss(restore = true) {
		this.opened.set(false);
		if (restore) this.trigger().nativeElement.focus();
	}
	clicked(event) {
		if (event.target.closest(".atr-speed-dial-action")) this.dismiss();
	}
	lostFocus(event) {
		if (event.relatedTarget && !this.element.contains(event.relatedTarget)) this.opened.set(false);
	}
	onKey(event) {
		if (this.disabled()) return;
		if (event.key === "Escape" && this.visible()) {
			event.preventDefault();
			event.stopPropagation();
			this.dismiss();
			return;
		}
		const actions = this.actions().filter((action) => !action.isDisabled());
		if (!actions.length) return;
		const vertical = this.orientation() === "vertical", rtl = this.element.matches(":dir(rtl)");
		const forward = vertical ? "ArrowDown" : rtl ? "ArrowLeft" : "ArrowRight", backward = vertical ? "ArrowUp" : rtl ? "ArrowRight" : "ArrowLeft";
		let index = actions.findIndex((action) => action.element() === event.target);
		if (![
			forward,
			backward,
			"Home",
			"End"
		].includes(event.key)) return;
		event.preventDefault();
		index = event.key === "Home" ? 0 : event.key === "End" ? actions.length - 1 : event.key === forward ? (index + 1) % actions.length : index < 0 ? actions.length - 1 : (index - 1 + actions.length) % actions.length;
		this.opened.set(true);
		afterNextRender(() => actions[index]?.focus(), { injector: this.injector });
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeSpeedDial,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.4",
		type: AtralumeSpeedDial,
		isStandalone: true,
		selector: "atr-speed-dial",
		inputs: {
			id: {
				classPropertyName: "id",
				publicName: "id",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			opened: {
				classPropertyName: "opened",
				publicName: "opened",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { opened: "openedChange" },
		host: {
			listeners: {
				"keydown": "onKey($event)",
				"click": "clicked($event)",
				"focusout": "lostFocus($event)"
			},
			properties: { "attr.data-orientation": "orientation()" },
			classAttribute: "atr-speed-dial"
		},
		queries: [{
			propertyName: "actions",
			predicate: AtralumeSpeedDialAction,
			isSignal: true
		}],
		viewQueries: [{
			propertyName: "trigger",
			first: true,
			predicate: ["trigger"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<button\n  #trigger\n  atrFab\n  type=\"button\"\n  [disabled]=\"disabled()\"\n  [attr.aria-label]=\"label()\"\n  [attr.aria-expanded]=\"visible()\"\n  [attr.aria-controls]=\"id() + '-actions'\"\n  (click)=\"toggle()\"\n>\n  {{ visible() ? \"×\" : \"+\" }}\n</button>\n<div\n  [id]=\"id() + '-actions'\"\n  role=\"group\"\n  [attr.aria-label]=\"label() + ' actions'\"\n  [hidden]=\"!visible()\"\n  class=\"actions\"\n>\n  <ng-content select=\"[atrSpeedDialAction]\" />\n</div>\n",
		styles: [":host{display:inline-flex;flex-direction:column;align-items:flex-end;gap:var(--atr-comp-speed-dial-gap);max-inline-size:100%;font-family:var(--atr-comp-speed-dial-font-family)}.actions{display:flex;flex-direction:column;gap:var(--atr-comp-speed-dial-gap);max-inline-size:calc(100vw - 2rem);max-block-size:calc(100dvh - 8rem);overflow:auto}.actions[hidden]{display:none}:host([data-orientation=horizontal]),:host([data-orientation=horizontal]) .actions{flex-direction:row;align-items:center}\n"],
		dependencies: [{
			kind: "directive",
			type: AtralumeFab,
			selector: "button[atrFab]",
			inputs: [
				"size",
				"appearance",
				"extended"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeSpeedDial,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-speed-dial",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [AtralumeFab],
			host: {
				class: "atr-speed-dial",
				"[attr.data-orientation]": "orientation()",
				"(keydown)": "onKey($event)",
				"(click)": "clicked($event)",
				"(focusout)": "lostFocus($event)"
			},
			template: "<button\n  #trigger\n  atrFab\n  type=\"button\"\n  [disabled]=\"disabled()\"\n  [attr.aria-label]=\"label()\"\n  [attr.aria-expanded]=\"visible()\"\n  [attr.aria-controls]=\"id() + '-actions'\"\n  (click)=\"toggle()\"\n>\n  {{ visible() ? \"×\" : \"+\" }}\n</button>\n<div\n  [id]=\"id() + '-actions'\"\n  role=\"group\"\n  [attr.aria-label]=\"label() + ' actions'\"\n  [hidden]=\"!visible()\"\n  class=\"actions\"\n>\n  <ng-content select=\"[atrSpeedDialAction]\" />\n</div>\n",
			styles: [":host{display:inline-flex;flex-direction:column;align-items:flex-end;gap:var(--atr-comp-speed-dial-gap);max-inline-size:100%;font-family:var(--atr-comp-speed-dial-font-family)}.actions{display:flex;flex-direction:column;gap:var(--atr-comp-speed-dial-gap);max-inline-size:calc(100vw - 2rem);max-block-size:calc(100dvh - 8rem);overflow:auto}.actions[hidden]{display:none}:host([data-orientation=horizontal]),:host([data-orientation=horizontal]) .actions{flex-direction:row;align-items:center}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		id: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "id",
				required: true
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		opened: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "opened",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["openedChange"]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		actions: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => AtralumeSpeedDialAction), { isSignal: true }]
		}],
		trigger: [{
			type: i0.ViewChild,
			args: ["trigger", { isSignal: true }]
		}]
	}
});
var AtralumeSpeedDialHarness = class extends ComponentHarness {
	static hostSelector = "atr-speed-dial";
	async getText() {
		return (await this.host()).text();
	}
	async toggle() {
		await (await this.locatorFor("button.atr-fab")()).click();
	}
	async isOpen() {
		return await (await this.locatorFor("button.atr-fab")()).getAttribute("aria-expanded") === "true";
	}
};
export { AtralumeSpeedDial, AtralumeSpeedDialAction, AtralumeSpeedDialActionHarness, AtralumeSpeedDialHarness };

//# sourceMappingURL=osmanjimenez-atralume-speed-dial.mjs.map