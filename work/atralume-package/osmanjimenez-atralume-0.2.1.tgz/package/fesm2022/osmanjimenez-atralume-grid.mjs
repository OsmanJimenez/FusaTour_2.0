import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, Directive, computed, input } from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
const GAP_TOKEN = {
	none: "0",
	xs: "var(--atr-sys-spacing-xs)",
	sm: "var(--atr-sys-spacing-sm)",
	md: "var(--atr-sys-spacing-md)",
	lg: "var(--atr-sys-spacing-lg)",
	xl: "var(--atr-sys-spacing-xl)"
};
var AtralumeGrid = class AtralumeGrid {
	columns = input(3, ...ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []);
	gap = input("md", ...ngDevMode ? [{ debugName: "gap" }] : /* istanbul ignore next */ []);
	minTrack = input("14rem", ...ngDevMode ? [{ debugName: "minTrack" }] : /* istanbul ignore next */ []);
	columnsAttr = computed(() => String(this.columns()), ...ngDevMode ? [{ debugName: "columnsAttr" }] : /* istanbul ignore next */ []);
	columnsCss = computed(() => {
		const columns = this.columns();
		if (columns === "auto") return "auto";
		const n = Math.trunc(Number(columns));
		return String(Number.isFinite(n) && n > 0 ? n : 3);
	}, ...ngDevMode ? [{ debugName: "columnsCss" }] : /* istanbul ignore next */ []);
	gapCss = computed(() => GAP_TOKEN[this.gap()] ?? GAP_TOKEN.md, ...ngDevMode ? [{ debugName: "gapCss" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeGrid,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeGrid,
		isStandalone: true,
		selector: "atr-grid",
		inputs: {
			columns: {
				classPropertyName: "columns",
				publicName: "columns",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			gap: {
				classPropertyName: "gap",
				publicName: "gap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minTrack: {
				classPropertyName: "minTrack",
				publicName: "minTrack",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: {
				"attr.data-columns": "columnsAttr()",
				"attr.data-gap": "gap()",
				"style.--atr-grid-columns": "columnsCss()",
				"style.--atr-grid-gap": "gapCss()",
				"style.--atr-grid-min": "minTrack()"
			},
			classAttribute: "atr-grid"
		},
		ngImport: i0,
		template: "<ng-content />",
		isInline: true,
		styles: [":host{display:grid;gap:var(--atr-grid-gap, var(--atr-comp-grid-gap, var(--atr-sys-spacing-md)));grid-template-columns:repeat(var(--atr-grid-columns, 3),minmax(0,1fr));align-items:stretch;justify-items:stretch;min-inline-size:0}:host([data-columns=auto]){grid-template-columns:repeat(auto-fill,minmax(min(100%,var(--atr-grid-min, 14rem)),1fr))}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeGrid,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-grid",
			standalone: true,
			template: "<ng-content />",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "atr-grid",
				"[attr.data-columns]": "columnsAttr()",
				"[attr.data-gap]": "gap()",
				"[style.--atr-grid-columns]": "columnsCss()",
				"[style.--atr-grid-gap]": "gapCss()",
				"[style.--atr-grid-min]": "minTrack()"
			},
			styles: [":host{display:grid;gap:var(--atr-grid-gap, var(--atr-comp-grid-gap, var(--atr-sys-spacing-md)));grid-template-columns:repeat(var(--atr-grid-columns, 3),minmax(0,1fr));align-items:stretch;justify-items:stretch;min-inline-size:0}:host([data-columns=auto]){grid-template-columns:repeat(auto-fill,minmax(min(100%,var(--atr-grid-min, 14rem)),1fr))}\n"]
		}]
	}],
	propDecorators: {
		columns: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columns",
				required: false
			}]
		}],
		gap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "gap",
				required: false
			}]
		}],
		minTrack: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minTrack",
				required: false
			}]
		}]
	}
});
var AtralumeGridItem = class AtralumeGridItem {
	span = input(1, ...ngDevMode ? [{ debugName: "span" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeGridItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeGridItem,
		isStandalone: true,
		selector: "[atrGridItem]",
		inputs: { span: {
			classPropertyName: "span",
			publicName: "span",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			properties: { "attr.data-span": "span()" },
			classAttribute: "atr-grid-item"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeGridItem,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrGridItem]",
			standalone: true,
			host: {
				class: "atr-grid-item",
				"[attr.data-span]": "span()"
			}
		}]
	}],
	propDecorators: { span: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "span",
			required: false
		}]
	}] }
});
var AtralumeGridHarness = class extends ComponentHarness {
	static hostSelector = "atr-grid";
	async getColumns() {
		return (await this.host()).getAttribute("data-columns");
	}
	async getGap() {
		return (await this.host()).getAttribute("data-gap");
	}
};
var AtralumeGridItemHarness = class extends ComponentHarness {
	static hostSelector = ".atr-grid-item";
	async getSpan() {
		return (await this.host()).getAttribute("data-span");
	}
};
export { AtralumeGrid, AtralumeGridHarness, AtralumeGridItem, AtralumeGridItemHarness };

//# sourceMappingURL=osmanjimenez-atralume-grid.mjs.map