import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, Directive, booleanAttribute, computed, input, model, output } from "@angular/core";
import * as i1$1 from "@taiga-ui/kit";
import { TuiDataListWrapper } from "@taiga-ui/kit";
import * as i1 from "@taiga-ui/core";
import { TuiOption } from "@taiga-ui/core";
import { ComponentHarness, HarnessPredicate } from "@angular/cdk/testing";
var AtralumeListbox = class AtralumeListbox {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	options = input([], ...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	value = model([], ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	selectionMode = input("single", ...ngDevMode ? [{ debugName: "selectionMode" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	emptyText = input("No results", ...ngDevMode ? [{ debugName: "emptyText" }] : /* istanbul ignore next */ []);
	chosen = output();
	items = computed(() => this.options().map((option) => option.value), ...ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []);
	pick(value) {
		if (this.disabled()) return;
		if (this.options().find((item) => Object.is(item.value, value))?.disabled) return;
		if (this.selectionMode() === "multiple") {
			const current = this.value();
			const next = current.some((item) => Object.is(item, value)) ? current.filter((item) => !Object.is(item, value)) : [...current, value];
			this.value.set(next);
		} else this.value.set([value]);
		this.chosen.emit(value);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeListbox,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeListbox,
		isStandalone: true,
		selector: "atr-listbox",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			options: {
				classPropertyName: "options",
				publicName: "options",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selectionMode: {
				classPropertyName: "selectionMode",
				publicName: "selectionMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			emptyText: {
				classPropertyName: "emptyText",
				publicName: "emptyText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			value: "valueChange",
			chosen: "chosen"
		},
		host: {
			attributes: { "role": "presentation" },
			classAttribute: "atr-listbox"
		},
		ngImport: i0,
		template: "<tui-data-list-wrapper\n  [attr.aria-label]=\"label()\"\n  [items]=\"items()\"\n  [emptyContent]=\"emptyText()\"\n  (itemClick)=\"pick($event)\"\n/>\n",
		styles: [":host{display:block;box-sizing:border-box;min-inline-size:0;min-block-size:var(--atr-comp-selection-option-height);padding:var(--atr-comp-listbox-gap);border-radius:var(--atr-comp-selection-panel-shape);color:var(--atr-comp-listbox-label-color);background:var(--atr-comp-listbox-container-color);font-family:var(--atr-ref-font-family-plain)}:host(:focus-visible){outline:var(--atr-sys-focus-ring-width) solid var(--atr-comp-listbox-focus-color);outline-offset:var(--atr-sys-focus-ring-offset)}.atr-option-group-label{padding:var(--atr-comp-listbox-padding);font-weight:600}:host([aria-orientation=horizontal]){display:flex;flex-wrap:wrap}@media(forced-colors:active){:host{border:1px solid CanvasText}}\n"],
		dependencies: [{
			kind: "component",
			type: i1$1.TuiDataListWrapperComponent,
			selector: "tui-data-list-wrapper:not([labels])",
			inputs: [
				"items",
				"emptyContent",
				"size",
				"itemContent"
			],
			outputs: ["itemClick"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeListbox,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-listbox",
			standalone: true,
			imports: [TuiDataListWrapper],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "atr-listbox",
				role: "presentation"
			},
			template: "<tui-data-list-wrapper\n  [attr.aria-label]=\"label()\"\n  [items]=\"items()\"\n  [emptyContent]=\"emptyText()\"\n  (itemClick)=\"pick($event)\"\n/>\n",
			styles: [":host{display:block;box-sizing:border-box;min-inline-size:0;min-block-size:var(--atr-comp-selection-option-height);padding:var(--atr-comp-listbox-gap);border-radius:var(--atr-comp-selection-panel-shape);color:var(--atr-comp-listbox-label-color);background:var(--atr-comp-listbox-container-color);font-family:var(--atr-ref-font-family-plain)}:host(:focus-visible){outline:var(--atr-sys-focus-ring-width) solid var(--atr-comp-listbox-focus-color);outline-offset:var(--atr-sys-focus-ring-offset)}.atr-option-group-label{padding:var(--atr-comp-listbox-padding);font-weight:600}:host([aria-orientation=horizontal]){display:flex;flex-wrap:wrap}@media(forced-colors:active){:host{border:1px solid CanvasText}}\n"]
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}],
		selectionMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectionMode",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		emptyText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "emptyText",
				required: false
			}]
		}],
		chosen: [{
			type: i0.Output,
			args: ["chosen"]
		}]
	}
});
var AtralumeOptionDirective = class AtralumeOptionDirective {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeOptionDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeOptionDirective,
		isStandalone: true,
		selector: "button[atrOption], a[atrOption], label[atrOption]",
		host: {
			properties: { "attr.tuiOption": "\"\"" },
			classAttribute: "atr-option"
		},
		hostDirectives: [{
			directive: i1.TuiOption,
			inputs: ["disabled", "disabled"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeOptionDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[atrOption], a[atrOption], label[atrOption]",
			standalone: true,
			hostDirectives: [{
				directive: TuiOption,
				inputs: ["disabled"]
			}],
			host: {
				class: "atr-option",
				"[attr.tuiOption]": "\"\""
			}
		}]
	}]
});
var AtralumeOptionGroup = class AtralumeOptionGroup {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeOptionGroup,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeOptionGroup,
		isStandalone: true,
		selector: "[atrOptionGroup]",
		inputs: { label: {
			classPropertyName: "label",
			publicName: "label",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: {
			attributes: { "role": "group" },
			properties: { "attr.aria-label": "label()" },
			classAttribute: "atr-option-group"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeOptionGroup,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrOptionGroup]",
			standalone: true,
			host: {
				role: "group",
				"[attr.aria-label]": "label()",
				class: "atr-option-group"
			}
		}]
	}],
	propDecorators: { label: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "label",
			required: true
		}]
	}] }
});
var AtralumeOptionGroupLabel = class AtralumeOptionGroupLabel {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeOptionGroupLabel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeOptionGroupLabel,
		isStandalone: true,
		selector: "[atrOptionGroupLabel]",
		host: {
			attributes: { "aria-hidden": "true" },
			classAttribute: "atr-option-group-label"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeOptionGroupLabel,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrOptionGroupLabel]",
			standalone: true,
			host: {
				class: "atr-option-group-label",
				"aria-hidden": "true"
			}
		}]
	}]
});
var AtralumeOptionHarness = class AtralumeOptionHarness extends ComponentHarness {
	static hostSelector = "button[tuiOption], button[atrOption]";
	static with(options = {}) {
		return new HarnessPredicate(AtralumeOptionHarness, options).addOption("label", options.label, (harness, label) => HarnessPredicate.stringMatches(harness.getLabel(), label));
	}
	async getLabel() {
		return (await this.host()).getAttribute("aria-label").then((label) => label ?? "");
	}
	async isSelected() {
		return (await this.host()).getAttribute("aria-selected").then((value) => value === "true");
	}
	async isDisabled() {
		return (await this.host()).getAttribute("aria-disabled").then((value) => value === "true");
	}
	async select() {
		await (await this.host()).click();
	}
};
var AtralumeListboxHarness = class extends ComponentHarness {
	static hostSelector = "atr-listbox";
	getOptions = this.locatorForAll(AtralumeOptionHarness);
	async getSelectedOptions() {
		const options = await this.getOptions();
		const selected = await Promise.all(options.map((option) => option.isSelected()));
		return options.filter((_, index) => selected[index]);
	}
	async selectOption(label) {
		await (await this.locatorFor(AtralumeOptionHarness.with({ label }))()).select();
	}
	async isMultiple() {
		return (await this.host()).getAttribute("aria-multiselectable").then((value) => value === "true");
	}
	async isDisabled() {
		return (await this.host()).getAttribute("aria-disabled").then((value) => value === "true");
	}
	async navigate(key) {
		await (await this.host()).sendKeys(key);
	}
};
export { AtralumeListbox, AtralumeListboxHarness, AtralumeOptionDirective, AtralumeOptionGroup, AtralumeOptionGroupLabel, AtralumeOptionHarness };

//# sourceMappingURL=osmanjimenez-atralume-listbox.mjs.map