import * as i0 from "@angular/core";
import { Directive, booleanAttribute, input } from "@angular/core";
import * as i1 from "@taiga-ui/core";
import { TuiButton } from "@taiga-ui/core";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeFab = class AtralumeFab {
	size = input("medium", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	appearance = input("primary", ...ngDevMode ? [{ debugName: "appearance" }] : /* istanbul ignore next */ []);
	extended = input(false, {
		...ngDevMode ? { debugName: "extended" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeFab,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeFab,
		isStandalone: true,
		selector: "button[atrFab]",
		inputs: {
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			extended: {
				classPropertyName: "extended",
				publicName: "extended",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: {
				"attr.tuiButton": "\"\"",
				"attr.data-size": "size()",
				"attr.data-appearance": "appearance()",
				"attr.data-extended": "extended()"
			},
			classAttribute: "atr-fab"
		},
		hostDirectives: [{
			directive: i1.TuiButton,
			inputs: ["size", "tuiSize"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeFab,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[atrFab]",
			standalone: true,
			hostDirectives: [{
				directive: TuiButton,
				inputs: ["size: tuiSize"]
			}],
			host: {
				class: "atr-fab",
				"[attr.tuiButton]": "\"\"",
				"[attr.data-size]": "size()",
				"[attr.data-appearance]": "appearance()",
				"[attr.data-extended]": "extended()"
			}
		}]
	}],
	propDecorators: {
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		extended: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "extended",
				required: false
			}]
		}]
	}
});
var AtralumeFabHarness = class extends ComponentHarness {
	static hostSelector = ".atr-fab";
	async getText() {
		return (await this.host()).text();
	}
	async click() {
		await (await this.host()).click();
	}
	async isDisabled() {
		return (await this.host()).getProperty("disabled");
	}
};
export { AtralumeFab, AtralumeFabHarness, AtralumeFabHarness as AtralumeFloatingActionButtonHarness };

//# sourceMappingURL=osmanjimenez-atralume-fab.mjs.map