import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, booleanAttribute, input, output } from "@angular/core";
import { TuiLineClamp } from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeTruncatedText = class AtralumeTruncatedText {
	content = input("", ...ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []);
	lines = input(1, {
		...ngDevMode ? { debugName: "lines" } : /* istanbul ignore next */ {},
		transform: (value) => value ?? 1
	});
	lineHeight = input(24, {
		...ngDevMode ? { debugName: "lineHeight" } : /* istanbul ignore next */ {},
		transform: (value) => value ?? 24
	});
	showHint = input(true, {
		...ngDevMode ? { debugName: "showHint" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	overflownChange = output();
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeTruncatedText,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeTruncatedText,
		isStandalone: true,
		selector: "atr-truncated-text",
		inputs: {
			content: {
				classPropertyName: "content",
				publicName: "content",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lines: {
				classPropertyName: "lines",
				publicName: "lines",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lineHeight: {
				classPropertyName: "lineHeight",
				publicName: "lineHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showHint: {
				classPropertyName: "showHint",
				publicName: "showHint",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { overflownChange: "overflownChange" },
		host: { classAttribute: "atr-truncated-text" },
		ngImport: i0,
		template: "<tui-line-clamp\n  [lineHeight]=\"lineHeight()\"\n  [linesLimit]=\"lines()\"\n  [content]=\"content()\"\n  [showHint]=\"showHint()\"\n  (overflownChange)=\"overflownChange.emit($event)\"\n/>\n",
		styles: [":host{display:block;min-inline-size:0;color:var(--atr-comp-truncated-text-color, var(--atr-sys-color-on-surface))}\n"],
		dependencies: [{
			kind: "component",
			type: TuiLineClamp,
			selector: "tui-line-clamp",
			inputs: [
				"lineHeight",
				"linesLimit",
				"content",
				"showHint"
			],
			outputs: ["overflownChange"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeTruncatedText,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-truncated-text",
			standalone: true,
			imports: [TuiLineClamp],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "atr-truncated-text" },
			template: "<tui-line-clamp\n  [lineHeight]=\"lineHeight()\"\n  [linesLimit]=\"lines()\"\n  [content]=\"content()\"\n  [showHint]=\"showHint()\"\n  (overflownChange)=\"overflownChange.emit($event)\"\n/>\n",
			styles: [":host{display:block;min-inline-size:0;color:var(--atr-comp-truncated-text-color, var(--atr-sys-color-on-surface))}\n"]
		}]
	}],
	propDecorators: {
		content: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "content",
				required: false
			}]
		}],
		lines: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lines",
				required: false
			}]
		}],
		lineHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lineHeight",
				required: false
			}]
		}],
		showHint: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showHint",
				required: false
			}]
		}],
		overflownChange: [{
			type: i0.Output,
			args: ["overflownChange"]
		}]
	}
});
var AtralumeTruncatedTextHarness = class extends ComponentHarness {
	static hostSelector = "atr-truncated-text";
	async getText() {
		return (await this.host()).text();
	}
};
export { AtralumeTruncatedText, AtralumeTruncatedTextHarness };

//# sourceMappingURL=osmanjimenez-atralume-truncated-text.mjs.map