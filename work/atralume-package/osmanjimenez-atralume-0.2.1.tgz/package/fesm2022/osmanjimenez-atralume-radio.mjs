import * as i0 from "@angular/core";
import { Directive, afterNextRender, inject } from "@angular/core";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";
import { NgControl } from "@angular/forms";
import * as i2 from "@taiga-ui/cdk/directives/native-validator";
import { TuiNativeValidator } from "@taiga-ui/cdk/directives/native-validator";
import { tuiInjectElement } from "@taiga-ui/cdk/utils/dom";
import * as i1 from "@taiga-ui/core/directives/appearance";
import { TuiAppearance, tuiAppearance } from "@taiga-ui/core/directives/appearance";
import { filter, fromEvent } from "rxjs";
import { ComponentHarness } from "@angular/cdk/testing";
function radioAppearance(el) {
	return el.checked ? "primary" : "outline-grayscale";
}
var AtralumeRadio = class AtralumeRadio {
	el = tuiInjectElement();
	appearance = tuiAppearance(radioAppearance(this.el));
	control = inject(NgControl, {
		optional: true,
		self: true
	});
	constructor() {
		const sync = () => this.appearance.set(radioAppearance(this.el));
		afterNextRender(() => {
			sync();
			setTimeout(sync);
		});
		this.control?.valueChanges?.pipe(takeUntilDestroyed()).subscribe(() => sync());
		fromEvent(this.el, "change").pipe(takeUntilDestroyed()).subscribe(sync);
		fromEvent(this.el, "click").pipe(takeUntilDestroyed()).subscribe(sync);
		fromEvent(this.el.ownerDocument, "change", { capture: true }).pipe(takeUntilDestroyed(), filter((event) => {
			const target = event.target;
			return target instanceof HTMLInputElement && target.type === "radio" && !!this.el.name && target.name === this.el.name;
		})).subscribe(sync);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeRadio,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeRadio,
		isStandalone: true,
		selector: "input[type=\"radio\"][atrRadio]",
		host: {
			properties: { "attr.tuiRadio": "\"\"" },
			classAttribute: "atr-radio"
		},
		hostDirectives: [{
			directive: i1.TuiAppearance,
			inputs: [
				"tuiAppearanceState",
				"tuiAppearanceState",
				"tuiAppearanceFocus",
				"tuiAppearanceFocus",
				"tuiAppearanceMode",
				"tuiAppearanceMode"
			]
		}, { directive: i2.TuiNativeValidator }],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeRadio,
	decorators: [{
		type: Directive,
		args: [{
			selector: "input[type=\"radio\"][atrRadio]",
			standalone: true,
			hostDirectives: [{
				directive: TuiAppearance,
				inputs: [
					"tuiAppearanceState",
					"tuiAppearanceFocus",
					"tuiAppearanceMode"
				]
			}, TuiNativeValidator],
			host: {
				class: "atr-radio",
				"[attr.tuiRadio]": "\"\""
			}
		}]
	}],
	ctorParameters: () => []
});
var AtralumeRadioHarness = class extends ComponentHarness {
	static hostSelector = ".atr-radio";
	async isChecked() {
		return (await this.host()).getProperty("checked");
	}
	async toggle() {
		if (!await this.isDisabled()) await (await this.host()).click();
	}
	async check() {
		if (!await this.isChecked()) await this.toggle();
	}
	async getName() {
		return (await this.host()).getProperty("name");
	}
	async getValue() {
		return (await this.host()).getProperty("value");
	}
	async isDisabled() {
		return (await this.host()).getProperty("disabled");
	}
};
export { AtralumeRadio, AtralumeRadioHarness };

//# sourceMappingURL=osmanjimenez-atralume-radio.mjs.map