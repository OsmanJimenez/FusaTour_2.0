import { Clipboard } from "@angular/cdk/clipboard";
import * as i0 from "@angular/core";
import { DestroyRef, Directive, inject, input, signal } from "@angular/core";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";
import * as i1 from "@taiga-ui/core";
import { TuiButton, tuiButtonOptionsProvider } from "@taiga-ui/core";
import { timer } from "rxjs";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeCopyButton = class AtralumeCopyButton {
	clipboard = inject(Clipboard);
	destroyRef = inject(DestroyRef);
	text = input("", ...ngDevMode ? [{ debugName: "text" }] : /* istanbul ignore next */ []);
	copied = signal(false, ...ngDevMode ? [{ debugName: "copied" }] : /* istanbul ignore next */ []);
	onCopy() {
		this.clipboard.copy(this.text());
		this.copied.set(true);
		timer(2e3).pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => this.copied.set(false));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeCopyButton,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeCopyButton,
		isStandalone: true,
		selector: "button[atrCopyButton]",
		inputs: { text: {
			classPropertyName: "text",
			publicName: "text",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			attributes: { "type": "button" },
			listeners: { "click": "onCopy()" },
			properties: {
				"attr.tuiButton": "\"\"",
				"attr.tuiButtonCopy": "text()",
				"attr.data-copied": "copied() ? \"true\" : null"
			},
			classAttribute: "atr-copy-button"
		},
		providers: [tuiButtonOptionsProvider({
			appearance: "flat-grayscale",
			size: "s"
		})],
		hostDirectives: [{ directive: i1.TuiButton }],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeCopyButton,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[atrCopyButton]",
			standalone: true,
			providers: [tuiButtonOptionsProvider({
				appearance: "flat-grayscale",
				size: "s"
			})],
			hostDirectives: [TuiButton],
			host: {
				class: "atr-copy-button",
				type: "button",
				"[attr.tuiButton]": "\"\"",
				"[attr.tuiButtonCopy]": "text()",
				"[attr.data-copied]": "copied() ? \"true\" : null",
				"(click)": "onCopy()"
			}
		}]
	}],
	propDecorators: { text: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "text",
			required: false
		}]
	}] }
});
var AtralumeCopyButtonHarness = class extends ComponentHarness {
	static hostSelector = "button.atr-copy-button";
	async getValue() {
		return (await this.host()).getAttribute("tuiButtonCopy");
	}
	async isCopied() {
		return await (await this.host()).getAttribute("data-copied") === "true";
	}
	async click() {
		await (await this.host()).click();
	}
	async getText() {
		return (await this.host()).text();
	}
};
export { AtralumeCopyButton, AtralumeCopyButtonHarness };

//# sourceMappingURL=osmanjimenez-atralume-copy-button.mjs.map