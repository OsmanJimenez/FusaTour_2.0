import * as i0 from "@angular/core";
import { DestroyRef, Directive, ElementRef, InjectionToken, inject } from "@angular/core";
import * as i1 from "@angular/cdk/menu";
import { CdkMenu, CdkMenuGroup, CdkMenuItem, CdkMenuItemCheckbox, CdkMenuItemRadio, CdkMenuTrigger, FocusNext } from "@angular/cdk/menu";
import * as i2 from "@taiga-ui/core";
import { TuiOption } from "@taiga-ui/core";
import { ɵAtralumeOverlayInfrastructure } from "@osmanjimenez/atralume";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";
import { ComponentHarness, TestKey } from "@angular/cdk/testing";
var AtralumeMenuCheckboxItem = class AtralumeMenuCheckboxItem {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeMenuCheckboxItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeMenuCheckboxItem,
		isStandalone: true,
		selector: "button[atrMenuCheckboxItem]",
		host: {
			properties: { "attr.tuiOption": "\"\"" },
			classAttribute: "atr-menu-item"
		},
		hostDirectives: [{
			directive: i1.CdkMenuItemCheckbox,
			inputs: [
				"cdkMenuItemDisabled",
				"disabled",
				"cdkMenuItemChecked",
				"checked"
			],
			outputs: ["cdkMenuItemTriggered", "invoked"]
		}, {
			directive: i2.TuiOption,
			inputs: ["disabled", "disabled"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeMenuCheckboxItem,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[atrMenuCheckboxItem]",
			standalone: true,
			hostDirectives: [{
				directive: CdkMenuItemCheckbox,
				inputs: ["cdkMenuItemDisabled:disabled", "cdkMenuItemChecked:checked"],
				outputs: ["cdkMenuItemTriggered:invoked"]
			}, {
				directive: TuiOption,
				inputs: ["disabled"]
			}],
			host: {
				class: "atr-menu-item",
				"[attr.tuiOption]": "\"\""
			}
		}]
	}]
});
var AtralumeMenuGroup = class AtralumeMenuGroup {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeMenuGroup,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeMenuGroup,
		isStandalone: true,
		selector: "[atrMenuGroup]",
		host: { classAttribute: "atr-menu-group" },
		hostDirectives: [{ directive: i1.CdkMenuGroup }],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeMenuGroup,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrMenuGroup]",
			standalone: true,
			hostDirectives: [CdkMenuGroup],
			host: { class: "atr-menu-group" }
		}]
	}]
});
var AtralumeMenuItem = class AtralumeMenuItem {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeMenuItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeMenuItem,
		isStandalone: true,
		selector: "button[atrMenuItem]",
		host: {
			properties: { "attr.tuiOption": "\"\"" },
			classAttribute: "atr-menu-item"
		},
		hostDirectives: [{
			directive: i1.CdkMenuItem,
			inputs: ["cdkMenuItemDisabled", "disabled"],
			outputs: ["cdkMenuItemTriggered", "invoked"]
		}, {
			directive: i2.TuiOption,
			inputs: ["disabled", "disabled"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeMenuItem,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[atrMenuItem]",
			standalone: true,
			hostDirectives: [{
				directive: CdkMenuItem,
				inputs: ["cdkMenuItemDisabled:disabled"],
				outputs: ["cdkMenuItemTriggered:invoked"]
			}, {
				directive: TuiOption,
				inputs: ["disabled"]
			}],
			host: {
				class: "atr-menu-item",
				"[attr.tuiOption]": "\"\""
			}
		}]
	}]
});
var AtralumeMenuRadioItem = class AtralumeMenuRadioItem {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeMenuRadioItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeMenuRadioItem,
		isStandalone: true,
		selector: "button[atrMenuRadioItem]",
		host: {
			properties: { "attr.tuiOption": "\"\"" },
			classAttribute: "atr-menu-item"
		},
		hostDirectives: [{
			directive: i1.CdkMenuItemRadio,
			inputs: [
				"cdkMenuItemDisabled",
				"disabled",
				"cdkMenuItemChecked",
				"checked"
			],
			outputs: ["cdkMenuItemTriggered", "invoked"]
		}, {
			directive: i2.TuiOption,
			inputs: ["disabled", "disabled"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeMenuRadioItem,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[atrMenuRadioItem]",
			standalone: true,
			hostDirectives: [{
				directive: CdkMenuItemRadio,
				inputs: ["cdkMenuItemDisabled:disabled", "cdkMenuItemChecked:checked"],
				outputs: ["cdkMenuItemTriggered:invoked"]
			}, {
				directive: TuiOption,
				inputs: ["disabled"]
			}],
			host: {
				class: "atr-menu-item",
				"[attr.tuiOption]": "\"\""
			}
		}]
	}]
});
var AtralumeMenuSeparator = class AtralumeMenuSeparator {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeMenuSeparator,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeMenuSeparator,
		isStandalone: true,
		selector: "[atrMenuSeparator]",
		host: {
			attributes: { "role": "separator" },
			classAttribute: "atr-menu-separator"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeMenuSeparator,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrMenuSeparator]",
			standalone: true,
			host: {
				class: "atr-menu-separator",
				role: "separator"
			}
		}]
	}]
});
const MENU_ORIGIN = new InjectionToken("Atralume menu origin");
var AtralumeMenuTrigger = class AtralumeMenuTrigger {
	trigger = inject(CdkMenuTrigger);
	engine = inject(ɵAtralumeOverlayInfrastructure);
	element = inject(ElementRef).nativeElement;
	constructor() {
		this.trigger.opened.pipe(takeUntilDestroyed()).subscribe(() => {
			queueMicrotask(() => {
				if (!this.trigger.isOpen()) return;
				const menu = this.trigger.getMenu();
				if (!menu) return;
				const panel = menu.nativeElement;
				this.engine.decorate(panel, this.element, "menu");
				panel.style.setProperty("--atr-menu-trigger-width", `${Math.ceil(this.element.getBoundingClientRect().width)}px`);
			});
		});
		inject(DestroyRef).onDestroy(() => this.trigger.close());
	}
	open() {
		if (this.engine.browser) this.trigger.open();
	}
	close() {
		this.trigger.close();
	}
	isOpen() {
		return this.trigger.isOpen();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeMenuTrigger,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeMenuTrigger,
		isStandalone: true,
		selector: "[atrMenuTriggerFor]",
		host: { classAttribute: "atr-menu-trigger" },
		providers: [{
			provide: MENU_ORIGIN,
			useFactory: () => inject(ElementRef).nativeElement
		}],
		exportAs: ["atrMenuTrigger"],
		hostDirectives: [{
			directive: i1.CdkMenuTrigger,
			inputs: ["cdkMenuTriggerFor", "atrMenuTriggerFor"]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeMenuTrigger,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrMenuTriggerFor]",
			standalone: true,
			exportAs: "atrMenuTrigger",
			providers: [{
				provide: MENU_ORIGIN,
				useFactory: () => inject(ElementRef).nativeElement
			}],
			hostDirectives: [{
				directive: CdkMenuTrigger,
				inputs: ["cdkMenuTriggerFor:atrMenuTriggerFor"]
			}],
			host: { class: "atr-menu-trigger" }
		}]
	}],
	ctorParameters: () => []
});
var AtralumeMenu = class AtralumeMenu {
	menu = inject(CdkMenu);
	engine = inject(ɵAtralumeOverlayInfrastructure);
	element = inject(ElementRef).nativeElement;
	constructor() {
		const origin = inject(MENU_ORIGIN, { optional: true });
		this.engine.decorate(this.element, origin ?? void 0, "menu");
		const release = this.engine.registerDismissal(this.element, () => this.menu.menuStack.close(this.menu, {
			focusNextOnEmpty: FocusNext.currentItem,
			focusParentTrigger: true
		}));
		inject(DestroyRef).onDestroy(release);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeMenu,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeMenu,
		isStandalone: true,
		selector: "[atrMenu]",
		host: {
			attributes: { "role": "menu" },
			classAttribute: "atr-menu"
		},
		hostDirectives: [{ directive: i1.CdkMenu }],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeMenu,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrMenu]",
			standalone: true,
			hostDirectives: [CdkMenu],
			host: {
				class: "atr-menu",
				role: "menu"
			}
		}]
	}],
	ctorParameters: () => []
});
var AtralumeMenuHarness = class extends ComponentHarness {
	static hostSelector = ".atr-menu";
	async getText() {
		return (await this.host()).text();
	}
	async getAccessibleName() {
		return (await this.host()).getAttribute("aria-label");
	}
	async pressEscape() {
		await (await this.host()).sendKeys(TestKey.ESCAPE);
	}
};
var AtralumeMenuItemHarness = class extends ComponentHarness {
	static hostSelector = ".atr-menu-item[role=\"menuitem\"]";
	async getText() {
		return (await this.host()).text();
	}
	async click() {
		await (await this.host()).click();
	}
	async isDisabled() {
		return await (await this.host()).getAttribute("aria-disabled") === "true";
	}
	async isChecked() {
		return await (await this.host()).getAttribute("aria-checked") === "true";
	}
};
var AtralumeMenuCheckboxItemHarness = class extends ComponentHarness {
	static hostSelector = ".atr-menu-item[role=\"menuitemcheckbox\"]";
	async getText() {
		return (await this.host()).text();
	}
	async click() {
		await (await this.host()).click();
	}
	async isDisabled() {
		return await (await this.host()).getAttribute("aria-disabled") === "true";
	}
	async isChecked() {
		return await (await this.host()).getAttribute("aria-checked") === "true";
	}
};
var AtralumeMenuRadioItemHarness = class extends ComponentHarness {
	static hostSelector = ".atr-menu-item[role=\"menuitemradio\"]";
	async getText() {
		return (await this.host()).text();
	}
	async click() {
		await (await this.host()).click();
	}
	async isDisabled() {
		return await (await this.host()).getAttribute("aria-disabled") === "true";
	}
	async isChecked() {
		return await (await this.host()).getAttribute("aria-checked") === "true";
	}
};
var AtralumeMenuTriggerHarness = class extends ComponentHarness {
	static hostSelector = ".atr-menu-trigger";
	async getText() {
		return (await this.host()).text();
	}
	async click() {
		await (await this.host()).click();
	}
	async isDisabled() {
		return await (await this.host()).getAttribute("aria-disabled") === "true";
	}
	async isChecked() {
		return await (await this.host()).getAttribute("aria-checked") === "true";
	}
};
var AtralumeMenuGroupHarness = class extends ComponentHarness {
	static hostSelector = ".atr-menu-group";
	async getText() {
		return (await this.host()).text();
	}
	async click() {
		await (await this.host()).click();
	}
	async isDisabled() {
		return await (await this.host()).getAttribute("aria-disabled") === "true";
	}
	async isChecked() {
		return await (await this.host()).getAttribute("aria-checked") === "true";
	}
};
var AtralumeMenuSeparatorHarness = class extends ComponentHarness {
	static hostSelector = ".atr-menu-separator";
	async getText() {
		return (await this.host()).text();
	}
	async click() {
		await (await this.host()).click();
	}
	async isDisabled() {
		return await (await this.host()).getAttribute("aria-disabled") === "true";
	}
	async isChecked() {
		return await (await this.host()).getAttribute("aria-checked") === "true";
	}
};
export { AtralumeMenu, AtralumeMenuCheckboxItem, AtralumeMenuCheckboxItemHarness, AtralumeMenuGroup, AtralumeMenuGroupHarness, AtralumeMenuHarness, AtralumeMenuItem, AtralumeMenuItemHarness, AtralumeMenuRadioItem, AtralumeMenuRadioItemHarness, AtralumeMenuSeparator, AtralumeMenuSeparatorHarness, AtralumeMenuTrigger, AtralumeMenuTriggerHarness };

//# sourceMappingURL=osmanjimenez-atralume-menu.mjs.map