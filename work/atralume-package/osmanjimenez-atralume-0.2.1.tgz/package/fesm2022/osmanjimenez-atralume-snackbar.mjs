import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, Injectable, InjectionToken, Injector, inject } from "@angular/core";
import { ReplaySubject } from "rxjs";
import { TuiNotificationService } from "@taiga-ui/core";
import { PolymorpheusComponent } from "@taiga-ui/polymorpheus";
import { AtralumeButton } from "@osmanjimenez/atralume/button";
import { AtralumeIconButton } from "@osmanjimenez/atralume/icon-button";
import { AtralumeIcon, closeIcon, provideAtralumeIcons } from "@osmanjimenez/atralume/icon";
import { ComponentHarness, TestKey } from "@angular/cdk/testing";
var AtralumeSnackbarRef = class {
	afterClosed;
	closeFn;
	constructor(afterClosed, closeFn) {
		this.afterClosed = afterClosed;
		this.closeFn = closeFn;
	}
	dismiss() {
		this.closeFn("dismiss");
	}
	action() {
		this.closeFn("action");
	}
};
const SNACKBAR_SESSION = new InjectionToken("Atralume snackbar session");
var AtralumeSnackbarPanel = class AtralumeSnackbarPanel {
	session = inject(SNACKBAR_SESSION);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeSnackbarPanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeSnackbarPanel,
		isStandalone: true,
		selector: "atr-snackbar-panel",
		host: {
			listeners: {
				"pointerenter": "session.pause(\"hover\")",
				"pointerleave": "session.resume(\"hover\")",
				"focusin": "session.pause(\"focus\")",
				"focusout": "session.resume(\"focus\")"
			},
			properties: { "attr.data-tone": "session.config.tone ?? \"neutral\"" },
			classAttribute: "atr-snackbar-panel"
		},
		providers: [provideAtralumeIcons([closeIcon])],
		ngImport: i0,
		template: "<span role=\"status\" aria-live=\"polite\" aria-atomic=\"true\">{{\n  session.config.message\n}}</span>\n@if (session.config.action) {\n  <button\n    atrButton\n    appearance=\"text\"\n    type=\"button\"\n    (click)=\"session.ref.action()\"\n  >\n    {{ session.config.action }}\n  </button>\n}\n@if (session.config.dismissLabel) {\n  <button\n    atrIconButton\n    type=\"button\"\n    [attr.aria-label]=\"session.config.dismissLabel\"\n    (click)=\"session.ref.dismiss()\"\n  >\n    <atr-icon name=\"close\" />\n  </button>\n}\n",
		styles: [":host{--atr-comp-button-text-label-color: currentcolor;--atr-comp-button-focus-ring-color: currentcolor;--atr-comp-icon-button-icon-color: currentcolor;--atr-comp-icon-button-focus-ring-color: currentcolor;display:flex;align-items:center;flex-wrap:nowrap;gap:var(--atr-comp-snackbar-gap);max-inline-size:min(var(--atr-comp-snackbar-max-width),100vw - 2rem);min-block-size:var(--atr-sys-touch-target-minimum);padding-block:var(--atr-sys-spacing-sm);padding-inline:var(--atr-comp-snackbar-padding);border:var(--atr-ref-border-width-thin) solid var(--atr-comp-snackbar-border-color);border-radius:var(--atr-comp-snackbar-shape);background:var(--atr-comp-snackbar-container-color);color:var(--atr-comp-snackbar-label-color);font-family:var(--atr-comp-snackbar-font-family);box-shadow:var(--atr-comp-snackbar-elevation)}:host>[role=status]{flex:1 1 auto;min-inline-size:0}@media(forced-colors:active){:host{border:var(--atr-ref-border-width-thin) solid CanvasText}}:host([data-tone=success]){background:var(--atr-comp-snackbar-success-container-color, var(--atr-sys-color-success-container));color:var(--atr-comp-snackbar-success-label-color, var(--atr-sys-color-on-success-container))}:host([data-tone=info]){background:var(--atr-comp-snackbar-info-container-color, var(--atr-sys-color-info-container));color:var(--atr-comp-snackbar-info-label-color, var(--atr-sys-color-on-info-container))}:host([data-tone=warning]){background:var(--atr-comp-snackbar-warning-container-color, var(--atr-sys-color-warning-container));color:var(--atr-comp-snackbar-warning-label-color, var(--atr-sys-color-on-warning-container))}:host([data-tone=error]){background:var(--atr-comp-snackbar-error-container-color, var(--atr-sys-color-error-container));color:var(--atr-comp-snackbar-error-label-color, var(--atr-sys-color-on-error-container))}\n"],
		dependencies: [
			{
				kind: "component",
				type: AtralumeButton,
				selector: "button[atrButton], a[atrButton]",
				inputs: [
					"appearance",
					"size",
					"disabled",
					"loading",
					"fullWidth",
					"tabindex"
				]
			},
			{
				kind: "directive",
				type: AtralumeIconButton,
				selector: "button[atrIconButton]",
				inputs: ["appearance", "size"]
			},
			{
				kind: "component",
				type: AtralumeIcon,
				selector: "atr-icon",
				inputs: [
					"name",
					"size",
					"decorative",
					"label",
					"engine"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeSnackbarPanel,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-snackbar-panel",
			standalone: true,
			imports: [
				AtralumeButton,
				AtralumeIconButton,
				AtralumeIcon
			],
			providers: [provideAtralumeIcons([closeIcon])],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "atr-snackbar-panel",
				"(pointerenter)": "session.pause(\"hover\")",
				"(pointerleave)": "session.resume(\"hover\")",
				"(focusin)": "session.pause(\"focus\")",
				"(focusout)": "session.resume(\"focus\")",
				"[attr.data-tone]": "session.config.tone ?? \"neutral\""
			},
			template: "<span role=\"status\" aria-live=\"polite\" aria-atomic=\"true\">{{\n  session.config.message\n}}</span>\n@if (session.config.action) {\n  <button\n    atrButton\n    appearance=\"text\"\n    type=\"button\"\n    (click)=\"session.ref.action()\"\n  >\n    {{ session.config.action }}\n  </button>\n}\n@if (session.config.dismissLabel) {\n  <button\n    atrIconButton\n    type=\"button\"\n    [attr.aria-label]=\"session.config.dismissLabel\"\n    (click)=\"session.ref.dismiss()\"\n  >\n    <atr-icon name=\"close\" />\n  </button>\n}\n",
			styles: [":host{--atr-comp-button-text-label-color: currentcolor;--atr-comp-button-focus-ring-color: currentcolor;--atr-comp-icon-button-icon-color: currentcolor;--atr-comp-icon-button-focus-ring-color: currentcolor;display:flex;align-items:center;flex-wrap:nowrap;gap:var(--atr-comp-snackbar-gap);max-inline-size:min(var(--atr-comp-snackbar-max-width),100vw - 2rem);min-block-size:var(--atr-sys-touch-target-minimum);padding-block:var(--atr-sys-spacing-sm);padding-inline:var(--atr-comp-snackbar-padding);border:var(--atr-ref-border-width-thin) solid var(--atr-comp-snackbar-border-color);border-radius:var(--atr-comp-snackbar-shape);background:var(--atr-comp-snackbar-container-color);color:var(--atr-comp-snackbar-label-color);font-family:var(--atr-comp-snackbar-font-family);box-shadow:var(--atr-comp-snackbar-elevation)}:host>[role=status]{flex:1 1 auto;min-inline-size:0}@media(forced-colors:active){:host{border:var(--atr-ref-border-width-thin) solid CanvasText}}:host([data-tone=success]){background:var(--atr-comp-snackbar-success-container-color, var(--atr-sys-color-success-container));color:var(--atr-comp-snackbar-success-label-color, var(--atr-sys-color-on-success-container))}:host([data-tone=info]){background:var(--atr-comp-snackbar-info-container-color, var(--atr-sys-color-info-container));color:var(--atr-comp-snackbar-info-label-color, var(--atr-sys-color-on-info-container))}:host([data-tone=warning]){background:var(--atr-comp-snackbar-warning-container-color, var(--atr-sys-color-warning-container));color:var(--atr-comp-snackbar-warning-label-color, var(--atr-sys-color-on-warning-container))}:host([data-tone=error]){background:var(--atr-comp-snackbar-error-container-color, var(--atr-sys-color-error-container));color:var(--atr-comp-snackbar-error-label-color, var(--atr-sys-color-on-error-container))}\n"]
		}]
	}]
});
const TONE_APPEARANCE = {
	neutral: "neutral",
	success: "positive",
	info: "info",
	warning: "warning",
	error: "negative"
};
var AtralumeSnackbar = class AtralumeSnackbar {
	notifications = inject(TuiNotificationService);
	injector = inject(Injector);
	destroy = inject(DestroyRef);
	queue = [];
	current;
	constructor() {
		this.destroy.onDestroy(() => {
			const entries = [...this.queue, ...this.current ? [this.current] : []];
			this.queue = [];
			this.current = void 0;
			for (const entry of entries) this.finish(entry, "dismiss");
		});
	}
	open(config) {
		if (!config.message.trim()) throw new Error("Snackbar requires a message.");
		const result = new ReplaySubject(1);
		const entry = {
			config,
			result,
			ref: new AtralumeSnackbarRef(result.asObservable(), (reason) => this.finish(entry, reason)),
			finished: false
		};
		if (config.owner) entry.unregister = config.owner.onDestroy(() => this.finish(entry, "dismiss"));
		if (this.current) {
			if (config.policy === "ignore") {
				this.finish(entry, "replaced");
				return entry.ref;
			}
			if (config.policy === "replace") {
				this.queue.unshift(entry);
				this.finish(this.current, "replaced");
				return entry.ref;
			}
			this.queue.push(entry);
		} else this.show(entry);
		return entry.ref;
	}
	dismiss() {
		if (this.current) this.finish(this.current, "dismiss");
	}
	show(entry) {
		this.current = entry;
		const tone = entry.config.tone ?? "neutral";
		const session = {
			config: entry.config,
			ref: entry.ref,
			pause: () => void 0,
			resume: () => void 0
		};
		const contentInjector = Injector.create({
			parent: this.injector,
			providers: [{
				provide: SNACKBAR_SESSION,
				useValue: session
			}]
		});
		const content = new PolymorpheusComponent(AtralumeSnackbarPanel, contentInjector);
		entry.subscription = this.notifications.open(content, {
			appearance: TONE_APPEARANCE[tone],
			autoClose: entry.config.duration ?? 5e3,
			closable: false,
			label: "",
			icon: ""
		}).subscribe({
			complete: () => {
				if (!entry.finished) this.finish(entry, "timeout");
			},
			error: () => {
				if (!entry.finished) this.finish(entry, "dismiss");
			}
		});
	}
	finish(entry, reason) {
		if (entry.finished) return;
		entry.finished = true;
		entry.unregister?.();
		entry.subscription?.unsubscribe();
		entry.subscription = void 0;
		entry.result.next(reason);
		entry.result.complete();
		this.queue = this.queue.filter((item) => item !== entry);
		if (this.current === entry) {
			this.current = void 0;
			const next = this.queue.shift();
			if (next) this.show(next);
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeSnackbar,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeSnackbar,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeSnackbar,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
var AtralumeSnackbarHarness = class extends ComponentHarness {
	static hostSelector = "atr-snackbar-panel";
	async getText() {
		return (await this.host()).text();
	}
	async getAccessibleName() {
		return (await this.host()).getAttribute("aria-label");
	}
	async pressEscape() {
		await (await this.host()).sendKeys(TestKey.ESCAPE);
	}
};
export { AtralumeSnackbar, AtralumeSnackbarHarness, AtralumeSnackbarRef };

//# sourceMappingURL=osmanjimenez-atralume-snackbar.mjs.map