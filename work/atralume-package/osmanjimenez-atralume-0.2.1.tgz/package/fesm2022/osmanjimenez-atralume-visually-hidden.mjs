import * as i0 from "@angular/core";
import { Directive, booleanAttribute, input } from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeVisuallyHidden = class AtralumeVisuallyHidden {
	focusable = input(false, {
		...ngDevMode ? { debugName: "focusable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeVisuallyHidden,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeVisuallyHidden,
		isStandalone: true,
		selector: "[atrVisuallyHidden]",
		inputs: { focusable: {
			classPropertyName: "focusable",
			publicName: "focusable",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			properties: { "class.atr-visually-hidden--focusable": "focusable()" },
			classAttribute: "atr-visually-hidden"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeVisuallyHidden,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrVisuallyHidden]",
			standalone: true,
			host: {
				class: "atr-visually-hidden",
				"[class.atr-visually-hidden--focusable]": "focusable()"
			}
		}]
	}],
	propDecorators: { focusable: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "focusable",
			required: false
		}]
	}] }
});
var AtralumeVisuallyHiddenHarness = class extends ComponentHarness {
	static hostSelector = ".atr-visually-hidden";
	async isFocusableVariant() {
		return (await this.host()).hasClass("atr-visually-hidden--focusable");
	}
	async getText() {
		return (await this.host()).text();
	}
};
export { AtralumeVisuallyHidden, AtralumeVisuallyHiddenHarness };

//# sourceMappingURL=osmanjimenez-atralume-visually-hidden.mjs.map