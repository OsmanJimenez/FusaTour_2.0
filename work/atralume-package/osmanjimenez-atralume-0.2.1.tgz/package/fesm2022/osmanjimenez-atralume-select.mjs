import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, Directive, booleanAttribute, computed, effect, forwardRef, inject, input, untracked } from "@angular/core";
import * as i1 from "@angular/forms";
import { FormControl, NG_VALUE_ACCESSOR, ReactiveFormsModule } from "@angular/forms";
import * as i1$1 from "@taiga-ui/kit";
import { TuiDataListWrapper, TuiSelect, TuiSelectDirective } from "@taiga-ui/kit";
import { TuiChevron } from "@taiga-ui/kit/directives/chevron";
import { AtralumeFormField } from "@osmanjimenez/atralume/form-field";
import { ɵAtralumeValueControl } from "@osmanjimenez/atralume/internal/forms";
import * as i2 from "@taiga-ui/core/components/label";
import * as i3 from "@taiga-ui/core/components/textfield";
import * as i4 from "@taiga-ui/core/portals/dropdown";
import { AtralumeComboboxHarness } from "@osmanjimenez/atralume/combobox";
var AtralumeSelectDirective = class AtralumeSelectDirective {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeSelectDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeSelectDirective,
		isStandalone: true,
		selector: "input[atrSelect]",
		host: {
			properties: { "attr.tuiSelect": "\"\"" },
			classAttribute: "atr-select-input"
		},
		hostDirectives: [{ directive: i1$1.TuiSelectDirective }],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeSelectDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "input[atrSelect]",
			standalone: true,
			hostDirectives: [TuiSelectDirective],
			host: {
				class: "atr-select-input",
				"[attr.tuiSelect]": "\"\""
			}
		}]
	}]
});
var AtralumeSelect = class AtralumeSelect extends ɵAtralumeValueControl {
	options = input([], ...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	placeholder = input("Choose an option", ...ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []);
	clearable = input(false, {
		...ngDevMode ? { debugName: "clearable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	emptyText = input("No results", ...ngDevMode ? [{ debugName: "emptyText" }] : /* istanbul ignore next */ []);
	compareWith = input(Object.is, ...ngDevMode ? [{ debugName: "compareWith" }] : /* istanbul ignore next */ []);
	displayWith = input(null, ...ngDevMode ? [{ debugName: "displayWith" }] : /* istanbul ignore next */ []);
	items = computed(() => this.options().map((option) => option.value), ...ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []);
	stringify = computed(() => {
		const display = this.displayWith();
		const options = this.options();
		return (value) => display?.(value) ?? options.find((option) => this.compareWith()(option.value, value))?.label ?? String(value ?? "");
	}, ...ngDevMode ? [{ debugName: "stringify" }] : /* istanbul ignore next */ []);
	identityMatcher = computed(() => (a, b) => this.compareWith()(a, b), ...ngDevMode ? [{ debugName: "identityMatcher" }] : /* istanbul ignore next */ []);
	disabledItemHandler = computed(() => {
		const options = this.options();
		const compare = this.compareWith();
		return (value) => !!options.find((option) => compare(option.value, value))?.disabled;
	}, ...ngDevMode ? [{ debugName: "disabledItemHandler" }] : /* istanbul ignore next */ []);
	inner = new FormControl(null);
	constructor() {
		super();
		const destroyRef = inject(DestroyRef);
		const sub = this.inner.valueChanges.subscribe((value) => this.commit(value));
		destroyRef.onDestroy(() => sub.unsubscribe());
		effect(() => {
			const next = this.value();
			untracked(() => {
				if (!Object.is(this.inner.value, next)) this.inner.setValue(next);
			});
		});
		effect(() => {
			if (this.blocked()) this.inner.disable({ emitEvent: false });
			else this.inner.enable({ emitEvent: false });
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeSelect,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeSelect,
		isStandalone: true,
		selector: "atr-select",
		inputs: {
			options: {
				classPropertyName: "options",
				publicName: "options",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			clearable: {
				classPropertyName: "clearable",
				publicName: "clearable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			emptyText: {
				classPropertyName: "emptyText",
				publicName: "emptyText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			compareWith: {
				classPropertyName: "compareWith",
				publicName: "compareWith",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			displayWith: {
				classPropertyName: "displayWith",
				publicName: "displayWith",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "atr-select" },
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => AtralumeSelect),
			multi: true
		}],
		usesInheritance: true,
		ngImport: i0,
		template: "<atr-form-field [hint]=\"hint()\" [error]=\"error()\">\n  <tui-textfield\n    tuiChevron\n    [invalid]=\"displayInvalid()\"\n    [stringify]=\"stringify()\"\n    [identityMatcher]=\"identityMatcher()\"\n    [disabledItemHandler]=\"disabledItemHandler()\"\n    [tuiTextfieldCleaner]=\"clearable()\"\n    tuiTextfieldSize=\"m\"\n  >\n    <label tuiLabel [attr.for]=\"controlId()\">\n      {{ label() }}\n      @if (required()) {\n        *\n      }\n    </label>\n    <input\n      atrSelect\n      [id]=\"controlId()\"\n      [placeholder]=\"placeholder()\"\n      [readOnly]=\"readonly()\"\n      [formControl]=\"inner\"\n    />\n    <ng-template tuiDropdown>\n      <tui-data-list-wrapper [items]=\"items()\" [emptyContent]=\"emptyText()\" />\n    </ng-template>\n  </tui-textfield>\n</atr-form-field>\n",
		styles: [":host{display:block}\n"],
		dependencies: [
			{
				kind: "ngmodule",
				type: ReactiveFormsModule
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.FormControlDirective,
				selector: "[formControl]",
				inputs: [
					"formControl",
					"disabled",
					"ngModel"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngForm"]
			},
			{
				kind: "component",
				type: AtralumeFormField,
				selector: "atr-form-field",
				inputs: [
					"hint",
					"error",
					"appearance",
					"density",
					"label",
					"required",
					"optional",
					"optionalText"
				]
			},
			{
				kind: "directive",
				type: i2.TuiLabel,
				selector: "label[tuiLabel]"
			},
			{
				kind: "component",
				type: i3.TuiTextfieldComponent,
				selector: "tui-textfield:not([multi])",
				inputs: [
					"content",
					"filler",
					"invalid",
					"tuiAppearanceFocus",
					"tuiAppearanceState"
				]
			},
			{
				kind: "directive",
				type: i3.TuiTextfieldOptionsDirective,
				selector: "[tuiTextfieldAppearance],[tuiTextfieldSize],[tuiTextfieldCleaner]",
				inputs: [
					"tuiTextfieldAppearance",
					"tuiTextfieldSize",
					"tuiTextfieldCleaner"
				]
			},
			{
				kind: "directive",
				type: i4.TuiDropdownContent,
				selector: "ng-template[tuiDropdown]"
			},
			{
				kind: "directive",
				type: TuiChevron,
				selector: "[tuiChevron]",
				inputs: ["tuiChevron"]
			},
			{
				kind: "component",
				type: i1$1.TuiDataListWrapperComponent,
				selector: "tui-data-list-wrapper:not([labels])",
				inputs: [
					"items",
					"emptyContent",
					"size",
					"itemContent"
				],
				outputs: ["itemClick"]
			},
			{
				kind: "directive",
				type: AtralumeSelectDirective,
				selector: "input[atrSelect]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeSelect,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-select",
			standalone: true,
			imports: [
				ReactiveFormsModule,
				AtralumeFormField,
				TuiSelect,
				TuiChevron,
				TuiDataListWrapper,
				AtralumeSelectDirective
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => AtralumeSelect),
				multi: true
			}],
			host: { class: "atr-select" },
			template: "<atr-form-field [hint]=\"hint()\" [error]=\"error()\">\n  <tui-textfield\n    tuiChevron\n    [invalid]=\"displayInvalid()\"\n    [stringify]=\"stringify()\"\n    [identityMatcher]=\"identityMatcher()\"\n    [disabledItemHandler]=\"disabledItemHandler()\"\n    [tuiTextfieldCleaner]=\"clearable()\"\n    tuiTextfieldSize=\"m\"\n  >\n    <label tuiLabel [attr.for]=\"controlId()\">\n      {{ label() }}\n      @if (required()) {\n        *\n      }\n    </label>\n    <input\n      atrSelect\n      [id]=\"controlId()\"\n      [placeholder]=\"placeholder()\"\n      [readOnly]=\"readonly()\"\n      [formControl]=\"inner\"\n    />\n    <ng-template tuiDropdown>\n      <tui-data-list-wrapper [items]=\"items()\" [emptyContent]=\"emptyText()\" />\n    </ng-template>\n  </tui-textfield>\n</atr-form-field>\n",
			styles: [":host{display:block}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		clearable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "clearable",
				required: false
			}]
		}],
		emptyText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "emptyText",
				required: false
			}]
		}],
		compareWith: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "compareWith",
				required: false
			}]
		}],
		displayWith: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "displayWith",
				required: false
			}]
		}]
	}
});
var AtralumeSelectHarness = class extends AtralumeComboboxHarness {
	static hostSelector = "atr-select";
};
export { AtralumeSelect, AtralumeSelectDirective, AtralumeSelectHarness };

//# sourceMappingURL=osmanjimenez-atralume-select.mjs.map