import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, booleanAttribute, input, model, output, viewChild } from "@angular/core";
import * as i1 from "@taiga-ui/kit";
import { TuiTree } from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeTree = class AtralumeTree {
	label = input("Tree", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	nodes = input([], ...ngDevMode ? [{ debugName: "nodes" }] : /* istanbul ignore next */ []);
	selectionMode = input("single", ...ngDevMode ? [{ debugName: "selectionMode" }] : /* istanbul ignore next */ []);
	selected = model([], ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	expanded = model([], ...ngDevMode ? [{ debugName: "expanded" }] : /* istanbul ignore next */ []);
	compareWith = input(Object.is, ...ngDevMode ? [{ debugName: "compareWith" }] : /* istanbul ignore next */ []);
	selectionChange = output();
	expansionChange = output();
	expandAll = input(true, {
		...ngDevMode ? { debugName: "expandAll" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	content = viewChild.required("node", ...ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []);
	childrenOf = (item) => {
		if (!this.isNode(item)) return item;
		return item.children ?? [];
	};
	isNode(item) {
		return !Array.isArray(item) && typeof item === "object" && item !== null;
	}
	isSelected(node) {
		return this.selected().some((value) => this.compareWith()(node.value, value));
	}
	select(node, event) {
		event.stopPropagation();
		if (node.disabled) return;
		const exists = this.isSelected(node);
		const selected = this.selectionMode() === "single" ? exists ? [] : [node.value] : exists ? this.selected().filter((value) => !this.compareWith()(value, node.value)) : [...this.selected(), node.value];
		this.selected.set(selected);
		this.selectionChange.emit(selected);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeTree,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeTree,
		isStandalone: true,
		selector: "atr-tree",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			nodes: {
				classPropertyName: "nodes",
				publicName: "nodes",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selectionMode: {
				classPropertyName: "selectionMode",
				publicName: "selectionMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selected: {
				classPropertyName: "selected",
				publicName: "selected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			expanded: {
				classPropertyName: "expanded",
				publicName: "expanded",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			compareWith: {
				classPropertyName: "compareWith",
				publicName: "compareWith",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			expandAll: {
				classPropertyName: "expandAll",
				publicName: "expandAll",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			selected: "selectedChange",
			expanded: "expandedChange",
			selectionChange: "selectionChange",
			expansionChange: "expansionChange"
		},
		host: { classAttribute: "atr-tree" },
		viewQueries: [{
			propertyName: "content",
			first: true,
			predicate: ["node"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<div [attr.aria-label]=\"label()\" role=\"presentation\">\n  <tui-tree\n    [value]=\"nodes()\"\n    [childrenHandler]=\"childrenOf\"\n    [content]=\"content()\"\n    [tuiTreeController]=\"expandAll()\"\n  />\n</div>\n<ng-template #node let-item>\n  @if (isNode(item)) {\n    <button\n      type=\"button\"\n      class=\"atr-tree__label\"\n      [class.atr-tree__label--selected]=\"isSelected(item)\"\n      [disabled]=\"item.disabled || null\"\n      (click)=\"select(item, $event)\"\n    >\n      {{ item.label }}\n      @if (item.loading) {\n        <span role=\"status\" aria-label=\"Loading children\">…</span>\n      }\n    </button>\n  }\n</ng-template>\n",
		styles: [":host{display:block;font-family:var(--atr-comp-tree-font-family, inherit);color:var(--atr-comp-tree-label-color, inherit)}.atr-tree__label{appearance:none;display:inline-flex;align-items:center;min-block-size:var(--atr-sys-touch-target-minimum);border:0;background:transparent;color:inherit;font:inherit;cursor:pointer;padding:var(--atr-sys-spacing-xs) var(--atr-sys-spacing-sm);border-radius:var(--atr-comp-tree-shape);text-align:start}:host ::ng-deep button.t-button,:host ::ng-deep [tuiTreeController] button,:host ::ng-deep tui-tree button.t-button{min-inline-size:var(--atr-sys-touch-target-minimum);min-block-size:var(--atr-sys-touch-target-minimum)}.atr-tree__label--selected{background:var(--atr-comp-tree-selected-container-color);color:var(--atr-comp-tree-selected-label-color)}.atr-tree__label:disabled{opacity:var(--atr-sys-state-disabled-content-opacity);cursor:default}\n"],
		dependencies: [
			{
				kind: "component",
				type: i1.TuiTreeComponent,
				selector: "tui-tree",
				inputs: [
					"value",
					"trackBy",
					"content"
				]
			},
			{
				kind: "directive",
				type: i1.TuiTreeChildren,
				selector: "tui-tree[childrenHandler]",
				inputs: ["childrenHandler"]
			},
			{
				kind: "directive",
				type: i1.TuiTreeItemController,
				selector: "[tuiTreeController]:not([map])",
				inputs: ["tuiTreeController"],
				exportAs: ["tuiTreeController"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeTree,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-tree",
			standalone: true,
			imports: [TuiTree],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "atr-tree" },
			template: "<div [attr.aria-label]=\"label()\" role=\"presentation\">\n  <tui-tree\n    [value]=\"nodes()\"\n    [childrenHandler]=\"childrenOf\"\n    [content]=\"content()\"\n    [tuiTreeController]=\"expandAll()\"\n  />\n</div>\n<ng-template #node let-item>\n  @if (isNode(item)) {\n    <button\n      type=\"button\"\n      class=\"atr-tree__label\"\n      [class.atr-tree__label--selected]=\"isSelected(item)\"\n      [disabled]=\"item.disabled || null\"\n      (click)=\"select(item, $event)\"\n    >\n      {{ item.label }}\n      @if (item.loading) {\n        <span role=\"status\" aria-label=\"Loading children\">…</span>\n      }\n    </button>\n  }\n</ng-template>\n",
			styles: [":host{display:block;font-family:var(--atr-comp-tree-font-family, inherit);color:var(--atr-comp-tree-label-color, inherit)}.atr-tree__label{appearance:none;display:inline-flex;align-items:center;min-block-size:var(--atr-sys-touch-target-minimum);border:0;background:transparent;color:inherit;font:inherit;cursor:pointer;padding:var(--atr-sys-spacing-xs) var(--atr-sys-spacing-sm);border-radius:var(--atr-comp-tree-shape);text-align:start}:host ::ng-deep button.t-button,:host ::ng-deep [tuiTreeController] button,:host ::ng-deep tui-tree button.t-button{min-inline-size:var(--atr-sys-touch-target-minimum);min-block-size:var(--atr-sys-touch-target-minimum)}.atr-tree__label--selected{background:var(--atr-comp-tree-selected-container-color);color:var(--atr-comp-tree-selected-label-color)}.atr-tree__label:disabled{opacity:var(--atr-sys-state-disabled-content-opacity);cursor:default}\n"]
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		nodes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "nodes",
				required: false
			}]
		}],
		selectionMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectionMode",
				required: false
			}]
		}],
		selected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selected",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["selectedChange"]
		}],
		expanded: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "expanded",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["expandedChange"]
		}],
		compareWith: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "compareWith",
				required: false
			}]
		}],
		selectionChange: [{
			type: i0.Output,
			args: ["selectionChange"]
		}],
		expansionChange: [{
			type: i0.Output,
			args: ["expansionChange"]
		}],
		expandAll: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "expandAll",
				required: false
			}]
		}],
		content: [{
			type: i0.ViewChild,
			args: ["node", { isSignal: true }]
		}]
	}
});
var AtralumeTreeHarness = class extends ComponentHarness {
	static hostSelector = "atr-tree";
	async getNodes() {
		return Promise.all((await this.locatorForAll("[role=\"treeitem\"]")()).map((node) => node.text()));
	}
	async expand(name) {
		await (await this.locatorFor(`button[aria-label="Expand ${name}"]`)()).click();
	}
	async collapse(name) {
		await (await this.locatorFor(`button[aria-label="Collapse ${name}"]`)()).click();
	}
	async select(name) {
		await (await this.locatorFor(`[role="treeitem"][aria-label="${name}"]`)()).click();
	}
};
export { AtralumeTree, AtralumeTreeHarness };

//# sourceMappingURL=osmanjimenez-atralume-tree.mjs.map