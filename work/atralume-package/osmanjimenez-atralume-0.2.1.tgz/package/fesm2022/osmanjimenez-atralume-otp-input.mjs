import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, computed, effect, forwardRef, inject, input, untracked } from "@angular/core";
import * as i1 from "@angular/forms";
import { FormControl, NG_VALIDATORS, NG_VALUE_ACCESSOR, ReactiveFormsModule } from "@angular/forms";
import * as i2 from "@taiga-ui/kit";
import { TuiInputPin } from "@taiga-ui/kit";
import { AtralumeFormField } from "@osmanjimenez/atralume/form-field";
import { ɵAtralumeValueControl } from "@osmanjimenez/atralume/internal/forms";
import * as i3 from "@taiga-ui/core/components/label";
import * as i4 from "@taiga-ui/core/components/textfield";
import { ComponentHarness } from "@angular/cdk/testing";
function toInner(value) {
	return value ?? "";
}
function fromInner(value) {
	return value ? value : null;
}
var AtralumeOtpInput = class AtralumeOtpInput extends ɵAtralumeValueControl {
	length = input(4, {
		...ngDevMode ? { debugName: "length" } : /* istanbul ignore next */ {},
		transform: (value) => value ?? 4
	});
	placeholderMask = computed(() => "·".repeat(Math.max(0, this.length())), ...ngDevMode ? [{ debugName: "placeholderMask" }] : /* istanbul ignore next */ []);
	inner = new FormControl("", { nonNullable: true });
	validatorChanged = () => void 0;
	constructor() {
		super();
		const destroyRef = inject(DestroyRef);
		const sub = this.inner.valueChanges.subscribe((value) => {
			this.commit(fromInner(value));
		});
		destroyRef.onDestroy(() => sub.unsubscribe());
		effect(() => {
			const next = toInner(this.value());
			untracked(() => {
				if (this.inner.value !== next) this.inner.setValue(next, { emitEvent: false });
			});
		});
		effect(() => {
			const blocked = this.blocked();
			untracked(() => {
				if (blocked) this.inner.disable({ emitEvent: false });
				else this.inner.enable({ emitEvent: false });
			});
		});
		effect(() => {
			this.value();
			this.length();
			this.required();
			untracked(() => this.validatorChanged());
		});
	}
	validate() {
		const text = this.value() ?? "";
		if (!text) return this.required() ? { required: true } : null;
		return text.length < this.length() ? { otpIncomplete: true } : null;
	}
	registerOnValidatorChange(fn) {
		this.validatorChanged = fn;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeOtpInput,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeOtpInput,
		isStandalone: true,
		selector: "atr-otp-input",
		inputs: { length: {
			classPropertyName: "length",
			publicName: "length",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: { classAttribute: "atr-otp-input" },
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => AtralumeOtpInput),
			multi: true
		}, {
			provide: NG_VALIDATORS,
			useExisting: forwardRef(() => AtralumeOtpInput),
			multi: true
		}],
		usesInheritance: true,
		ngImport: i0,
		template: "<atr-form-field [hint]=\"hint()\" [error]=\"error()\">\n  <tui-textfield [invalid]=\"displayInvalid()\" tuiTextfieldSize=\"m\">\n    <label tuiLabel [attr.for]=\"controlId()\">\n      {{ label() }}\n      @if (required()) {\n        *\n      }\n    </label>\n    <input\n      tuiInputPin\n      data-atr-value-control\n      [id]=\"controlId()\"\n      [formControl]=\"inner\"\n      [attr.maxlength]=\"length()\"\n      [attr.placeholder]=\"placeholderMask()\"\n      [readOnly]=\"readonly()\"\n    />\n  </tui-textfield>\n</atr-form-field>\n",
		styles: [":host{display:block;min-inline-size:0}\n"],
		dependencies: [
			{
				kind: "ngmodule",
				type: ReactiveFormsModule
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.FormControlDirective,
				selector: "[formControl]",
				inputs: [
					"formControl",
					"disabled",
					"ngModel"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngForm"]
			},
			{
				kind: "component",
				type: AtralumeFormField,
				selector: "atr-form-field",
				inputs: [
					"hint",
					"error",
					"appearance",
					"density",
					"label",
					"required",
					"optional",
					"optionalText"
				]
			},
			{
				kind: "directive",
				type: i2.TuiInputPinComponent,
				selector: "input[tuiInputPin]",
				inputs: ["mask"]
			},
			{
				kind: "directive",
				type: i3.TuiLabel,
				selector: "label[tuiLabel]"
			},
			{
				kind: "component",
				type: i4.TuiTextfieldComponent,
				selector: "tui-textfield:not([multi])",
				inputs: [
					"content",
					"filler",
					"invalid",
					"tuiAppearanceFocus",
					"tuiAppearanceState"
				]
			},
			{
				kind: "directive",
				type: i4.TuiTextfieldOptionsDirective,
				selector: "[tuiTextfieldAppearance],[tuiTextfieldSize],[tuiTextfieldCleaner]",
				inputs: [
					"tuiTextfieldAppearance",
					"tuiTextfieldSize",
					"tuiTextfieldCleaner"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeOtpInput,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-otp-input",
			standalone: true,
			imports: [
				ReactiveFormsModule,
				AtralumeFormField,
				TuiInputPin
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => AtralumeOtpInput),
				multi: true
			}, {
				provide: NG_VALIDATORS,
				useExisting: forwardRef(() => AtralumeOtpInput),
				multi: true
			}],
			host: { class: "atr-otp-input" },
			template: "<atr-form-field [hint]=\"hint()\" [error]=\"error()\">\n  <tui-textfield [invalid]=\"displayInvalid()\" tuiTextfieldSize=\"m\">\n    <label tuiLabel [attr.for]=\"controlId()\">\n      {{ label() }}\n      @if (required()) {\n        *\n      }\n    </label>\n    <input\n      tuiInputPin\n      data-atr-value-control\n      [id]=\"controlId()\"\n      [formControl]=\"inner\"\n      [attr.maxlength]=\"length()\"\n      [attr.placeholder]=\"placeholderMask()\"\n      [readOnly]=\"readonly()\"\n    />\n  </tui-textfield>\n</atr-form-field>\n",
			styles: [":host{display:block;min-inline-size:0}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { length: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "length",
			required: false
		}]
	}] }
});
var AtralumeOtpInputHarness = class extends ComponentHarness {
	static hostSelector = "atr-otp-input";
	input = this.locatorFor("input[tuiInputPin]");
	async getValue() {
		return (await this.input()).getProperty("value");
	}
	async setValue(value) {
		const input = await this.input();
		await input.clear();
		await input.sendKeys(value);
	}
	async isDisabled() {
		return await (await this.input()).getProperty("disabled");
	}
};
export { AtralumeOtpInput, AtralumeOtpInputHarness };

//# sourceMappingURL=osmanjimenez-atralume-otp-input.mjs.map