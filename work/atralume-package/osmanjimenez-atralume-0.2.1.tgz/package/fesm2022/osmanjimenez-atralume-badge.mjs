import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, ViewEncapsulation, booleanAttribute, computed, input } from "@angular/core";
import * as i1 from "@taiga-ui/kit";
import { TuiBadge } from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeBadge = class AtralumeBadge {
	tone = input("neutral", ...ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []);
	appearance = input("soft", ...ngDevMode ? [{ debugName: "appearance" }] : /* istanbul ignore next */ []);
	size = input("medium", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	count = input(null, ...ngDevMode ? [{ debugName: "count" }] : /* istanbul ignore next */ []);
	max = input(99, ...ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []);
	dot = input(false, {
		...ngDevMode ? { debugName: "dot" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	label = input(null, ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	displayCount = computed(() => {
		const count = this.count();
		return count === null ? null : count > this.max() ? `${this.max()}+` : String(count);
	}, ...ngDevMode ? [{ debugName: "displayCount" }] : /* istanbul ignore next */ []);
	accessibleLabel = computed(() => {
		if (this.dot() && !this.label()?.trim()) throw new Error("Dot badges require a label.");
		return this.label() ?? (this.count() === null ? null : String(this.count()));
	}, ...ngDevMode ? [{ debugName: "accessibleLabel" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeBadge,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeBadge,
		isStandalone: true,
		selector: "atr-badge",
		inputs: {
			tone: {
				classPropertyName: "tone",
				publicName: "tone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			count: {
				classPropertyName: "count",
				publicName: "count",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			max: {
				classPropertyName: "max",
				publicName: "max",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dot: {
				classPropertyName: "dot",
				publicName: "dot",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: {
				"attr.tuiBadge": "\"\"",
				"attr.data-tone": "tone()",
				"attr.data-appearance": "appearance()",
				"attr.data-size": "size()",
				"class.atr-badge--dot": "dot()",
				"attr.aria-label": "accessibleLabel()",
				"attr.role": "accessibleLabel() ? \"img\" : null"
			},
			classAttribute: "atr-badge"
		},
		hostDirectives: [{
			directive: i1.TuiBadge,
			inputs: ["size", "tuiSize"]
		}],
		ngImport: i0,
		template: "@if (!dot()) {\n  <ng-content />\n  @if (count() !== null) {\n    <span aria-hidden=\"true\">{{ displayCount() }}</span>\n  }\n}\n",
		styles: ["[tuiBadge].atr-badge{display:inline-flex;align-items:center;justify-content:center;box-sizing:border-box;gap:var(--atr-comp-badge-gap);min-block-size:var(--atr-comp-badge-height);padding-inline:var(--atr-comp-badge-padding);border:var(--atr-ref-border-width-thin) solid transparent;border-radius:var(--atr-comp-badge-shape);font-family:var(--atr-comp-badge-font-family);font-size:var(--atr-comp-badge-font-size);background:var(--atr-comp-badge-container-color, var(--atr-badge-background));color:var(--atr-comp-badge-label-color, var(--atr-badge-foreground))}[tuiBadge].atr-badge[data-size=small]{min-block-size:var(--atr-comp-badge-height-small)}[tuiBadge].atr-badge[data-appearance=outlined]{background:transparent;border-color:var(--atr-comp-badge-outline-color);color:var(--atr-badge-foreground)}[tuiBadge].atr-badge.atr-badge--dot{min-block-size:0;inline-size:var(--atr-comp-badge-dot-size);block-size:var(--atr-comp-badge-dot-size);padding:0}@media(forced-colors:active){[tuiBadge].atr-badge{border-color:CanvasText}}[tuiBadge].atr-badge[data-tone=neutral]{--atr-badge-background: var(--atr-comp-badge-neutral-soft-container);--atr-badge-foreground: var(--atr-comp-badge-neutral-soft-label)}[tuiBadge].atr-badge[data-tone=neutral][data-appearance=filled]{--atr-badge-background: var(--atr-comp-badge-neutral-filled-container);--atr-badge-foreground: var(--atr-comp-badge-neutral-filled-label)}[tuiBadge].atr-badge[data-tone=primary]{--atr-badge-background: var(--atr-comp-badge-primary-soft-container);--atr-badge-foreground: var(--atr-comp-badge-primary-soft-label)}[tuiBadge].atr-badge[data-tone=primary][data-appearance=filled]{--atr-badge-background: var(--atr-comp-badge-primary-filled-container);--atr-badge-foreground: var(--atr-comp-badge-primary-filled-label)}[tuiBadge].atr-badge[data-tone=success]{--atr-badge-background: var(--atr-comp-badge-success-soft-container);--atr-badge-foreground: var(--atr-comp-badge-success-soft-label)}[tuiBadge].atr-badge[data-tone=success][data-appearance=filled]{--atr-badge-background: var(--atr-comp-badge-success-filled-container);--atr-badge-foreground: var(--atr-comp-badge-success-filled-label)}[tuiBadge].atr-badge[data-tone=warning]{--atr-badge-background: var(--atr-comp-badge-warning-soft-container);--atr-badge-foreground: var(--atr-comp-badge-warning-soft-label)}[tuiBadge].atr-badge[data-tone=warning][data-appearance=filled]{--atr-badge-background: var(--atr-comp-badge-warning-filled-container);--atr-badge-foreground: var(--atr-comp-badge-warning-filled-label)}[tuiBadge].atr-badge[data-tone=error]{--atr-badge-background: var(--atr-comp-badge-error-soft-container);--atr-badge-foreground: var(--atr-comp-badge-error-soft-label)}[tuiBadge].atr-badge[data-tone=error][data-appearance=filled]{--atr-badge-background: var(--atr-comp-badge-error-filled-container);--atr-badge-foreground: var(--atr-comp-badge-error-filled-label)}[tuiBadge].atr-badge[data-tone=info]{--atr-badge-background: var(--atr-comp-badge-info-soft-container);--atr-badge-foreground: var(--atr-comp-badge-info-soft-label)}[tuiBadge].atr-badge[data-tone=info][data-appearance=filled]{--atr-badge-background: var(--atr-comp-badge-info-filled-container);--atr-badge-foreground: var(--atr-comp-badge-info-filled-label)}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush,
		encapsulation: i0.ViewEncapsulation.None
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeBadge,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-badge",
			standalone: true,
			hostDirectives: [{
				directive: TuiBadge,
				inputs: ["size: tuiSize"]
			}],
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			host: {
				class: "atr-badge",
				"[attr.tuiBadge]": "\"\"",
				"[attr.data-tone]": "tone()",
				"[attr.data-appearance]": "appearance()",
				"[attr.data-size]": "size()",
				"[class.atr-badge--dot]": "dot()",
				"[attr.aria-label]": "accessibleLabel()",
				"[attr.role]": "accessibleLabel() ? \"img\" : null"
			},
			template: "@if (!dot()) {\n  <ng-content />\n  @if (count() !== null) {\n    <span aria-hidden=\"true\">{{ displayCount() }}</span>\n  }\n}\n",
			styles: ["[tuiBadge].atr-badge{display:inline-flex;align-items:center;justify-content:center;box-sizing:border-box;gap:var(--atr-comp-badge-gap);min-block-size:var(--atr-comp-badge-height);padding-inline:var(--atr-comp-badge-padding);border:var(--atr-ref-border-width-thin) solid transparent;border-radius:var(--atr-comp-badge-shape);font-family:var(--atr-comp-badge-font-family);font-size:var(--atr-comp-badge-font-size);background:var(--atr-comp-badge-container-color, var(--atr-badge-background));color:var(--atr-comp-badge-label-color, var(--atr-badge-foreground))}[tuiBadge].atr-badge[data-size=small]{min-block-size:var(--atr-comp-badge-height-small)}[tuiBadge].atr-badge[data-appearance=outlined]{background:transparent;border-color:var(--atr-comp-badge-outline-color);color:var(--atr-badge-foreground)}[tuiBadge].atr-badge.atr-badge--dot{min-block-size:0;inline-size:var(--atr-comp-badge-dot-size);block-size:var(--atr-comp-badge-dot-size);padding:0}@media(forced-colors:active){[tuiBadge].atr-badge{border-color:CanvasText}}[tuiBadge].atr-badge[data-tone=neutral]{--atr-badge-background: var(--atr-comp-badge-neutral-soft-container);--atr-badge-foreground: var(--atr-comp-badge-neutral-soft-label)}[tuiBadge].atr-badge[data-tone=neutral][data-appearance=filled]{--atr-badge-background: var(--atr-comp-badge-neutral-filled-container);--atr-badge-foreground: var(--atr-comp-badge-neutral-filled-label)}[tuiBadge].atr-badge[data-tone=primary]{--atr-badge-background: var(--atr-comp-badge-primary-soft-container);--atr-badge-foreground: var(--atr-comp-badge-primary-soft-label)}[tuiBadge].atr-badge[data-tone=primary][data-appearance=filled]{--atr-badge-background: var(--atr-comp-badge-primary-filled-container);--atr-badge-foreground: var(--atr-comp-badge-primary-filled-label)}[tuiBadge].atr-badge[data-tone=success]{--atr-badge-background: var(--atr-comp-badge-success-soft-container);--atr-badge-foreground: var(--atr-comp-badge-success-soft-label)}[tuiBadge].atr-badge[data-tone=success][data-appearance=filled]{--atr-badge-background: var(--atr-comp-badge-success-filled-container);--atr-badge-foreground: var(--atr-comp-badge-success-filled-label)}[tuiBadge].atr-badge[data-tone=warning]{--atr-badge-background: var(--atr-comp-badge-warning-soft-container);--atr-badge-foreground: var(--atr-comp-badge-warning-soft-label)}[tuiBadge].atr-badge[data-tone=warning][data-appearance=filled]{--atr-badge-background: var(--atr-comp-badge-warning-filled-container);--atr-badge-foreground: var(--atr-comp-badge-warning-filled-label)}[tuiBadge].atr-badge[data-tone=error]{--atr-badge-background: var(--atr-comp-badge-error-soft-container);--atr-badge-foreground: var(--atr-comp-badge-error-soft-label)}[tuiBadge].atr-badge[data-tone=error][data-appearance=filled]{--atr-badge-background: var(--atr-comp-badge-error-filled-container);--atr-badge-foreground: var(--atr-comp-badge-error-filled-label)}[tuiBadge].atr-badge[data-tone=info]{--atr-badge-background: var(--atr-comp-badge-info-soft-container);--atr-badge-foreground: var(--atr-comp-badge-info-soft-label)}[tuiBadge].atr-badge[data-tone=info][data-appearance=filled]{--atr-badge-background: var(--atr-comp-badge-info-filled-container);--atr-badge-foreground: var(--atr-comp-badge-info-filled-label)}\n"]
		}]
	}],
	propDecorators: {
		tone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tone",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		count: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "count",
				required: false
			}]
		}],
		max: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "max",
				required: false
			}]
		}],
		dot: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dot",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}]
	}
});
var AtralumeBadgeHarness = class extends ComponentHarness {
	static hostSelector = ".atr-badge";
	async getText() {
		return (await this.host()).text();
	}
	async getTone() {
		return (await this.host()).getAttribute("data-tone");
	}
	async getAppearance() {
		return (await this.host()).getAttribute("data-appearance");
	}
};
export { AtralumeBadge, AtralumeBadgeHarness };

//# sourceMappingURL=osmanjimenez-atralume-badge.mjs.map