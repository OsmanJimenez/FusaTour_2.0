import * as i0 from "@angular/core";
import { DestroyRef, Directive, ElementRef, Injectable, InjectionToken, PLATFORM_ID, RendererFactory2, inject, makeEnvironmentProviders, signal } from "@angular/core";
import { provideTaiga } from "@taiga-ui/core";
import { provideEventPlugins } from "@taiga-ui/event-plugins";
import { DOCUMENT, isPlatformBrowser } from "@angular/common";
function provideAtralume() {
	return makeEnvironmentProviders([provideEventPlugins(), provideTaiga()]);
}
var AtralumeControlIds = class AtralumeControlIds {
	next = 0;
	create() {
		return "atr-control-" + this.next++;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeControlIds,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeControlIds,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeControlIds,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
const ATR_FORM_FIELD_CONTROL = new InjectionToken("AtralumeFormFieldControl");
var AtralumeNativeTextControl = class AtralumeNativeTextControl {
	element = inject(ElementRef).nativeElement;
	controlId = signal(this.element.id || inject(AtralumeControlIds).create(), ...ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []);
	disabled = signal(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	readonly = signal(false, ...ngDevMode ? [{ debugName: "readonly" }] : /* istanbul ignore next */ []);
	invalid = signal(false, ...ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []);
	focused = signal(false, ...ngDevMode ? [{ debugName: "focused" }] : /* istanbul ignore next */ []);
	describedBy = [];
	constructor() {
		if (!this.element.id) this.element.id = this.controlId();
	}
	ngDoCheck() {
		this.controlId.set(this.element.id);
		this.disabled.set(this.element.disabled);
		this.readonly.set(this.element.readOnly);
		this.invalid.set(this.element.getAttribute("aria-invalid") === "true" || this.element.classList.contains("ng-invalid") && (this.element.classList.contains("ng-touched") || this.element.classList.contains("ng-dirty")));
	}
	setDescribedByIds(ids) {
		const existing = (this.element.getAttribute("aria-describedby") || "").split(/\s+/).filter((id) => id && !this.describedBy.includes(id));
		this.describedBy = ids;
		const merged = [.../* @__PURE__ */ new Set([...existing, ...ids])].join(" ");
		if (merged) this.element.setAttribute("aria-describedby", merged);
		else this.element.removeAttribute("aria-describedby");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeNativeTextControl,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeNativeTextControl,
		isStandalone: true,
		host: { listeners: {
			"focus": "focused.set(true)",
			"blur": "focused.set(false)"
		} },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeNativeTextControl,
	decorators: [{
		type: Directive,
		args: [{ host: {
			"(focus)": "focused.set(true)",
			"(blur)": "focused.set(false)"
		} }]
	}],
	ctorParameters: () => []
});
var AtralumeOverlayInfrastructure = class AtralumeOverlayInfrastructure {
	browser = isPlatformBrowser(inject(PLATFORM_ID));
	renderer = inject(RendererFactory2).createRenderer(null, null);
	dismissals = /* @__PURE__ */ new Set();
	document = inject(DOCUMENT);
	destroy = inject(DestroyRef);
	layers = /* @__PURE__ */ new WeakMap();
	layer = 0;
	constructor() {
		const unlisten = this.browser ? this.renderer.listen(this.document, "keydown", (event) => {
			if (event.key !== "Escape" || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
			const top = [...this.dismissals].reverse().find((entry) => entry.node.isConnected);
			if (top) {
				event.preventDefault();
				event.stopImmediatePropagation();
				top.close();
			}
		}, { capture: true }) : void 0;
		this.destroy.onDestroy(() => {
			unlisten?.();
			this.dismissals.clear();
		});
	}
	registerDismissal(node, close) {
		const entry = {
			node,
			close
		};
		this.dismissals.add(entry);
		return () => this.dismissals.delete(entry);
	}
	decorate(panel, origin, kind = "dialog", classes = []) {
		if (!this.browser) return;
		const source = origin ?? this.document.documentElement;
		const style = this.document.defaultView?.getComputedStyle(source);
		if (!style) return;
		for (const attr of [
			"data-atr-theme",
			"data-atr-surface",
			"data-atr-density",
			"data-atr-shape",
			"data-atr-brand"
		]) {
			const value = source.closest("[" + attr + "]")?.getAttribute(attr);
			if (value) panel.setAttribute(attr, value);
		}
		panel.setAttribute("dir", style.direction === "rtl" ? "rtl" : "ltr");
		panel.classList.add("atr-overlay-context", ...classes);
		for (let i = 0; i < style.length; i++) {
			const key = style.item(i);
			if (/^--atr-(sys|comp|ref)-/.test(key)) panel.style.setProperty(key, style.getPropertyValue(key));
		}
		const roleLayer = panel.closest(".cdk-overlay-pane") ?? panel;
		let order = this.layers.get(roleLayer);
		if (order === void 0) {
			order = ++this.layer;
			this.layers.set(roleLayer, order);
		}
		const z = `calc(var(--atr-sys-overlay-z-index-${kind}) + ${order} * var(--atr-sys-overlay-stack-step))`;
		roleLayer.style.zIndex = z;
		if (roleLayer.parentElement?.classList.contains("cdk-global-overlay-wrapper")) roleLayer.parentElement.style.zIndex = z;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeOverlayInfrastructure,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeOverlayInfrastructure,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeOverlayInfrastructure,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
const ATRALUME_VERSION = "0.0.0";
export { ATRALUME_VERSION, provideAtralume, ATR_FORM_FIELD_CONTROL as ɵATR_FORM_FIELD_CONTROL, AtralumeControlIds as ɵAtralumeControlIds, AtralumeNativeTextControl as ɵAtralumeNativeTextControl, AtralumeOverlayInfrastructure as ɵAtralumeOverlayInfrastructure };

//# sourceMappingURL=osmanjimenez-atralume.mjs.map