import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, Directive, computed, input, isDevMode } from "@angular/core";
import { TuiLoader } from "@taiga-ui/core";
import { TuiProgressBar, TuiProgressCircle } from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeProgress = class AtralumeProgress {
	value = input(null, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	min = input(0, ...ngDevMode ? [{ debugName: "min" }] : /* istanbul ignore next */ []);
	max = input(100, ...ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	range = computed(() => {
		const min = this.min(), max = this.max(), value = this.value();
		if (!this.label().trim()) throw new Error("Progress requires an accessible label.");
		if (!Number.isFinite(min) || !Number.isFinite(max) || max <= min) throw new Error("Progress requires finite min < max.");
		if (value !== null && !Number.isFinite(value)) throw new Error("Progress value must be finite or null.");
		if (value !== null && (value < min || value > max) && isDevMode()) console.warn("Atralume progress value is outside its range; clamped for display.");
		return {
			min,
			max,
			value: value === null ? null : Math.min(max, Math.max(min, value))
		};
	}, ...ngDevMode ? [{ debugName: "range" }] : /* istanbul ignore next */ []);
	normalizedValue = computed(() => this.range().value, ...ngDevMode ? [{ debugName: "normalizedValue" }] : /* istanbul ignore next */ []);
	percentage = computed(() => {
		const { min, max, value } = this.range();
		return value === null ? null : 100 * (value - min) / (max - min);
	}, ...ngDevMode ? [{ debugName: "percentage" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeProgress,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeProgress,
		isStandalone: true,
		inputs: {
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			min: {
				classPropertyName: "min",
				publicName: "min",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			max: {
				classPropertyName: "max",
				publicName: "max",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeProgress,
	decorators: [{ type: Directive }],
	propDecorators: {
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		min: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "min",
				required: false
			}]
		}],
		max: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "max",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}]
	}
});
var AtralumeProgressSpinner = class AtralumeProgressSpinner extends AtralumeProgress {
	size = input("medium", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	tuiSize = computed(() => {
		switch (this.size()) {
			case "small": return "s";
			case "large": return "l";
			default: return "m";
		}
	}, ...ngDevMode ? [{ debugName: "tuiSize" }] : /* istanbul ignore next */ []);
	circleMax = computed(() => {
		const { min, max } = this.range();
		return max - min;
	}, ...ngDevMode ? [{ debugName: "circleMax" }] : /* istanbul ignore next */ []);
	circleValue = computed(() => {
		const { min, value } = this.range();
		return value === null ? 0 : value - min;
	}, ...ngDevMode ? [{ debugName: "circleValue" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeProgressSpinner,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeProgressSpinner,
		isStandalone: true,
		selector: "atr-progress-spinner",
		inputs: { size: {
			classPropertyName: "size",
			publicName: "size",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			attributes: { "role": "progressbar" },
			properties: {
				"attr.aria-label": "label()",
				"attr.aria-valuemin": "range().min",
				"attr.aria-valuemax": "range().max",
				"attr.aria-valuenow": "normalizedValue()",
				"class.atr-progress--indeterminate": "value() === null",
				"attr.data-size": "size()"
			},
			classAttribute: "atr-progress-spinner"
		},
		usesInheritance: true,
		ngImport: i0,
		template: "@if (value() === null) {\n  <tui-loader\n    class=\"atr-progress-spinner__loader\"\n    [size]=\"tuiSize()\"\n    [inheritColor]=\"true\"\n    [overlay]=\"false\"\n  />\n} @else {\n  <tui-progress-circle\n    class=\"atr-progress-spinner__circle\"\n    [value]=\"circleValue()\"\n    [max]=\"circleMax()\"\n    [size]=\"tuiSize()\"\n  />\n}\n",
		styles: [":host{display:inline-flex;align-items:center;justify-content:center;inline-size:var(--atr-comp-progress-size-medium);block-size:var(--atr-comp-progress-size-medium);color:var(--atr-comp-progress-indicator-color)}:host([data-size=small]){inline-size:var(--atr-comp-progress-size-small);block-size:var(--atr-comp-progress-size-small)}:host([data-size=large]){inline-size:var(--atr-comp-progress-size-large);block-size:var(--atr-comp-progress-size-large)}.atr-progress-spinner__loader,.atr-progress-spinner__circle{inline-size:100%;block-size:100%}@media(forced-colors:active){:host{color:Highlight}}\n"],
		dependencies: [{
			kind: "component",
			type: TuiProgressCircle,
			selector: "tui-progress-circle",
			inputs: [
				"value",
				"max",
				"color",
				"size",
				"arc"
			]
		}, {
			kind: "component",
			type: TuiLoader,
			selector: "tui-loader",
			inputs: [
				"size",
				"inheritColor",
				"overlay",
				"textContent",
				"loading"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeProgressSpinner,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-progress-spinner",
			standalone: true,
			imports: [TuiProgressCircle, TuiLoader],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "atr-progress-spinner",
				role: "progressbar",
				"[attr.aria-label]": "label()",
				"[attr.aria-valuemin]": "range().min",
				"[attr.aria-valuemax]": "range().max",
				"[attr.aria-valuenow]": "normalizedValue()",
				"[class.atr-progress--indeterminate]": "value() === null",
				"[attr.data-size]": "size()"
			},
			template: "@if (value() === null) {\n  <tui-loader\n    class=\"atr-progress-spinner__loader\"\n    [size]=\"tuiSize()\"\n    [inheritColor]=\"true\"\n    [overlay]=\"false\"\n  />\n} @else {\n  <tui-progress-circle\n    class=\"atr-progress-spinner__circle\"\n    [value]=\"circleValue()\"\n    [max]=\"circleMax()\"\n    [size]=\"tuiSize()\"\n  />\n}\n",
			styles: [":host{display:inline-flex;align-items:center;justify-content:center;inline-size:var(--atr-comp-progress-size-medium);block-size:var(--atr-comp-progress-size-medium);color:var(--atr-comp-progress-indicator-color)}:host([data-size=small]){inline-size:var(--atr-comp-progress-size-small);block-size:var(--atr-comp-progress-size-small)}:host([data-size=large]){inline-size:var(--atr-comp-progress-size-large);block-size:var(--atr-comp-progress-size-large)}.atr-progress-spinner__loader,.atr-progress-spinner__circle{inline-size:100%;block-size:100%}@media(forced-colors:active){:host{color:Highlight}}\n"]
		}]
	}],
	propDecorators: { size: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "size",
			required: false
		}]
	}] }
});
var AtralumeProgressSpinnerHarness = class extends ComponentHarness {
	static hostSelector = ".atr-progress-spinner";
	async getValue() {
		const value = await (await this.host()).getAttribute("aria-valuenow");
		return value === null ? null : Number(value);
	}
	async getMin() {
		const value = await (await this.host()).getAttribute("aria-valuemin");
		return value === null ? null : Number(value);
	}
	async getMax() {
		const value = await (await this.host()).getAttribute("aria-valuemax");
		return value === null ? null : Number(value);
	}
	async isIndeterminate() {
		return await (await this.host()).getAttribute("aria-valuenow") === null;
	}
	async getAccessibleName() {
		return (await this.host()).getAttribute("aria-label");
	}
};
var AtralumeProgressBar = class AtralumeProgressBar extends AtralumeProgress {
	nativeMax = computed(() => {
		const { min, max } = this.range();
		return max - min;
	}, ...ngDevMode ? [{ debugName: "nativeMax" }] : /* istanbul ignore next */ []);
	nativeValue = computed(() => {
		const { min, value } = this.range();
		return value === null ? null : value - min;
	}, ...ngDevMode ? [{ debugName: "nativeValue" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeProgressBar,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeProgressBar,
		isStandalone: true,
		selector: "atr-progress-bar",
		host: {
			attributes: { "role": "progressbar" },
			properties: {
				"attr.aria-label": "label()",
				"attr.aria-valuemin": "range().min",
				"attr.aria-valuemax": "range().max",
				"attr.aria-valuenow": "normalizedValue()",
				"class.atr-progress--indeterminate": "value() === null"
			},
			classAttribute: "atr-progress-bar"
		},
		usesInheritance: true,
		ngImport: i0,
		template: "<progress\n  tuiProgressBar\n  class=\"atr-progress-bar__native\"\n  aria-hidden=\"true\"\n  [attr.value]=\"nativeValue() === null ? null : nativeValue()\"\n  [max]=\"nativeMax()\"\n></progress>\n",
		styles: [":host{display:block}.atr-progress-bar__native{display:block;inline-size:100%;block-size:var(--atr-comp-progress-height);border-radius:var(--atr-comp-progress-shape);color:var(--atr-comp-progress-indicator-color);background:var(--atr-comp-progress-track-color)}:host(.atr-progress--indeterminate) .atr-progress-bar__native{animation:atr-bar-pulse var(--atr-comp-progress-reduced-motion-duration) var(--atr-comp-progress-motion-easing) infinite alternate}@keyframes atr-bar-pulse{to{opacity:var(--atr-sys-state-disabled-content-opacity)}}@media(prefers-reduced-motion:reduce){:host(.atr-progress--indeterminate) .atr-progress-bar__native{animation:atr-bar-pulse var(--atr-comp-progress-reduced-motion-duration) var(--atr-comp-progress-motion-easing) infinite alternate}}@media(forced-colors:active){.atr-progress-bar__native{background:Canvas;border:var(--atr-ref-border-width-thin) solid CanvasText;color:Highlight}}\n"],
		dependencies: [{
			kind: "component",
			type: TuiProgressBar,
			selector: "progress[tuiProgressBar]",
			inputs: ["color", "size"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeProgressBar,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-progress-bar",
			standalone: true,
			imports: [TuiProgressBar],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "atr-progress-bar",
				role: "progressbar",
				"[attr.aria-label]": "label()",
				"[attr.aria-valuemin]": "range().min",
				"[attr.aria-valuemax]": "range().max",
				"[attr.aria-valuenow]": "normalizedValue()",
				"[class.atr-progress--indeterminate]": "value() === null"
			},
			template: "<progress\n  tuiProgressBar\n  class=\"atr-progress-bar__native\"\n  aria-hidden=\"true\"\n  [attr.value]=\"nativeValue() === null ? null : nativeValue()\"\n  [max]=\"nativeMax()\"\n></progress>\n",
			styles: [":host{display:block}.atr-progress-bar__native{display:block;inline-size:100%;block-size:var(--atr-comp-progress-height);border-radius:var(--atr-comp-progress-shape);color:var(--atr-comp-progress-indicator-color);background:var(--atr-comp-progress-track-color)}:host(.atr-progress--indeterminate) .atr-progress-bar__native{animation:atr-bar-pulse var(--atr-comp-progress-reduced-motion-duration) var(--atr-comp-progress-motion-easing) infinite alternate}@keyframes atr-bar-pulse{to{opacity:var(--atr-sys-state-disabled-content-opacity)}}@media(prefers-reduced-motion:reduce){:host(.atr-progress--indeterminate) .atr-progress-bar__native{animation:atr-bar-pulse var(--atr-comp-progress-reduced-motion-duration) var(--atr-comp-progress-motion-easing) infinite alternate}}@media(forced-colors:active){.atr-progress-bar__native{background:Canvas;border:var(--atr-ref-border-width-thin) solid CanvasText;color:Highlight}}\n"]
		}]
	}]
});
var AtralumeProgressBarHarness = class extends ComponentHarness {
	static hostSelector = ".atr-progress-bar";
	async getValue() {
		const value = await (await this.host()).getAttribute("aria-valuenow");
		return value === null ? null : Number(value);
	}
	async getMin() {
		const value = await (await this.host()).getAttribute("aria-valuemin");
		return value === null ? null : Number(value);
	}
	async getMax() {
		const value = await (await this.host()).getAttribute("aria-valuemax");
		return value === null ? null : Number(value);
	}
	async isIndeterminate() {
		return await (await this.host()).getAttribute("aria-valuenow") === null;
	}
	async getAccessibleName() {
		return (await this.host()).getAttribute("aria-label");
	}
};
export { AtralumeProgressBar, AtralumeProgressBarHarness, AtralumeProgressSpinner, AtralumeProgressSpinnerHarness };

//# sourceMappingURL=osmanjimenez-atralume-progress.mjs.map