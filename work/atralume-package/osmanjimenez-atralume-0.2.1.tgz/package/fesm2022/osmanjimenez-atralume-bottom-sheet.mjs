import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, Directive, Injectable, InjectionToken, Injector, TemplateRef, inject, input } from "@angular/core";
import { NgTemplateOutlet } from "@angular/common";
import { Subject } from "rxjs";
import { TuiDialogService } from "@taiga-ui/core";
import { PolymorpheusComponent } from "@taiga-ui/polymorpheus";
import { ɵAtralumeOverlayInfrastructure } from "@osmanjimenez/atralume";
import { ComponentHarness, TestKey } from "@angular/cdk/testing";
var AtralumeBottomSheetActions = class AtralumeBottomSheetActions {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeBottomSheetActions,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeBottomSheetActions,
		isStandalone: true,
		selector: "[atrBottomSheetActions]",
		host: { classAttribute: "atr-bottom-sheet-actions" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeBottomSheetActions,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrBottomSheetActions]",
			standalone: true,
			host: { class: "atr-bottom-sheet-actions" }
		}]
	}]
});
const ATR_BOTTOM_SHEET_DATA = new InjectionToken("AtralumeBottomSheet data");
const ATR_BOTTOM_SHEET_TEMPLATE = new InjectionToken("AtralumeBottomSheet template");
var AtralumeBottomSheetRef = class {
	afterClosed;
	closeFn;
	constructor(afterClosed, closeFn) {
		this.afterClosed = afterClosed;
		this.closeFn = closeFn;
	}
	close(result) {
		this.closeFn(result);
	}
};
var AtralumeBottomSheetTemplateHost = class AtralumeBottomSheetTemplateHost {
	template = inject(ATR_BOTTOM_SHEET_TEMPLATE);
	injector = inject(Injector);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeBottomSheetTemplateHost,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeBottomSheetTemplateHost,
		isStandalone: true,
		selector: "atr-bottom-sheet-template-host",
		ngImport: i0,
		template: `<ng-container *ngTemplateOutlet="template; injector: injector" />`,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: NgTemplateOutlet,
			selector: "[ngTemplateOutlet]",
			inputs: [
				"ngTemplateOutletContext",
				"ngTemplateOutlet",
				"ngTemplateOutletInjector"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeBottomSheetTemplateHost,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-bottom-sheet-template-host",
			standalone: true,
			imports: [NgTemplateOutlet],
			template: `<ng-container *ngTemplateOutlet="template; injector: injector" />`,
			changeDetection: ChangeDetectionStrategy.OnPush
		}]
	}]
});
var AtralumeBottomSheet = class AtralumeBottomSheet {
	dialogs = inject(TuiDialogService);
	injector = inject(Injector);
	overlays = inject(ɵAtralumeOverlayInfrastructure);
	open(content, config = {}) {
		const afterClosed = new Subject();
		let subscription;
		let closed = false;
		const finish = (result) => {
			if (closed) return;
			closed = true;
			subscription?.unsubscribe();
			subscription = void 0;
			afterClosed.next(result);
			afterClosed.complete();
		};
		const sheetRef = new AtralumeBottomSheetRef(afterClosed.asObservable(), (result) => finish(result));
		const providers = [{
			provide: AtralumeBottomSheetRef,
			useValue: sheetRef
		}, {
			provide: ATR_BOTTOM_SHEET_DATA,
			useValue: config.data
		}];
		let polyContent;
		if (content instanceof TemplateRef) {
			const templateInjector = Injector.create({
				parent: config.injector ?? this.injector,
				providers: [...providers, {
					provide: ATR_BOTTOM_SHEET_TEMPLATE,
					useValue: content
				}]
			});
			polyContent = new PolymorpheusComponent(AtralumeBottomSheetTemplateHost, templateInjector);
		} else polyContent = new PolymorpheusComponent(content, Injector.create({
			parent: config.injector ?? this.injector,
			providers
		}));
		subscription = this.dialogs.open(polyContent, {
			label: config.label ?? "",
			dismissible: !config.disableClose,
			closable: !config.disableClose,
			data: config.data,
			appearance: "atr-bottom-sheet",
			size: "m"
		}).subscribe({
			next: (result) => finish(result),
			complete: () => finish(void 0),
			error: () => finish(void 0)
		});
		queueMicrotask(() => this.applyPortalChrome(config));
		config.owner?.onDestroy(() => sheetRef.close());
		return sheetRef;
	}
	applyPortalChrome(config) {
		if (!this.overlays.browser) return;
		let seen = false;
		const bind = () => {
			const dialogs = document.querySelectorAll("tui-modal[role=\"dialog\"], tui-modal[role=\"alertdialog\"]");
			const modal = dialogs.item(dialogs.length - 1);
			if (!modal) return false;
			seen = true;
			const panel = modal.querySelector("tui-dialog[data-appearance=\"atr-bottom-sheet\"]") ?? modal;
			this.overlays.decorate(panel, config.origin, "bottom-sheet", config.contextClasses ?? []);
			this.overlays.decorate(modal, config.origin, "bottom-sheet");
			if (config.labelledBy && modal.ownerDocument.getElementById(config.labelledBy)) modal.setAttribute("aria-labelledby", config.labelledBy);
			if (config.describedBy && modal.ownerDocument.getElementById(config.describedBy)) modal.setAttribute("aria-describedby", config.describedBy);
			if (config.role) modal.setAttribute("role", config.role);
			return modal.isConnected;
		};
		bind();
		let attempts = 0;
		const timer = globalThis.setInterval(() => {
			attempts += 1;
			const connected = bind();
			if (attempts >= 60 || seen && !connected) globalThis.clearInterval(timer);
		}, 16);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeBottomSheet,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeBottomSheet,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeBottomSheet,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
var AtralumeBottomSheetClose = class AtralumeBottomSheetClose {
	atrBottomSheetClose = input(...ngDevMode ? [void 0, { debugName: "atrBottomSheetClose" }] : /* istanbul ignore next */ []);
	ref = inject(AtralumeBottomSheetRef);
	close() {
		this.ref.close(this.atrBottomSheetClose());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeBottomSheetClose,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeBottomSheetClose,
		isStandalone: true,
		selector: "button[atrBottomSheetClose]",
		inputs: { atrBottomSheetClose: {
			classPropertyName: "atrBottomSheetClose",
			publicName: "atrBottomSheetClose",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: { listeners: { "click": "close()" } },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeBottomSheetClose,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[atrBottomSheetClose]",
			standalone: true,
			host: { "(click)": "close()" }
		}]
	}],
	propDecorators: { atrBottomSheetClose: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "atrBottomSheetClose",
			required: false
		}]
	}] }
});
var AtralumeBottomSheetContent = class AtralumeBottomSheetContent {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeBottomSheetContent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeBottomSheetContent,
		isStandalone: true,
		selector: "[atrBottomSheetContent]",
		host: { classAttribute: "atr-bottom-sheet-content" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeBottomSheetContent,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrBottomSheetContent]",
			standalone: true,
			host: { class: "atr-bottom-sheet-content" }
		}]
	}]
});
var AtralumeBottomSheetTitle = class AtralumeBottomSheetTitle {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeBottomSheetTitle,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeBottomSheetTitle,
		isStandalone: true,
		selector: "[atrBottomSheetTitle]",
		host: { classAttribute: "atr-bottom-sheet-title" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeBottomSheetTitle,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrBottomSheetTitle]",
			standalone: true,
			host: { class: "atr-bottom-sheet-title" }
		}]
	}]
});
var AtralumeBottomSheetHarness = class extends ComponentHarness {
	static hostSelector = "tui-dialog[data-appearance=\"atr-bottom-sheet\"]";
	async getText() {
		return (await this.host()).text();
	}
	async getAccessibleName() {
		return (await this.host()).getAttribute("aria-label");
	}
	async pressEscape() {
		await (await this.host()).sendKeys(TestKey.ESCAPE);
	}
};
var AtralumeBottomSheetActionsHarness = class extends ComponentHarness {
	static hostSelector = ".atr-bottom-sheet-actions";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeBottomSheetCloseHarness = class extends ComponentHarness {
	static hostSelector = ".atr-bottom-sheet-close";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeBottomSheetContentHarness = class extends ComponentHarness {
	static hostSelector = ".atr-bottom-sheet-content";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeBottomSheetTitleHarness = class extends ComponentHarness {
	static hostSelector = ".atr-bottom-sheet-title";
	async getText() {
		return (await this.host()).text();
	}
};
export { ATR_BOTTOM_SHEET_DATA, AtralumeBottomSheet, AtralumeBottomSheetActions, AtralumeBottomSheetActionsHarness, AtralumeBottomSheetClose, AtralumeBottomSheetCloseHarness, AtralumeBottomSheetContent, AtralumeBottomSheetContentHarness, AtralumeBottomSheetHarness, AtralumeBottomSheetRef, AtralumeBottomSheetTitle, AtralumeBottomSheetTitleHarness };

//# sourceMappingURL=osmanjimenez-atralume-bottom-sheet.mjs.map