import * as i0 from "@angular/core";
import { Directive, effect, inject, input } from "@angular/core";
import * as i1 from "@taiga-ui/core";
import { TuiDropdownDirective, TuiDropdownOpen, TuiDropdownOptionsDirective } from "@taiga-ui/core";
import { ComponentHarness, TestKey } from "@angular/cdk/testing";
var AtralumePopover = class AtralumePopover {
	label = input(null, ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	panelRole = input("dialog", ...ngDevMode ? [{ debugName: "panelRole" }] : /* istanbul ignore next */ []);
	position = input("below", ...ngDevMode ? [{ debugName: "position" }] : /* istanbul ignore next */ []);
	dropdown = inject(TuiDropdownDirective);
	dropdownOpen = inject(TuiDropdownOpen);
	options = inject(TuiDropdownOptionsDirective);
	constructor() {
		this.options.appearance = "atr-popover";
		effect(() => {
			const pos = this.position();
			this.options.direction = pos === "above" ? "top" : pos === "below" ? "bottom" : null;
		});
		effect(() => {
			const label = this.label();
			const role = this.panelRole();
			const el = this.dropdown.ref()?.location.nativeElement;
			if (!el) return;
			el.setAttribute("role", role);
			if (label?.trim()) el.setAttribute("aria-label", label);
			else el.removeAttribute("aria-label");
		});
	}
	open() {
		this.dropdownOpen.toggle(true);
	}
	close() {
		this.dropdownOpen.toggle(false);
	}
	toggle() {
		this.dropdownOpen.toggle(!this.dropdownOpen.open());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumePopover,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumePopover,
		isStandalone: true,
		selector: "[atrPopover]",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			panelRole: {
				classPropertyName: "panelRole",
				publicName: "panelRole",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			position: {
				classPropertyName: "position",
				publicName: "position",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "atr-popover-trigger" },
		exportAs: ["atrPopover"],
		hostDirectives: [
			{
				directive: i1.TuiDropdownDirective,
				inputs: ["tuiDropdown", "atrPopover"]
			},
			{
				directive: i1.TuiDropdownOpen,
				inputs: [
					"tuiDropdownOpen",
					"opened",
					"tuiDropdownEnabled",
					"popoverEnabled"
				],
				outputs: ["tuiDropdownOpenChange", "openedChange"]
			},
			{
				directive: i1.TuiDropdownOptionsDirective,
				inputs: [
					"tuiDropdownAlign",
					"dropdownAlign",
					"tuiDropdownDirection",
					"dropdownDirection",
					"tuiDropdownOffset",
					"dropdownOffset"
				]
			}
		],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumePopover,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrPopover]",
			standalone: true,
			exportAs: "atrPopover",
			hostDirectives: [
				{
					directive: TuiDropdownDirective,
					inputs: ["tuiDropdown: atrPopover"]
				},
				{
					directive: TuiDropdownOpen,
					inputs: ["tuiDropdownOpen: opened", "tuiDropdownEnabled: popoverEnabled"],
					outputs: ["tuiDropdownOpenChange: openedChange"]
				},
				{
					directive: TuiDropdownOptionsDirective,
					inputs: [
						"tuiDropdownAlign: dropdownAlign",
						"tuiDropdownDirection: dropdownDirection",
						"tuiDropdownOffset: dropdownOffset"
					]
				}
			],
			host: { class: "atr-popover-trigger" }
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		panelRole: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "panelRole",
				required: false
			}]
		}],
		position: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "position",
				required: false
			}]
		}]
	}
});
var AtralumePopoverHarness = class extends ComponentHarness {
	static hostSelector = "tui-dropdown[data-appearance=\"atr-popover\"]";
	async getRole() {
		return (await this.host()).getAttribute("role");
	}
	async getText() {
		return (await this.host()).text();
	}
	async close() {
		await (await this.host()).sendKeys(TestKey.ESCAPE);
	}
};
export { AtralumePopover, AtralumePopoverHarness };

//# sourceMappingURL=osmanjimenez-atralume-popover.mjs.map