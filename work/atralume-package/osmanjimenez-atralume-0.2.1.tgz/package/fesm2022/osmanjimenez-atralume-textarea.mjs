import * as i0 from "@angular/core";
import { Directive, input } from "@angular/core";
import * as i1 from "@taiga-ui/kit";
import { TuiTextareaComponent } from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeTextarea = class AtralumeTextarea {
	resize = input("vertical", ...ngDevMode ? [{ debugName: "resize" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeTextarea,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeTextarea,
		isStandalone: true,
		selector: "textarea[atrTextarea]",
		inputs: { resize: {
			classPropertyName: "resize",
			publicName: "resize",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			properties: {
				"attr.tuiTextarea": "\"\"",
				"style.resize": "resize()"
			},
			classAttribute: "atr-textarea"
		},
		hostDirectives: [{
			directive: i1.TuiTextareaComponent,
			inputs: [
				"minRows",
				"minRows",
				"maxRows",
				"maxRows",
				"content",
				"content"
			]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeTextarea,
	decorators: [{
		type: Directive,
		args: [{
			selector: "textarea[atrTextarea]",
			standalone: true,
			hostDirectives: [{
				directive: TuiTextareaComponent,
				inputs: [
					"minRows",
					"maxRows",
					"content"
				]
			}],
			host: {
				class: "atr-textarea",
				"[attr.tuiTextarea]": "\"\"",
				"[style.resize]": "resize()"
			}
		}]
	}],
	propDecorators: { resize: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "resize",
			required: false
		}]
	}] }
});
var AtralumeTextareaHarness = class extends ComponentHarness {
	static hostSelector = ".atr-textarea";
	async getValue() {
		return (await this.host()).getProperty("value");
	}
	async setValue(value) {
		const host = await this.host();
		await host.clear();
		await host.sendKeys(value);
	}
	async focus() {
		await (await this.host()).focus();
	}
	async blur() {
		await (await this.host()).blur();
	}
	async isReadonly() {
		return (await this.host()).getProperty("readOnly");
	}
	async isInvalid() {
		const h = await this.host();
		return await h.getAttribute("aria-invalid") === "true" || await h.hasClass("ng-invalid") && (await h.hasClass("ng-touched") || await h.hasClass("ng-dirty"));
	}
	async isDisabled() {
		return (await this.host()).getProperty("disabled");
	}
};
export { AtralumeTextarea, AtralumeTextareaHarness };

//# sourceMappingURL=osmanjimenez-atralume-textarea.mjs.map