import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, booleanAttribute, computed, effect, forwardRef, inject, input, untracked } from "@angular/core";
import * as i1 from "@angular/forms";
import { FormControl, NG_VALIDATORS, NG_VALUE_ACCESSOR, ReactiveFormsModule } from "@angular/forms";
import { TuiDay, TuiDayRange } from "@taiga-ui/cdk/date-time";
import * as i2 from "@taiga-ui/kit";
import { TuiInputDate, TuiInputDateRange } from "@taiga-ui/kit";
import { AtralumeFormField } from "@osmanjimenez/atralume/form-field";
import { ɵAtralumeValueControl } from "@osmanjimenez/atralume/internal/forms";
import * as i3 from "@taiga-ui/core/components/calendar";
import * as i4 from "@taiga-ui/core/components/label";
import * as i5 from "@taiga-ui/core/components/textfield";
import * as i6 from "@taiga-ui/core/portals/dropdown";
import * as i7 from "@taiga-ui/kit/components/calendar-range";
import { AtralumeCalendarHarness, AtralumeDateAdapter, provideAtralumeNativeDateAdapter } from "@osmanjimenez/atralume/calendar";
import { ComponentHarness, TestKey } from "@angular/cdk/testing";
function toDay(value) {
	return value ? TuiDay.fromLocalNativeDate(value) : null;
}
function fromDay(value) {
	return value ? value.toLocalNativeDate() : null;
}
var AtralumeDatePicker = class AtralumeDatePicker extends ɵAtralumeValueControl {
	selectionMode = input("single", ...ngDevMode ? [{ debugName: "selectionMode" }] : /* istanbul ignore next */ []);
	min = input(null, ...ngDevMode ? [{ debugName: "min" }] : /* istanbul ignore next */ []);
	max = input(null, ...ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []);
	dateFilter = input(() => true, ...ngDevMode ? [{ debugName: "dateFilter" }] : /* istanbul ignore next */ []);
	clearable = input(false, {
		...ngDevMode ? { debugName: "clearable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	presentation = input("popover", ...ngDevMode ? [{ debugName: "presentation" }] : /* istanbul ignore next */ []);
	visibleDate = input(null, ...ngDevMode ? [{ debugName: "visibleDate" }] : /* istanbul ignore next */ []);
	tuiMin = computed(() => toDay(this.min()) ?? void 0, ...ngDevMode ? [{ debugName: "tuiMin" }] : /* istanbul ignore next */ []);
	tuiMax = computed(() => toDay(this.max()) ?? void 0, ...ngDevMode ? [{ debugName: "tuiMax" }] : /* istanbul ignore next */ []);
	disabledItemHandler = computed(() => {
		const filter = this.dateFilter();
		return (day) => !filter(day.toLocalNativeDate());
	}, ...ngDevMode ? [{ debugName: "disabledItemHandler" }] : /* istanbul ignore next */ []);
	single = new FormControl(null);
	range = new FormControl(null);
	validatorChanged = () => void 0;
	constructor() {
		super();
		const destroyRef = inject(DestroyRef);
		const singleSub = this.single.valueChanges.subscribe((day) => {
			if (this.selectionMode() !== "single") return;
			this.commit(fromDay(day));
		});
		const rangeSub = this.range.valueChanges.subscribe((value) => {
			if (this.selectionMode() !== "range") return;
			this.commit(value ? {
				start: fromDay(value.from),
				end: fromDay(value.to)
			} : null);
		});
		destroyRef.onDestroy(() => {
			singleSub.unsubscribe();
			rangeSub.unsubscribe();
		});
		effect(() => {
			const mode = this.selectionMode();
			const next = this.value();
			untracked(() => {
				if (mode === "single") {
					const day = toDay(next ?? null);
					if (!Object.is(this.single.value, day) && !(day && this.single.value?.daySame(day))) this.single.setValue(day, { emitEvent: false });
				} else {
					const rangeValue = next;
					const mapped = rangeValue?.start && rangeValue.end ? new TuiDayRange(TuiDay.fromLocalNativeDate(rangeValue.start), TuiDay.fromLocalNativeDate(rangeValue.end)) : null;
					const current = this.range.value;
					if (!mapped && current || mapped && (!current || !current.daySame(mapped))) this.range.setValue(mapped, { emitEvent: false });
				}
			});
		});
		effect(() => {
			const blocked = this.blocked();
			untracked(() => {
				if (blocked) {
					this.single.disable({ emitEvent: false });
					this.range.disable({ emitEvent: false });
				} else {
					this.single.enable({ emitEvent: false });
					this.range.enable({ emitEvent: false });
				}
			});
		});
		effect(() => {
			this.value();
			this.min();
			this.max();
			this.required();
			untracked(() => this.validatorChanged());
		});
	}
	validate() {
		const value = this.value();
		if (value === null) return this.required() ? { required: true } : null;
		if (this.selectionMode() === "single") {
			const date = value;
			return date instanceof Date && !Number.isNaN(date.getTime()) ? null : { dateInvalid: true };
		}
		const range = value;
		return range.start && range.end ? null : { dateRange: true };
	}
	registerOnValidatorChange(fn) {
		this.validatorChanged = fn;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeDatePicker,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeDatePicker,
		isStandalone: true,
		selector: "atr-date-picker",
		inputs: {
			selectionMode: {
				classPropertyName: "selectionMode",
				publicName: "selectionMode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			min: {
				classPropertyName: "min",
				publicName: "min",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			max: {
				classPropertyName: "max",
				publicName: "max",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dateFilter: {
				classPropertyName: "dateFilter",
				publicName: "dateFilter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			clearable: {
				classPropertyName: "clearable",
				publicName: "clearable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			presentation: {
				classPropertyName: "presentation",
				publicName: "presentation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			visibleDate: {
				classPropertyName: "visibleDate",
				publicName: "visibleDate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "atr-date-picker" },
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => AtralumeDatePicker),
			multi: true
		}, {
			provide: NG_VALIDATORS,
			useExisting: forwardRef(() => AtralumeDatePicker),
			multi: true
		}],
		usesInheritance: true,
		ngImport: i0,
		template: "<atr-form-field [hint]=\"hint()\" [error]=\"error()\">\n  @if (selectionMode() === \"range\") {\n    <tui-textfield\n      [invalid]=\"displayInvalid()\"\n      [tuiTextfieldCleaner]=\"clearable()\"\n      [disabledItemHandler]=\"disabledItemHandler()\"\n      tuiTextfieldSize=\"m\"\n    >\n      <label tuiLabel [attr.for]=\"controlId()\">\n        {{ label() }}\n        @if (required()) {\n          *\n        }\n      </label>\n      <input\n        tuiInputDateRange\n        data-atr-value-control\n        [id]=\"controlId()\"\n        [formControl]=\"range\"\n        [min]=\"tuiMin()\"\n        [max]=\"tuiMax()\"\n        [readOnly]=\"readonly()\"\n      />\n      <ng-template tuiDropdown>\n        <tui-calendar-range />\n      </ng-template>\n    </tui-textfield>\n  } @else {\n    <tui-textfield\n      [invalid]=\"displayInvalid()\"\n      [tuiTextfieldCleaner]=\"clearable()\"\n      [disabledItemHandler]=\"disabledItemHandler()\"\n      tuiTextfieldSize=\"m\"\n    >\n      <label tuiLabel [attr.for]=\"controlId()\">\n        {{ label() }}\n        @if (required()) {\n          *\n        }\n      </label>\n      <input\n        tuiInputDate\n        data-atr-value-control\n        [id]=\"controlId()\"\n        [formControl]=\"single\"\n        [min]=\"tuiMin()\"\n        [max]=\"tuiMax()\"\n        [readOnly]=\"readonly()\"\n      />\n      <ng-template tuiDropdown>\n        <tui-calendar />\n      </ng-template>\n    </tui-textfield>\n  }\n</atr-form-field>\n",
		styles: [":host{display:block;min-inline-size:0}\n"],
		dependencies: [
			{
				kind: "ngmodule",
				type: ReactiveFormsModule
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.FormControlDirective,
				selector: "[formControl]",
				inputs: [
					"formControl",
					"disabled",
					"ngModel"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngForm"]
			},
			{
				kind: "component",
				type: AtralumeFormField,
				selector: "atr-form-field",
				inputs: [
					"hint",
					"error",
					"appearance",
					"density",
					"label",
					"required",
					"optional",
					"optionalText"
				]
			},
			{
				kind: "directive",
				type: i2.TuiInputDateDirective,
				selector: "input[tuiInputDate]",
				inputs: ["max", "min"]
			},
			{
				kind: "component",
				type: i3.TuiCalendar,
				selector: "tui-calendar:not([new]):not([months])",
				inputs: [
					"minViewedMonth",
					"maxViewedMonth",
					"showAdjacent",
					"markerHandler",
					"initialView",
					"hoveredItem"
				],
				outputs: ["hoveredItemChange", "dayClick"]
			},
			{
				kind: "directive",
				type: i4.TuiLabel,
				selector: "label[tuiLabel]"
			},
			{
				kind: "component",
				type: i5.TuiTextfieldComponent,
				selector: "tui-textfield:not([multi])",
				inputs: [
					"content",
					"filler",
					"invalid",
					"tuiAppearanceFocus",
					"tuiAppearanceState"
				]
			},
			{
				kind: "directive",
				type: i5.TuiTextfieldOptionsDirective,
				selector: "[tuiTextfieldAppearance],[tuiTextfieldSize],[tuiTextfieldCleaner]",
				inputs: [
					"tuiTextfieldAppearance",
					"tuiTextfieldSize",
					"tuiTextfieldCleaner"
				]
			},
			{
				kind: "directive",
				type: i6.TuiDropdownContent,
				selector: "ng-template[tuiDropdown]"
			},
			{
				kind: "directive",
				type: i2.TuiInputDateRangeDirective,
				selector: "input[tuiInputDateRange]",
				inputs: [
					"max",
					"min",
					"minLength",
					"maxLength"
				]
			},
			{
				kind: "component",
				type: i7.TuiCalendarRange,
				selector: "tui-calendar-range",
				inputs: [
					"minLength",
					"maxLength",
					"items",
					"listSize",
					"defaultViewedMonth",
					"markerHandler",
					"item"
				],
				outputs: ["itemChange"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeDatePicker,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-date-picker",
			standalone: true,
			imports: [
				ReactiveFormsModule,
				AtralumeFormField,
				TuiInputDate,
				TuiInputDateRange
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => AtralumeDatePicker),
				multi: true
			}, {
				provide: NG_VALIDATORS,
				useExisting: forwardRef(() => AtralumeDatePicker),
				multi: true
			}],
			host: { class: "atr-date-picker" },
			template: "<atr-form-field [hint]=\"hint()\" [error]=\"error()\">\n  @if (selectionMode() === \"range\") {\n    <tui-textfield\n      [invalid]=\"displayInvalid()\"\n      [tuiTextfieldCleaner]=\"clearable()\"\n      [disabledItemHandler]=\"disabledItemHandler()\"\n      tuiTextfieldSize=\"m\"\n    >\n      <label tuiLabel [attr.for]=\"controlId()\">\n        {{ label() }}\n        @if (required()) {\n          *\n        }\n      </label>\n      <input\n        tuiInputDateRange\n        data-atr-value-control\n        [id]=\"controlId()\"\n        [formControl]=\"range\"\n        [min]=\"tuiMin()\"\n        [max]=\"tuiMax()\"\n        [readOnly]=\"readonly()\"\n      />\n      <ng-template tuiDropdown>\n        <tui-calendar-range />\n      </ng-template>\n    </tui-textfield>\n  } @else {\n    <tui-textfield\n      [invalid]=\"displayInvalid()\"\n      [tuiTextfieldCleaner]=\"clearable()\"\n      [disabledItemHandler]=\"disabledItemHandler()\"\n      tuiTextfieldSize=\"m\"\n    >\n      <label tuiLabel [attr.for]=\"controlId()\">\n        {{ label() }}\n        @if (required()) {\n          *\n        }\n      </label>\n      <input\n        tuiInputDate\n        data-atr-value-control\n        [id]=\"controlId()\"\n        [formControl]=\"single\"\n        [min]=\"tuiMin()\"\n        [max]=\"tuiMax()\"\n        [readOnly]=\"readonly()\"\n      />\n      <ng-template tuiDropdown>\n        <tui-calendar />\n      </ng-template>\n    </tui-textfield>\n  }\n</atr-form-field>\n",
			styles: [":host{display:block;min-inline-size:0}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		selectionMode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectionMode",
				required: false
			}]
		}],
		min: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "min",
				required: false
			}]
		}],
		max: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "max",
				required: false
			}]
		}],
		dateFilter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dateFilter",
				required: false
			}]
		}],
		clearable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "clearable",
				required: false
			}]
		}],
		presentation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "presentation",
				required: false
			}]
		}],
		visibleDate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "visibleDate",
				required: false
			}]
		}]
	}
});
var AtralumeDatePickerHarness = class extends ComponentHarness {
	static hostSelector = "atr-date-picker";
	input = this.locatorFor("input[type=\"text\"]");
	async openCalendar() {
		const button = await this.locatorFor("button[aria-haspopup=\"dialog\"]")();
		if (await button.getAttribute("aria-expanded") !== "true") await button.click();
	}
	async close() {
		await (await this.input()).sendKeys(TestKey.ESCAPE);
	}
	async getValue() {
		return (await this.input()).getProperty("value");
	}
	async enterText(value) {
		const input = await this.input();
		await input.setInputValue(value);
		await input.dispatchEvent("input");
	}
	async getCalendar() {
		await this.openCalendar();
		return this.documentRootLocatorFactory().locatorFor(AtralumeCalendarHarness)();
	}
	async navigateMonth(direction = "next") {
		const calendar = await this.getCalendar();
		if (direction === "next") await calendar.nextMonth();
		else await calendar.previousMonth();
	}
	async selectDate(id) {
		await (await this.getCalendar()).selectDate(id);
	}
	async clear() {
		await (await this.locatorFor("button[aria-label^=\"Clear \"]")()).click();
	}
	async isDisabled() {
		return (await this.input()).getProperty("disabled");
	}
};
export { AtralumeDateAdapter, AtralumeDatePicker, AtralumeDatePickerHarness, provideAtralumeNativeDateAdapter };

//# sourceMappingURL=osmanjimenez-atralume-date-picker.mjs.map