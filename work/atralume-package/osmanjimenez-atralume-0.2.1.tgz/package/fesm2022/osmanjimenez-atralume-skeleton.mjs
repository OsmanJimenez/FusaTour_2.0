import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, input } from "@angular/core";
import * as i1 from "@taiga-ui/kit";
import { TuiSkeleton } from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeSkeleton = class AtralumeSkeleton {
	active = input(true, ...ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []);
	appearance = input("text", ...ngDevMode ? [{ debugName: "appearance" }] : /* istanbul ignore next */ []);
	animation = input("pulse", ...ngDevMode ? [{ debugName: "animation" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeSkeleton,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeSkeleton,
		isStandalone: true,
		selector: "atr-skeleton",
		inputs: {
			active: {
				classPropertyName: "active",
				publicName: "active",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			appearance: {
				classPropertyName: "appearance",
				publicName: "appearance",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			animation: {
				classPropertyName: "animation",
				publicName: "animation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "aria-hidden": "true" },
			properties: {
				"attr.data-appearance": "appearance()",
				"attr.data-animation": "animation()"
			},
			classAttribute: "atr-skeleton"
		},
		hostDirectives: [{
			directive: i1.TuiSkeleton,
			inputs: ["tuiSkeleton", "active"]
		}],
		ngImport: i0,
		template: "<span></span>\n",
		styles: [":host{display:block;position:relative;overflow:hidden;inline-size:var(--atr-comp-skeleton-width, 100%);block-size:var(--atr-comp-skeleton-height, var(--atr-sys-spacing-md));background:var(--atr-comp-skeleton-container-color);border-radius:var(--atr-comp-skeleton-shape)}:host([data-appearance=circle]){inline-size:var(--atr-comp-skeleton-width, var(--atr-ref-spacing-12));block-size:var(--atr-comp-skeleton-height, var(--atr-ref-spacing-12));border-radius:var(--atr-sys-shape-full)}:host([data-appearance=rectangle]){border-radius:var(--atr-sys-shape-none)}:host([data-appearance=rounded]){border-radius:var(--atr-sys-shape-medium)}:host([data-animation=pulse]){animation:atr-skeleton-pulse var(--atr-ref-duration-activity-reduced) var(--atr-sys-motion-easing-standard) infinite alternate}:host([data-animation=shimmer]) span{position:absolute;inset:0;background:linear-gradient(90deg,transparent,var(--atr-sys-color-surface),transparent);animation:atr-skeleton-shimmer var(--atr-ref-duration-activity-bar) linear infinite}@keyframes atr-skeleton-pulse{to{opacity:var(--atr-sys-state-disabled-content-opacity)}}@keyframes atr-skeleton-shimmer{0%{transform:translate(-100%)}to{transform:translate(100%)}}@media(prefers-reduced-motion:reduce){:host([data-animation=pulse]),:host([data-animation=shimmer]) span{animation:none}}@media(forced-colors:active){:host{background:CanvasText;opacity:var(--atr-sys-state-disabled-content-opacity)}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeSkeleton,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-skeleton",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			hostDirectives: [{
				directive: TuiSkeleton,
				inputs: ["tuiSkeleton: active"]
			}],
			host: {
				class: "atr-skeleton",
				"aria-hidden": "true",
				"[attr.data-appearance]": "appearance()",
				"[attr.data-animation]": "animation()"
			},
			template: "<span></span>\n",
			styles: [":host{display:block;position:relative;overflow:hidden;inline-size:var(--atr-comp-skeleton-width, 100%);block-size:var(--atr-comp-skeleton-height, var(--atr-sys-spacing-md));background:var(--atr-comp-skeleton-container-color);border-radius:var(--atr-comp-skeleton-shape)}:host([data-appearance=circle]){inline-size:var(--atr-comp-skeleton-width, var(--atr-ref-spacing-12));block-size:var(--atr-comp-skeleton-height, var(--atr-ref-spacing-12));border-radius:var(--atr-sys-shape-full)}:host([data-appearance=rectangle]){border-radius:var(--atr-sys-shape-none)}:host([data-appearance=rounded]){border-radius:var(--atr-sys-shape-medium)}:host([data-animation=pulse]){animation:atr-skeleton-pulse var(--atr-ref-duration-activity-reduced) var(--atr-sys-motion-easing-standard) infinite alternate}:host([data-animation=shimmer]) span{position:absolute;inset:0;background:linear-gradient(90deg,transparent,var(--atr-sys-color-surface),transparent);animation:atr-skeleton-shimmer var(--atr-ref-duration-activity-bar) linear infinite}@keyframes atr-skeleton-pulse{to{opacity:var(--atr-sys-state-disabled-content-opacity)}}@keyframes atr-skeleton-shimmer{0%{transform:translate(-100%)}to{transform:translate(100%)}}@media(prefers-reduced-motion:reduce){:host([data-animation=pulse]),:host([data-animation=shimmer]) span{animation:none}}@media(forced-colors:active){:host{background:CanvasText;opacity:var(--atr-sys-state-disabled-content-opacity)}}\n"]
		}]
	}],
	propDecorators: {
		active: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "active",
				required: false
			}]
		}],
		appearance: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "appearance",
				required: false
			}]
		}],
		animation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "animation",
				required: false
			}]
		}]
	}
});
var AtralumeSkeletonHarness = class extends ComponentHarness {
	static hostSelector = "atr-skeleton";
	async getText() {
		return (await this.host()).text();
	}
};
export { AtralumeSkeleton, AtralumeSkeletonHarness };

//# sourceMappingURL=osmanjimenez-atralume-skeleton.mjs.map