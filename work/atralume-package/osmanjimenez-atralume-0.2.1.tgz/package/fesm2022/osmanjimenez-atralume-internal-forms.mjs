import * as i0 from "@angular/core";
import { Directive, ElementRef, Injector, booleanAttribute, computed, inject, input, model, output, signal } from "@angular/core";
import { NgControl } from "@angular/forms";
import { ɵAtralumeControlIds } from "@osmanjimenez/atralume";
var AtralumeValueControl = class AtralumeValueControl {
	value = model(null, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	controlId = input(inject(ɵAtralumeControlIds).create(), ...ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	readonly = input(false, {
		...ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	required = input(false, {
		...ngDevMode ? { debugName: "required" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	invalid = input(false, {
		...ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	hint = input(null, ...ngDevMode ? [{ debugName: "hint" }] : /* istanbul ignore next */ []);
	error = input(null, ...ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []);
	touch = output();
	focused = signal(false, ...ngDevMode ? [{ debugName: "focused" }] : /* istanbul ignore next */ []);
	descriptions = signal([], ...ngDevMode ? [{ debugName: "descriptions" }] : /* istanbul ignore next */ []);
	formDisabled = signal(false, ...ngDevMode ? [{ debugName: "formDisabled" }] : /* istanbul ignore next */ []);
	formInvalid = signal(false, ...ngDevMode ? [{ debugName: "formInvalid" }] : /* istanbul ignore next */ []);
	blocked = computed(() => this.disabled() || this.formDisabled(), ...ngDevMode ? [{ debugName: "blocked" }] : /* istanbul ignore next */ []);
	displayInvalid = computed(() => this.invalid() || this.formInvalid() || !!this.error(), ...ngDevMode ? [{ debugName: "displayInvalid" }] : /* istanbul ignore next */ []);
	element = inject(ElementRef).nativeElement;
	controlInjector = inject(Injector);
	change = () => void 0;
	onTouched = () => void 0;
	writeValue(value) {
		this.value.set(value ?? null);
	}
	registerOnChange(fn) {
		this.change = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	setDisabledState(disabled) {
		this.formDisabled.set(disabled);
	}
	ngDoCheck() {
		const control = this.controlInjector.get(NgControl, null, { self: true })?.control;
		this.formInvalid.set(!!control?.invalid && (!!control?.touched || !!control?.dirty));
	}
	commit(value) {
		if (this.blocked() || this.readonly()) return;
		this.value.set(value);
		this.change(value);
	}
	markTouched() {
		this.onTouched();
		this.touch.emit();
	}
	blur(event) {
		if (event.relatedTarget && this.element.contains(event.relatedTarget)) return;
		this.focused.set(false);
		this.markTouched();
	}
	focus(options) {
		this.element.querySelector("[data-atr-value-control]")?.focus(options);
	}
	setDescribedByIds(ids) {
		this.descriptions.set(ids);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeValueControl,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeValueControl,
		isStandalone: true,
		inputs: {
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			controlId: {
				classPropertyName: "controlId",
				publicName: "controlId",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readonly: {
				classPropertyName: "readonly",
				publicName: "readonly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			invalid: {
				classPropertyName: "invalid",
				publicName: "invalid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hint: {
				classPropertyName: "hint",
				publicName: "hint",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			error: {
				classPropertyName: "error",
				publicName: "error",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			value: "valueChange",
			touch: "touch"
		},
		host: { listeners: {
			"focusin": "focused.set(true)",
			"focusout": "blur($event)"
		} },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeValueControl,
	decorators: [{
		type: Directive,
		args: [{ host: {
			"(focusin)": "focused.set(true)",
			"(focusout)": "blur($event)"
		} }]
	}],
	propDecorators: {
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		controlId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "controlId",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		readonly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readonly",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		invalid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		hint: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hint",
				required: false
			}]
		}],
		error: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "error",
				required: false
			}]
		}],
		touch: [{
			type: i0.Output,
			args: ["touch"]
		}]
	}
});
export { AtralumeValueControl as ɵAtralumeValueControl };

//# sourceMappingURL=osmanjimenez-atralume-internal-forms.mjs.map