import * as i0 from "@angular/core";
import * as i1 from "@angular/cdk/menu";
import * as i2 from "@taiga-ui/core";
import { ComponentHarness } from "@angular/cdk/testing";
/**
 * CDK Menu checkbox item with Taiga UI `TuiOption` appearance adapter.
 */
export declare class AtralumeMenuCheckboxItem {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeMenuCheckboxItem, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeMenuCheckboxItem, "button[atrMenuCheckboxItem]", never, {}, {}, never, never, true, [{
    directive: typeof i1.CdkMenuItemCheckbox;
    inputs: {
      "cdkMenuItemDisabled": "disabled";
      "cdkMenuItemChecked": "checked";
    };
    outputs: {
      "cdkMenuItemTriggered": "invoked";
    };
  }, {
    directive: typeof i2.TuiOption;
    inputs: {
      "disabled": "disabled";
    };
    outputs: {};
  }]>;
}
export declare class AtralumeMenuGroup {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeMenuGroup, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeMenuGroup, "[atrMenuGroup]", never, {}, {}, never, never, true, [{
    directive: typeof i1.CdkMenuGroup;
    inputs: {};
    outputs: {};
  }]>;
}
/**
 * CDK Menu item with Taiga UI `TuiOption` appearance adapter.
 */
export declare class AtralumeMenuItem {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeMenuItem, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeMenuItem, "button[atrMenuItem]", never, {}, {}, never, never, true, [{
    directive: typeof i1.CdkMenuItem;
    inputs: {
      "cdkMenuItemDisabled": "disabled";
    };
    outputs: {
      "cdkMenuItemTriggered": "invoked";
    };
  }, {
    directive: typeof i2.TuiOption;
    inputs: {
      "disabled": "disabled";
    };
    outputs: {};
  }]>;
}
/**
 * CDK Menu radio item with Taiga UI `TuiOption` appearance adapter.
 */
export declare class AtralumeMenuRadioItem {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeMenuRadioItem, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeMenuRadioItem, "button[atrMenuRadioItem]", never, {}, {}, never, never, true, [{
    directive: typeof i1.CdkMenuItemRadio;
    inputs: {
      "cdkMenuItemDisabled": "disabled";
      "cdkMenuItemChecked": "checked";
    };
    outputs: {
      "cdkMenuItemTriggered": "invoked";
    };
  }, {
    directive: typeof i2.TuiOption;
    inputs: {
      "disabled": "disabled";
    };
    outputs: {};
  }]>;
}
export declare class AtralumeMenuSeparator {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeMenuSeparator, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeMenuSeparator, "[atrMenuSeparator]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeMenuTrigger {
  private readonly trigger;
  private readonly engine;
  private readonly element;
  constructor();
  open(): void;
  close(): void;
  isOpen(): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeMenuTrigger, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeMenuTrigger, "[atrMenuTriggerFor]", ["atrMenuTrigger"], {}, {}, never, never, true, [{
    directive: typeof i1.CdkMenuTrigger;
    inputs: {
      "cdkMenuTriggerFor": "atrMenuTriggerFor";
    };
    outputs: {};
  }]>;
}
/**
 * Menu panel built on Angular CDK Menu.
 * Item appearance uses Taiga UI `TuiOption`; no Taiga menu service replaces CDK menu behavior.
 */
export declare class AtralumeMenu {
  private readonly menu;
  private readonly engine;
  private readonly element;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeMenu, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeMenu, "[atrMenu]", never, {}, {}, never, never, true, [{
    directive: typeof i1.CdkMenu;
    inputs: {};
    outputs: {};
  }]>;
}
export declare class AtralumeMenuHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  getAccessibleName(): Promise<string | null>;
  pressEscape(): Promise<void>;
}
export declare class AtralumeMenuItemHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  click(): Promise<void>;
  isDisabled(): Promise<boolean>;
  isChecked(): Promise<boolean>;
}
export declare class AtralumeMenuCheckboxItemHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  click(): Promise<void>;
  isDisabled(): Promise<boolean>;
  isChecked(): Promise<boolean>;
}
export declare class AtralumeMenuRadioItemHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  click(): Promise<void>;
  isDisabled(): Promise<boolean>;
  isChecked(): Promise<boolean>;
}
export declare class AtralumeMenuTriggerHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  click(): Promise<void>;
  isDisabled(): Promise<boolean>;
  isChecked(): Promise<boolean>;
}
export declare class AtralumeMenuGroupHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  click(): Promise<void>;
  isDisabled(): Promise<boolean>;
  isChecked(): Promise<boolean>;
}
export declare class AtralumeMenuSeparatorHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  click(): Promise<void>;
  isDisabled(): Promise<boolean>;
  isChecked(): Promise<boolean>;
}