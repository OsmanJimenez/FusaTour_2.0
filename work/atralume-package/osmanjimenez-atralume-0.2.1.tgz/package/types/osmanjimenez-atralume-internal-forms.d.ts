import * as i0 from "@angular/core";
import { DoCheck } from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";
import { FormValueControl } from "@angular/forms/signals";
/** @internal Common value bridge. User commits and external writes have distinct paths. */
declare abstract class AtralumeValueControl<T> implements ControlValueAccessor, FormValueControl<T | null>, DoCheck {
  readonly value: import("@angular/core").ModelSignal<T | null>;
  readonly label: import("@angular/core").InputSignal<string>;
  readonly controlId: import("@angular/core").InputSignal<string>;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly readonly: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly required: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly invalid: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly hint: import("@angular/core").InputSignal<string | null>;
  readonly error: import("@angular/core").InputSignal<string | null>;
  readonly touch: import("@angular/core").OutputEmitterRef<void>;
  readonly focused: import("@angular/core").WritableSignal<boolean>;
  readonly descriptions: import("@angular/core").WritableSignal<readonly string[]>;
  private readonly formDisabled;
  private readonly formInvalid;
  readonly blocked: import("@angular/core").Signal<boolean>;
  readonly displayInvalid: import("@angular/core").Signal<boolean>;
  protected readonly element: HTMLElement;
  private readonly controlInjector;
  private change;
  private onTouched;
  writeValue(value: T | null): void;
  registerOnChange(fn: (value: T | null) => void): void;
  registerOnTouched(fn: () => void): void;
  setDisabledState(disabled: boolean): void;
  ngDoCheck(): void;
  commit(value: T | null): void;
  markTouched(): void;
  protected blur(event: FocusEvent): void;
  focus(options?: FocusOptions): void;
  setDescribedByIds(ids: readonly string[]): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeValueControl<any>, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeValueControl<any>, never, never, {
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "controlId": {
      "alias": "controlId";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "readonly": {
      "alias": "readonly";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "hint": {
      "alias": "hint";
      "required": false;
      "isSignal": true;
    };
    "error": {
      "alias": "error";
      "required": false;
      "isSignal": true;
    };
  }, {
    "value": "valueChange";
    "touch": "touch";
  }, never, never, true, never>;
}
export { AtralumeValueControl as ɵAtralumeValueControl };