import * as i0 from "@angular/core";
import * as i1 from "@taiga-ui/core";
import { ComponentHarness } from "@angular/cdk/testing";
export type ButtonAppearance = "filled" | "tonal" | "outlined" | "text";
export type ButtonSize = "small" | "medium" | "large";
/**
 * Public Atralume button adapter over Taiga UI `TuiButton`.
 * Keeps Atralume selectors, appearances, sizes, loading, and tokens.
 */
export declare class AtralumeButton {
  readonly appearance: import("@angular/core").InputSignal<ButtonAppearance>;
  readonly size: import("@angular/core").InputSignal<ButtonSize>;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly loading: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly fullWidth: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly tabindex: import("@angular/core").InputSignal<string | number | null>;
  protected readonly nativeButton: boolean;
  protected readonly blocked: import("@angular/core").Signal<boolean>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeButton, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeButton, "button[atrButton], a[atrButton]", never, {
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "loading": {
      "alias": "loading";
      "required": false;
      "isSignal": true;
    };
    "fullWidth": {
      "alias": "fullWidth";
      "required": false;
      "isSignal": true;
    };
    "tabindex": {
      "alias": "tabindex";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, [{
    directive: typeof i1.TuiButton;
    inputs: {
      "size": "tuiSize";
    };
    outputs: {};
  }]>;
}
export declare class AtralumeButtonHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  getAppearance(): Promise<string | null>;
  getSize(): Promise<string | null>;
  isDisabled(): Promise<boolean>;
  isLoading(): Promise<boolean>;
  click(): Promise<void>;
}