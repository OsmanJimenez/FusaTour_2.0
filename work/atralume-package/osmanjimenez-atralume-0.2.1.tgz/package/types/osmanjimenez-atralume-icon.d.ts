import * as i0 from "@angular/core";
import { InjectionToken, Provider } from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
export type IconSize = "small" | "medium" | "large" | number;
export interface AtralumeIconDefinition {
  readonly name: string;
  readonly paths: readonly string[];
  readonly viewBox?: string;
  readonly mirrorInRtl?: boolean;
}
type AtralumeIconEngine = "registry" | "tui" | "auto";
/**
 * Dual icon host: keeps `atr-icon` + SVG registry, with an optional bridge to Taiga `TuiIcon`.
 * - `engine="registry"` (default): structured SVG paths via `provideAtralumeIcons`.
 * - `engine="tui"`: render `<tui-icon [icon]="name">` (CSS-mask / Taiga icon names).
 * - `engine="auto"`: registry hit → SVG; otherwise treat `name` as a Taiga icon key.
 * Full registry cutover is deferred (high blast radius across badge/button/avatar/playground).
 */
export declare class AtralumeIcon {
  readonly name: import("@angular/core").InputSignal<string>;
  readonly size: import("@angular/core").InputSignal<IconSize>;
  readonly decorative: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly label: import("@angular/core").InputSignal<string | null>;
  /** Optional bridge toward Taiga `TuiIcon` without breaking registry consumers. */
  readonly engine: import("@angular/core").InputSignal<AtralumeIconEngine>;
  private readonly registry;
  protected readonly definition: import("@angular/core").Signal<import("@osmanjimenez/atralume/icon").AtralumeIconDefinition | null | undefined>;
  protected readonly resolvedEngine: import("@angular/core").Signal<"registry" | "tui">;
  protected readonly pixelSize: import("@angular/core").Signal<string | null>;
  protected readonly accessibleLabel: import("@angular/core").Signal<string | null>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeIcon, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeIcon, "atr-icon", never, {
    "name": {
      "alias": "name";
      "required": true;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "decorative": {
      "alias": "decorative";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "engine": {
      "alias": "engine";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class AtralumeIconHarness extends ComponentHarness {
  static hostSelector: string;
  getName(): Promise<string | null>;
  getLabel(): Promise<string | null>;
  isDecorative(): Promise<boolean>;
  getSize(): Promise<string | null>;
}
export declare const checkIcon: {
  readonly name: "check";
  readonly paths: readonly ["M5 12l4 4L19 6"];
};
export declare const closeIcon: {
  readonly name: "close";
  readonly paths: readonly ["M6 6l12 12M6 18L18 6"];
};
export declare const arrowRightIcon: {
  readonly name: "arrow-right";
  readonly paths: readonly ["M5 12h14m-6-6 6 6-6 6"];
  readonly mirrorInRtl: true;
};
export declare const chevronDownIcon: {
  readonly name: "chevron-down";
  readonly paths: readonly ["m6 9 6 6 6-6"];
};
export declare const infoIcon: {
  readonly name: "info";
  readonly paths: readonly ["M12 11v6m0-10v1M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20"];
};
export declare const warningIcon: {
  readonly name: "warning";
  readonly paths: readonly ["M12 9v4m0 3v1M12 3 2 21h20L12 3"];
};
export declare const userIcon: {
  readonly name: "user";
  readonly paths: readonly ["M20 21v-2a7 7 0 0 0-14 0v2M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8"];
};
export declare const menuIcon: {
  readonly name: "menu";
  readonly paths: readonly ["M4 6h16M4 12h16M4 18h16"];
};
export declare const ATR_ICONS: InjectionToken<readonly AtralumeIconDefinition[]>;
export declare class AtralumeIconRegistry {
  private readonly parent;
  private readonly definitions;
  get(name: string): AtralumeIconDefinition | null;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeIconRegistry, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/** Register only developer-owned structured paths; never pass user-supplied SVG. One call per injector; arrays can be combined. */
export declare function provideAtralumeIcons(icons: readonly AtralumeIconDefinition[]): Provider[];
export type { AtralumeIconEngine };