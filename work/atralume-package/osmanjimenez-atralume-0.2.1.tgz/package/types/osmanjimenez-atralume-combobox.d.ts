import { FormControl } from "@angular/forms";
import { ɵAtralumeValueControl } from "@osmanjimenez/atralume/internal/forms";
import { AtralumeOptionData } from "@osmanjimenez/atralume/listbox";
import * as i0 from "@angular/core";
import * as i1 from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
type AutocompleteStrategy = "manual" | "automatic";
/** @deprecated Chips/multi moved to `tui-textfield[multi]` + chip controls. */
type SelectionDisplay = "text" | "count" | "chips";
/**
 * Thin Combobox recipe over Taiga `tuiComboBox` + `tui-data-list-wrapper`.
 *
 * Breaking: single value `T | string | null`; no custom overlay/listbox engine;
 * `multiple`/chips removed from this host.
 */
export declare class AtralumeCombobox<T> extends ɵAtralumeValueControl<T | string | null> {
  readonly options: import("@angular/core").InputSignal<readonly AtralumeOptionData<T>[]>;
  readonly query: import("@angular/core").ModelSignal<string>;
  readonly placeholder: import("@angular/core").InputSignal<string>;
  readonly clearable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly emptyText: import("@angular/core").InputSignal<string>;
  readonly strict: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly filterOptions: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly compareWith: import("@angular/core").InputSignal<(a: T, b: T) => boolean>;
  readonly displayWith: import("@angular/core").InputSignal<((value: T) => string) | null>;
  readonly items: import("@angular/core").Signal<T[]>;
  readonly stringify: import("@angular/core").Signal<(value: T) => string>;
  readonly identityMatcher: import("@angular/core").Signal<(a: T, b: T) => boolean>;
  readonly disabledItemHandler: import("@angular/core").Signal<(value: T) => boolean>;
  /** Inner CVA host for Taiga `tuiComboBox`. */
  protected readonly inner: FormControl<string | T | null>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeCombobox<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeCombobox<any>, "atr-combobox", never, {
    "options": {
      "alias": "options";
      "required": false;
      "isSignal": true;
    };
    "query": {
      "alias": "query";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "clearable": {
      "alias": "clearable";
      "required": false;
      "isSignal": true;
    };
    "emptyText": {
      "alias": "emptyText";
      "required": false;
      "isSignal": true;
    };
    "strict": {
      "alias": "strict";
      "required": false;
      "isSignal": true;
    };
    "filterOptions": {
      "alias": "filterOptions";
      "required": false;
      "isSignal": true;
    };
    "compareWith": {
      "alias": "compareWith";
      "required": false;
      "isSignal": true;
    };
    "displayWith": {
      "alias": "displayWith";
      "required": false;
      "isSignal": true;
    };
  }, {
    "query": "queryChange";
  }, never, never, true, never>;
}
/**
 * Thin adapter: `input[atrComboBox]` → Taiga `TuiComboBoxDirective`.
 *
 * Must sit inside consumer-authored `tui-textfield`. Pair with
 * `<tui-data-list-wrapper *tuiDropdown [items]="…" />`.
 * Forwards Taiga `strict` / `matcher`.
 */
export declare class AtralumeComboBoxDirective {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeComboBoxDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeComboBoxDirective, "input[atrComboBox]", never, {}, {}, never, never, true, [{
    directive: typeof i1.TuiComboBoxDirective;
    inputs: {
      "strict": "strict";
      "matcher": "matcher";
    };
    outputs: {};
  }]>;
}
export declare class AtralumeComboboxHarness extends ComponentHarness {
  static hostSelector: string;
  protected readonly control: () => Promise<import("@angular/cdk/testing").TestElement>;
  isOpen(): Promise<boolean>;
  open(): Promise<void>;
  close(): Promise<void>;
  isDisabled(): Promise<boolean>;
  getValue(): Promise<string>;
  enterText(value: string): Promise<void>;
  clear(): Promise<void>;
  selectOption(label: string): Promise<void>;
}
export type { AutocompleteStrategy, SelectionDisplay };