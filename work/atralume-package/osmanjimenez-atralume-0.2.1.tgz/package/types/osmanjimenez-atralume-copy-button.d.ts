import * as i0 from "@angular/core";
import * as i1 from "@taiga-ui/core";
import { ComponentHarness } from "@angular/cdk/testing";
/**
 * Brand adapter for clipboard copy on a native button.
 * Mirrors Taiga `TuiButtonCopy` (CDK Clipboard + `TuiButton`) because
 * `TuiButtonCopy` is an attribute component and cannot be used in hostDirectives.
 */
export declare class AtralumeCopyButton {
  private readonly clipboard;
  private readonly destroyRef;
  /** String written to the clipboard (Taiga `tuiButtonCopy` equivalent). */
  readonly text: import("@angular/core").InputSignal<string>;
  protected readonly copied: import("@angular/core").WritableSignal<boolean>;
  protected onCopy(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeCopyButton, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeCopyButton, "button[atrCopyButton]", never, {
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.TuiButton;
    inputs: {};
    outputs: {};
  }]>;
}
export declare class AtralumeCopyButtonHarness extends ComponentHarness {
  static hostSelector: string;
  getValue(): Promise<string | null>;
  isCopied(): Promise<boolean>;
  click(): Promise<void>;
  getText(): Promise<string>;
}