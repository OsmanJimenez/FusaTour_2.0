import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
interface AtralumeCarouselSlide {
  readonly id: string;
  readonly label: string;
  readonly description?: string;
}
/**
 * Thin carousel over Taiga `tui-carousel`.
 * Keeps the slides DTO; autoplay maps to `[duration]`.
 */
export declare class AtralumeCarousel {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly slides: import("@angular/core").InputSignal<readonly AtralumeCarouselSlide[]>;
  readonly activeIndex: import("@angular/core").ModelSignal<number>;
  readonly loop: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly autoplay: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly autoplayDelay: import("@angular/core").InputSignal<number>;
  readonly showIndicators: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly activeChange: import("@angular/core").OutputEmitterRef<number>;
  protected readonly duration: import("@angular/core").Signal<number>;
  protected readonly max: import("@angular/core").Signal<number>;
  protected onIndex(index: number): void;
  next(): void;
  previous(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeCarousel, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeCarousel, "atr-carousel", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "slides": {
      "alias": "slides";
      "required": false;
      "isSignal": true;
    };
    "activeIndex": {
      "alias": "activeIndex";
      "required": false;
      "isSignal": true;
    };
    "loop": {
      "alias": "loop";
      "required": false;
      "isSignal": true;
    };
    "autoplay": {
      "alias": "autoplay";
      "required": false;
      "isSignal": true;
    };
    "autoplayDelay": {
      "alias": "autoplayDelay";
      "required": false;
      "isSignal": true;
    };
    "showIndicators": {
      "alias": "showIndicators";
      "required": false;
      "isSignal": true;
    };
  }, {
    "activeIndex": "activeIndexChange";
    "activeChange": "activeChange";
  }, never, never, true, never>;
}
export declare class AtralumeCarouselHarness extends ComponentHarness {
  static hostSelector: string;
  getActiveSlide(): Promise<string>;
  next(): Promise<void>;
  previous(): Promise<void>;
  goToSlide(index: number): Promise<void>;
  pause(): Promise<void>;
  resume(): Promise<void>;
}
export type { AtralumeCarouselSlide };