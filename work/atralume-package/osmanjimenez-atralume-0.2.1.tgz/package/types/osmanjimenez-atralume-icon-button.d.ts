import * as i0 from "@angular/core";
import * as i1 from "@taiga-ui/core";
import { ComponentHarness } from "@angular/cdk/testing";
export type IconButtonAppearance = "standard" | "filled" | "tonal" | "outlined";
export type IconButtonSize = "small" | "medium" | "large";
/** Adapter over Taiga UI `TuiButton` (icon-button host); keeps Atralume API. */
export declare class AtralumeIconButton {
  readonly appearance: import("@angular/core").InputSignal<IconButtonAppearance>;
  readonly size: import("@angular/core").InputSignal<IconButtonSize>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeIconButton, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeIconButton, "button[atrIconButton]", never, {
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.TuiButton;
    inputs: {
      "size": "tuiSize";
    };
    outputs: {};
  }]>;
}
export declare class AtralumeIconButtonHarness extends ComponentHarness {
  static hostSelector: string;
  isDisabled(): Promise<boolean>;
  click(): Promise<void>;
  getAccessibleName(): Promise<string | null>;
}