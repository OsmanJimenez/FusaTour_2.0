import * as i0 from "@angular/core";
import * as i1 from "@taiga-ui/core/directives/appearance";
import * as i2 from "@taiga-ui/core/directives/icons";
import { ComponentHarness } from "@angular/cdk/testing";
/**
 * Native checkbox with Atralume tokens and Taiga appearance/icon primitives.
 *
 * Does not host `TuiCheckbox`: that attribute component disables the host when
 * no `NgControl` is present (`disabled: !control`), and using it as
 * `hostDirectives` fails at runtime. Styles come from `[attr.tuiCheckbox]`.
 *
 * Syncs `data-appearance` (primary ↔ outline-grayscale) and Taiga icons so the
 * control does not render as a dead black square.
 */
export declare class AtralumeCheckbox {
  readonly indeterminate: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  private readonly el;
  private readonly appearance;
  private readonly control;
  /** Check / indeterminate glyphs used by `[tuiCheckbox]::before` masks. */
  private readonly checkIcon;
  private readonly indeterminateIcon;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeCheckbox, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeCheckbox, "input[type=\"checkbox\"][atrCheckbox]", never, {
    "indeterminate": {
      "alias": "indeterminate";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.TuiAppearance;
    inputs: {
      "tuiAppearanceState": "tuiAppearanceState";
      "tuiAppearanceFocus": "tuiAppearanceFocus";
      "tuiAppearanceMode": "tuiAppearanceMode";
    };
    outputs: {};
  }, {
    directive: typeof i2.TuiIcons;
    inputs: {};
    outputs: {};
  }]>;
}
export declare class AtralumeCheckboxHarness extends ComponentHarness {
  static hostSelector: string;
  isChecked(): Promise<boolean>;
  toggle(): Promise<void>;
  check(): Promise<void>;
  uncheck(): Promise<void>;
  isIndeterminate(): Promise<boolean>;
  isDisabled(): Promise<boolean>;
}