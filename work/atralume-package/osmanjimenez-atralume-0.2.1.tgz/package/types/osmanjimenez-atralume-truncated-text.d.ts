import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
/**
 * Composition over Taiga UI `TuiLineClamp`.
 * Pass text through the `content` input; overflow can emit `overflownChange`.
 */
export declare class AtralumeTruncatedText {
  readonly content: import("@angular/core").InputSignal<string>;
  readonly lines: import("@angular/core").InputSignalWithTransform<number, number | undefined>;
  readonly lineHeight: import("@angular/core").InputSignalWithTransform<number, number | undefined>;
  readonly showHint: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly overflownChange: import("@angular/core").OutputEmitterRef<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeTruncatedText, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeTruncatedText, "atr-truncated-text", never, {
    "content": {
      "alias": "content";
      "required": false;
      "isSignal": true;
    };
    "lines": {
      "alias": "lines";
      "required": false;
      "isSignal": true;
    };
    "lineHeight": {
      "alias": "lineHeight";
      "required": false;
      "isSignal": true;
    };
    "showHint": {
      "alias": "showHint";
      "required": false;
      "isSignal": true;
    };
  }, {
    "overflownChange": "overflownChange";
  }, never, never, true, never>;
}
export declare class AtralumeTruncatedTextHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}