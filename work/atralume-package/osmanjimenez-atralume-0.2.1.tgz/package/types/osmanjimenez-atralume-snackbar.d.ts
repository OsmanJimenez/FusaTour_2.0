import * as i0 from "@angular/core";
import { DestroyRef, InjectionToken } from "@angular/core";
import { Observable } from "rxjs";
import { ComponentHarness } from "@angular/cdk/testing";
type SnackbarTone = "neutral" | "success" | "info" | "warning" | "error";
type SnackbarResult = "action" | "dismiss" | "timeout" | "replaced";
interface SnackbarConfig {
  message: string;
  action?: string;
  dismissLabel?: string;
  duration?: number;
  tone?: SnackbarTone;
  position?: "top" | "bottom";
  policy?: "queue" | "replace" | "ignore";
  origin?: HTMLElement;
  owner?: DestroyRef;
}
export declare class AtralumeSnackbarRef {
  readonly afterClosed: Observable<SnackbarResult>;
  private readonly closeFn;
  constructor(afterClosed: Observable<SnackbarResult>, closeFn: (result: SnackbarResult) => void);
  dismiss(): void;
  action(): void;
}
interface SnackbarSession {
  config: SnackbarConfig;
  ref: AtralumeSnackbarRef;
  pause(reason: string): void;
  resume(reason: string): void;
}
declare const SNACKBAR_SESSION: InjectionToken<SnackbarSession>;
/**
 * Adapter over Taiga UI `TuiNotificationService`.
 * Preserves AtralumeSnackbar / AtralumeSnackbarRef and queue policies.
 */
export declare class AtralumeSnackbar {
  private readonly notifications;
  private readonly injector;
  private readonly destroy;
  private queue;
  private current?;
  constructor();
  open(config: SnackbarConfig): AtralumeSnackbarRef;
  dismiss(): void;
  private show;
  private finish;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeSnackbar, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class AtralumeSnackbarHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  getAccessibleName(): Promise<string | null>;
  pressEscape(): Promise<void>;
}
export type { SnackbarConfig, SnackbarResult, SnackbarTone };