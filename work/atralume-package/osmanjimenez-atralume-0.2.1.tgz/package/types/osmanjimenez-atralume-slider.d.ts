import { FormControl, ValidationErrors, Validator } from "@angular/forms";
import { ɵAtralumeValueControl } from "@osmanjimenez/atralume/internal/forms";
import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
interface AtralumeSliderRange {
  readonly start: number;
  readonly end: number;
}
/** @internal Native range controls retain pointer/touch/keyboard behavior. */
declare abstract class AtralumeSliderBase<T> extends ɵAtralumeValueControl<T> {
  protected abstract lower(): number;
  protected abstract upper(): number;
  readonly step: import("@angular/core").InputSignal<number>;
  readonly continuous: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly orientation: import("@angular/core").InputSignal<"horizontal" | "vertical">;
  readonly inverted: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly showTicks: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly displayWith: import("@angular/core").InputSignal<(value: number) => string>;
  private validatorChanged;
  protected readonly ticks: import("@angular/core").Signal<string>;
  constructor();
  registerOnValidatorChange(fn: () => void): void;
  normalize(value: number): number;
  protected guard(event: Event): void;
  protected page(event: KeyboardEvent, current: number, change: (value: number) => void): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeSliderBase<any>, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeSliderBase<any>, never, never, {
    "step": {
      "alias": "step";
      "required": false;
      "isSignal": true;
    };
    "continuous": {
      "alias": "continuous";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "inverted": {
      "alias": "inverted";
      "required": false;
      "isSignal": true;
    };
    "showTicks": {
      "alias": "showTicks";
      "required": false;
      "isSignal": true;
    };
    "displayWith": {
      "alias": "displayWith";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * Composition over Taiga UI `TuiSliderComponent` on the native range input.
 * Keeps the public `atr-slider` host, forms API, and `--atr-*` tokens.
 */
export declare class AtralumeSlider extends AtralumeSliderBase<number> implements Validator {
  readonly min: import("@angular/core").InputSignalWithTransform<number, number | undefined>;
  readonly max: import("@angular/core").InputSignalWithTransform<number, number | undefined>;
  protected lower(): number;
  protected upper(): number;
  readonly displayed: import("@angular/core").Signal<number>;
  readonly fill: import("@angular/core").Signal<number>;
  /** Visual tick count for Taiga `TuiSliderComponent` segments. */
  protected readonly segments: import("@angular/core").Signal<number>;
  protected input(event: Event): void;
  protected key(event: KeyboardEvent): void;
  validate(): ValidationErrors | null;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeSlider, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeSlider, "atr-slider", never, {
    "min": {
      "alias": "min";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * Thin range recipe over Taiga `tui-range`.
 * Public value stays `{ start, end }`; inner FormControl syncs `[number, number]`
 * to the Taiga CVA (no stacked ngModel).
 */
export declare class AtralumeRangeSlider extends AtralumeSliderBase<AtralumeSliderRange> implements Validator {
  readonly minimum: import("@angular/core").InputSignalWithTransform<number, number | undefined>;
  readonly maximum: import("@angular/core").InputSignalWithTransform<number, number | undefined>;
  protected lower(): number;
  protected upper(): number;
  readonly startLabel: import("@angular/core").InputSignal<string | null>;
  readonly endLabel: import("@angular/core").InputSignal<string | null>;
  readonly displayed: import("@angular/core").Signal<{
    start: number;
    end: number;
  }>;
  /** Visual tick count for Taiga `TuiRange` segments. */
  protected readonly segments: import("@angular/core").Signal<number>;
  protected readonly rangeStep: import("@angular/core").Signal<number>;
  /** Inner CVA host for Taiga `tui-range`. */
  protected readonly inner: FormControl<[number, number]>;
  constructor();
  validate(): ValidationErrors | null;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeRangeSlider, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeRangeSlider, "atr-range-slider", never, {
    "minimum": {
      "alias": "minimum";
      "required": false;
      "isSignal": true;
    };
    "maximum": {
      "alias": "maximum";
      "required": false;
      "isSignal": true;
    };
    "startLabel": {
      "alias": "startLabel";
      "required": false;
      "isSignal": true;
    };
    "endLabel": {
      "alias": "endLabel";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class AtralumeSliderHarness extends ComponentHarness {
  static hostSelector: string;
  private readonly input;
  getValue(): Promise<number>;
  setValue(value: number): Promise<void>;
  increment(): Promise<void>;
  decrement(): Promise<void>;
  getThumbLabels(): Promise<string[]>;
  isDisabled(): Promise<boolean>;
}
export declare class AtralumeRangeSliderHarness extends ComponentHarness {
  static hostSelector: string;
  private readonly range;
  private readonly inputs;
  getValue(): Promise<AtralumeSliderRange>;
  setValue(value: AtralumeSliderRange): Promise<void>;
  increment(thumb?: "start" | "end"): Promise<void>;
  decrement(thumb?: "start" | "end"): Promise<void>;
  getThumbLabels(): Promise<string[]>;
  isDisabled(): Promise<boolean>;
}
export type { AtralumeSliderRange };