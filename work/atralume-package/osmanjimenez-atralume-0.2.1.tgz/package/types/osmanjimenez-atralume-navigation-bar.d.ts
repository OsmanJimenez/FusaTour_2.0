import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
/**
 * Thin host over Taiga `nav[tuiNavigationNav]` (`TuiNavigation`).
 * Breaking: `nav[atrNavigationBar]` → `<atr-navigation-bar>`.
 */
export declare class AtralumeNavigationBar {
  readonly label: import("@angular/core").InputSignal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeNavigationBar, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeNavigationBar, "atr-navigation-bar", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
export declare class AtralumeNavigationBarHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeNavigationItem {
  readonly active: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeNavigationItem, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeNavigationItem, "a[atrNavigationItem]", never, {
    "active": {
      "alias": "active";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class AtralumeNavigationItemHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  isSelected(): Promise<boolean>;
}