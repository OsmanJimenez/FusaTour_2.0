import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
import * as i1 from "@taiga-ui/layout";
export declare class AtralumeCardActions {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeCardActions, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeCardActions, "[atrCardActions]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeCardActionsHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeCardContent {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeCardContent, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeCardContent, "[atrCardContent]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeCardContentHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeCardHeader {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeCardHeader, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeCardHeader, "[atrCardHeader]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeCardHeaderHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeCardMedia {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeCardMedia, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeCardMedia, "[atrCardMedia]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeCardMediaHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
/** Adapter over Taiga UI `TuiCardLarge`; keeps Atralume appearances and slots. */
export declare class AtralumeCard {
  readonly appearance: import("@angular/core").InputSignal<"filled" | "elevated" | "outlined" | "glass">;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeCard, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeCard, "atr-card", never, {
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, [{
    directive: typeof i1.TuiCardLarge;
    inputs: {};
    outputs: {};
  }]>;
}
export declare class AtralumeCardHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}