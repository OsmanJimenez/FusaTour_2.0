import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
import * as i1 from "@taiga-ui/layout";
export declare class AtralumeListHeadline {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeListHeadline, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeListHeadline, "[atrListHeadline]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeListHeadlineHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeListItem {
  readonly selected: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeListItem, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeListItem, "li[atrListItem], a[atrListItem], button[atrListItem]", never, {
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class AtralumeListItemHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeListLeading {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeListLeading, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeListLeading, "[atrListLeading]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeListLeadingHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeListMetadata {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeListMetadata, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeListMetadata, "[atrListMetadata]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeListMetadataHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeListSupporting {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeListSupporting, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeListSupporting, "[atrListSupporting]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeListSupportingHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeListTrailing {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeListTrailing, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeListTrailing, "[atrListTrailing]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeListTrailingHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
/** Adapter over Taiga UI `TuiList`; keeps Atralume density tokens. */
export declare class AtralumeList {
  readonly density: import("@angular/core").InputSignal<"comfortable" | "compact">;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeList, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeList, "ul[atrList], ol[atrList]", never, {
    "density": {
      "alias": "density";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.TuiList;
    inputs: {
      "tuiList": "tuiSize";
    };
    outputs: {};
  }]>;
}
export declare class AtralumeListHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}