import * as i0 from "@angular/core";
import { DestroyRef, InjectionToken, Injector, TemplateRef, Type, ViewContainerRef } from "@angular/core";
import { Observable } from "rxjs";
import { ComponentHarness } from "@angular/cdk/testing";
export declare class AtralumeBottomSheetActions {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeBottomSheetActions, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeBottomSheetActions, "[atrBottomSheetActions]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeBottomSheetClose<R = unknown> {
  readonly atrBottomSheetClose: import("@angular/core").InputSignal<R | undefined>;
  private readonly ref;
  close(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeBottomSheetClose<any>, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeBottomSheetClose<any>, "button[atrBottomSheetClose]", never, {
    "atrBottomSheetClose": {
      "alias": "atrBottomSheetClose";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class AtralumeBottomSheetContent {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeBottomSheetContent, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeBottomSheetContent, "[atrBottomSheetContent]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeBottomSheetTitle {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeBottomSheetTitle, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeBottomSheetTitle, "[atrBottomSheetTitle]", never, {}, {}, never, never, true, never>;
}
/**
 * Bottom sheet over Taiga `TuiDialogService` with `appearance: atr-bottom-sheet`.
 * `TuiDrawer` is horizontal-only; sheet chrome is CSS on the dialog appearance.
 */
export declare const ATR_BOTTOM_SHEET_DATA: InjectionToken<unknown>;
export interface AtralumeBottomSheetConfig<D> {
  data?: D;
  origin?: HTMLElement;
  label?: string;
  labelledBy?: string;
  describedBy?: string;
  role?: "dialog" | "alertdialog";
  disableClose?: boolean;
  autoFocus?: "dialog" | "first-tabbable" | "first-heading";
  restoreFocus?: boolean;
  owner?: DestroyRef;
  injector?: Injector;
  viewContainerRef?: ViewContainerRef;
  contextClasses?: readonly string[];
  closeOnNavigation?: boolean;
  /** Retained for API compatibility; Taiga dialogs are modal. */
  mode?: "modal" | "standard";
}
export declare class AtralumeBottomSheetRef<R = unknown> {
  readonly afterClosed: Observable<R | undefined>;
  private readonly closeFn;
  constructor(afterClosed: Observable<R | undefined>, closeFn: (result?: R) => void);
  close(result?: R): void;
}
export declare class AtralumeBottomSheet {
  private readonly dialogs;
  private readonly injector;
  private readonly overlays;
  open<T, D = unknown, R = unknown>(content: Type<T> | TemplateRef<T>, config?: AtralumeBottomSheetConfig<D>): AtralumeBottomSheetRef<R>;
  private applyPortalChrome;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeBottomSheet, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class AtralumeBottomSheetHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  getAccessibleName(): Promise<string | null>;
  pressEscape(): Promise<void>;
}
export declare class AtralumeBottomSheetActionsHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeBottomSheetCloseHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeBottomSheetContentHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeBottomSheetTitleHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}