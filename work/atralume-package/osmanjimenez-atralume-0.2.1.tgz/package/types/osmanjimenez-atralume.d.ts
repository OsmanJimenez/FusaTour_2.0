import * as i0 from "@angular/core";
import { DoCheck, EnvironmentProviders, InjectionToken, Signal } from "@angular/core";
/**
 * Application bootstrap for Atralume as a brand layer over Taiga UI.
 *
 * Registers Taiga runtime providers. Load `@osmanjimenez/atralume/styles/theme.css`
 * once and set brand modes on a scope:
 * - `data-atr-theme="light|dark|system"`
 * - `data-atr-surface="standard|elevated|glass|transparent"`
 * - `data-atr-shape="rounded|sharp|pill"`
 * - `data-atr-brand="default|green"`
 *
 * Modes remap Atralume tokens; the token bridge pushes them into Taiga's
 * `--tui-*` theme surface so every Taiga-backed control updates together.
 */
export declare function provideAtralume(): EnvironmentProviders;
/** @internal Application-scoped counters are isolated between SSR requests. */
declare class AtralumeControlIds {
  private next;
  create(): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeControlIds, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/** @internal Shared across secondary entrypoints; not a consumer extension API. */
interface AtralumeFormFieldControl {
  readonly controlId: Signal<string>;
  readonly disabled: Signal<boolean>;
  readonly readonly: Signal<boolean>;
  readonly invalid: Signal<boolean>;
  readonly focused: Signal<boolean>;
  setDescribedByIds(ids: readonly string[]): void;
}
/** @internal */
declare const ATR_FORM_FIELD_CONTROL: InjectionToken<AtralumeFormFieldControl>;
/** @internal Reads native state; Angular keeps ownership of its value accessor. */
declare abstract class AtralumeNativeTextControl implements AtralumeFormFieldControl, DoCheck {
  protected readonly element: HTMLInputElement | HTMLTextAreaElement;
  readonly controlId: import("@angular/core").WritableSignal<string>;
  readonly disabled: import("@angular/core").WritableSignal<boolean>;
  readonly readonly: import("@angular/core").WritableSignal<boolean>;
  readonly invalid: import("@angular/core").WritableSignal<boolean>;
  readonly focused: import("@angular/core").WritableSignal<boolean>;
  private describedBy;
  constructor();
  ngDoCheck(): void;
  setDescribedByIds(ids: readonly string[]): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeNativeTextControl, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeNativeTextControl, never, never, {}, {}, never, never, true, never>;
}
type OverlayKind = "tooltip" | "menu" | "snackbar" | "bottom-sheet" | "dialog" | "critical";
/**
 * Shared portal helpers for CDK Menu (theme attrs, token copy, Escape stack).
 * Dialog / bottom-sheet / popover / snackbar / tooltip open paths were removed
 * after those families moved onto Taiga services.
 */
declare class AtralumeOverlayInfrastructure {
  readonly browser: boolean;
  private readonly renderer;
  private readonly dismissals;
  private readonly document;
  private readonly destroy;
  private readonly layers;
  private layer;
  constructor();
  registerDismissal(node: HTMLElement, close: () => void): () => void;
  decorate(panel: HTMLElement, origin?: HTMLElement, kind?: OverlayKind, classes?: readonly string[]): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeOverlayInfrastructure, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Root entry point for Atralume foundations (brand layer over Taiga UI).
 * Components are exported from explicit secondary entry points.
 */
export declare const ATRALUME_VERSION = "0.0.0";
export { ATR_FORM_FIELD_CONTROL as ɵATR_FORM_FIELD_CONTROL, AtralumeControlIds as ɵAtralumeControlIds, type AtralumeFormFieldControl as ɵAtralumeFormFieldControl, AtralumeNativeTextControl as ɵAtralumeNativeTextControl, AtralumeOverlayInfrastructure as ɵAtralumeOverlayInfrastructure, type OverlayKind as ɵOverlayKind };