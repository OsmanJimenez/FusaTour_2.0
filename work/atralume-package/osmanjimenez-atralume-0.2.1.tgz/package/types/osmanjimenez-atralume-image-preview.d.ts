import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
interface AtralumePreviewImage {
  readonly src: string;
  readonly alt: string;
  readonly title?: string;
  readonly description?: string;
  readonly fallbackSrc?: string;
}
/** A trigger that presents one or more images in the shared Atralume dialog with Taiga zoom. */
export declare class AtralumeImagePreview {
  readonly images: import("@angular/core").InputSignal<readonly AtralumePreviewImage[]>;
  readonly activeIndex: import("@angular/core").ModelSignal<number>;
  readonly label: import("@angular/core").InputSignal<string>;
  readonly triggerLabel: import("@angular/core").InputSignal<string>;
  readonly zoomable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly rotatable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly showTrigger: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly closed: import("@angular/core").OutputEmitterRef<void>;
  private readonly dialog;
  private readonly destroyRef;
  private readonly trigger;
  open(origin?: HTMLElement | undefined): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeImagePreview, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeImagePreview, "atr-image-preview", never, {
    "images": {
      "alias": "images";
      "required": true;
      "isSignal": true;
    };
    "activeIndex": {
      "alias": "activeIndex";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "triggerLabel": {
      "alias": "triggerLabel";
      "required": false;
      "isSignal": true;
    };
    "zoomable": {
      "alias": "zoomable";
      "required": false;
      "isSignal": true;
    };
    "rotatable": {
      "alias": "rotatable";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "showTrigger": {
      "alias": "showTrigger";
      "required": false;
      "isSignal": true;
    };
  }, {
    "activeIndex": "activeIndexChange";
    "closed": "closed";
  }, never, never, true, never>;
}
export declare class AtralumeImagePreviewHarness extends ComponentHarness {
  static hostSelector: string;
  open(): Promise<void>;
  isTriggerDisabled(): Promise<boolean>;
}
export type { AtralumePreviewImage };