import { FormControl, ValidationErrors, Validator } from "@angular/forms";
import { TuiDay, TuiDayRange } from "@taiga-ui/cdk/date-time";
import { ɵAtralumeValueControl } from "@osmanjimenez/atralume/internal/forms";
import { AtralumeCalendarHarness, AtralumeDateAdapter, AtralumeDateRange, AtralumeDateRange as AtralumeDateRange$1, provideAtralumeNativeDateAdapter } from "@osmanjimenez/atralume/calendar";
import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
type AtralumeDatePickerValue<D = Date> = D | AtralumeDateRange$1<D>;
/**
 * Thin date picker over Taiga `tuiInputDate` / `tuiInputDateRange`.
 * Public value stays `Date` / `{ start, end }`; inner FormControl holds CDK types.
 */
export declare class AtralumeDatePicker extends ɵAtralumeValueControl<AtralumeDatePickerValue<Date>> implements Validator {
  readonly selectionMode: import("@angular/core").InputSignal<"single" | "range">;
  readonly min: import("@angular/core").InputSignal<Date | null>;
  readonly max: import("@angular/core").InputSignal<Date | null>;
  readonly dateFilter: import("@angular/core").InputSignal<(value: Date) => boolean>;
  readonly clearable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Kept for API compatibility; Taiga dropdown replaces popover/dialog. */
  readonly presentation: import("@angular/core").InputSignal<"popover" | "dialog">;
  readonly visibleDate: import("@angular/core").InputSignal<Date | null>;
  protected readonly tuiMin: import("@angular/core").Signal<TuiDay | undefined>;
  protected readonly tuiMax: import("@angular/core").Signal<TuiDay | undefined>;
  protected readonly disabledItemHandler: import("@angular/core").Signal<(day: TuiDay) => boolean>;
  protected readonly single: FormControl<TuiDay | null>;
  protected readonly range: FormControl<TuiDayRange | null>;
  private validatorChanged;
  constructor();
  validate(): ValidationErrors | null;
  registerOnValidatorChange(fn: () => void): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeDatePicker, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeDatePicker, "atr-date-picker", never, {
    "selectionMode": {
      "alias": "selectionMode";
      "required": false;
      "isSignal": true;
    };
    "min": {
      "alias": "min";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
    "dateFilter": {
      "alias": "dateFilter";
      "required": false;
      "isSignal": true;
    };
    "clearable": {
      "alias": "clearable";
      "required": false;
      "isSignal": true;
    };
    "presentation": {
      "alias": "presentation";
      "required": false;
      "isSignal": true;
    };
    "visibleDate": {
      "alias": "visibleDate";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class AtralumeDatePickerHarness extends ComponentHarness {
  static hostSelector: string;
  private readonly input;
  openCalendar(): Promise<void>;
  close(): Promise<void>;
  getValue(): Promise<string>;
  enterText(value: string): Promise<void>;
  getCalendar(): Promise<AtralumeCalendarHarness>;
  navigateMonth(direction?: "next" | "previous"): Promise<void>;
  selectDate(id: string): Promise<void>;
  clear(): Promise<void>;
  isDisabled(): Promise<boolean>;
}
export { AtralumeDateAdapter, type AtralumeDatePickerValue, type AtralumeDateRange, provideAtralumeNativeDateAdapter };