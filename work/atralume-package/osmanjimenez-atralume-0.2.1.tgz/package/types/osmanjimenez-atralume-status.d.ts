import * as i0 from "@angular/core";
import * as i1 from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
export type StatusTone = "neutral" | "success" | "warning" | "error" | "info" | "primary";
export type StatusSize = "small" | "medium" | "large";
/**
 * Adapter over Taiga UI `TuiStatus`. Tone paints via CSS when `color` is empty.
 */
export declare class AtralumeStatus {
  readonly tone: import("@angular/core").InputSignal<StatusTone>;
  /** Raw CSS color for Taiga `--t-status`; empty lets tone CSS apply. */
  readonly color: import("@angular/core").InputSignal<string>;
  readonly size: import("@angular/core").InputSignal<StatusSize>;
  protected readonly dataSize: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeStatus, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeStatus, "[atrStatus]", never, {
    "tone": {
      "alias": "tone";
      "required": false;
      "isSignal": true;
    };
    "color": {
      "alias": "color";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.TuiStatus;
    inputs: {
      "tuiStatus": "color";
    };
    outputs: {};
  }]>;
}
export declare class AtralumeStatusHarness extends ComponentHarness {
  static hostSelector: string;
  getTone(): Promise<string | null>;
  getSize(): Promise<string | null>;
  getText(): Promise<string>;
}