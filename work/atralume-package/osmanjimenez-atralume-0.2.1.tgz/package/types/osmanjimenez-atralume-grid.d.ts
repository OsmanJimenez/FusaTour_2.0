import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
type AtralumeGridColumns = number | "auto";
type AtralumeGridGap = "none" | "xs" | "sm" | "md" | "lg" | "xl";
/**
 * Lightweight CSS grid layout host. No Taiga grid primitive; columns/gap are
 * tokenized via `--atr-comp-grid-*` with a min-track floor for auto-fill.
 */
export declare class AtralumeGrid {
  /** Fixed column count, or `"auto"` for auto-fill by `minTrack`. */
  readonly columns: import("@angular/core").InputSignal<AtralumeGridColumns>;
  readonly gap: import("@angular/core").InputSignal<AtralumeGridGap>;
  /** Minimum track size when `columns="auto"` (CSS length). */
  readonly minTrack: import("@angular/core").InputSignal<string>;
  protected readonly columnsAttr: import("@angular/core").Signal<string>;
  protected readonly columnsCss: import("@angular/core").Signal<string>;
  protected readonly gapCss: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeGrid, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeGrid, "atr-grid", never, {
    "columns": {
      "alias": "columns";
      "required": false;
      "isSignal": true;
    };
    "gap": {
      "alias": "gap";
      "required": false;
      "isSignal": true;
    };
    "minTrack": {
      "alias": "minTrack";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
type AtralumeGridSpan = 1 | 2 | 3 | 4 | "full";
/**
 * Optional span marker for children projected into `atr-grid`.
 */
export declare class AtralumeGridItem {
  readonly span: import("@angular/core").InputSignal<AtralumeGridSpan>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeGridItem, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeGridItem, "[atrGridItem]", never, {
    "span": {
      "alias": "span";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class AtralumeGridHarness extends ComponentHarness {
  static hostSelector: string;
  getColumns(): Promise<string | null>;
  getGap(): Promise<string | null>;
}
export declare class AtralumeGridItemHarness extends ComponentHarness {
  static hostSelector: string;
  getSpan(): Promise<string | null>;
}
export type { AtralumeGridColumns, AtralumeGridGap };