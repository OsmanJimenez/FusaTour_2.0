import * as i0 from "@angular/core";
import * as i1 from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
export type BadgeTone = "neutral" | "primary" | "success" | "warning" | "error" | "info";
export type BadgeAppearance = "filled" | "soft" | "outlined";
export type BadgeSize = "small" | "medium";
/** Adapter over Taiga UI `TuiBadge`; keeps Atralume tones, appearances, and count API. */
export declare class AtralumeBadge {
  readonly tone: import("@angular/core").InputSignal<BadgeTone>;
  readonly appearance: import("@angular/core").InputSignal<BadgeAppearance>;
  readonly size: import("@angular/core").InputSignal<BadgeSize>;
  readonly count: import("@angular/core").InputSignal<number | null>;
  readonly max: import("@angular/core").InputSignal<number>;
  readonly dot: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly label: import("@angular/core").InputSignal<string | null>;
  protected readonly displayCount: import("@angular/core").Signal<string | null>;
  protected readonly accessibleLabel: import("@angular/core").Signal<string | null>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeBadge, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeBadge, "atr-badge", never, {
    "tone": {
      "alias": "tone";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "count": {
      "alias": "count";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
    "dot": {
      "alias": "dot";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, [{
    directive: typeof i1.TuiBadge;
    inputs: {
      "size": "tuiSize";
    };
    outputs: {};
  }]>;
}
export declare class AtralumeBadgeHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  getTone(): Promise<string | null>;
  getAppearance(): Promise<string | null>;
}