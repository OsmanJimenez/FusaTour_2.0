import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
/**
 * Applies Atralume's accordion token scope to Taiga's native accordion host.
 *
 * `TuiAccordionComponent` discovers and pairs its direct child buttons and
 * expands. Keeping this as a directive, rather than wrapping the host in an
 * extra component, preserves that public Taiga contract.
 */
export declare class AtralumeAccordion {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeAccordion, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeAccordion, "tui-accordion[atrAccordion]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeAccordionHeader {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeAccordionHeader, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeAccordionHeader, "button[tuiAccordion][atrAccordionHeader]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeAccordionHeaderHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
/**
 * Marks a Taiga accordion trigger as an Atralume accordion item.
 *
 * The native button retains Taiga's public `tuiAccordion` behavior, including
 * keyboard activation, `aria-expanded`, and `aria-controls`.
 */
export declare class AtralumeAccordionItem {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeAccordionItem, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeAccordionItem, "button[tuiAccordion][atrAccordionItem]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeAccordionItemHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  isExpanded(): Promise<boolean>;
  toggle(): Promise<void>;
}
export declare class AtralumeAccordionPanel {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeAccordionPanel, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeAccordionPanel, "tui-expand[atrAccordionPanel]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeAccordionPanelHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeAccordionHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}