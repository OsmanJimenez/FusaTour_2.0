import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
export type KbdSize = "small" | "medium";
/**
 * Brands a native `kbd` element for shortcut hints with `--atr-comp-kbd-*` tokens.
 */
export declare class AtralumeKbd {
  readonly size: import("@angular/core").InputSignal<KbdSize>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeKbd, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeKbd, "kbd[atrKbd]", never, {
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class AtralumeKbdHarness extends ComponentHarness {
  static hostSelector: string;
  getSize(): Promise<string | null>;
  getText(): Promise<string>;
}