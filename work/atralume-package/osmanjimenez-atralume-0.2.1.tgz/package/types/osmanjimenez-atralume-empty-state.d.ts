import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
type AtralumeEmptyStateAppearance = "standard" | "compact";
/** Generic absence-of-content status, composed from Taiga's accessible block status. */
export declare class AtralumeEmptyState {
  readonly title: import("@angular/core").InputSignal<string>;
  readonly description: import("@angular/core").InputSignal<string | null>;
  readonly appearance: import("@angular/core").InputSignal<AtralumeEmptyStateAppearance>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeEmptyState, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeEmptyState, "atr-empty-state", never, {
    "title": {
      "alias": "title";
      "required": true;
      "isSignal": true;
    };
    "description": {
      "alias": "description";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["[atrEmptyStateIcon]", "*", "[atrEmptyStatePrimary]", "[atrEmptyStateSecondary]"], true, never>;
}
export declare class AtralumeEmptyStateHarness extends ComponentHarness {
  static hostSelector: string;
  getTitle(): Promise<string>;
  getDescription(): Promise<string | null>;
}
export type { AtralumeEmptyStateAppearance };