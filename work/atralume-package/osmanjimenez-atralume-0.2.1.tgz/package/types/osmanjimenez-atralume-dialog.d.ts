import * as i0 from "@angular/core";
import { DestroyRef, InjectionToken, Injector, TemplateRef, Type, ViewContainerRef } from "@angular/core";
import { Observable } from "rxjs";
import { ComponentHarness } from "@angular/cdk/testing";
export declare class AtralumeDialogActions {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeDialogActions, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeDialogActions, "[atrDialogActions]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeDialogClose<R = unknown> {
  readonly atrDialogClose: import("@angular/core").InputSignal<R | undefined>;
  private readonly ref;
  close(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeDialogClose<any>, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeDialogClose<any>, "button[atrDialogClose]", never, {
    "atrDialogClose": {
      "alias": "atrDialogClose";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class AtralumeDialogContent {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeDialogContent, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeDialogContent, "[atrDialogContent]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeDialogTitle {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeDialogTitle, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeDialogTitle, "[atrDialogTitle]", never, {}, {}, never, never, true, never>;
}
export declare const ATR_DIALOG_DATA: InjectionToken<unknown>;
export interface AtralumeDialogConfig<D> {
  data?: D;
  origin?: HTMLElement;
  label?: string;
  labelledBy?: string;
  describedBy?: string;
  role?: "dialog" | "alertdialog";
  disableClose?: boolean;
  /** When false, hides Taiga's header close control. Escape/backdrop still follow `disableClose`. */
  closable?: boolean;
  /** Taiga dialog size. `l` for wide surfaces; `null` sizes to content. */
  size?: "s" | "m" | "l" | null;
  /** Taiga `data-appearance`. Defaults to `atr-dialog`. */
  appearance?: string;
  autoFocus?: "dialog" | "first-tabbable" | "first-heading";
  restoreFocus?: boolean;
  owner?: DestroyRef;
  injector?: Injector;
  viewContainerRef?: ViewContainerRef;
  contextClasses?: readonly string[];
  closeOnNavigation?: boolean;
}
export declare class AtralumeDialogRef<R = unknown> {
  readonly afterClosed: Observable<R | undefined>;
  private readonly closeFn;
  constructor(afterClosed: Observable<R | undefined>, closeFn: (result?: R) => void);
  close(result?: R): void;
}
/**
 * Adapter over Taiga UI `TuiDialogService`.
 * Preserves AtralumeDialog / AtralumeDialogRef / ATR_DIALOG_DATA.
 */
export declare class AtralumeDialog {
  private readonly dialogs;
  private readonly injector;
  private readonly overlays;
  open<T, D = unknown, R = unknown>(content: Type<T> | TemplateRef<T>, config?: AtralumeDialogConfig<D>): AtralumeDialogRef<R>;
  /**
   * Taiga portals outside the trigger tree. Re-apply labelledBy/describedBy and
   * copy theme/dir/token context onto the mounted modal + dialog hosts.
   */
  private applyPortalChrome;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeDialog, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class AtralumeDialogHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  getAccessibleName(): Promise<string | null>;
  pressEscape(): Promise<void>;
}
export declare class AtralumeDialogActionsHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeDialogCloseHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeDialogContentHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeDialogTitleHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}