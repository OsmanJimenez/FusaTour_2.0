import * as i0 from "@angular/core";
import * as i1 from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
/**
 * Adapter over Taiga UI `TuiSkeleton`.
 * Keeps `atr-skeleton` with appearance/animation tokens.
 */
export declare class AtralumeSkeleton {
  /** Forwards to Taiga `tuiSkeleton`; dedicated placeholder is always active. */
  readonly active: import("@angular/core").InputSignal<boolean>;
  readonly appearance: import("@angular/core").InputSignal<"text" | "circle" | "rectangle" | "rounded">;
  readonly animation: import("@angular/core").InputSignal<"pulse" | "shimmer" | "none">;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeSkeleton, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeSkeleton, "atr-skeleton", never, {
    "active": {
      "alias": "active";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "animation": {
      "alias": "animation";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.TuiSkeleton;
    inputs: {
      "tuiSkeleton": "active";
    };
    outputs: {};
  }]>;
}
export declare class AtralumeSkeletonHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}