import { FormControl } from "@angular/forms";
import { ɵAtralumeValueControl } from "@osmanjimenez/atralume/internal/forms";
import { AtralumeOptionData, AtralumeOptionData as AtralumeOptionData$1, AtralumeOptionTemplateContext } from "@osmanjimenez/atralume/listbox";
import * as i0 from "@angular/core";
import * as i1 from "@taiga-ui/kit";
import { AtralumeComboboxHarness } from "@osmanjimenez/atralume/combobox";
/**
 * Thin Select recipe over Taiga `tuiSelect` + `tui-data-list-wrapper`.
 *
 * Breaking: single value `T | null` (no `multiple`/chips on this host). Use
 * `tui-textfield[multi]` + chip controls for multi. Overlay/listbox engines
 * removed — dropdown is Taiga's.
 */
export declare class AtralumeSelect<T> extends ɵAtralumeValueControl<T | null> {
  readonly options: import("@angular/core").InputSignal<readonly AtralumeOptionData$1<T>[]>;
  readonly placeholder: import("@angular/core").InputSignal<string>;
  readonly clearable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly emptyText: import("@angular/core").InputSignal<string>;
  readonly compareWith: import("@angular/core").InputSignal<(a: T, b: T) => boolean>;
  readonly displayWith: import("@angular/core").InputSignal<((value: T) => string) | null>;
  readonly items: import("@angular/core").Signal<T[]>;
  readonly stringify: import("@angular/core").Signal<(value: T) => string>;
  readonly identityMatcher: import("@angular/core").Signal<(a: T, b: T) => boolean>;
  readonly disabledItemHandler: import("@angular/core").Signal<(value: T) => boolean>;
  /** Inner CVA host for Taiga `tuiSelect` (avoid stacking ngModel on TuiControl). */
  protected readonly inner: FormControl<T | null>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeSelect<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeSelect<any>, "atr-select", never, {
    "options": {
      "alias": "options";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "clearable": {
      "alias": "clearable";
      "required": false;
      "isSignal": true;
    };
    "emptyText": {
      "alias": "emptyText";
      "required": false;
      "isSignal": true;
    };
    "compareWith": {
      "alias": "compareWith";
      "required": false;
      "isSignal": true;
    };
    "displayWith": {
      "alias": "displayWith";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * Thin adapter: `input[atrSelect]` → Taiga `TuiSelectDirective` (`tuiSelect`).
 *
 * Must sit inside consumer-authored `tui-textfield`. Pair with
 * `<tui-data-list-wrapper *tuiDropdown [items]="…" />`.
 */
export declare class AtralumeSelectDirective {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeSelectDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeSelectDirective, "input[atrSelect]", never, {}, {}, never, never, true, [{
    directive: typeof i1.TuiSelectDirective;
    inputs: {};
    outputs: {};
  }]>;
}
export declare class AtralumeSelectHarness extends AtralumeComboboxHarness {
  static hostSelector: string;
}
export type { AtralumeOptionData, AtralumeOptionTemplateContext };