import * as i0 from "@angular/core";
import * as i1 from "@taiga-ui/core/directives/appearance";
import { ComponentHarness } from "@angular/cdk/testing";
/**
 * Native switch (checkbox + role) with Atralume tokens and Taiga primitives.
 *
 * Does not host `TuiSwitch`: without `NgControl` Taiga forces `disabled`, and
 * the component token breaks as `hostDirectives`. Styles come from
 * `[attr.tuiSwitch]`. Thumb is painted by `.atr-switch::before` — no Taiga
 * check icon (`TuiIcons` / `tuiIconStart`) so the glyph never shows through.
 */
export declare class AtralumeSwitch {
  private readonly el;
  private readonly appearance;
  private readonly control;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeSwitch, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeSwitch, "input[type=\"checkbox\"][atrSwitch]", never, {}, {}, never, never, true, [{
    directive: typeof i1.TuiAppearance;
    inputs: {
      "tuiAppearanceState": "tuiAppearanceState";
      "tuiAppearanceFocus": "tuiAppearanceFocus";
      "tuiAppearanceMode": "tuiAppearanceMode";
    };
    outputs: {};
  }]>;
}
export declare class AtralumeSwitchHarness extends ComponentHarness {
  static hostSelector: string;
  isChecked(): Promise<boolean>;
  toggle(): Promise<void>;
  check(): Promise<void>;
  isDisabled(): Promise<boolean>;
}