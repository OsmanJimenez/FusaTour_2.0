import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
export type DividerOrientation = "horizontal" | "vertical";
export type DividerInset = "none" | "start" | "end" | "both";
/**
 * Minimal divider: native `hr` / separator semantics + `--atr-comp-divider-*` tokens.
 * No public Taiga divider primitive in core/kit/layout.
 */
export declare class AtralumeDivider {
  readonly orientation: import("@angular/core").InputSignal<DividerOrientation>;
  readonly inset: import("@angular/core").InputSignal<DividerInset>;
  readonly decorative: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeDivider, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeDivider, "[atrDivider]", never, {
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "inset": {
      "alias": "inset";
      "required": false;
      "isSignal": true;
    };
    "decorative": {
      "alias": "decorative";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class AtralumeDividerHarness extends ComponentHarness {
  static hostSelector: string;
  getOrientation(): Promise<string | null>;
  isDecorative(): Promise<boolean>;
}