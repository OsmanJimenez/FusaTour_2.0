import * as i0 from "@angular/core";
import { InjectionToken, TemplateRef } from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
/**
 * Step slot for `AtralumeStepper`.
 * Header chrome is rendered as `button[tuiStep]`; projected content is a panel.
 */
export declare class AtralumeStep {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly stepId: import("@angular/core").InputSignal<string>;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly stepState: import("@angular/core").InputSignal<"normal" | "pass" | "error">;
  readonly icon: import("@angular/core").InputSignal<string>;
  readonly content: import("@angular/core").Signal<TemplateRef<unknown> | undefined>;
  private readonly owner;
  belongsTo(owner: unknown): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeStep, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeStep, "atr-step", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "stepId": {
      "alias": "stepId";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "stepState": {
      "alias": "stepState";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
interface AtralumeStepChange {
  readonly previous: number;
  readonly current: number;
}
/**
 * Thin stepper recipe over Taiga `tui-stepper` + `button[tuiStep]`.
 * Consumers gate Next themselves; no linear/`AbstractControl` engine.
 */
export declare class AtralumeStepper {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly selected: import("@angular/core").ModelSignal<number>;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly orientation: import("@angular/core").InputSignal<"horizontal" | "vertical">;
  readonly stepChange: import("@angular/core").OutputEmitterRef<AtralumeStepChange>;
  private readonly projected;
  private readonly element;
  private readonly injector;
  readonly steps: import("@angular/core").Signal<AtralumeStep[]>;
  readonly activeIndex: import("@angular/core").Signal<number>;
  readonly activeStep: import("@angular/core").Signal<AtralumeStep>;
  readonly canNext: import("@angular/core").Signal<boolean>;
  readonly canPrevious: import("@angular/core").Signal<boolean>;
  activate(index: number): void;
  next(): void;
  previous(): void;
  reset(): void;
  protected onIndex(index: number): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeStepper, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeStepper, "atr-stepper", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selectedChange";
    "stepChange": "stepChange";
  }, ["projected"], ["*"], true, never>;
}
/** @internal */
interface StepperContext {
  next(): void;
  previous(): void;
}
declare const STEPPER_CONTEXT: InjectionToken<StepperContext>;
export declare class AtralumeStepperNext {
  protected readonly stepper: StepperContext;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeStepperNext, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeStepperNext, "button[atrStepperNext]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeStepperPrevious {
  protected readonly stepper: StepperContext;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeStepperPrevious, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeStepperPrevious, "button[atrStepperPrevious]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeStepperHarness extends ComponentHarness {
  static hostSelector: string;
  private readonly headers;
  getLabels(): Promise<string[]>;
  getActiveIndex(): Promise<number>;
  select(index: number): Promise<void>;
  next(): Promise<void>;
  previous(): Promise<void>;
  getContent(): Promise<string>;
}
export type { AtralumeStepChange };