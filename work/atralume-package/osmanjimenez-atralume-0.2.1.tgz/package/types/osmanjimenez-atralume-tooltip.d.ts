import * as i0 from "@angular/core";
import * as i1 from "@taiga-ui/core";
import { ComponentHarness } from "@angular/cdk/testing";
export type TooltipPosition = "above" | "below" | "before" | "after";
/**
 * Adapter over Taiga UI `TuiHintDirective`.
 * Forwards tooltip text and delays through `hostDirectives` input aliases.
 */
export declare class AtralumeTooltip {
  readonly atrTooltip: import("@angular/core").InputSignal<string>;
  /** Retained for a11y consumers; Taiga hint manages description ids. */
  readonly tooltipId: import("@angular/core").InputSignal<string>;
  /** Kept for API stability; Taiga hint direction defaults apply. */
  readonly position: import("@angular/core").InputSignal<TooltipPosition>;
  readonly showDelay: import("@angular/core").InputSignal<number>;
  readonly hideDelay: import("@angular/core").InputSignal<number>;
  /** When true, pass an empty `atrTooltip` to suppress the hint. */
  readonly tooltipDisabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeTooltip, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeTooltip, "[atrTooltip]", ["atrTooltip"], {
    "atrTooltip": {
      "alias": "atrTooltip";
      "required": true;
      "isSignal": true;
    };
    "tooltipId": {
      "alias": "tooltipId";
      "required": true;
      "isSignal": true;
    };
    "position": {
      "alias": "position";
      "required": false;
      "isSignal": true;
    };
    "showDelay": {
      "alias": "showDelay";
      "required": false;
      "isSignal": true;
    };
    "hideDelay": {
      "alias": "hideDelay";
      "required": false;
      "isSignal": true;
    };
    "tooltipDisabled": {
      "alias": "tooltipDisabled";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.TuiHintDirective;
    inputs: {
      "tuiHint": "atrTooltip";
    };
    outputs: {};
  }]>;
}
export declare class AtralumeTooltipHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  getAccessibleName(): Promise<string | null>;
  pressEscape(): Promise<void>;
}