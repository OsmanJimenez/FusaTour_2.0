import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
/**
 * Thin pagination over Taiga `tui-pagination`.
 * Public `page` stays 1-based; Taiga `index` is 0-based.
 */
export declare class AtralumePagination {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly page: import("@angular/core").ModelSignal<number>;
  readonly pageCount: import("@angular/core").InputSignal<number>;
  readonly siblingCount: import("@angular/core").InputSignal<number>;
  readonly loading: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** @deprecated Dropped — use router links around `tui-pagination` if needed. */
  readonly href: import("@angular/core").InputSignal<((page: number) => string) | null>;
  protected readonly total: import("@angular/core").Signal<number>;
  protected readonly index: import("@angular/core").Signal<number>;
  protected readonly activePadding: import("@angular/core").Signal<number>;
  protected readonly blocked: import("@angular/core").Signal<boolean>;
  constructor();
  protected onIndex(index: number): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumePagination, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumePagination, "atr-pagination", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "page": {
      "alias": "page";
      "required": false;
      "isSignal": true;
    };
    "pageCount": {
      "alias": "pageCount";
      "required": false;
      "isSignal": true;
    };
    "siblingCount": {
      "alias": "siblingCount";
      "required": false;
      "isSignal": true;
    };
    "loading": {
      "alias": "loading";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "href": {
      "alias": "href";
      "required": false;
      "isSignal": true;
    };
  }, {
    "page": "pageChange";
  }, never, never, true, never>;
}
export declare class AtralumePaginationHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  getCurrentPage(): Promise<number>;
}