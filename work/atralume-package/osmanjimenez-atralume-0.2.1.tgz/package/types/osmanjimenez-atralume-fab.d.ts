import * as i0 from "@angular/core";
import * as i1 from "@taiga-ui/core";
import { ComponentHarness } from "@angular/cdk/testing";
/** Extension over Taiga UI `TuiButton` with Atralume FAB appearances and sizes. */
export declare class AtralumeFab {
  readonly size: import("@angular/core").InputSignal<"small" | "medium" | "large">;
  readonly appearance: import("@angular/core").InputSignal<"primary" | "secondary" | "tertiary" | "surface">;
  readonly extended: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeFab, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeFab, "button[atrFab]", never, {
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "extended": {
      "alias": "extended";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.TuiButton;
    inputs: {
      "size": "tuiSize";
    };
    outputs: {};
  }]>;
}
export declare class AtralumeFabHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  click(): Promise<void>;
  isDisabled(): Promise<boolean>;
}
export { AtralumeFabHarness as AtralumeFloatingActionButtonHarness };