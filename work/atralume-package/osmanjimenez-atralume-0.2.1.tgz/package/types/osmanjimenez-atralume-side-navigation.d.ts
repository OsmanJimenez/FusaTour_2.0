import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
import * as i1 from "@taiga-ui/core";
/**
 * Layout host for side navigation; projects Taiga aside + `main[tuiNavigationMain]`.
 */
export declare class AtralumeSideNavigationContainer {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeSideNavigationContainer, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeSideNavigationContainer, "atr-side-navigation-container", never, {}, {}, never, ["atr-side-navigation, aside", "*"], true, never>;
}
export declare class AtralumeSideNavigationContainerHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
/**
 * Marks projected main content inside `atr-side-navigation-container`.
 * Breaking: host no longer needs `main[atrSideNavigationContent]`; container wraps content in `main[tuiNavigationMain]`.
 * Kept as a no-op marker for existing templates.
 */
export declare class AtralumeSideNavigationContent {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeSideNavigationContent, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeSideNavigationContent, "[atrSideNavigationContent]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeSideNavigationContentHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeSideNavigationGroup {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeSideNavigationGroup, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeSideNavigationGroup, "[atrSideNavigationGroup]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeSideNavigationGroupHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeSideNavigationHeader {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeSideNavigationHeader, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeSideNavigationHeader, "[atrSideNavigationHeader]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeSideNavigationHeaderHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
/**
 * Side-nav item styled with Taiga `TuiButton`.
 * Avoids `TuiAsideItemDirective` (injects `TuiAsideComponent` via hint host),
 * which fails under `ng-content` projection into `aside[tuiNavigationAside]`.
 *
 * Forces `flat` appearance so default TuiButton `primary` does not paint
 * on-accent text (invisible on dark surfaces without a filled background).
 */
export declare class AtralumeSideNavigationItem {
  readonly active: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Keep nav items flat; Atralume CSS owns active container colors. */
  private readonly _tuiAppearance;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeSideNavigationItem, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeSideNavigationItem, "a[atrSideNavigationItem], button[atrSideNavigationItem]", never, {
    "active": {
      "alias": "active";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.TuiButton;
    inputs: {
      "size": "tuiSize";
    };
    outputs: {};
  }]>;
}
export declare class AtralumeSideNavigationItemHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  isSelected(): Promise<boolean>;
}
export declare class AtralumeSideNavigationLabel {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeSideNavigationLabel, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeSideNavigationLabel, "[atrSideNavigationLabel]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeSideNavigationLabelHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export type SideNavigationMode = "side" | "over" | "push";
/**
 * Composes Taiga `aside[tuiNavigationAside]`.
 * Breaking: custom overlay engine for `mode="over"` removed; open/close is show/hide.
 * `collapsed` maps to Taiga `expanded` inverted (`!collapsed`).
 */
export declare class AtralumeSideNavigation {
  readonly panelId: import("@angular/core").InputSignal<string>;
  readonly label: import("@angular/core").InputSignal<string>;
  /** Kept for API compatibility; `over` no longer portals via overlay. */
  readonly mode: import("@angular/core").InputSignal<SideNavigationMode>;
  readonly opened: import("@angular/core").ModelSignal<boolean>;
  readonly collapsed: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** @deprecated Unused after overlay removal. */
  readonly origin: import("@angular/core").InputSignal<HTMLElement | null>;
  protected readonly expanded: import("@angular/core").Signal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeSideNavigation, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeSideNavigation, "atr-side-navigation", never, {
    "panelId": {
      "alias": "panelId";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
    "opened": {
      "alias": "opened";
      "required": false;
      "isSignal": true;
    };
    "collapsed": {
      "alias": "collapsed";
      "required": false;
      "isSignal": true;
    };
    "origin": {
      "alias": "origin";
      "required": false;
      "isSignal": true;
    };
  }, {
    "opened": "openedChange";
  }, never, ["header", "*", "footer"], true, never>;
}
export declare class AtralumeSideNavigationHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  isOpen(): Promise<boolean>;
}