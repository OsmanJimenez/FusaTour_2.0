import * as i0 from "@angular/core";
import { InjectionToken } from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
import * as i1 from "@taiga-ui/kit";
/** Composition around Taiga-backed `AtralumeChip`; no Taiga chip-group primitive. */
export declare class AtralumeChipSet {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly selection: import("@angular/core").InputSignal<"single" | "multiple">;
  readonly orientation: import("@angular/core").InputSignal<"horizontal" | "vertical">;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly selectionChange: import("@angular/core").OutputEmitterRef<readonly string[]>;
  private readonly chips;
  private readonly element;
  choose(value: string, selected: boolean): void;
  protected onKey(event: KeyboardEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeChipSet, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeChipSet, "atr-chip-set", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "selection": {
      "alias": "selection";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selectionChange": "selectionChange";
  }, ["chips"], ["*"], true, never>;
}
export declare class AtralumeChipSetHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
type ChipKind = "assist" | "filter" | "input" | "suggestion";
interface ChipSelectionContext {
  disabled(): boolean;
  choose(value: string, selected: boolean): void;
}
declare const CHIP_SET: InjectionToken<ChipSelectionContext>;
/** Extension over Taiga UI `TuiChip` with Atralume chip-set selection and remove API. */
export declare class AtralumeChip {
  readonly kind: import("@angular/core").InputSignal<ChipKind>;
  readonly value: import("@angular/core").InputSignal<string>;
  readonly label: import("@angular/core").InputSignal<string>;
  readonly selected: import("@angular/core").ModelSignal<boolean>;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly removable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly removed: import("@angular/core").OutputEmitterRef<string>;
  readonly invoked: import("@angular/core").OutputEmitterRef<string>;
  private readonly owner;
  protected readonly blocked: import("@angular/core").Signal<boolean>;
  private readonly button;
  activate(): void;
  focus(): void;
  remove(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeChip, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeChip, "atr-chip", never, {
    "kind": {
      "alias": "kind";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "removable": {
      "alias": "removable";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selectedChange";
    "removed": "removed";
    "invoked": "invoked";
  }, never, ["[atrChipLeading]", "*"], true, [{
    directive: typeof i1.TuiChip;
    inputs: {
      "size": "tuiSize";
    };
    outputs: {};
  }]>;
}
export declare class AtralumeChipHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  isSelected(): Promise<boolean>;
  select(): Promise<void>;
  remove(): Promise<void>;
}
export type { ChipKind };