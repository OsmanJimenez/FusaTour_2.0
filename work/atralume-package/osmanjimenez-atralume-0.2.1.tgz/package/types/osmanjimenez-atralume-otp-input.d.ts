import { FormControl, ValidationErrors, Validator } from "@angular/forms";
import { ɵAtralumeValueControl } from "@osmanjimenez/atralume/internal/forms";
import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
/**
 * Composition over Taiga UI `TuiInputPin` inside Form Field / textfield chrome.
 * Public value is `string | null`; incomplete codes emit `otpIncomplete`.
 */
export declare class AtralumeOtpInput extends ɵAtralumeValueControl<string> implements Validator {
  readonly length: import("@angular/core").InputSignalWithTransform<number, number | undefined>;
  protected readonly placeholderMask: import("@angular/core").Signal<string>;
  protected readonly inner: FormControl<string>;
  private validatorChanged;
  constructor();
  validate(): ValidationErrors | null;
  registerOnValidatorChange(fn: () => void): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeOtpInput, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeOtpInput, "atr-otp-input", never, {
    "length": {
      "alias": "length";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class AtralumeOtpInputHarness extends ComponentHarness {
  static hostSelector: string;
  private readonly input;
  getValue(): Promise<string>;
  setValue(value: string): Promise<void>;
  isDisabled(): Promise<boolean>;
}