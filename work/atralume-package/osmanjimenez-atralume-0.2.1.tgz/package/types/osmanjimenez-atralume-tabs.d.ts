import * as i0 from "@angular/core";
import { InjectionToken } from "@angular/core";
import * as i1 from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
interface TabContext {
  activeId(): string;
  activePanel(): string;
  focusId(): string;
  label(): string;
  orientation(): "horizontal" | "vertical";
  activate(id: string): void;
}
declare const TAB_CONTEXT: InjectionToken<TabContext>;
type TabActivation = "automatic" | "manual";
/**
 * Deepens the tab list shell onto Taiga `tui-tabs` (`TuiTabsHorizontal` → `TuiTabs`).
 * Breaking: host must be `<tui-tabs atrTabList>` (no plain `div[atrTabList]`).
 * Vertical: set `[vertical]` / `data-vertical` on the same `tui-tabs` when needed.
 */
export declare class AtralumeTabList {
  readonly underline: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  protected readonly owner: TabContext;
  private readonly tabs;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeTabList, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeTabList, "tui-tabs[atrTabList]", never, {
    "underline": {
      "alias": "underline";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.TuiTabsHorizontal;
    inputs: {
      "underline": "underline";
    };
    outputs: {};
  }]>;
}
export declare class AtralumeTabListHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeTabPanel {
  readonly id: import("@angular/core").InputSignal<string>;
  readonly labelledBy: import("@angular/core").InputSignal<string>;
  protected readonly owner: TabContext;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeTabPanel, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeTabPanel, "[atrTabPanel]", never, {
    "id": {
      "alias": "id";
      "required": true;
      "isSignal": true;
    };
    "labelledBy": {
      "alias": "labelledBy";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class AtralumeTabPanelHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  isSelected(): Promise<boolean>;
}
/** Adapter over Taiga UI `TuiTab`; Atralume owns id/panel selection state. */
export declare class AtralumeTab {
  readonly id: import("@angular/core").InputSignal<string>;
  readonly panel: import("@angular/core").InputSignal<string>;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  protected readonly owner: TabContext;
  private readonly element;
  activate(): void;
  focus(): void;
  belongsTo(owner: unknown): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeTab, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeTab, "button[atrTab]", never, {
    "id": {
      "alias": "id";
      "required": true;
      "isSignal": true;
    };
    "panel": {
      "alias": "panel";
      "required": true;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.TuiTab;
    inputs: {};
    outputs: {};
  }]>;
}
export declare class AtralumeTabHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  isSelected(): Promise<boolean>;
  click(): Promise<void>;
  isDisabled(): Promise<boolean>;
}
/**
 * Tabs container composing Taiga `tui-tabs` (`TuiTabs`) + `TuiTab` on triggers.
 * Keeps Atralume string-id selection, panels, and activation modes.
 * Project the list as `<tui-tabs atrTabList>`.
 */
export declare class AtralumeTabs {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly selected: import("@angular/core").ModelSignal<string>;
  readonly activation: import("@angular/core").InputSignal<TabActivation>;
  readonly orientation: import("@angular/core").InputSignal<"horizontal" | "vertical">;
  private readonly tabs;
  private readonly focused;
  private readonly element;
  readonly activeId: import("@angular/core").Signal<string>;
  readonly activePanel: import("@angular/core").Signal<string>;
  readonly focusId: import("@angular/core").Signal<string>;
  activate(id: string): void;
  protected onKey(event: KeyboardEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeTabs, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeTabs, "atr-tabs", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
    "activation": {
      "alias": "activation";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selectedChange";
  }, ["tabs"], ["*"], true, never>;
}
export declare class AtralumeTabsHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export type { TabActivation };