import { FormControl, ValidationErrors, Validator } from "@angular/forms";
import { ɵAtralumeValueControl } from "@osmanjimenez/atralume/internal/forms";
import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
/**
 * Composition over Taiga UI `TuiRating`.
 * Public value is `number | null`; inner FormControl uses Taiga's `0` fallback.
 */
export declare class AtralumeRating extends ɵAtralumeValueControl<number> implements Validator {
  readonly max: import("@angular/core").InputSignalWithTransform<number, number | undefined>;
  protected readonly inner: FormControl<number>;
  private validatorChanged;
  constructor();
  validate(): ValidationErrors | null;
  registerOnValidatorChange(fn: () => void): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeRating, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeRating, "atr-rating", never, {
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class AtralumeRatingHarness extends ComponentHarness {
  static hostSelector: string;
  private readonly range;
  getValue(): Promise<number>;
  isDisabled(): Promise<boolean>;
}