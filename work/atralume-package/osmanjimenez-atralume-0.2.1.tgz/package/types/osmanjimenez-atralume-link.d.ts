import * as i0 from "@angular/core";
import * as i1 from "@taiga-ui/core";
import { ComponentHarness } from "@angular/cdk/testing";
export type LinkAppearance = "inline" | "standalone";
export type LinkUnderline = "always" | "hover";
/** Adapter over Taiga UI `TuiLink`; keeps Atralume selector and underline API. */
export declare class AtralumeLink {
  readonly appearance: import("@angular/core").InputSignal<LinkAppearance>;
  readonly underline: import("@angular/core").InputSignal<LinkUnderline>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeLink, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeLink, "a[atrLink]", never, {
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "underline": {
      "alias": "underline";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.TuiLink;
    inputs: {};
    outputs: {};
  }]>;
}
export declare class AtralumeLinkHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  getHref(): Promise<string | null>;
  getAppearance(): Promise<string | null>;
}