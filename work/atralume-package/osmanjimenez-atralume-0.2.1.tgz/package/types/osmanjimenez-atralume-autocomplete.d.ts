import { ɵAtralumeValueControl } from "@osmanjimenez/atralume/internal/forms";
import { AtralumeOptionData, AtralumeOptionData as AtralumeOptionData$1, AtralumeOptionTemplateContext } from "@osmanjimenez/atralume/listbox";
import * as i0 from "@angular/core";
import { AtralumeComboboxHarness } from "@osmanjimenez/atralume/combobox";
/**
 * Thin Autocomplete over `atr-combobox` / Taiga `tuiComboBox` (filter on).
 */
export declare class AtralumeAutocomplete<T> extends ɵAtralumeValueControl<T | string | null> {
  readonly options: import("@angular/core").InputSignal<readonly AtralumeOptionData$1<T>[]>;
  readonly query: import("@angular/core").ModelSignal<string>;
  readonly placeholder: import("@angular/core").InputSignal<string>;
  readonly clearable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly compareWith: import("@angular/core").InputSignal<(a: T, b: T) => boolean>;
  readonly displayWith: import("@angular/core").InputSignal<((value: T) => string) | null>;
  readonly strict: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly emptyText: import("@angular/core").InputSignal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeAutocomplete<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeAutocomplete<any>, "atr-autocomplete", never, {
    "options": {
      "alias": "options";
      "required": false;
      "isSignal": true;
    };
    "query": {
      "alias": "query";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "clearable": {
      "alias": "clearable";
      "required": false;
      "isSignal": true;
    };
    "compareWith": {
      "alias": "compareWith";
      "required": false;
      "isSignal": true;
    };
    "displayWith": {
      "alias": "displayWith";
      "required": false;
      "isSignal": true;
    };
    "strict": {
      "alias": "strict";
      "required": false;
      "isSignal": true;
    };
    "emptyText": {
      "alias": "emptyText";
      "required": false;
      "isSignal": true;
    };
  }, {
    "query": "queryChange";
  }, never, never, true, never>;
}
export declare class AtralumeAutocompleteHarness extends AtralumeComboboxHarness {
  static hostSelector: string;
}
export type { AtralumeOptionData, AtralumeOptionTemplateContext };