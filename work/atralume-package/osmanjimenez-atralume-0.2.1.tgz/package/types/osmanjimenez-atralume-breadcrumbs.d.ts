import * as i0 from "@angular/core";
import * as i1 from "@taiga-ui/cdk/directives/item";
import { ComponentHarness } from "@angular/cdk/testing";
/**
 * Thin breadcrumbs over Taiga `tui-breadcrumbs`.
 * Project items with `*tuiItem` (or `[tuiItem]`).
 */
export declare class AtralumeBreadcrumbs {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly size: import("@angular/core").InputSignal<"m" | "l">;
  readonly itemsLimit: import("@angular/core").InputSignal<number>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeBreadcrumbs, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeBreadcrumbs, "atr-breadcrumbs, nav[atrBreadcrumbs]", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "itemsLimit": {
      "alias": "itemsLimit";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/**
 * Item marker for `atr-breadcrumbs` / `tui-breadcrumbs`.
 * Prefer `*tuiItem` in new templates; this keeps the `atrBreadcrumbItem` selector.
 */
export declare class AtralumeBreadcrumbItem {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeBreadcrumbItem, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeBreadcrumbItem, "[atrBreadcrumbItem]", never, {}, {}, never, never, true, [{
    directive: typeof i1.TuiItem;
    inputs: {};
    outputs: {};
  }]>;
}
/** @deprecated Separators are owned by Taiga `tui-breadcrumbs`. No-op host. */
export declare class AtralumeBreadcrumbSeparator {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeBreadcrumbSeparator, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeBreadcrumbSeparator, "[atrBreadcrumbSeparator]", never, {}, {}, never, never, true, never>;
}
/** @deprecated Overflow is owned by Taiga `itemsLimit`. No-op host. */
export declare class AtralumeBreadcrumbOverflow {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeBreadcrumbOverflow, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeBreadcrumbOverflow, "[atrBreadcrumbOverflow]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeBreadcrumbsHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeBreadcrumbItemHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeBreadcrumbSeparatorHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}
export declare class AtralumeBreadcrumbOverflowHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
}