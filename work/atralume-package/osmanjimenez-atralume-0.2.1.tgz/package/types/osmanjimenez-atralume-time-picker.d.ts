import { FormControl, ValidationErrors, Validator } from "@angular/forms";
import { TuiTime } from "@taiga-ui/cdk/date-time";
import { MaskitoTimeMode } from "@maskito/kit";
import { ɵAtralumeValueControl } from "@osmanjimenez/atralume/internal/forms";
import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
interface AtralumeTimeValue {
  readonly hours: number;
  readonly minutes: number;
  readonly seconds?: number;
}
type AtralumeTimeFormat = "12h" | "24h";
/**
 * Thin time picker over Taiga `tuiInputTime`.
 * Public value stays `AtralumeTimeValue`; inner FormControl holds `TuiTime`.
 */
export declare class AtralumeTimePicker extends ɵAtralumeValueControl<AtralumeTimeValue> implements Validator {
  readonly format: import("@angular/core").InputSignal<AtralumeTimeFormat>;
  readonly seconds: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly step: import("@angular/core").InputSignal<number>;
  readonly min: import("@angular/core").InputSignal<AtralumeTimeValue | null>;
  readonly max: import("@angular/core").InputSignal<AtralumeTimeValue | null>;
  readonly clearable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly hasSeconds: import("@angular/core").Signal<boolean>;
  protected readonly mode: import("@angular/core").Signal<MaskitoTimeMode>;
  protected readonly inner: FormControl<TuiTime | null>;
  private validatorChanged;
  constructor();
  validate(): ValidationErrors | null;
  registerOnValidatorChange(fn: () => void): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeTimePicker, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeTimePicker, "atr-time-picker", never, {
    "format": {
      "alias": "format";
      "required": false;
      "isSignal": true;
    };
    "seconds": {
      "alias": "seconds";
      "required": false;
      "isSignal": true;
    };
    "step": {
      "alias": "step";
      "required": false;
      "isSignal": true;
    };
    "min": {
      "alias": "min";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
    "clearable": {
      "alias": "clearable";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class AtralumeTimePickerHarness extends ComponentHarness {
  static hostSelector: string;
  private readonly input;
  getValue(): Promise<string>;
  setValue(value: string): Promise<void>;
  open(): Promise<void>;
  close(): Promise<void>;
  clear(): Promise<void>;
}
export type { AtralumeTimeFormat, AtralumeTimeValue };