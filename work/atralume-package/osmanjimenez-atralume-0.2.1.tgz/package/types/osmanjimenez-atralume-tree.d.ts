import * as i0 from "@angular/core";
import { TemplateRef } from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
interface AtralumeTreeNode<T> {
  readonly value: T;
  readonly label: string;
  readonly children?: readonly AtralumeTreeNode<T>[];
  readonly disabled?: boolean;
  readonly loading?: boolean;
}
/**
 * Thin recipe over Taiga `tui-tree` (`TuiTree`).
 * Blockers vs full parity: Taiga expansion is controller/map-based (not value[] models);
 * multi-select / aria-multiselectable and loading placeholders stay Atralume-side.
 * This pass shows `tui-tree` in the DOM and maps `AtralumeTreeNode` via `childrenHandler`.
 */
export declare class AtralumeTree<T> {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly nodes: import("@angular/core").InputSignal<readonly AtralumeTreeNode<T>[]>;
  readonly selectionMode: import("@angular/core").InputSignal<"single" | "multiple">;
  readonly selected: import("@angular/core").ModelSignal<readonly T[]>;
  readonly expanded: import("@angular/core").ModelSignal<readonly T[]>;
  readonly compareWith: import("@angular/core").InputSignal<(a: T, b: T) => boolean>;
  readonly selectionChange: import("@angular/core").OutputEmitterRef<readonly T[]>;
  readonly expansionChange: import("@angular/core").OutputEmitterRef<readonly T[]>;
  /** Prefer Taiga map controller; when true all nodes start expanded. */
  readonly expandAll: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  protected readonly content: import("@angular/core").Signal<TemplateRef<unknown>>;
  protected readonly childrenOf: (item: AtralumeTreeNode<T> | readonly AtralumeTreeNode<T>[]) => readonly AtralumeTreeNode<T>[];
  protected isNode(item: AtralumeTreeNode<T> | readonly AtralumeTreeNode<T>[]): item is AtralumeTreeNode<T>;
  protected isSelected(node: AtralumeTreeNode<T>): boolean;
  protected select(node: AtralumeTreeNode<T>, event: Event): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeTree<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeTree<any>, "atr-tree", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "nodes": {
      "alias": "nodes";
      "required": false;
      "isSignal": true;
    };
    "selectionMode": {
      "alias": "selectionMode";
      "required": false;
      "isSignal": true;
    };
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
    "expanded": {
      "alias": "expanded";
      "required": false;
      "isSignal": true;
    };
    "compareWith": {
      "alias": "compareWith";
      "required": false;
      "isSignal": true;
    };
    "expandAll": {
      "alias": "expandAll";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selectedChange";
    "expanded": "expandedChange";
    "selectionChange": "selectionChange";
    "expansionChange": "expansionChange";
  }, never, never, true, never>;
}
export declare class AtralumeTreeHarness extends ComponentHarness {
  static hostSelector: string;
  getNodes(): Promise<string[]>;
  expand(name: string): Promise<void>;
  collapse(name: string): Promise<void>;
  select(name: string): Promise<void>;
}
export type { AtralumeTreeNode };