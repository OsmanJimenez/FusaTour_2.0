import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
/**
 * Visually hides content while keeping it available to assistive technology.
 * With `focusable`, content becomes visible on focus (skip-link pattern).
 */
export declare class AtralumeVisuallyHidden {
  readonly focusable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeVisuallyHidden, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeVisuallyHidden, "[atrVisuallyHidden]", never, {
    "focusable": {
      "alias": "focusable";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class AtralumeVisuallyHiddenHarness extends ComponentHarness {
  static hostSelector: string;
  isFocusableVariant(): Promise<boolean>;
  getText(): Promise<string>;
}