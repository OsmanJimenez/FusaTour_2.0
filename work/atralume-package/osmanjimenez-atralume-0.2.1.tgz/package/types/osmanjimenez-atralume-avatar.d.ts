import * as i0 from "@angular/core";
import * as i1 from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
export type AvatarSize = "small" | "medium" | "large" | "x-large";
export type AvatarShape = "circle" | "rounded";
/** Adapter over Taiga UI `TuiAvatar`; keeps Atralume initials/image API and tokens. */
export declare class AtralumeAvatar {
  readonly src: import("@angular/core").InputSignal<string | null>;
  readonly alt: import("@angular/core").InputSignal<string>;
  readonly name: import("@angular/core").InputSignal<string | null>;
  readonly initials: import("@angular/core").InputSignal<string | null>;
  readonly size: import("@angular/core").InputSignal<AvatarSize>;
  readonly shape: import("@angular/core").InputSignal<AvatarShape>;
  readonly loading: import("@angular/core").InputSignal<"lazy" | "eager">;
  private readonly failedSrc;
  protected readonly hasImage: import("@angular/core").Signal<boolean>;
  protected readonly displayInitials: import("@angular/core").Signal<string>;
  protected imageFailed(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeAvatar, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeAvatar, "atr-avatar", never, {
    "src": {
      "alias": "src";
      "required": false;
      "isSignal": true;
    };
    "alt": {
      "alias": "alt";
      "required": false;
      "isSignal": true;
    };
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "initials": {
      "alias": "initials";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "shape": {
      "alias": "shape";
      "required": false;
      "isSignal": true;
    };
    "loading": {
      "alias": "loading";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.TuiAvatar;
    inputs: {
      "size": "tuiSize";
    };
    outputs: {};
  }]>;
}
export type AvatarGroupDirection = "start" | "end";
/** Adapter over Taiga UI `TuiAvatarStack` for stacked `atr-avatar` children. */
export declare class AtralumeAvatarGroup {
  readonly direction: import("@angular/core").InputSignal<AvatarGroupDirection>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeAvatarGroup, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeAvatarGroup, "atr-avatar-group", never, {
    "direction": {
      "alias": "direction";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
export declare class AtralumeAvatarHarness extends ComponentHarness {
  static hostSelector: string;
  getName(): Promise<string | null>;
  getInitials(): Promise<string | null>;
  getSize(): Promise<string | null>;
  hasImage(): Promise<boolean>;
}
export declare class AtralumeAvatarGroupHarness extends ComponentHarness {
  static hostSelector: string;
  getDirection(): Promise<string | null>;
  getAvatars(): Promise<AtralumeAvatarHarness[]>;
}