import { TuiDay, TuiDayRange, TuiMonth } from "@taiga-ui/cdk/date-time";
import * as i0 from "@angular/core";
import { Provider } from "@angular/core";
import { BaseHarnessFilters, ComponentHarness, HarnessPredicate } from "@angular/cdk/testing";
interface AtralumeDateRange<D> {
  readonly start: D | null;
  readonly end: D | null;
}
type AtralumeDateFormat = "input" | "full" | "month-year";
/** Calendar arithmetic and parsing are replaceable without changing picker contracts. */
export declare abstract class AtralumeDateAdapter<D> {
  abstract readonly locale: string;
  abstract today(): D;
  abstract create(year: number, month: number, day: number): D;
  abstract parse(value: string, locale?: string): D | null;
  abstract format(value: D, format?: AtralumeDateFormat, locale?: string): string;
  abstract compare(a: D, b: D): number;
  abstract addDays(value: D, days: number): D;
  abstract addMonths(value: D, months: number): D;
  abstract addYears(value: D, years: number): D;
  abstract year(value: D): number;
  abstract month(value: D): number;
  abstract day(value: D): number;
  abstract weekday(value: D): number;
  abstract daysInMonth(year: number, month: number): number;
  abstract firstDayOfWeek(locale?: string): number;
  abstract isValid(value: unknown): value is D;
  abstract weekdayName(day: number, locale?: string): string;
  abstract serialize(value: D): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeDateAdapter<any>, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/** A Date represents a local civil day, normalized to noon. It is not an instant contract. */
export declare class AtralumeNativeDateAdapter extends AtralumeDateAdapter<Date> {
  readonly locale: string;
  private readonly weekStart;
  constructor(locale?: string, weekStart?: number);
  today(): Date;
  create(year: number, month: number, day: number): Date;
  year(value: Date): number;
  month(value: Date): number;
  day(value: Date): number;
  weekday(value: Date): number;
  isValid(value: unknown): value is Date;
  firstDayOfWeek(): number;
  daysInMonth(year: number, month: number): number;
  compare(a: Date, b: Date): number;
  addDays(value: Date, days: number): Date;
  addMonths(value: Date, months: number): Date;
  addYears(value: Date, years: number): Date;
  parse(text: string, locale?: string): Date | null;
  format(value: Date, format?: AtralumeDateFormat, locale?: string): string;
  weekdayName(day: number, locale?: string): string;
  serialize(value: Date): string;
}
export declare function provideAtralumeNativeDateAdapter(options?: {
  locale?: string;
  firstDayOfWeek?: number;
}): Provider[];
/**
 * Thin calendar over Taiga `tui-calendar` / `tui-calendar-range`.
 * Public value stays native `Date` / `{ start, end }`; CDK `TuiDay` is internal.
 */
export declare class AtralumeCalendar {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly value: import("@angular/core").ModelSignal<Date | null>;
  readonly rangeValue: import("@angular/core").ModelSignal<AtralumeDateRange<Date> | null>;
  readonly selectionMode: import("@angular/core").InputSignal<"single" | "range">;
  readonly visibleDate: import("@angular/core").ModelSignal<Date | null>;
  readonly today: import("@angular/core").InputSignal<Date>;
  readonly min: import("@angular/core").InputSignal<Date | null>;
  readonly max: import("@angular/core").InputSignal<Date | null>;
  readonly dateFilter: import("@angular/core").InputSignal<(value: Date) => boolean>;
  readonly showAdjacentDays: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly readonly: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  protected readonly tuiMin: import("@angular/core").Signal<TuiDay>;
  protected readonly tuiMax: import("@angular/core").Signal<TuiDay>;
  protected readonly tuiDay: import("@angular/core").Signal<TuiDay | null>;
  protected readonly tuiRange: import("@angular/core").Signal<TuiDayRange | null>;
  protected readonly tuiMonth: import("@angular/core").Signal<TuiMonth>;
  protected readonly disabledItemHandler: import("@angular/core").Signal<(day: TuiDay) => boolean>;
  protected onDayClick(day: TuiDay): void;
  protected onRange(value: TuiDayRange | null): void;
  protected onMonth(month: TuiMonth): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeCalendar, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeCalendar, "atr-calendar", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "rangeValue": {
      "alias": "rangeValue";
      "required": false;
      "isSignal": true;
    };
    "selectionMode": {
      "alias": "selectionMode";
      "required": false;
      "isSignal": true;
    };
    "visibleDate": {
      "alias": "visibleDate";
      "required": false;
      "isSignal": true;
    };
    "today": {
      "alias": "today";
      "required": false;
      "isSignal": true;
    };
    "min": {
      "alias": "min";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
    "dateFilter": {
      "alias": "dateFilter";
      "required": false;
      "isSignal": true;
    };
    "showAdjacentDays": {
      "alias": "showAdjacentDays";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "readonly": {
      "alias": "readonly";
      "required": false;
      "isSignal": true;
    };
  }, {
    "value": "valueChange";
    "rangeValue": "rangeValueChange";
    "visibleDate": "visibleDateChange";
  }, never, never, true, never>;
}
export declare class AtralumeCalendarHarness extends ComponentHarness {
  static hostSelector: string;
  static with(options?: BaseHarnessFilters): HarnessPredicate<AtralumeCalendarHarness>;
  private readonly cells;
  getVisibleMonth(): Promise<string>;
  nextMonth(): Promise<void>;
  previousMonth(): Promise<void>;
  selectDate(id: string): Promise<void>;
  getSelectedDates(): Promise<string[]>;
}
export type { AtralumeDateFormat, AtralumeDateRange };