import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
type AtralumeImageFit = "cover" | "contain" | "fill" | "none" | "scale-down";
type AtralumeImageAspectRatio = "auto" | "square" | "landscape" | "portrait" | number;
type AtralumeImageState = "loading" | "loaded" | "error" | "empty";
/** Native responsive image with stable dimensions and tokenized load states. */
export declare class AtralumeImage {
  readonly src: import("@angular/core").InputSignal<string | null>;
  readonly alt: import("@angular/core").InputSignal<string>;
  readonly fallbackSrc: import("@angular/core").InputSignal<string | null>;
  readonly loading: import("@angular/core").InputSignal<"lazy" | "eager">;
  readonly fit: import("@angular/core").InputSignal<AtralumeImageFit>;
  readonly position: import("@angular/core").InputSignal<string>;
  readonly aspectRatio: import("@angular/core").InputSignal<AtralumeImageAspectRatio>;
  readonly width: import("@angular/core").InputSignal<number | null>;
  readonly height: import("@angular/core").InputSignal<number | null>;
  readonly previewable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly previewLabel: import("@angular/core").InputSignal<string>;
  readonly stateChange: import("@angular/core").OutputEmitterRef<AtralumeImageState>;
  readonly previewRequested: import("@angular/core").OutputEmitterRef<MouseEvent>;
  protected readonly state: import("@angular/core").WritableSignal<AtralumeImageState>;
  private readonly failedPrimary;
  private readonly failedFallback;
  protected readonly activeSrc: import("@angular/core").Signal<string | null>;
  protected readonly imageAvailable: import("@angular/core").Signal<boolean>;
  protected readonly isEmpty: import("@angular/core").Signal<boolean>;
  protected readonly displayState: import("@angular/core").Signal<AtralumeImageState>;
  protected readonly resolvedAspectRatio: import("@angular/core").Signal<string | null>;
  protected readonly aspectRatioName: import("@angular/core").Signal<AtralumeImageAspectRatio | "custom">;
  protected loaded(): void;
  protected failed(): void;
  protected requestPreview(event: MouseEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeImage, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeImage, "atr-image", never, {
    "src": {
      "alias": "src";
      "required": false;
      "isSignal": true;
    };
    "alt": {
      "alias": "alt";
      "required": true;
      "isSignal": true;
    };
    "fallbackSrc": {
      "alias": "fallbackSrc";
      "required": false;
      "isSignal": true;
    };
    "loading": {
      "alias": "loading";
      "required": false;
      "isSignal": true;
    };
    "fit": {
      "alias": "fit";
      "required": false;
      "isSignal": true;
    };
    "position": {
      "alias": "position";
      "required": false;
      "isSignal": true;
    };
    "aspectRatio": {
      "alias": "aspectRatio";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "height": {
      "alias": "height";
      "required": false;
      "isSignal": true;
    };
    "previewable": {
      "alias": "previewable";
      "required": false;
      "isSignal": true;
    };
    "previewLabel": {
      "alias": "previewLabel";
      "required": false;
      "isSignal": true;
    };
  }, {
    "stateChange": "stateChange";
    "previewRequested": "previewRequested";
  }, never, never, true, never>;
}
export declare class AtralumeImageHarness extends ComponentHarness {
  static hostSelector: string;
  getState(): Promise<string | null>;
  getAlt(): Promise<string | null>;
  requestPreview(): Promise<void>;
}
export type { AtralumeImageAspectRatio, AtralumeImageFit, AtralumeImageState };