import * as i0 from "@angular/core";
import * as i1 from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
type AtralumeTextareaResize = "none" | "vertical" | "horizontal" | "both";
/**
 * Thin adapter: `textarea[atrTextarea]` → Taiga `TuiTextareaComponent`.
 *
 * Must sit inside `atr-form-field` / `tui-textfield`. Optional `resize` remains
 * an Atralume affordance on top of Taiga row behavior.
 */
export declare class AtralumeTextarea {
  readonly resize: import("@angular/core").InputSignal<AtralumeTextareaResize>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeTextarea, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeTextarea, "textarea[atrTextarea]", never, {
    "resize": {
      "alias": "resize";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.TuiTextareaComponent;
    inputs: {
      "minRows": "minRows";
      "maxRows": "maxRows";
      "content": "content";
    };
    outputs: {};
  }]>;
}
export declare class AtralumeTextareaHarness extends ComponentHarness {
  static hostSelector: string;
  getValue(): Promise<string>;
  setValue(value: string): Promise<void>;
  focus(): Promise<void>;
  blur(): Promise<void>;
  isReadonly(): Promise<boolean>;
  isInvalid(): Promise<boolean>;
  isDisabled(): Promise<boolean>;
}
export type { AtralumeTextareaResize };