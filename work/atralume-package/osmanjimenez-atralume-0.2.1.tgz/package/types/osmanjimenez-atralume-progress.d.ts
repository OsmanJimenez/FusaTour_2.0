import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
declare abstract class AtralumeProgress {
  readonly value: import("@angular/core").InputSignal<number | null>;
  readonly min: import("@angular/core").InputSignal<number>;
  readonly max: import("@angular/core").InputSignal<number>;
  readonly label: import("@angular/core").InputSignal<string>;
  protected readonly range: import("@angular/core").Signal<{
    min: number;
    max: number;
    value: number | null;
  }>;
  protected readonly normalizedValue: import("@angular/core").Signal<number | null>;
  protected readonly percentage: import("@angular/core").Signal<number | null>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeProgress, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeProgress, never, never, {
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "min": {
      "alias": "min";
      "required": false;
      "isSignal": true;
    };
    "max": {
      "alias": "max";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export type ProgressSpinnerSize = "small" | "medium" | "large";
/**
 * Composition adapter over Taiga UI `TuiProgressCircle` / `TuiLoader`.
 * Keeps `atr-progress-spinner` and Atralume size/label/value API.
 */
export declare class AtralumeProgressSpinner extends AtralumeProgress {
  readonly size: import("@angular/core").InputSignal<ProgressSpinnerSize>;
  protected readonly tuiSize: import("@angular/core").Signal<"s" | "l" | "m">;
  protected readonly circleMax: import("@angular/core").Signal<number>;
  protected readonly circleValue: import("@angular/core").Signal<number>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeProgressSpinner, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeProgressSpinner, "atr-progress-spinner", never, {
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class AtralumeProgressSpinnerHarness extends ComponentHarness {
  static hostSelector: string;
  getValue(): Promise<number | null>;
  getMin(): Promise<number | null>;
  getMax(): Promise<number | null>;
  isIndeterminate(): Promise<boolean>;
  getAccessibleName(): Promise<string | null>;
}
/**
 * Composition adapter over Taiga UI `TuiProgressBar`.
 * Keeps the public `atr-progress-bar` element and Atralume progress inputs.
 */
export declare class AtralumeProgressBar extends AtralumeProgress {
  /** Native progress max mapped from Atralume min/max. */
  protected readonly nativeMax: import("@angular/core").Signal<number>;
  /** Native progress value mapped into 0..nativeMax, or null when indeterminate. */
  protected readonly nativeValue: import("@angular/core").Signal<number | null>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeProgressBar, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeProgressBar, "atr-progress-bar", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeProgressBarHarness extends ComponentHarness {
  static hostSelector: string;
  getValue(): Promise<number | null>;
  getMin(): Promise<number | null>;
  getMax(): Promise<number | null>;
  isIndeterminate(): Promise<boolean>;
  getAccessibleName(): Promise<string | null>;
}
export {};