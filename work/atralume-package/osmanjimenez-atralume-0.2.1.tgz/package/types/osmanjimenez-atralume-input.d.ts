import * as i0 from "@angular/core";
import * as i1 from "@taiga-ui/core";
import { ComponentHarness } from "@angular/cdk/testing";
/**
 * Thin adapter: `input[atrInput]` → Taiga `TuiInputDirective` (`tuiInput`).
 *
 * Must sit inside `atr-form-field` / `tui-textfield`. Brand look comes from
 * Taiga + Atralume modes/bridge.
 */
export declare class AtralumeInput {
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeInput, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeInput, "input[atrInput]", never, {}, {}, never, never, true, [{
    directive: typeof i1.TuiInputDirective;
    inputs: {
      "readonly": "readonly";
      "invalid": "invalid";
      "focused": "focused";
      "state": "state";
    };
    outputs: {};
  }]>;
}
export declare class AtralumeInputHarness extends ComponentHarness {
  static hostSelector: string;
  getValue(): Promise<string>;
  setValue(value: string): Promise<void>;
  focus(): Promise<void>;
  blur(): Promise<void>;
  isReadonly(): Promise<boolean>;
  isInvalid(): Promise<boolean>;
  isDisabled(): Promise<boolean>;
}