import * as i0 from "@angular/core";
import { TemplateRef } from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";
import { PolymorpheusContent } from "@taiga-ui/polymorpheus";
import { ComponentHarness } from "@angular/cdk/testing";
interface AtralumeFilterOption<T> {
  readonly value: T;
  readonly label: string;
  readonly disabled?: boolean;
  readonly badge?: number | null;
}
/** Typed multi-select filter adapter over `TuiFilter`, including Angular Forms support. */
export declare class AtralumeFilter<T> implements ControlValueAccessor {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly options: import("@angular/core").InputSignal<readonly AtralumeFilterOption<T>[]>;
  readonly size: import("@angular/core").InputSignal<"s" | "m" | "l">;
  readonly optionTemplate: import("@angular/core").InputSignal<TemplateRef<{
    $implicit: AtralumeFilterOption<T>;
  }> | null>;
  readonly selectionChange: import("@angular/core").OutputEmitterRef<readonly T[]>;
  readonly cleared: import("@angular/core").OutputEmitterRef<void>;
  protected readonly selected: import("@angular/core").WritableSignal<readonly AtralumeFilterOption<T>[]>;
  protected readonly disabled: import("@angular/core").WritableSignal<boolean>;
  protected readonly content: import("@angular/core").Signal<PolymorpheusContent<{
    $implicit: AtralumeFilterOption<T>;
  }>>;
  protected readonly badgeHandler: (option: AtralumeFilterOption<T>) => number | null;
  protected readonly disabledItemHandler: (option: AtralumeFilterOption<T>) => boolean;
  private onChange;
  private onTouched;
  writeValue(value: readonly T[] | null): void;
  registerOnChange(fn: (value: readonly T[]) => void): void;
  registerOnTouched(fn: () => void): void;
  setDisabledState(disabled: boolean): void;
  protected update(value: readonly AtralumeFilterOption<T>[]): void;
  clear(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeFilter<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeFilter<any>, "atr-filter", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "options": {
      "alias": "options";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "optionTemplate": {
      "alias": "optionTemplate";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selectionChange": "selectionChange";
    "cleared": "cleared";
  }, never, never, true, never>;
}
export declare class AtralumeFilterHarness extends ComponentHarness {
  static hostSelector: string;
  select(label: string): Promise<void>;
  clear(): Promise<void>;
}
export type { AtralumeFilterOption };