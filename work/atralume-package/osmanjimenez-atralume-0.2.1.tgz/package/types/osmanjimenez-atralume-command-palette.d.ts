import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
import { AtralumeComboboxHarness } from "@osmanjimenez/atralume/combobox";
interface AtralumeCommand<T> {
  readonly id: string;
  readonly label: string;
  readonly value: T;
  readonly disabled?: boolean;
  readonly group?: string;
  readonly keywords?: readonly string[];
  readonly shortcut?: string;
  readonly children?: readonly AtralumeCommand<T>[];
}
interface AtralumeCommandShortcut {
  readonly key: string;
  readonly modifier: "control" | "meta" | "either";
  readonly allowInEditable?: boolean;
}
/**
 * Composition of Atralume Dialog + Combobox. No Taiga command-palette primitive;
 * evaluated against input/dropdown/data-list building blocks.
 */
export declare class AtralumeCommandPalette<T> {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly commands: import("@angular/core").InputSignal<readonly AtralumeCommand<T>[]>;
  readonly recentCommands: import("@angular/core").InputSignal<readonly AtralumeCommand<T>[]>;
  readonly opened: import("@angular/core").ModelSignal<boolean>;
  readonly query: import("@angular/core").ModelSignal<string>;
  readonly loading: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly loadError: import("@angular/core").InputSignal<string | null>;
  readonly shortcut: import("@angular/core").InputSignal<AtralumeCommandShortcut | null>;
  readonly closeAfterAction: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly invoked: import("@angular/core").OutputEmitterRef<AtralumeCommand<T>>;
  private readonly levels;
  protected readonly canGoBack: import("@angular/core").Signal<boolean>;
  protected readonly options: import("@angular/core").Signal<{
    id: string;
    value: AtralumeCommand<T>;
    label: string;
    disabled: boolean | undefined;
    group: string | undefined;
    keywords: readonly string[] | undefined;
  }[]>;
  private readonly content;
  private readonly combobox;
  private readonly dialog;
  private readonly views;
  private readonly owner;
  private readonly document;
  private readonly renderer;
  private readonly browser;
  private ref;
  private origin;
  constructor();
  open(origin?: HTMLElement): void;
  close(): void;
  protected choose(value: AtralumeCommand<T> | string | null): void;
  back(): void;
  protected readonly displayCommand: (command: AtralumeCommand<T>) => string;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeCommandPalette<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeCommandPalette<any>, "atr-command-palette", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "commands": {
      "alias": "commands";
      "required": false;
      "isSignal": true;
    };
    "recentCommands": {
      "alias": "recentCommands";
      "required": false;
      "isSignal": true;
    };
    "opened": {
      "alias": "opened";
      "required": false;
      "isSignal": true;
    };
    "query": {
      "alias": "query";
      "required": false;
      "isSignal": true;
    };
    "loading": {
      "alias": "loading";
      "required": false;
      "isSignal": true;
    };
    "loadError": {
      "alias": "loadError";
      "required": false;
      "isSignal": true;
    };
    "shortcut": {
      "alias": "shortcut";
      "required": false;
      "isSignal": true;
    };
    "closeAfterAction": {
      "alias": "closeAfterAction";
      "required": false;
      "isSignal": true;
    };
  }, {
    "opened": "openedChange";
    "query": "queryChange";
    "invoked": "invoked";
  }, never, never, true, never>;
}
export declare class AtralumeCommandPaletteHarness extends ComponentHarness {
  static hostSelector: string;
  readonly combobox: () => Promise<AtralumeComboboxHarness>;
  search(query: string): Promise<void>;
  invoke(label: string): Promise<void>;
  back(): Promise<void>;
  close(): Promise<void>;
}
export type { AtralumeCommand, AtralumeCommandShortcut };