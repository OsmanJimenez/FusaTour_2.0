import * as i0 from "@angular/core";
/**
 * Accessible, dependency-free viewer for equirectangular (2:1) panorama images.
 * Drag or use the keyboard to explore the scene; the image repeats seamlessly on
 * the horizontal axis so a visitor can make a complete 360-degree turn.
 */
export declare class AtralumeImage360 {
  readonly src: import("@angular/core").InputSignal<string>;
  readonly alt: import("@angular/core").InputSignal<string>;
  readonly label: import("@angular/core").InputSignal<string>;
  readonly yaw: import("@angular/core").WritableSignal<number>;
  readonly zoom: import("@angular/core").WritableSignal<number>;
  protected readonly sceneStyle: import("@angular/core").Signal<{
    "background-image": string;
    "background-position": string;
    "background-size": string;
  }>;
  private dragStart;
  protected startDrag(event: PointerEvent): void;
  protected drag(event: PointerEvent): void;
  protected endDrag(): void;
  protected onKey(event: KeyboardEvent): void;
  protected onWheel(event: WheelEvent): void;
  protected rotate(value: number): void;
  protected changeZoom(delta: number): void;
  protected reset(): void;
  protected fullscreen(event: MouseEvent): Promise<void>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeImage360, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeImage360, "atr-image-360", never, {
    "src": {
      "alias": "src";
      "required": true;
      "isSignal": true;
    };
    "alt": {
      "alias": "alt";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}