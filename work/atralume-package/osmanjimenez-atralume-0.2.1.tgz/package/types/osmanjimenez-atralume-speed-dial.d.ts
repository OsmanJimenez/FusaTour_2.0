import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
export declare class AtralumeSpeedDialAction {
  private readonly ref;
  focus(): void;
  isDisabled(): boolean;
  element(): HTMLButtonElement;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeSpeedDialAction, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeSpeedDialAction, "button[atrSpeedDialAction]", never, {}, {}, never, never, true, never>;
}
export declare class AtralumeSpeedDialActionHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  click(): Promise<void>;
  isDisabled(): Promise<boolean>;
}
/**
 * Composition over Taiga-backed `AtralumeFab`. No Taiga speed-dial primitive.
 */
export declare class AtralumeSpeedDial {
  readonly id: import("@angular/core").InputSignal<string>;
  readonly label: import("@angular/core").InputSignal<string>;
  readonly opened: import("@angular/core").ModelSignal<boolean>;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly orientation: import("@angular/core").InputSignal<"vertical" | "horizontal">;
  protected readonly visible: import("@angular/core").Signal<boolean>;
  private readonly actions;
  private readonly element;
  private readonly trigger;
  private readonly injector;
  constructor();
  protected toggle(): void;
  dismiss(restore?: boolean): void;
  protected clicked(event: Event): void;
  protected lostFocus(event: FocusEvent): void;
  protected onKey(event: KeyboardEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeSpeedDial, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeSpeedDial, "atr-speed-dial", never, {
    "id": {
      "alias": "id";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "opened": {
      "alias": "opened";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "orientation": {
      "alias": "orientation";
      "required": false;
      "isSignal": true;
    };
  }, {
    "opened": "openedChange";
  }, ["actions"], ["[atrSpeedDialAction]"], true, never>;
}
export declare class AtralumeSpeedDialHarness extends ComponentHarness {
  static hostSelector: string;
  getText(): Promise<string>;
  toggle(): Promise<void>;
  isOpen(): Promise<boolean>;
}