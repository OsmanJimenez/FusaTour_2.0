import * as i0 from "@angular/core";
import * as i1 from "@taiga-ui/core";
import { BaseHarnessFilters, ComponentHarness, HarnessPredicate, TestKey } from "@angular/cdk/testing";
type SelectionMode = "single" | "multiple";
type FocusMode = "roving" | "activedescendant";
interface AtralumeOptionData<T> {
  readonly id: string;
  readonly value: T;
  readonly label: string;
  readonly disabled?: boolean;
  readonly group?: string;
  readonly keywords?: readonly string[];
}
interface AtralumeOptionTemplateContext<T> {
  $implicit: T;
  option: AtralumeOptionData<T>;
  selected: boolean;
}
/**
 * Thin listbox over Taiga `tui-data-list-wrapper`.
 *
 * Breaking: CDK key manager removed; prefer wrapper `items` API.
 * `selectionMode="multiple"` keeps a local multi model (itemClick toggles).
 */
export declare class AtralumeListbox<T> {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly options: import("@angular/core").InputSignal<readonly AtralumeOptionData<T>[]>;
  readonly value: import("@angular/core").ModelSignal<readonly T[]>;
  readonly selectionMode: import("@angular/core").InputSignal<SelectionMode>;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly emptyText: import("@angular/core").InputSignal<string>;
  readonly chosen: import("@angular/core").OutputEmitterRef<T>;
  readonly items: import("@angular/core").Signal<T[]>;
  protected pick(value: T): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeListbox<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeListbox<any>, "atr-listbox", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "options": {
      "alias": "options";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "selectionMode": {
      "alias": "selectionMode";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "emptyText": {
      "alias": "emptyText";
      "required": false;
      "isSignal": true;
    };
  }, {
    "value": "valueChange";
    "chosen": "chosen";
  }, never, never, true, never>;
}
/**
 * Thin adapter: `button[atrOption]` → Taiga `TuiOption`.
 *
 * Breaking: host must be `button` / `a` / `label`. Bind `[value]` for
 * `TuiOptionWithValue` selection inside `tui-data-list` when needed.
 */
export declare class AtralumeOptionDirective {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeOptionDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeOptionDirective, "button[atrOption], a[atrOption], label[atrOption]", never, {}, {}, never, never, true, [{
    directive: typeof i1.TuiOption;
    inputs: {
      "disabled": "disabled";
    };
    outputs: {};
  }]>;
}
export declare class AtralumeOptionGroup {
  readonly label: import("@angular/core").InputSignal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeOptionGroup, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeOptionGroup, "[atrOptionGroup]", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class AtralumeOptionGroupLabel {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeOptionGroupLabel, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeOptionGroupLabel, "[atrOptionGroupLabel]", never, {}, {}, never, never, true, never>;
}
export interface AtralumeOptionHarnessFilters extends BaseHarnessFilters {
  label?: string | RegExp;
}
export declare class AtralumeOptionHarness extends ComponentHarness {
  /** Taiga data-list option buttons inside `atr-listbox`. */
  static hostSelector: string;
  static with(options?: AtralumeOptionHarnessFilters): HarnessPredicate<AtralumeOptionHarness>;
  getLabel(): Promise<string>;
  isSelected(): Promise<boolean>;
  isDisabled(): Promise<boolean>;
  select(): Promise<void>;
}
export declare class AtralumeListboxHarness extends ComponentHarness {
  static hostSelector: string;
  getOptions: () => Promise<AtralumeOptionHarness[]>;
  getSelectedOptions(): Promise<AtralumeOptionHarness[]>;
  selectOption(label: string): Promise<void>;
  isMultiple(): Promise<boolean>;
  isDisabled(): Promise<boolean>;
  navigate(key: TestKey): Promise<void>;
}
export type { AtralumeOptionData, AtralumeOptionTemplateContext, FocusMode, SelectionMode };