import * as i0 from "@angular/core";
import * as i1 from "@taiga-ui/core/directives/appearance";
import * as i2 from "@taiga-ui/cdk/directives/native-validator";
import { ComponentHarness } from "@angular/cdk/testing";
/**
 * Native radio with Atralume tokens and Taiga appearance primitives.
 *
 * Does not host `TuiRadioComponent`: without `NgControl` Taiga forces
 * `disabled` + `_readonly`, and the component token breaks as `hostDirectives`.
 * Styles come from `[attr.tuiRadio]`.
 *
 * Syncs `data-appearance` after ngModel writes the initial `checked` state
 * (which does not fire a native `change` on first bind).
 */
export declare class AtralumeRadio {
  private readonly el;
  private readonly appearance;
  private readonly control;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeRadio, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeRadio, "input[type=\"radio\"][atrRadio]", never, {}, {}, never, never, true, [{
    directive: typeof i1.TuiAppearance;
    inputs: {
      "tuiAppearanceState": "tuiAppearanceState";
      "tuiAppearanceFocus": "tuiAppearanceFocus";
      "tuiAppearanceMode": "tuiAppearanceMode";
    };
    outputs: {};
  }, {
    directive: typeof i2.TuiNativeValidator;
    inputs: {};
    outputs: {};
  }]>;
}
export declare class AtralumeRadioHarness extends ComponentHarness {
  static hostSelector: string;
  isChecked(): Promise<boolean>;
  toggle(): Promise<void>;
  check(): Promise<void>;
  getName(): Promise<string>;
  getValue(): Promise<string>;
  isDisabled(): Promise<boolean>;
}