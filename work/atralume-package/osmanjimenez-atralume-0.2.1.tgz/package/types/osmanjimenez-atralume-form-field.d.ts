import * as i0 from "@angular/core";
import * as i1 from "@taiga-ui/core";
import { TuiLabel, TuiTextfield } from "@taiga-ui/core";
import { ComponentHarness } from "@angular/cdk/testing";
type AtralumeFormFieldAppearance = "outline" | "filled";
type AtralumeFormFieldDensity = "comfortable" | "compact";
/**
 * Brand chrome (hint/error/density attrs) around a Taiga `tui-textfield`.
 *
 * Breaking: project a consumer-authored `tui-textfield` with
 * `label[tuiLabel]` and `input[atrInput]` / `textarea[atrTextarea]`.
 * Do not project a bare input into this host — `TuiInputDirective` must
 * inject `TuiTextfieldComponent` from the same consumer template tree.
 *
 * @example
 * ```html
 * <atr-form-field [hint]="hint" [error]="error">
 *   <tui-textfield [invalid]="!!error" tuiTextfieldSize="m">
 *     <label tuiLabel>Email</label>
 *     <input atrInput type="email" formControlName="email" />
 *   </tui-textfield>
 * </atr-form-field>
 * ```
 */
export declare class AtralumeFormField {
  readonly hint: import("@angular/core").InputSignal<string | null>;
  readonly error: import("@angular/core").InputSignal<string | null>;
  readonly appearance: import("@angular/core").InputSignal<AtralumeFormFieldAppearance>;
  readonly density: import("@angular/core").InputSignal<AtralumeFormFieldDensity>;
  /** Kept for call-site compatibility; render label inside `tui-textfield`. */
  readonly label: import("@angular/core").InputSignal<string>;
  readonly required: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly optional: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly optionalText: import("@angular/core").InputSignal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeFormField, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeFormField, "atr-form-field", never, {
    "hint": {
      "alias": "hint";
      "required": false;
      "isSignal": true;
    };
    "error": {
      "alias": "error";
      "required": false;
      "isSignal": true;
    };
    "appearance": {
      "alias": "appearance";
      "required": false;
      "isSignal": true;
    };
    "density": {
      "alias": "density";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "optional": {
      "alias": "optional";
      "required": false;
      "isSignal": true;
    };
    "optionalText": {
      "alias": "optionalText";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/** A self-contained catalogue search field, exposing only Atralume's API. */
export declare class AtralumeSearchField {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly placeholder: import("@angular/core").InputSignal<string>;
  readonly value: import("@angular/core").InputSignal<string>;
  readonly valueChange: import("@angular/core").OutputEmitterRef<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeSearchField, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeSearchField, "atr-search-field", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
  }, {
    "valueChange": "valueChange";
  }, never, never, true, never>;
}
/**
 * Layout for a native wrapping or explicitly associated label.
 * Adapter over Taiga UI `TuiLabel`.
 */
export declare class AtralumeControlLabel {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeControlLabel, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumeControlLabel, "label[atrControlLabel]", never, {}, {}, never, never, true, [{
    directive: typeof i1.TuiLabel;
    inputs: {};
    outputs: {};
  }]>;
}
export declare class AtralumeFormFieldHarness extends ComponentHarness {
  static hostSelector: string;
  private readonly label;
  private readonly hint;
  private readonly error;
  getLabel(): Promise<string>;
  getHint(): Promise<string | null>;
  getError(): Promise<string | null>;
  isRequired(): Promise<boolean>;
  getAppearance(): Promise<string | null>;
  readonly getControl: () => Promise<import("@angular/cdk/testing").TestElement>;
}
export { type AtralumeFormFieldAppearance, type AtralumeFormFieldDensity, TuiLabel, TuiTextfield };