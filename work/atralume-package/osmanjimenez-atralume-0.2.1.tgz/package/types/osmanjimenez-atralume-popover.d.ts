import * as i0 from "@angular/core";
import * as i1 from "@taiga-ui/core";
import { ComponentHarness } from "@angular/cdk/testing";
type PopoverPosition = "above" | "below" | "before" | "after";
/**
 * Thin popover over Taiga `TuiDropdown`.
 * Apply on the trigger; pass panel content as `[atrPopover]` (TemplateRef).
 * `opened` / `popoverEnabled` come from hosted Taiga inputs.
 */
export declare class AtralumePopover {
  readonly label: import("@angular/core").InputSignal<string | null>;
  readonly panelRole: import("@angular/core").InputSignal<string>;
  readonly position: import("@angular/core").InputSignal<PopoverPosition>;
  private readonly dropdown;
  private readonly dropdownOpen;
  private readonly options;
  constructor();
  open(): void;
  close(): void;
  toggle(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumePopover, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<AtralumePopover, "[atrPopover]", ["atrPopover"], {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "panelRole": {
      "alias": "panelRole";
      "required": false;
      "isSignal": true;
    };
    "position": {
      "alias": "position";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof i1.TuiDropdownDirective;
    inputs: {
      "tuiDropdown": "atrPopover";
    };
    outputs: {};
  }, {
    directive: typeof i1.TuiDropdownOpen;
    inputs: {
      "tuiDropdownOpen": "opened";
      "tuiDropdownEnabled": "popoverEnabled";
    };
    outputs: {
      "tuiDropdownOpenChange": "openedChange";
    };
  }, {
    directive: typeof i1.TuiDropdownOptionsDirective;
    inputs: {
      "tuiDropdownAlign": "dropdownAlign";
      "tuiDropdownDirection": "dropdownDirection";
      "tuiDropdownOffset": "dropdownOffset";
    };
    outputs: {};
  }]>;
}
export declare class AtralumePopoverHarness extends ComponentHarness {
  static hostSelector: string;
  getRole(): Promise<string | null>;
  getText(): Promise<string>;
  close(): Promise<void>;
}
export type { PopoverPosition };