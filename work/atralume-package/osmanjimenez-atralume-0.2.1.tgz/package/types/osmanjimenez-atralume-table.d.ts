import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
interface AtralumeTableColumn<T> {
  readonly id: string;
  readonly header: string;
  readonly cell: (row: T) => string | number | null | undefined;
  readonly sortable?: boolean;
  readonly sticky?: "start" | "end";
}
interface AtralumeSort {
  readonly active: string;
  readonly direction: "asc" | "desc" | "";
}
interface AtralumeTableSelectionChange<T> {
  readonly selected: readonly T[];
  readonly changed: T;
}
/**
 * High-level table composed over `@taiga-ui/addon-table` (`tuiTable` / `tuiTh` / `tuiTd`).
 * Keeps rows/columns/selection/sort/expand contract; cells render via column.cell().
 */
export declare class AtralumeTable<T extends Partial<Record<keyof T, unknown>>> {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly rows: import("@angular/core").InputSignal<readonly T[]>;
  readonly columns: import("@angular/core").InputSignal<readonly AtralumeTableColumn<T>[]>;
  readonly trackBy: import("@angular/core").InputSignal<(row: T, index: number) => unknown>;
  readonly selectionMode: import("@angular/core").InputSignal<"none" | "single" | "multiple">;
  readonly selected: import("@angular/core").ModelSignal<readonly T[]>;
  readonly expanded: import("@angular/core").ModelSignal<readonly T[]>;
  readonly sort: import("@angular/core").ModelSignal<AtralumeSort>;
  readonly loading: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly error: import("@angular/core").InputSignal<string | null>;
  readonly emptyText: import("@angular/core").InputSignal<string>;
  readonly zebra: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly hover: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly expandable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly detail: import("@angular/core").InputSignal<(row: T) => string | null>;
  readonly selectionChange: import("@angular/core").OutputEmitterRef<AtralumeTableSelectionChange<T>>;
  readonly expansionChange: import("@angular/core").OutputEmitterRef<readonly T[]>;
  readonly columnIds: import("@angular/core").Signal<string[]>;
  readonly allSelected: import("@angular/core").Signal<boolean>;
  readonly colspan: import("@angular/core").Signal<number>;
  private same;
  isSelected(row: T, index: number): boolean;
  isExpanded(row: T, index: number): boolean;
  select(row: T, index: number): void;
  selectAll(): void;
  toggleExpanded(row: T, index: number): void;
  requestSort(column: AtralumeTableColumn<T>): void;
  sortLabel(column: AtralumeTableColumn<T>): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeTable<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeTable<any>, "atr-table", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "rows": {
      "alias": "rows";
      "required": false;
      "isSignal": true;
    };
    "columns": {
      "alias": "columns";
      "required": false;
      "isSignal": true;
    };
    "trackBy": {
      "alias": "trackBy";
      "required": false;
      "isSignal": true;
    };
    "selectionMode": {
      "alias": "selectionMode";
      "required": false;
      "isSignal": true;
    };
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
    "expanded": {
      "alias": "expanded";
      "required": false;
      "isSignal": true;
    };
    "sort": {
      "alias": "sort";
      "required": false;
      "isSignal": true;
    };
    "loading": {
      "alias": "loading";
      "required": false;
      "isSignal": true;
    };
    "error": {
      "alias": "error";
      "required": false;
      "isSignal": true;
    };
    "emptyText": {
      "alias": "emptyText";
      "required": false;
      "isSignal": true;
    };
    "zebra": {
      "alias": "zebra";
      "required": false;
      "isSignal": true;
    };
    "hover": {
      "alias": "hover";
      "required": false;
      "isSignal": true;
    };
    "expandable": {
      "alias": "expandable";
      "required": false;
      "isSignal": true;
    };
    "detail": {
      "alias": "detail";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selectedChange";
    "expanded": "expandedChange";
    "sort": "sortChange";
    "selectionChange": "selectionChange";
    "expansionChange": "expansionChange";
  }, never, never, true, never>;
}
export declare class AtralumeTableHarness extends ComponentHarness {
  static hostSelector: string;
  getRows(): Promise<string[][]>;
  getCells(row: number): Promise<string[]>;
  sort(name: string): Promise<void>;
  selectRow(row: number): Promise<void>;
  expandRow(row: number): Promise<void>;
  getState(): Promise<"loading" | "empty" | "error" | "ready">;
}
export type { AtralumeSort, AtralumeTableColumn, AtralumeTableSelectionChange };