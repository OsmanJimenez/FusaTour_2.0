import * as i0 from "@angular/core";
import { ElementRef } from "@angular/core";
import { ValidationErrors, Validator } from "@angular/forms";
import { ɵAtralumeValueControl } from "@osmanjimenez/atralume/internal/forms";
import { ComponentHarness } from "@angular/cdk/testing";
type UploadFileStatus = "selected" | "uploading" | "success" | "error" | "cancelled";
interface AtralumeUploadFileState {
  readonly file: File;
  readonly status: UploadFileStatus;
  readonly progress?: number;
  readonly error?: string;
  readonly cancellable?: boolean;
}
interface AtralumeFileRejection {
  readonly file: File;
  readonly errors: readonly string[];
}
/**
 * File upload composed over Taiga `label[tuiInputFiles]` chrome.
 * Value stays on this CVA — native input uses `atrFileInput` (attr + appearance)
 * without hosting `TuiInputFilesDirective` (also a CVA).
 */
export declare class AtralumeFileUpload extends ɵAtralumeValueControl<readonly File[]> implements Validator {
  readonly multiple: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly accept: import("@angular/core").InputSignal<string>;
  readonly maxSize: import("@angular/core").InputSignal<number>;
  readonly minSize: import("@angular/core").InputSignal<number>;
  readonly maxCount: import("@angular/core").InputSignal<number>;
  readonly detectDuplicates: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly append: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly dropZone: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly imagePreviews: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly fileValidator: import("@angular/core").InputSignal<((file: File) => string | null) | null>;
  readonly states: import("@angular/core").InputSignal<readonly AtralumeUploadFileState[]>;
  readonly rejected: import("@angular/core").OutputEmitterRef<readonly AtralumeFileRejection[]>;
  readonly removed: import("@angular/core").OutputEmitterRef<File>;
  readonly cancelRequested: import("@angular/core").OutputEmitterRef<File>;
  readonly files: import("@angular/core").Signal<readonly File[]>;
  readonly dragging: import("@angular/core").WritableSignal<boolean>;
  readonly rejections: import("@angular/core").WritableSignal<readonly AtralumeFileRejection[]>;
  readonly previews: import("@angular/core").WritableSignal<ReadonlyMap<File, string>>;
  protected readonly fileInput: import("@angular/core").Signal<ElementRef<HTMLInputElement>>;
  private readonly browser;
  private readonly urls;
  private dragDepth;
  private validatorChanged;
  constructor();
  fileKey(file: File): string;
  status(file: File): AtralumeUploadFileState;
  private errorsFor;
  choose(): void;
  protected changed(event: Event): void;
  selectFiles(incoming: readonly File[]): void;
  remove(file: File): void;
  protected dragEnter(event: DragEvent): void;
  protected dragLeave(event: DragEvent): void;
  protected dragOver(event: DragEvent): void;
  protected dropped(event: DragEvent): void;
  validate(): ValidationErrors | null;
  registerOnValidatorChange(fn: () => void): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeFileUpload, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeFileUpload, "atr-file-upload", never, {
    "multiple": {
      "alias": "multiple";
      "required": false;
      "isSignal": true;
    };
    "accept": {
      "alias": "accept";
      "required": false;
      "isSignal": true;
    };
    "maxSize": {
      "alias": "maxSize";
      "required": false;
      "isSignal": true;
    };
    "minSize": {
      "alias": "minSize";
      "required": false;
      "isSignal": true;
    };
    "maxCount": {
      "alias": "maxCount";
      "required": false;
      "isSignal": true;
    };
    "detectDuplicates": {
      "alias": "detectDuplicates";
      "required": false;
      "isSignal": true;
    };
    "append": {
      "alias": "append";
      "required": false;
      "isSignal": true;
    };
    "dropZone": {
      "alias": "dropZone";
      "required": false;
      "isSignal": true;
    };
    "imagePreviews": {
      "alias": "imagePreviews";
      "required": false;
      "isSignal": true;
    };
    "fileValidator": {
      "alias": "fileValidator";
      "required": false;
      "isSignal": true;
    };
    "states": {
      "alias": "states";
      "required": false;
      "isSignal": true;
    };
  }, {
    "rejected": "rejected";
    "removed": "removed";
    "cancelRequested": "cancelRequested";
  }, never, never, true, never>;
}
export declare class AtralumeFileUploadHarness extends ComponentHarness {
  static hostSelector: string;
  getFileNames(): Promise<string[]>;
  removeFile(name: string): Promise<void>;
  getValidationErrors(): Promise<string[]>;
  getStatuses(): Promise<string[]>;
  isDisabled(): Promise<boolean>;
}
export type { AtralumeFileRejection, AtralumeUploadFileState, UploadFileStatus };