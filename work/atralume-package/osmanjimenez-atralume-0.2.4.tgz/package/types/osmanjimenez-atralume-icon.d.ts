import * as i0 from "@angular/core";
import { InjectionToken, Provider } from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
export type IconSize = "small" | "medium" | "large" | number;
/** Navigable catalog categories for the Icon Explorer and search API. */
export type AtralumeIconCategory = "accessibility" | "actions" | "arrows" | "calendar-time" | "commerce" | "communication" | "custom" | "development" | "devices" | "editing" | "files" | "finance" | "folders" | "layout" | "maps-location" | "media" | "navigation" | "notifications" | "security" | "social" | "status-feedback" | "users";
export type AtralumeIconSource = "atralume" | "taiga" | "custom";
/**
 * Structured path icon registered with `provideAtralumeIcons`.
 * Paths must be SVG path `d` data only — never HTML, URLs, or scripts.
 */
export interface AtralumeIconDefinition {
  readonly name: string;
  readonly paths: readonly string[];
  readonly viewBox?: string;
  readonly mirrorInRtl?: boolean;
  readonly category?: AtralumeIconCategory;
  readonly keywords?: readonly string[];
  readonly aliases?: readonly string[];
}
/** Metadata-only catalog entry (no SVG payload). */
export interface AtralumeIconCatalogEntry {
  readonly name: string;
  /** Stable Taiga CSS-mask name, e.g. `@tui.check`. */
  readonly tuiName: string;
  readonly category: AtralumeIconCategory;
  readonly keywords: readonly string[];
  readonly aliases?: readonly string[];
  readonly filled?: boolean;
  readonly filledName?: string;
  readonly source: AtralumeIconSource;
  readonly mirrorInRtl?: boolean;
}
export interface AtralumeIconSearchOptions {
  readonly query?: string;
  readonly category?: AtralumeIconCategory | "all";
  readonly source?: AtralumeIconSource | "all";
  readonly limit?: number;
}
type AtralumeIconEngine = "registry" | "tui" | "auto";
/**
 * Dual icon host: keeps `atr-icon` + SVG registry, with an optional bridge to Taiga Lucide assets.
 * - `engine="registry"` (default): structured SVG paths via `provideAtralumeIcons`.
 * - `engine="tui"`: CSS-mask glyph from `/assets/taiga-ui/icons/{name}.svg`.
 * - `engine="auto"`: registry hit → SVG; otherwise treat `name` as a Taiga icon key.
 * Full registry cutover is deferred (high blast radius across badge/button/avatar/playground).
 */
export declare class AtralumeIcon {
  readonly name: import("@angular/core").InputSignal<string>;
  readonly size: import("@angular/core").InputSignal<IconSize>;
  readonly decorative: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly label: import("@angular/core").InputSignal<string | null>;
  /** Optional bridge toward Taiga `TuiIcon` without breaking registry consumers. */
  readonly engine: import("@angular/core").InputSignal<AtralumeIconEngine>;
  private readonly registry;
  protected readonly definition: import("@angular/core").Signal<import("@osmanjimenez/atralume/icon").AtralumeIconDefinition | null | undefined>;
  protected readonly resolvedEngine: import("@angular/core").Signal<"registry" | "tui">;
  /** Public Taiga token (`@tui.heart`) for docs / snippets. */
  protected readonly tuiIconName: import("@angular/core").Signal<string>;
  /** CSS `mask-image` url for Lucide assets under Storybook / app static dirs. */
  protected readonly tuiMaskUrl: import("@angular/core").Signal<string>;
  protected readonly pixelSize: import("@angular/core").Signal<string | null>;
  protected readonly accessibleLabel: import("@angular/core").Signal<string | null>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeIcon, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeIcon, "atr-icon", never, {
    "name": {
      "alias": "name";
      "required": true;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "decorative": {
      "alias": "decorative";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "engine": {
      "alias": "engine";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class AtralumeIconHarness extends ComponentHarness {
  static hostSelector: string;
  getName(): Promise<string | null>;
  getLabel(): Promise<string | null>;
  isDecorative(): Promise<boolean>;
  getSize(): Promise<string | null>;
}
export declare const checkIcon: {
  readonly name: "check";
  readonly paths: readonly ["M5 12l4 4L19 6"];
  readonly category: "status-feedback";
  readonly keywords: readonly ["success", "done", "ok"];
  readonly aliases: readonly ["@tui.check"];
};
export declare const closeIcon: {
  readonly name: "close";
  readonly paths: readonly ["M6 6l12 12M6 18L18 6"];
  readonly category: "actions";
  readonly keywords: readonly ["dismiss", "cancel", "x"];
  readonly aliases: readonly ["@tui.x"];
};
export declare const arrowRightIcon: {
  readonly name: "arrow-right";
  readonly paths: readonly ["M5 12h14m-6-6 6 6-6 6"];
  readonly mirrorInRtl: true;
  readonly category: "arrows";
  readonly keywords: readonly ["next", "forward"];
  readonly aliases: readonly ["@tui.arrow-right"];
};
export declare const chevronDownIcon: {
  readonly name: "chevron-down";
  readonly paths: readonly ["m6 9 6 6 6-6"];
  readonly category: "arrows";
  readonly keywords: readonly ["expand", "dropdown"];
  readonly aliases: readonly ["@tui.chevron-down"];
};
export declare const infoIcon: {
  readonly name: "info";
  readonly paths: readonly ["M12 11v6m0-10v1M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20"];
  readonly category: "status-feedback";
  readonly keywords: readonly ["information", "help"];
  readonly aliases: readonly ["@tui.info"];
};
export declare const warningIcon: {
  readonly name: "warning";
  readonly paths: readonly ["M12 9v4m0 3v1M12 3 2 21h20L12 3"];
  readonly category: "status-feedback";
  readonly keywords: readonly ["alert", "caution"];
  readonly aliases: readonly ["@tui.triangle-alert"];
};
export declare const userIcon: {
  readonly name: "user";
  readonly paths: readonly ["M20 21v-2a7 7 0 0 0-14 0v2M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8"];
  readonly category: "users";
  readonly keywords: readonly ["person", "profile", "account"];
  readonly aliases: readonly ["@tui.user"];
};
export declare const menuIcon: {
  readonly name: "menu";
  readonly paths: readonly ["M4 6h16M4 12h16M4 18h16"];
  readonly category: "navigation";
  readonly keywords: readonly ["hamburger", "navigation"];
  readonly aliases: readonly ["@tui.menu"];
};
/** Built-in structured icons shipped with the icon entrypoint. */
export declare const ATRALUME_BUILTIN_ICONS: readonly [{
  readonly name: "check";
  readonly paths: readonly ["M5 12l4 4L19 6"];
  readonly category: "status-feedback";
  readonly keywords: readonly ["success", "done", "ok"];
  readonly aliases: readonly ["@tui.check"];
}, {
  readonly name: "close";
  readonly paths: readonly ["M6 6l12 12M6 18L18 6"];
  readonly category: "actions";
  readonly keywords: readonly ["dismiss", "cancel", "x"];
  readonly aliases: readonly ["@tui.x"];
}, {
  readonly name: "arrow-right";
  readonly paths: readonly ["M5 12h14m-6-6 6 6-6 6"];
  readonly mirrorInRtl: true;
  readonly category: "arrows";
  readonly keywords: readonly ["next", "forward"];
  readonly aliases: readonly ["@tui.arrow-right"];
}, {
  readonly name: "chevron-down";
  readonly paths: readonly ["m6 9 6 6 6-6"];
  readonly category: "arrows";
  readonly keywords: readonly ["expand", "dropdown"];
  readonly aliases: readonly ["@tui.chevron-down"];
}, {
  readonly name: "info";
  readonly paths: readonly ["M12 11v6m0-10v1M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20"];
  readonly category: "status-feedback";
  readonly keywords: readonly ["information", "help"];
  readonly aliases: readonly ["@tui.info"];
}, {
  readonly name: "warning";
  readonly paths: readonly ["M12 9v4m0 3v1M12 3 2 21h20L12 3"];
  readonly category: "status-feedback";
  readonly keywords: readonly ["alert", "caution"];
  readonly aliases: readonly ["@tui.triangle-alert"];
}, {
  readonly name: "user";
  readonly paths: readonly ["M20 21v-2a7 7 0 0 0-14 0v2M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8"];
  readonly category: "users";
  readonly keywords: readonly ["person", "profile", "account"];
  readonly aliases: readonly ["@tui.user"];
}, {
  readonly name: "menu";
  readonly paths: readonly ["M4 6h16M4 12h16M4 18h16"];
  readonly category: "navigation";
  readonly keywords: readonly ["hamburger", "navigation"];
  readonly aliases: readonly ["@tui.menu"];
}];
export declare const ATR_ICONS: InjectionToken<readonly AtralumeIconDefinition[]>;
export declare class AtralumeIconRegistry {
  private readonly parent;
  private readonly definitions;
  private readonly aliases;
  constructor();
  /** Resolve a registered icon; throws in development when missing. */
  get(name: string): AtralumeIconDefinition | null;
  /** Resolve without throwing — preferred for `engine="auto"`. */
  tryGet(name: string): AtralumeIconDefinition | null;
  has(name: string): boolean;
  /** Canonical names registered in this injector (excluding parent). */
  names(): readonly string[];
  /**
   * Register additional structured icons at runtime (SSR-safe; no network).
   * Rejects invalid names, unsafe path data, and duplicate names unless replaced.
   */
  register(icons: readonly AtralumeIconDefinition[], options?: {
    allowReplace?: boolean;
  }): void;
  /** Map an alias onto an existing canonical name in this injector. */
  registerAlias(alias: string, target: string): void;
  private resolveName;
  private registerDefinition;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeIconRegistry, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Register only developer-owned structured path icons.
 * Never pass user-supplied SVG markup, remote URLs, or unsanitized HTML.
 * One provider call per injector; combine arrays when needed.
 * Child injectors may extend a parent registry.
 */
export declare function provideAtralumeIcons(icons: readonly AtralumeIconDefinition[]): Provider[];
export type { AtralumeIconEngine };