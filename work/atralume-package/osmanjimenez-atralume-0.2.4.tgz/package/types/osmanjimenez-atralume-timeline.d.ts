import { TuiTimelineComponent, TuiTimelineItem as AtralumeTimelineItem } from "@taiga-ui/kit";
import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
type AtralumeTimelineOrientation = "horizontal" | "vertical";
/**
 * Brand host for Taiga UI `TuiTimelineComponent`.
 * Extends the Taiga host (instead of nesting it) so projected
 * `label[tuiTimelineItem]` can `inject(TuiTimelineComponent)`.
 */
export declare class AtralumeTimeline extends TuiTimelineComponent {
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeTimeline, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeTimeline, "atr-timeline", never, {}, {}, never, ["*"], true, never>;
}
export declare class AtralumeTimelineHarness extends ComponentHarness {
  static hostSelector: string;
  getOrientation(): Promise<string | null>;
  getItemCount(): Promise<number>;
}
export { AtralumeTimelineItem, type AtralumeTimelineOrientation };