import * as i0 from "@angular/core";
/**
 * Immersive equirectangular (2:1) panorama viewer.
 * Drag + inertia, pinch zoom, optional DeviceOrientation gyro, and a light
 * stereo/VR split for phone cardboard / fullscreen comfort — no WebGL dependency.
 */
export declare class AtralumeImage360 {
  readonly src: import("@angular/core").InputSignal<string>;
  readonly alt: import("@angular/core").InputSignal<string>;
  readonly label: import("@angular/core").InputSignal<string>;
  readonly enableGyro: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly enableVr: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly initialYaw: import("@angular/core").InputSignal<number>;
  readonly initialPitch: import("@angular/core").InputSignal<number>;
  protected readonly yaw: import("@angular/core").WritableSignal<number>;
  protected readonly pitch: import("@angular/core").WritableSignal<number>;
  protected readonly zoom: import("@angular/core").WritableSignal<number>;
  protected readonly gyroActive: import("@angular/core").WritableSignal<boolean>;
  protected readonly vr: import("@angular/core").WritableSignal<boolean>;
  protected readonly chromeVisible: import("@angular/core").WritableSignal<boolean>;
  protected readonly hintVisible: import("@angular/core").WritableSignal<boolean>;
  protected readonly status: import("@angular/core").WritableSignal<"idle" | "loading" | "ready" | "error">;
  protected readonly gyroSupported: import("@angular/core").WritableSignal<boolean>;
  protected readonly gyroDenied: import("@angular/core").WritableSignal<boolean>;
  protected readonly yawLabel: import("@angular/core").Signal<string>;
  protected readonly pitchClamp: import("@angular/core").Signal<number>;
  protected readonly sceneStyle: import("@angular/core").Signal<Record<string, string>>;
  protected readonly sceneStyleRight: import("@angular/core").Signal<Record<string, string>>;
  protected readonly ariaDescription: import("@angular/core").Signal<string>;
  private readonly host;
  private readonly destroyRef;
  private readonly pointers;
  private dragOrigin;
  private pinchOrigin;
  private samples;
  private velocity;
  private inertiaFrame;
  private chromeTimer;
  private hintTimer;
  private reducedMotion;
  private orientationHandler;
  private gyroBase;
  private imageProbe;
  constructor();
  protected startPointer(event: PointerEvent): void;
  protected movePointer(event: PointerEvent): void;
  protected endPointer(event: PointerEvent): void;
  protected onKey(event: KeyboardEvent): void;
  protected onWheel(event: WheelEvent): void;
  protected onSceneActivate(): void;
  protected changeZoom(delta: number): void;
  protected reset(): void;
  protected toggleGyro(): Promise<void>;
  protected toggleVr(force?: boolean): void;
  protected fullscreen(): Promise<void>;
  protected retryLoad(): void;
  private enterFullscreen;
  private preload;
  private buildSceneStyle;
  private pointerDistance;
  private launchInertia;
  private stopInertia;
  private detachGyro;
  private showChrome;
  private scheduleChromeHide;
  private nudgeYaw;
  private nudgePitch;
  private setZoom;
  private normalizeYaw;
  private clampPitch;
  private shortestAngle;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeImage360, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeImage360, "atr-image-360", never, {
    "src": {
      "alias": "src";
      "required": true;
      "isSignal": true;
    };
    "alt": {
      "alias": "alt";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "enableGyro": {
      "alias": "enableGyro";
      "required": false;
      "isSignal": true;
    };
    "enableVr": {
      "alias": "enableVr";
      "required": false;
      "isSignal": true;
    };
    "initialYaw": {
      "alias": "initialYaw";
      "required": false;
      "isSignal": true;
    };
    "initialPitch": {
      "alias": "initialPitch";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}