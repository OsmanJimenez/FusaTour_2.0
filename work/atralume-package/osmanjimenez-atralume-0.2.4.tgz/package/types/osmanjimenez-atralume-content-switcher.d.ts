import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
type AtralumeContentSwitcherSize = "s" | "m" | "l";
/**
 * Thin adapter over Taiga UI `TuiSegmented` for mutually exclusive content modes.
 * Project buttons or links as options.
 */
export declare class AtralumeContentSwitcher {
  readonly size: import("@angular/core").InputSignal<AtralumeContentSwitcherSize>;
  readonly activeItemIndex: import("@angular/core").ModelSignal<number>;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeContentSwitcher, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeContentSwitcher, "atr-content-switcher", never, {
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "activeItemIndex": {
      "alias": "activeItemIndex";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {
    "activeItemIndex": "activeItemIndexChange";
  }, never, ["*"], true, never>;
}
export declare class AtralumeContentSwitcherHarness extends ComponentHarness {
  static hostSelector: string;
  getActiveItemIndex(): Promise<number>;
  isDisabled(): Promise<boolean>;
  getOptionCount(): Promise<number>;
}
export type { AtralumeContentSwitcherSize };