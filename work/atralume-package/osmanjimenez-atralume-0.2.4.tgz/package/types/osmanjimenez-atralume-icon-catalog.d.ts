import { AtralumeIconCatalogEntry, AtralumeIconCategory, AtralumeIconSearchOptions, AtralumeIconSource } from "@osmanjimenez/atralume/icon";
export declare const ATRALUME_ICON_CATALOG_VERSION = "0.2.4";
export declare const ATRALUME_ICON_CATEGORIES: readonly AtralumeIconCategory[];
export declare const ATRALUME_ICON_CATALOG: readonly AtralumeIconCatalogEntry[];
/** Resolve a friendly or `@tui.*` name to the Taiga mask token. */
export declare function toTuiIconName(name: string): string;
/** Look up a single catalog entry by name or alias. */
export declare function getAtralumeIconCatalogEntry(name: string): AtralumeIconCatalogEntry | undefined;
export declare function listAtralumeIconCategories(): readonly AtralumeIconCategory[];
export declare function countAtralumeIcons(options?: {
  category?: AtralumeIconCategory | "all";
  source?: AtralumeIconSource | "all";
}): number;
/**
 * Case-insensitive catalog search over name, alias, category, and keywords.
 * The catalog is metadata-only — rendering still goes through `atr-icon`
 * (`engine="tui"` / `"auto"`) or the structured registry.
 */
export declare function searchAtralumeIcons(options?: AtralumeIconSearchOptions): readonly AtralumeIconCatalogEntry[];