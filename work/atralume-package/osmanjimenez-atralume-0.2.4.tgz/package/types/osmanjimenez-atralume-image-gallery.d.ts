import { AtralumeImagePreview, AtralumePreviewImage } from "@osmanjimenez/atralume/image-preview";
import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
type CarouselApi = {
  next: () => void;
  prev: () => void;
};
type AtralumeImageGalleryLayout = "carousel" | "mosaic";
interface AtralumeGalleryImage extends AtralumePreviewImage {
  readonly id: string;
  readonly width?: number;
  readonly height?: number;
  readonly location?: string;
  readonly tags?: readonly string[];
}
/** Responsive image collection composed from Taiga carousel, Atralume Image, and Atralume Preview. */
export declare class AtralumeImageGallery {
  readonly images: import("@angular/core").InputSignal<readonly AtralumeGalleryImage[]>;
  readonly label: import("@angular/core").InputSignal<string>;
  readonly layout: import("@angular/core").InputSignal<AtralumeImageGalleryLayout>;
  readonly activeIndex: import("@angular/core").ModelSignal<number>;
  readonly loop: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly showThumbnails: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly showCaptions: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly previewable: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly activeChange: import("@angular/core").OutputEmitterRef<number>;
  protected readonly preview: import("@angular/core").Signal<AtralumeImagePreview | undefined>;
  protected readonly carousel: import("@angular/core").Signal<CarouselApi | undefined>;
  private readonly element;
  protected readonly max: import("@angular/core").Signal<number>;
  protected readonly current: import("@angular/core").Signal<AtralumeGalleryImage>;
  protected readonly previewImages: import("@angular/core").Signal<readonly AtralumePreviewImage[]>;
  protected readonly isMosaic: import("@angular/core").Signal<boolean>;
  protected onIndex(index: number): void;
  /**
   * Prefer Taiga carousel scroll API in the browser so intersection observers
   * stay in sync. Fall back to index mutation when scrollTo is unavailable
   * (unit tests / jsdom).
   */
  protected previous(): void;
  protected next(): void;
  protected openPreview(index: number, origin: MouseEvent): void;
  protected selectTile(index: number, event: MouseEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeImageGallery, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeImageGallery, "atr-image-gallery", never, {
    "images": {
      "alias": "images";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "layout": {
      "alias": "layout";
      "required": false;
      "isSignal": true;
    };
    "activeIndex": {
      "alias": "activeIndex";
      "required": false;
      "isSignal": true;
    };
    "loop": {
      "alias": "loop";
      "required": false;
      "isSignal": true;
    };
    "showThumbnails": {
      "alias": "showThumbnails";
      "required": false;
      "isSignal": true;
    };
    "showCaptions": {
      "alias": "showCaptions";
      "required": false;
      "isSignal": true;
    };
    "previewable": {
      "alias": "previewable";
      "required": false;
      "isSignal": true;
    };
  }, {
    "activeIndex": "activeIndexChange";
    "activeChange": "activeChange";
  }, never, never, true, never>;
}
export declare class AtralumeImageGalleryHarness extends ComponentHarness {
  static hostSelector: string;
  next(): Promise<void>;
  getIndex(): Promise<string>;
  getTileCount(): Promise<number>;
  getCaptionText(): Promise<string>;
}
export type { AtralumeGalleryImage, AtralumeImageGalleryLayout };