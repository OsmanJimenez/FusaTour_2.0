import { TuiSizeS } from "@taiga-ui/core";
import * as i0 from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
type AtralumeActionBarSize = TuiSizeS;
/**
 * Thin adapter over Taiga UI `TuiActionBar` for multi-select / bulk action toolbars.
 * Project status text and action buttons; pair with a popup host when floating.
 */
export declare class AtralumeActionBar {
  /** Expands overflow / mobile action chrome when true. */
  readonly expanded: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly size: import("@angular/core").InputSignal<TuiSizeS>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AtralumeActionBar, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AtralumeActionBar, "atr-action-bar", never, {
    "expanded": {
      "alias": "expanded";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
export declare class AtralumeActionBarHarness extends ComponentHarness {
  static hostSelector: string;
  isExpanded(): Promise<boolean>;
  getSize(): Promise<string | null>;
  getActionCount(): Promise<number>;
}
export type { AtralumeActionBarSize };