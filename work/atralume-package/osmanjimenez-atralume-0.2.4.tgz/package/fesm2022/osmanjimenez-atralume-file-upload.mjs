import { isPlatformBrowser } from "@angular/common";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, Directive, PLATFORM_ID, booleanAttribute, computed, effect, forwardRef, inject, input, output, signal, untracked, viewChild } from "@angular/core";
import { NG_VALIDATORS, NG_VALUE_ACCESSOR } from "@angular/forms";
import { ɵAtralumeValueControl } from "@osmanjimenez/atralume/internal/forms";
import { AtralumeFormField } from "@osmanjimenez/atralume/form-field";
import { AtralumeButton } from "@osmanjimenez/atralume/button";
import { AtralumeIconButton } from "@osmanjimenez/atralume/icon-button";
import { AtralumeIcon, closeIcon, provideAtralumeIcons } from "@osmanjimenez/atralume/icon";
import { AtralumeList, AtralumeListHeadline, AtralumeListItem, AtralumeListSupporting } from "@osmanjimenez/atralume/list";
import { AtralumeProgressBar } from "@osmanjimenez/atralume/progress";
import { TuiInputFiles } from "@taiga-ui/kit";
import * as i1 from "@taiga-ui/cdk";
import { TuiNativeValidator } from "@taiga-ui/cdk";
import * as i2 from "@taiga-ui/core/directives/appearance";
import { TuiWithAppearance } from "@taiga-ui/core/directives/appearance";
import { ɵATR_FORM_FIELD_CONTROL, ɵAtralumeNativeTextControl } from "@osmanjimenez/atralume";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeFileInput = class AtralumeFileInput extends ɵAtralumeNativeTextControl {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeFileInput,
		deps: null,
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeFileInput,
		isStandalone: true,
		selector: "input[atrFileInput]",
		host: {
			properties: { "attr.tuiInputFiles": "\"\"" },
			classAttribute: "atr-file-input"
		},
		providers: [{
			provide: ɵATR_FORM_FIELD_CONTROL,
			useExisting: forwardRef(() => AtralumeFileInput)
		}],
		usesInheritance: true,
		hostDirectives: [{ directive: i1.TuiNativeValidator }, { directive: i2.TuiWithAppearance }],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeFileInput,
	decorators: [{
		type: Directive,
		args: [{
			selector: "input[atrFileInput]",
			standalone: true,
			hostDirectives: [TuiNativeValidator, TuiWithAppearance],
			providers: [{
				provide: ɵATR_FORM_FIELD_CONTROL,
				useExisting: forwardRef(() => AtralumeFileInput)
			}],
			host: {
				class: "atr-file-input",
				"[attr.tuiInputFiles]": "\"\""
			}
		}]
	}]
});
var AtralumeFileUpload = class AtralumeFileUpload extends ɵAtralumeValueControl {
	multiple = input(false, {
		...ngDevMode ? { debugName: "multiple" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	accept = input("", ...ngDevMode ? [{ debugName: "accept" }] : /* istanbul ignore next */ []);
	maxSize = input(Number.POSITIVE_INFINITY, ...ngDevMode ? [{ debugName: "maxSize" }] : /* istanbul ignore next */ []);
	minSize = input(0, ...ngDevMode ? [{ debugName: "minSize" }] : /* istanbul ignore next */ []);
	maxCount = input(Number.POSITIVE_INFINITY, ...ngDevMode ? [{ debugName: "maxCount" }] : /* istanbul ignore next */ []);
	detectDuplicates = input(true, {
		...ngDevMode ? { debugName: "detectDuplicates" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	append = input(true, {
		...ngDevMode ? { debugName: "append" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	dropZone = input(true, {
		...ngDevMode ? { debugName: "dropZone" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	imagePreviews = input(false, {
		...ngDevMode ? { debugName: "imagePreviews" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	fileValidator = input(null, ...ngDevMode ? [{ debugName: "fileValidator" }] : /* istanbul ignore next */ []);
	states = input([], ...ngDevMode ? [{ debugName: "states" }] : /* istanbul ignore next */ []);
	rejected = output();
	removed = output();
	cancelRequested = output();
	files = computed(() => this.value() ?? [], ...ngDevMode ? [{ debugName: "files" }] : /* istanbul ignore next */ []);
	dragging = signal(false, ...ngDevMode ? [{ debugName: "dragging" }] : /* istanbul ignore next */ []);
	rejections = signal([], ...ngDevMode ? [{ debugName: "rejections" }] : /* istanbul ignore next */ []);
	previews = signal(/* @__PURE__ */ new Map(), ...ngDevMode ? [{ debugName: "previews" }] : /* istanbul ignore next */ []);
	fileInput = viewChild.required("nativeFile", ...ngDevMode ? [{ debugName: "fileInput" }] : /* istanbul ignore next */ []);
	browser = isPlatformBrowser(inject(PLATFORM_ID));
	urls = /* @__PURE__ */ new Map();
	dragDepth = 0;
	validatorChanged = () => void 0;
	constructor() {
		super();
		effect(() => {
			const files = this.files(), enabled = this.imagePreviews();
			if (!this.browser) return;
			const api = this.element.ownerDocument.defaultView?.URL;
			if (!api?.createObjectURL) return;
			for (const [file, url] of this.urls) if (!enabled || !files.includes(file)) {
				api.revokeObjectURL(url);
				this.urls.delete(file);
			}
			if (enabled) {
				for (const file of files) if (file.type.startsWith("image/") && file.type !== "image/svg+xml" && !this.urls.has(file)) this.urls.set(file, api.createObjectURL(file));
			}
			this.previews.set(new Map(this.urls));
		});
		effect(() => {
			this.value();
			this.accept();
			this.maxSize();
			this.minSize();
			this.maxCount();
			this.fileValidator();
			this.required();
			untracked(() => this.validatorChanged());
		});
		inject(DestroyRef).onDestroy(() => {
			const api = this.element.ownerDocument.defaultView?.URL;
			for (const url of this.urls.values()) api?.revokeObjectURL(url);
			this.urls.clear();
		});
	}
	fileKey(file) {
		return file.name + "|" + file.size + "|" + file.lastModified + "|" + file.type;
	}
	status(file) {
		return this.states().find((state) => state.file === file) ?? {
			file,
			status: "selected"
		};
	}
	formatSize(bytes) {
		if (!Number.isFinite(bytes) || bytes < 0) return "0 B";
		if (bytes < 1024) return `${bytes} B`;
		const kb = bytes / 1024;
		if (kb < 1024) return `${kb < 10 ? kb.toFixed(1) : Math.round(kb)} KB`;
		const mb = kb / 1024;
		return `${mb < 10 ? mb.toFixed(1) : Math.round(mb)} MB`;
	}
	statusLabel(status) {
		switch (status) {
			case "uploading": return "Uploading";
			case "success": return "Uploaded";
			case "error": return "Failed";
			case "cancelled": return "Cancelled";
			default: return "Ready";
		}
	}
	errorsFor(file) {
		const errors = [];
		if (file.size > this.maxSize()) errors.push("File is too large");
		if (file.size < this.minSize()) errors.push("File is too small");
		const accept = this.accept().split(",").map((value) => value.trim().toLowerCase()).filter(Boolean);
		const type = file.type.toLowerCase(), name = file.name.toLowerCase();
		if (accept.length && !accept.some((rule) => rule.startsWith(".") ? name.endsWith(rule) : rule.endsWith("/*") ? type.startsWith(rule.slice(0, -1)) : type === rule)) errors.push("File type is not accepted");
		const custom = this.fileValidator()?.(file);
		if (custom) errors.push(custom);
		return errors;
	}
	choose() {
		if (this.browser && !this.blocked() && !this.readonly()) this.fileInput().nativeElement.click();
	}
	changed(event) {
		const input = event.target;
		this.selectFiles([...input.files ?? []]);
		input.value = "";
	}
	selectFiles(incoming) {
		if (this.blocked() || this.readonly()) return;
		const existing = this.multiple() && this.append() ? [...this.files()] : [];
		const accepted = [...existing];
		const rejected = [];
		const keys = new Set(existing.map((file) => this.fileKey(file)));
		const limit = this.multiple() ? this.maxCount() : 1;
		for (const file of incoming) {
			const errors = this.errorsFor(file);
			if (accepted.length >= limit) errors.push("Too many files");
			if (this.detectDuplicates() && keys.has(this.fileKey(file))) errors.push("Duplicate file");
			if (errors.length) rejected.push({
				file,
				errors
			});
			else {
				accepted.push(file);
				keys.add(this.fileKey(file));
			}
		}
		this.rejections.set(rejected);
		if (rejected.length) this.rejected.emit(rejected);
		if (accepted.length !== existing.length) this.commit(accepted);
	}
	remove(file) {
		if (this.blocked() || this.readonly()) return;
		this.commit(this.files().filter((item) => item !== file));
		this.removed.emit(file);
	}
	dragEnter(event) {
		event.preventDefault();
		if (this.dropZone() && !this.blocked() && !this.readonly()) {
			this.dragDepth++;
			this.dragging.set(true);
		}
	}
	dragLeave(event) {
		event.preventDefault();
		this.dragDepth = Math.max(0, this.dragDepth - 1);
		this.dragging.set(this.dragDepth > 0);
	}
	dragOver(event) {
		event.preventDefault();
		if (event.dataTransfer) event.dataTransfer.dropEffect = this.blocked() || this.readonly() ? "none" : "copy";
	}
	dropped(event) {
		event.preventDefault();
		this.dragDepth = 0;
		this.dragging.set(false);
		if (this.dropZone()) this.selectFiles([...event.dataTransfer?.files ?? []]);
	}
	validate() {
		const files = this.files();
		if (this.required() && !files.length) return { required: true };
		if (files.length > (this.multiple() ? this.maxCount() : 1)) return { fileCount: true };
		return files.some((file) => this.errorsFor(file).length) ? { files: true } : null;
	}
	registerOnValidatorChange(fn) {
		this.validatorChanged = fn;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeFileUpload,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeFileUpload,
		isStandalone: true,
		selector: "atr-file-upload",
		inputs: {
			multiple: {
				classPropertyName: "multiple",
				publicName: "multiple",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			accept: {
				classPropertyName: "accept",
				publicName: "accept",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxSize: {
				classPropertyName: "maxSize",
				publicName: "maxSize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minSize: {
				classPropertyName: "minSize",
				publicName: "minSize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxCount: {
				classPropertyName: "maxCount",
				publicName: "maxCount",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			detectDuplicates: {
				classPropertyName: "detectDuplicates",
				publicName: "detectDuplicates",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			append: {
				classPropertyName: "append",
				publicName: "append",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropZone: {
				classPropertyName: "dropZone",
				publicName: "dropZone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			imagePreviews: {
				classPropertyName: "imagePreviews",
				publicName: "imagePreviews",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fileValidator: {
				classPropertyName: "fileValidator",
				publicName: "fileValidator",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			states: {
				classPropertyName: "states",
				publicName: "states",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			rejected: "rejected",
			removed: "removed",
			cancelRequested: "cancelRequested"
		},
		host: {
			properties: { "class.atr-file-upload--dragging": "dragging()" },
			classAttribute: "atr-file-upload"
		},
		providers: [
			provideAtralumeIcons([closeIcon]),
			{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => AtralumeFileUpload),
				multi: true
			},
			{
				provide: NG_VALIDATORS,
				useExisting: forwardRef(() => AtralumeFileUpload),
				multi: true
			}
		],
		viewQueries: [{
			propertyName: "fileInput",
			first: true,
			predicate: ["nativeFile"],
			descendants: true,
			isSignal: true
		}],
		usesInheritance: true,
		ngImport: i0,
		template: "<div\n  class=\"drop-zone\"\n  role=\"group\"\n  [attr.aria-label]=\"label() + ' file selection'\"\n  [class.drop-zone--enabled]=\"dropZone()\"\n  [class.drop-zone--has-files]=\"files().length > 0\"\n  (dragenter)=\"dragEnter($event)\"\n  (dragleave)=\"dragLeave($event)\"\n  (dragover)=\"dragOver($event)\"\n  (drop)=\"dropped($event)\"\n>\n  <atr-form-field [hint]=\"hint()\" [error]=\"error()\">\n    <span class=\"atr-file-upload__label\">\n      {{ label() }}\n      @if (required()) {\n        *\n      }\n    </span>\n    <label tuiInputFiles class=\"atr-file-upload__input-files\">\n      <input\n        #nativeFile\n        atrFileInput\n        type=\"file\"\n        [id]=\"controlId()\"\n        [attr.aria-label]=\"label()\"\n        [accept]=\"accept()\"\n        [multiple]=\"multiple()\"\n        [disabled]=\"blocked() || readonly()\"\n        [attr.aria-invalid]=\"displayInvalid()\"\n        (change)=\"changed($event)\"\n      />\n      <ng-template let-dragged>\n        <span class=\"atr-file-upload__prompt\">\n          @if (dragged) {\n            <span class=\"atr-file-upload__cta\">Drop files to add them</span>\n            <span class=\"atr-file-upload__hint\"\n              >Release to attach them to this field.</span\n            >\n          } @else {\n            <span class=\"atr-file-upload__cta\">{{\n              multiple() ? \"Choose files\" : \"Choose file\"\n            }}</span>\n            @if (dropZone()) {\n              <span class=\"atr-file-upload__hint\"\n                >or drag and drop them into this area</span\n              >\n            }\n          }\n        </span>\n      </ng-template>\n    </label>\n  </atr-form-field>\n</div>\n<p class=\"atr-file-upload__status\" role=\"status\">\n  @if (files().length === 0) {\n    No files selected yet\n  } @else if (files().length === 1) {\n    1 file ready\n  } @else {\n    {{ files().length }} files ready\n  }\n</p>\n@if (rejections().length) {\n  <ul class=\"errors\" aria-label=\"File validation errors\">\n    @for (rejection of rejections(); track $index) {\n      <li>\n        <span class=\"errors__name\">{{ rejection.file.name }}</span>\n        <span class=\"errors__detail\">{{ rejection.errors.join(\". \") }}</span>\n      </li>\n    }\n  </ul>\n}\n@if (files().length) {\n  <ul atrList class=\"atr-file-upload__list\">\n    @for (file of files(); track fileKey(file)) {\n      <li atrListItem class=\"atr-file-upload__item\">\n        @if (previews().get(file); as preview) {\n          <img\n            class=\"atr-file-upload__preview\"\n            [src]=\"preview\"\n            [alt]=\"file.name + ' preview'\"\n            (error)=\"$event.target.hidden = true\"\n          />\n        }\n        <div class=\"file-details\">\n          <span atrListHeadline>{{ file.name }}</span>\n          <span atrListSupporting>\n            {{ formatSize(file.size) }} · {{ statusLabel(status(file).status) }}\n          </span>\n          @if (status(file).status === \"uploading\") {\n            <atr-progress-bar\n              [label]=\"'Upload ' + file.name\"\n              [value]=\"status(file).progress ?? null\"\n            />\n          }\n          @if (status(file).error) {\n            <p class=\"atr-file-upload__file-error\">\n              {{ status(file).error }}\n            </p>\n          }\n        </div>\n        @if (status(file).cancellable) {\n          <button\n            atrButton\n            appearance=\"text\"\n            type=\"button\"\n            [disabled]=\"blocked() || readonly()\"\n            (click)=\"cancelRequested.emit(file)\"\n          >\n            Cancel {{ file.name }}\n          </button>\n        }\n        <button\n          atrIconButton\n          type=\"button\"\n          [attr.aria-label]=\"'Remove ' + file.name\"\n          [disabled]=\"blocked() || readonly()\"\n          (click)=\"remove(file)\"\n        >\n          <atr-icon name=\"close\" />\n        </button>\n      </li>\n    }\n  </ul>\n}\n",
		styles: [":host{display:grid;gap:var(--atr-comp-file-upload-gap);min-inline-size:0;color:var(--atr-comp-file-upload-label-color);font-family:var(--atr-ref-font-family-plain)}.drop-zone{padding:var(--atr-sys-spacing-sm);border-radius:var(--atr-comp-file-upload-shape);background:var(--atr-comp-file-upload-container-color)}.drop-zone--enabled{border:1px dashed var(--atr-comp-file-upload-border-color);background:color-mix(in srgb,var(--atr-comp-file-upload-container-color) 88%,var(--atr-sys-color-surface) 12%)}.drop-zone--has-files{border-style:solid;border-color:color-mix(in srgb,var(--atr-comp-file-upload-border-color) 80%,transparent)}:host(.atr-file-upload--dragging) .drop-zone{border-color:var(--atr-comp-file-upload-focus-color);outline:var(--atr-sys-focus-ring-width) solid color-mix(in srgb,var(--atr-comp-file-upload-focus-color) 45%,transparent);outline-offset:2px;background:color-mix(in srgb,var(--atr-sys-color-primary-container) 42%,var(--atr-comp-file-upload-container-color))}.atr-file-upload__label{display:block;margin-block-end:var(--atr-sys-spacing-xs);font-weight:var(--atr-ref-font-weight-medium)}.atr-file-upload__input-files{box-sizing:border-box;display:grid;place-items:center;inline-size:100%;min-block-size:8.5rem;margin-block-start:0;padding:var(--atr-sys-spacing-lg) var(--atr-sys-spacing-md);background:color-mix(in srgb,var(--atr-sys-color-surface) 70%,var(--atr-comp-file-upload-container-color));border-color:var(--atr-comp-file-upload-border-color);border-radius:calc(var(--atr-comp-file-upload-shape) - .15rem);color:var(--atr-comp-file-upload-label-color);text-align:center;cursor:pointer}.atr-file-upload__prompt{display:grid;gap:var(--atr-sys-spacing-xs);justify-items:center;max-inline-size:22rem}.atr-file-upload__cta{display:block;color:var(--atr-sys-color-primary);font-size:var(--atr-sys-typography-title-medium-font-size, 1rem);font-weight:var(--atr-ref-font-weight-medium);line-height:1.35;text-decoration:underline;text-underline-offset:.18em}.atr-file-upload__hint{display:block;color:var(--atr-sys-color-on-surface-variant);font-size:var(--atr-sys-typography-body-small-font-size);line-height:1.4;opacity:1}.atr-file-upload__status{margin:0;color:var(--atr-sys-color-on-surface-variant);font-size:var(--atr-sys-typography-body-small-font-size)}.atr-file-upload__list{margin:0;padding:0;background:transparent}.atr-file-upload__item{align-items:flex-start;padding-block:var(--atr-sys-spacing-sm);border:var(--atr-ref-border-width-thin, 1px) solid var(--atr-sys-color-outline-variant);border-radius:var(--atr-comp-file-upload-shape);background:var(--atr-sys-color-surface-container-low, var(--atr-sys-color-surface))}.atr-file-upload__item+.atr-file-upload__item{margin-block-start:var(--atr-sys-spacing-xs)}.file-details{flex:1;min-inline-size:0;overflow-wrap:anywhere}.atr-file-upload__preview,img{inline-size:var(--atr-ref-spacing-12);block-size:var(--atr-ref-spacing-12);flex-shrink:0;border-radius:var(--atr-sys-shape-small, .5rem);object-fit:cover;background:var(--atr-sys-color-surface-container-high)}.atr-file-upload__file-error{margin:var(--atr-sys-spacing-xs) 0 0;color:var(--atr-sys-color-error);font-size:var(--atr-sys-typography-body-small-font-size)}.errors{display:grid;gap:var(--atr-sys-spacing-xs);margin:0;padding:var(--atr-sys-spacing-sm) var(--atr-sys-spacing-md);list-style:none;border:var(--atr-ref-border-width-thin, 1px) solid color-mix(in srgb,var(--atr-sys-color-error) 40%,transparent);border-radius:var(--atr-comp-file-upload-shape);background:color-mix(in srgb,var(--atr-sys-color-error-container, var(--atr-sys-color-error)) 18%,var(--atr-sys-color-surface));color:var(--atr-sys-color-error)}.errors li{display:grid;gap:.15rem}.errors__name{font-weight:var(--atr-ref-font-weight-medium);color:var(--atr-sys-color-on-surface)}.errors__detail{color:var(--atr-sys-color-error);font-size:var(--atr-sys-typography-body-small-font-size)}@media(forced-colors:active){.drop-zone--enabled,.atr-file-upload__item,.errors{border-color:CanvasText}.atr-file-upload__cta{color:LinkText}}\n"],
		dependencies: [
			{
				kind: "component",
				type: AtralumeFormField,
				selector: "atr-form-field",
				inputs: [
					"hint",
					"error",
					"appearance",
					"density",
					"label",
					"required",
					"optional",
					"optionalText"
				]
			},
			{
				kind: "component",
				type: AtralumeButton,
				selector: "button[atrButton], a[atrButton]",
				inputs: [
					"appearance",
					"size",
					"disabled",
					"loading",
					"fullWidth",
					"tabindex"
				]
			},
			{
				kind: "directive",
				type: AtralumeIconButton,
				selector: "button[atrIconButton]",
				inputs: ["appearance", "size"]
			},
			{
				kind: "component",
				type: AtralumeIcon,
				selector: "atr-icon",
				inputs: [
					"name",
					"size",
					"decorative",
					"label",
					"engine"
				]
			},
			{
				kind: "directive",
				type: AtralumeList,
				selector: "ul[atrList], ol[atrList]",
				inputs: ["density"]
			},
			{
				kind: "directive",
				type: AtralumeListItem,
				selector: "li[atrListItem], a[atrListItem], button[atrListItem]",
				inputs: ["selected"]
			},
			{
				kind: "directive",
				type: AtralumeListHeadline,
				selector: "[atrListHeadline]"
			},
			{
				kind: "directive",
				type: AtralumeListSupporting,
				selector: "[atrListSupporting]"
			},
			{
				kind: "component",
				type: AtralumeProgressBar,
				selector: "atr-progress-bar"
			},
			{
				kind: "directive",
				type: AtralumeFileInput,
				selector: "input[atrFileInput]"
			},
			{
				kind: "component",
				type: TuiInputFiles,
				selector: "label[tuiInputFiles]",
				inputs: ["tuiInputFiles"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeFileUpload,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-file-upload",
			standalone: true,
			imports: [
				AtralumeFormField,
				AtralumeButton,
				AtralumeIconButton,
				AtralumeIcon,
				AtralumeList,
				AtralumeListItem,
				AtralumeListHeadline,
				AtralumeListSupporting,
				AtralumeProgressBar,
				AtralumeFileInput,
				TuiInputFiles
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [
				provideAtralumeIcons([closeIcon]),
				{
					provide: NG_VALUE_ACCESSOR,
					useExisting: forwardRef(() => AtralumeFileUpload),
					multi: true
				},
				{
					provide: NG_VALIDATORS,
					useExisting: forwardRef(() => AtralumeFileUpload),
					multi: true
				}
			],
			host: {
				class: "atr-file-upload",
				"[class.atr-file-upload--dragging]": "dragging()"
			},
			template: "<div\n  class=\"drop-zone\"\n  role=\"group\"\n  [attr.aria-label]=\"label() + ' file selection'\"\n  [class.drop-zone--enabled]=\"dropZone()\"\n  [class.drop-zone--has-files]=\"files().length > 0\"\n  (dragenter)=\"dragEnter($event)\"\n  (dragleave)=\"dragLeave($event)\"\n  (dragover)=\"dragOver($event)\"\n  (drop)=\"dropped($event)\"\n>\n  <atr-form-field [hint]=\"hint()\" [error]=\"error()\">\n    <span class=\"atr-file-upload__label\">\n      {{ label() }}\n      @if (required()) {\n        *\n      }\n    </span>\n    <label tuiInputFiles class=\"atr-file-upload__input-files\">\n      <input\n        #nativeFile\n        atrFileInput\n        type=\"file\"\n        [id]=\"controlId()\"\n        [attr.aria-label]=\"label()\"\n        [accept]=\"accept()\"\n        [multiple]=\"multiple()\"\n        [disabled]=\"blocked() || readonly()\"\n        [attr.aria-invalid]=\"displayInvalid()\"\n        (change)=\"changed($event)\"\n      />\n      <ng-template let-dragged>\n        <span class=\"atr-file-upload__prompt\">\n          @if (dragged) {\n            <span class=\"atr-file-upload__cta\">Drop files to add them</span>\n            <span class=\"atr-file-upload__hint\"\n              >Release to attach them to this field.</span\n            >\n          } @else {\n            <span class=\"atr-file-upload__cta\">{{\n              multiple() ? \"Choose files\" : \"Choose file\"\n            }}</span>\n            @if (dropZone()) {\n              <span class=\"atr-file-upload__hint\"\n                >or drag and drop them into this area</span\n              >\n            }\n          }\n        </span>\n      </ng-template>\n    </label>\n  </atr-form-field>\n</div>\n<p class=\"atr-file-upload__status\" role=\"status\">\n  @if (files().length === 0) {\n    No files selected yet\n  } @else if (files().length === 1) {\n    1 file ready\n  } @else {\n    {{ files().length }} files ready\n  }\n</p>\n@if (rejections().length) {\n  <ul class=\"errors\" aria-label=\"File validation errors\">\n    @for (rejection of rejections(); track $index) {\n      <li>\n        <span class=\"errors__name\">{{ rejection.file.name }}</span>\n        <span class=\"errors__detail\">{{ rejection.errors.join(\". \") }}</span>\n      </li>\n    }\n  </ul>\n}\n@if (files().length) {\n  <ul atrList class=\"atr-file-upload__list\">\n    @for (file of files(); track fileKey(file)) {\n      <li atrListItem class=\"atr-file-upload__item\">\n        @if (previews().get(file); as preview) {\n          <img\n            class=\"atr-file-upload__preview\"\n            [src]=\"preview\"\n            [alt]=\"file.name + ' preview'\"\n            (error)=\"$event.target.hidden = true\"\n          />\n        }\n        <div class=\"file-details\">\n          <span atrListHeadline>{{ file.name }}</span>\n          <span atrListSupporting>\n            {{ formatSize(file.size) }} · {{ statusLabel(status(file).status) }}\n          </span>\n          @if (status(file).status === \"uploading\") {\n            <atr-progress-bar\n              [label]=\"'Upload ' + file.name\"\n              [value]=\"status(file).progress ?? null\"\n            />\n          }\n          @if (status(file).error) {\n            <p class=\"atr-file-upload__file-error\">\n              {{ status(file).error }}\n            </p>\n          }\n        </div>\n        @if (status(file).cancellable) {\n          <button\n            atrButton\n            appearance=\"text\"\n            type=\"button\"\n            [disabled]=\"blocked() || readonly()\"\n            (click)=\"cancelRequested.emit(file)\"\n          >\n            Cancel {{ file.name }}\n          </button>\n        }\n        <button\n          atrIconButton\n          type=\"button\"\n          [attr.aria-label]=\"'Remove ' + file.name\"\n          [disabled]=\"blocked() || readonly()\"\n          (click)=\"remove(file)\"\n        >\n          <atr-icon name=\"close\" />\n        </button>\n      </li>\n    }\n  </ul>\n}\n",
			styles: [":host{display:grid;gap:var(--atr-comp-file-upload-gap);min-inline-size:0;color:var(--atr-comp-file-upload-label-color);font-family:var(--atr-ref-font-family-plain)}.drop-zone{padding:var(--atr-sys-spacing-sm);border-radius:var(--atr-comp-file-upload-shape);background:var(--atr-comp-file-upload-container-color)}.drop-zone--enabled{border:1px dashed var(--atr-comp-file-upload-border-color);background:color-mix(in srgb,var(--atr-comp-file-upload-container-color) 88%,var(--atr-sys-color-surface) 12%)}.drop-zone--has-files{border-style:solid;border-color:color-mix(in srgb,var(--atr-comp-file-upload-border-color) 80%,transparent)}:host(.atr-file-upload--dragging) .drop-zone{border-color:var(--atr-comp-file-upload-focus-color);outline:var(--atr-sys-focus-ring-width) solid color-mix(in srgb,var(--atr-comp-file-upload-focus-color) 45%,transparent);outline-offset:2px;background:color-mix(in srgb,var(--atr-sys-color-primary-container) 42%,var(--atr-comp-file-upload-container-color))}.atr-file-upload__label{display:block;margin-block-end:var(--atr-sys-spacing-xs);font-weight:var(--atr-ref-font-weight-medium)}.atr-file-upload__input-files{box-sizing:border-box;display:grid;place-items:center;inline-size:100%;min-block-size:8.5rem;margin-block-start:0;padding:var(--atr-sys-spacing-lg) var(--atr-sys-spacing-md);background:color-mix(in srgb,var(--atr-sys-color-surface) 70%,var(--atr-comp-file-upload-container-color));border-color:var(--atr-comp-file-upload-border-color);border-radius:calc(var(--atr-comp-file-upload-shape) - .15rem);color:var(--atr-comp-file-upload-label-color);text-align:center;cursor:pointer}.atr-file-upload__prompt{display:grid;gap:var(--atr-sys-spacing-xs);justify-items:center;max-inline-size:22rem}.atr-file-upload__cta{display:block;color:var(--atr-sys-color-primary);font-size:var(--atr-sys-typography-title-medium-font-size, 1rem);font-weight:var(--atr-ref-font-weight-medium);line-height:1.35;text-decoration:underline;text-underline-offset:.18em}.atr-file-upload__hint{display:block;color:var(--atr-sys-color-on-surface-variant);font-size:var(--atr-sys-typography-body-small-font-size);line-height:1.4;opacity:1}.atr-file-upload__status{margin:0;color:var(--atr-sys-color-on-surface-variant);font-size:var(--atr-sys-typography-body-small-font-size)}.atr-file-upload__list{margin:0;padding:0;background:transparent}.atr-file-upload__item{align-items:flex-start;padding-block:var(--atr-sys-spacing-sm);border:var(--atr-ref-border-width-thin, 1px) solid var(--atr-sys-color-outline-variant);border-radius:var(--atr-comp-file-upload-shape);background:var(--atr-sys-color-surface-container-low, var(--atr-sys-color-surface))}.atr-file-upload__item+.atr-file-upload__item{margin-block-start:var(--atr-sys-spacing-xs)}.file-details{flex:1;min-inline-size:0;overflow-wrap:anywhere}.atr-file-upload__preview,img{inline-size:var(--atr-ref-spacing-12);block-size:var(--atr-ref-spacing-12);flex-shrink:0;border-radius:var(--atr-sys-shape-small, .5rem);object-fit:cover;background:var(--atr-sys-color-surface-container-high)}.atr-file-upload__file-error{margin:var(--atr-sys-spacing-xs) 0 0;color:var(--atr-sys-color-error);font-size:var(--atr-sys-typography-body-small-font-size)}.errors{display:grid;gap:var(--atr-sys-spacing-xs);margin:0;padding:var(--atr-sys-spacing-sm) var(--atr-sys-spacing-md);list-style:none;border:var(--atr-ref-border-width-thin, 1px) solid color-mix(in srgb,var(--atr-sys-color-error) 40%,transparent);border-radius:var(--atr-comp-file-upload-shape);background:color-mix(in srgb,var(--atr-sys-color-error-container, var(--atr-sys-color-error)) 18%,var(--atr-sys-color-surface));color:var(--atr-sys-color-error)}.errors li{display:grid;gap:.15rem}.errors__name{font-weight:var(--atr-ref-font-weight-medium);color:var(--atr-sys-color-on-surface)}.errors__detail{color:var(--atr-sys-color-error);font-size:var(--atr-sys-typography-body-small-font-size)}@media(forced-colors:active){.drop-zone--enabled,.atr-file-upload__item,.errors{border-color:CanvasText}.atr-file-upload__cta{color:LinkText}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		multiple: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "multiple",
				required: false
			}]
		}],
		accept: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "accept",
				required: false
			}]
		}],
		maxSize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxSize",
				required: false
			}]
		}],
		minSize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minSize",
				required: false
			}]
		}],
		maxCount: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxCount",
				required: false
			}]
		}],
		detectDuplicates: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "detectDuplicates",
				required: false
			}]
		}],
		append: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "append",
				required: false
			}]
		}],
		dropZone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropZone",
				required: false
			}]
		}],
		imagePreviews: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "imagePreviews",
				required: false
			}]
		}],
		fileValidator: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fileValidator",
				required: false
			}]
		}],
		states: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "states",
				required: false
			}]
		}],
		rejected: [{
			type: i0.Output,
			args: ["rejected"]
		}],
		removed: [{
			type: i0.Output,
			args: ["removed"]
		}],
		cancelRequested: [{
			type: i0.Output,
			args: ["cancelRequested"]
		}],
		fileInput: [{
			type: i0.ViewChild,
			args: ["nativeFile", { isSignal: true }]
		}]
	}
});
var AtralumeFileUploadHarness = class extends ComponentHarness {
	static hostSelector = "atr-file-upload";
	async getFileNames() {
		return Promise.all((await this.locatorForAll(".atr-list-headline")()).map((item) => item.text()));
	}
	async removeFile(name) {
		const buttons = await this.locatorForAll("button[aria-label]")();
		for (const button of buttons) if (await button.getAttribute("aria-label") === "Remove " + name) {
			await button.click();
			return;
		}
		throw new Error("Selected file not found: " + name);
	}
	async getValidationErrors() {
		return Promise.all((await this.locatorForAll("[aria-label=\"File validation errors\"] li")()).map((item) => item.text()));
	}
	async getStatuses() {
		return Promise.all((await this.locatorForAll(".atr-list-supporting")()).map((item) => item.text()));
	}
	async isDisabled() {
		return (await this.locatorFor("input[type=\"file\"]")()).getProperty("disabled");
	}
};
export { AtralumeFileUpload, AtralumeFileUploadHarness };

//# sourceMappingURL=osmanjimenez-atralume-file-upload.mjs.map