import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, Injectable, InjectionToken, booleanAttribute, computed, inject, input, isDevMode } from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
const ATR_ICONS = new InjectionToken("Atralume icons");
const PATH_PATTERN = /^[MmZzLlHhVvCcSsQqTtAaEe0-9.,+\s-]+$/;
const VIEWBOX_PATTERN = /^[-+\d.\s]+$/;
const NAME_PATTERN = /^[a-z][a-z0-9-]*$/;
function assertValidDefinition(icon) {
	if (!icon.name || !NAME_PATTERN.test(icon.name)) throw new Error("Invalid structured icon definition: " + icon.name);
	if (!icon.paths.length || icon.paths.some((path) => !PATH_PATTERN.test(path)) || icon.viewBox && !VIEWBOX_PATTERN.test(icon.viewBox)) throw new Error("Invalid structured icon definition: " + icon.name);
}
var AtralumeIconRegistry = class AtralumeIconRegistry {
	parent = inject(AtralumeIconRegistry, {
		skipSelf: true,
		optional: true
	});
	definitions = /* @__PURE__ */ new Map();
	aliases = /* @__PURE__ */ new Map();
	constructor() {
		for (const icon of inject(ATR_ICONS, { optional: true }) ?? []) this.registerDefinition(icon, { allowReplace: false });
	}
	get(name) {
		const icon = this.tryGet(name);
		if (!icon && isDevMode()) throw new Error("Unknown Atralume icon: " + name + ". Register it with provideAtralumeIcons.");
		return icon;
	}
	tryGet(name) {
		const canonical = this.resolveName(name);
		return this.definitions.get(canonical) ?? this.parent?.tryGet(canonical) ?? null;
	}
	has(name) {
		return this.tryGet(name) !== null;
	}
	names() {
		return [...this.definitions.keys()].sort();
	}
	register(icons, options = {}) {
		for (const icon of icons) this.registerDefinition(icon, options);
	}
	registerAlias(alias, target) {
		if (!alias || alias === target) throw new Error("Invalid icon alias: " + alias);
		if (!this.has(target) && !this.definitions.has(target)) throw new Error("Cannot alias to unknown icon: " + target + " (alias " + alias + ")");
		if (this.definitions.has(alias) || this.aliases.has(alias) && this.aliases.get(alias) !== target) throw new Error("Duplicate icon alias: " + alias);
		this.aliases.set(alias, target);
	}
	resolveName(name) {
		return this.aliases.get(name) ?? this.parent?.resolveName?.(name) ?? name;
	}
	registerDefinition(icon, options) {
		assertValidDefinition(icon);
		if (this.definitions.has(icon.name) && !options.allowReplace) throw new Error("Duplicate Atralume icon: " + icon.name);
		this.definitions.set(icon.name, icon);
		for (const alias of icon.aliases ?? []) {
			if (!alias || alias === icon.name) continue;
			if (this.definitions.has(alias) || this.aliases.has(alias) && this.aliases.get(alias) !== icon.name) throw new Error("Duplicate icon alias: " + alias);
			this.aliases.set(alias, icon.name);
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeIconRegistry,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeIconRegistry,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeIconRegistry,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
var AtralumeIcon = class AtralumeIcon {
	name = input.required(...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	size = input("medium", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	decorative = input(true, {
		...ngDevMode ? { debugName: "decorative" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	label = input(null, ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	engine = input("registry", ...ngDevMode ? [{ debugName: "engine" }] : /* istanbul ignore next */ []);
	registry = inject(AtralumeIconRegistry);
	definition = computed(() => {
		if (this.engine() === "tui") return void 0;
		if (this.engine() === "auto") return this.registry.tryGet(this.name());
		return this.registry.get(this.name());
	}, ...ngDevMode ? [{ debugName: "definition" }] : /* istanbul ignore next */ []);
	resolvedEngine = computed(() => {
		const mode = this.engine();
		if (mode === "tui") return "tui";
		if (mode === "registry") return "registry";
		return this.definition() ? "registry" : "tui";
	}, ...ngDevMode ? [{ debugName: "resolvedEngine" }] : /* istanbul ignore next */ []);
	tuiIconName = computed(() => {
		const raw = this.name();
		if (raw.startsWith("@tui.")) return raw;
		if (raw.startsWith("@") || raw.includes("/") || raw.startsWith("http")) return raw;
		return `@tui.${raw.replace(/^@tui\./, "")}`;
	}, ...ngDevMode ? [{ debugName: "tuiIconName" }] : /* istanbul ignore next */ []);
	tuiMaskUrl = computed(() => {
		const token = this.tuiIconName();
		if (token.startsWith("http") || token.includes("/")) return `url("${token}")`;
		return `url("/assets/taiga-ui/icons/${token.replace(/^@tui\./, "")}.svg")`;
	}, ...ngDevMode ? [{ debugName: "tuiMaskUrl" }] : /* istanbul ignore next */ []);
	pixelSize = computed(() => {
		const value = this.size();
		return typeof value === "number" && Number.isFinite(value) && value > 0 ? `${value}px` : null;
	}, ...ngDevMode ? [{ debugName: "pixelSize" }] : /* istanbul ignore next */ []);
	accessibleLabel = computed(() => {
		if (this.decorative()) return null;
		const label = this.label()?.trim();
		if (!label) throw new Error("Informative atr-icon requires a label.");
		return label;
	}, ...ngDevMode ? [{ debugName: "accessibleLabel" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeIcon,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeIcon,
		isStandalone: true,
		selector: "atr-icon",
		inputs: {
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			decorative: {
				classPropertyName: "decorative",
				publicName: "decorative",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			engine: {
				classPropertyName: "engine",
				publicName: "engine",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: {
				"attr.data-name": "name()",
				"attr.data-size": "size()",
				"attr.data-engine": "resolvedEngine()",
				"attr.aria-hidden": "decorative() ? \"true\" : null",
				"attr.role": "decorative() ? null : \"img\"",
				"attr.aria-label": "accessibleLabel()",
				"class.atr-icon--rtl": "definition()?.mirrorInRtl",
				"class.atr-icon--tui": "resolvedEngine() === \"tui\"",
				"style.--atr-icon-custom-size": "pixelSize()"
			},
			classAttribute: "atr-icon"
		},
		ngImport: i0,
		template: "@if (resolvedEngine() === \"tui\") {\n  <!--\n    Paint Lucide assets with a plain CSS mask. Taiga <tui-icon> masks fail to\n    show stroke SVGs reliably under Chromium when served as static files; the\n    same URLs paint correctly with mask + background:currentColor.\n  -->\n  <span\n    class=\"atr-icon__tui-glyph\"\n    [style.--atr-tui-mask]=\"tuiMaskUrl()\"\n    aria-hidden=\"true\"\n  ></span>\n} @else if (definition(); as icon) {\n  <svg\n    [attr.viewBox]=\"icon.viewBox || '0 0 24 24'\"\n    fill=\"none\"\n    stroke=\"currentColor\"\n    stroke-width=\"2\"\n    stroke-linecap=\"round\"\n    stroke-linejoin=\"round\"\n    aria-hidden=\"true\"\n    focusable=\"false\"\n  >\n    @for (path of icon.paths; track $index) {\n      <path [attr.d]=\"path\" />\n    }\n  </svg>\n}\n",
		styles: [":host{display:inline-flex;flex:none;vertical-align:var(--atr-comp-icon-optical-alignment);color:var(--atr-comp-icon-color, currentColor);inline-size:var(--atr-icon-custom-size, var(--atr-comp-icon-size-medium));block-size:var(--atr-icon-custom-size, var(--atr-comp-icon-size-medium))}:host([data-size=small]){inline-size:var(--atr-comp-icon-size-small);block-size:var(--atr-comp-icon-size-small)}:host([data-size=large]){inline-size:var(--atr-comp-icon-size-large);block-size:var(--atr-comp-icon-size-large)}:host-context([aria-disabled=true]){color:var(--atr-comp-icon-disabled-color, currentColor)}svg,.atr-icon__tui-glyph{inline-size:100%;block-size:100%}.atr-icon__tui-glyph{display:block;flex:none;background:currentColor;-webkit-mask:var(--atr-tui-mask) center/contain no-repeat;mask:var(--atr-tui-mask) center/contain no-repeat}:host(.atr-icon--rtl:dir(rtl)) svg{transform:scaleX(-1)}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeIcon,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-icon",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "atr-icon",
				"[attr.data-name]": "name()",
				"[attr.data-size]": "size()",
				"[attr.data-engine]": "resolvedEngine()",
				"[attr.aria-hidden]": "decorative() ? \"true\" : null",
				"[attr.role]": "decorative() ? null : \"img\"",
				"[attr.aria-label]": "accessibleLabel()",
				"[class.atr-icon--rtl]": "definition()?.mirrorInRtl",
				"[class.atr-icon--tui]": "resolvedEngine() === \"tui\"",
				"[style.--atr-icon-custom-size]": "pixelSize()"
			},
			template: "@if (resolvedEngine() === \"tui\") {\n  <!--\n    Paint Lucide assets with a plain CSS mask. Taiga <tui-icon> masks fail to\n    show stroke SVGs reliably under Chromium when served as static files; the\n    same URLs paint correctly with mask + background:currentColor.\n  -->\n  <span\n    class=\"atr-icon__tui-glyph\"\n    [style.--atr-tui-mask]=\"tuiMaskUrl()\"\n    aria-hidden=\"true\"\n  ></span>\n} @else if (definition(); as icon) {\n  <svg\n    [attr.viewBox]=\"icon.viewBox || '0 0 24 24'\"\n    fill=\"none\"\n    stroke=\"currentColor\"\n    stroke-width=\"2\"\n    stroke-linecap=\"round\"\n    stroke-linejoin=\"round\"\n    aria-hidden=\"true\"\n    focusable=\"false\"\n  >\n    @for (path of icon.paths; track $index) {\n      <path [attr.d]=\"path\" />\n    }\n  </svg>\n}\n",
			styles: [":host{display:inline-flex;flex:none;vertical-align:var(--atr-comp-icon-optical-alignment);color:var(--atr-comp-icon-color, currentColor);inline-size:var(--atr-icon-custom-size, var(--atr-comp-icon-size-medium));block-size:var(--atr-icon-custom-size, var(--atr-comp-icon-size-medium))}:host([data-size=small]){inline-size:var(--atr-comp-icon-size-small);block-size:var(--atr-comp-icon-size-small)}:host([data-size=large]){inline-size:var(--atr-comp-icon-size-large);block-size:var(--atr-comp-icon-size-large)}:host-context([aria-disabled=true]){color:var(--atr-comp-icon-disabled-color, currentColor)}svg,.atr-icon__tui-glyph{inline-size:100%;block-size:100%}.atr-icon__tui-glyph{display:block;flex:none;background:currentColor;-webkit-mask:var(--atr-tui-mask) center/contain no-repeat;mask:var(--atr-tui-mask) center/contain no-repeat}:host(.atr-icon--rtl:dir(rtl)) svg{transform:scaleX(-1)}\n"]
		}]
	}],
	propDecorators: {
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: true
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		decorative: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "decorative",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		engine: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "engine",
				required: false
			}]
		}]
	}
});
var AtralumeIconHarness = class extends ComponentHarness {
	static hostSelector = ".atr-icon";
	async getName() {
		return (await this.host()).getAttribute("data-name");
	}
	async getLabel() {
		return (await this.host()).getAttribute("aria-label");
	}
	async isDecorative() {
		return await (await this.host()).getAttribute("aria-hidden") === "true";
	}
	async getSize() {
		return (await this.host()).getAttribute("data-size");
	}
};
const checkIcon = {
	name: "check",
	paths: ["M5 12l4 4L19 6"],
	category: "status-feedback",
	keywords: [
		"success",
		"done",
		"ok"
	],
	aliases: ["@tui.check"]
};
const closeIcon = {
	name: "close",
	paths: ["M6 6l12 12M6 18L18 6"],
	category: "actions",
	keywords: [
		"dismiss",
		"cancel",
		"x"
	],
	aliases: ["@tui.x"]
};
const arrowRightIcon = {
	name: "arrow-right",
	paths: ["M5 12h14m-6-6 6 6-6 6"],
	mirrorInRtl: true,
	category: "arrows",
	keywords: ["next", "forward"],
	aliases: ["@tui.arrow-right"]
};
const chevronDownIcon = {
	name: "chevron-down",
	paths: ["m6 9 6 6 6-6"],
	category: "arrows",
	keywords: ["expand", "dropdown"],
	aliases: ["@tui.chevron-down"]
};
const infoIcon = {
	name: "info",
	paths: ["M12 11v6m0-10v1M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20"],
	category: "status-feedback",
	keywords: ["information", "help"],
	aliases: ["@tui.info"]
};
const warningIcon = {
	name: "warning",
	paths: ["M12 9v4m0 3v1M12 3 2 21h20L12 3"],
	category: "status-feedback",
	keywords: ["alert", "caution"],
	aliases: ["@tui.triangle-alert"]
};
const userIcon = {
	name: "user",
	paths: ["M20 21v-2a7 7 0 0 0-14 0v2M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8"],
	category: "users",
	keywords: [
		"person",
		"profile",
		"account"
	],
	aliases: ["@tui.user"]
};
const menuIcon = {
	name: "menu",
	paths: ["M4 6h16M4 12h16M4 18h16"],
	category: "navigation",
	keywords: ["hamburger", "navigation"],
	aliases: ["@tui.menu"]
};
const ATRALUME_BUILTIN_ICONS = [
	checkIcon,
	closeIcon,
	arrowRightIcon,
	chevronDownIcon,
	infoIcon,
	warningIcon,
	userIcon,
	menuIcon
];
function provideAtralumeIcons(icons) {
	return [{
		provide: ATR_ICONS,
		useValue: icons
	}, AtralumeIconRegistry];
}
export { ATRALUME_BUILTIN_ICONS, ATR_ICONS, AtralumeIcon, AtralumeIconHarness, AtralumeIconRegistry, arrowRightIcon, checkIcon, chevronDownIcon, closeIcon, infoIcon, menuIcon, provideAtralumeIcons, userIcon, warningIcon };

//# sourceMappingURL=osmanjimenez-atralume-icon.mjs.map