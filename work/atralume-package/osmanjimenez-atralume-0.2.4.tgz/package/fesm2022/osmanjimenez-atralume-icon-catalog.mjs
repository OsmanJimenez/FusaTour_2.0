const ATRALUME_ICON_CATALOG_VERSION = "0.2.4";
const ATRALUME_ICON_CATEGORIES = [
	"accessibility",
	"actions",
	"arrows",
	"calendar-time",
	"commerce",
	"communication",
	"custom",
	"development",
	"devices",
	"editing",
	"files",
	"finance",
	"layout",
	"maps-location",
	"media",
	"navigation",
	"notifications",
	"security",
	"social",
	"status-feedback",
	"users"
];
const ATRALUME_ICON_CATALOG = [
	{
		"name": "check",
		"tuiName": "@tui.check",
		"category": "status-feedback",
		"keywords": [
			"success",
			"done",
			"ok"
		],
		"aliases": ["@tui.check"],
		"filled": false,
		"source": "atralume",
		"mirrorInRtl": false
	},
	{
		"name": "close",
		"tuiName": "@tui.close",
		"category": "actions",
		"keywords": [
			"dismiss",
			"cancel",
			"x"
		],
		"aliases": ["@tui.x"],
		"filled": false,
		"source": "atralume",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-right",
		"tuiName": "@tui.arrow-right",
		"category": "arrows",
		"keywords": ["next", "forward"],
		"aliases": ["@tui.arrow-right"],
		"filled": false,
		"source": "atralume",
		"mirrorInRtl": true
	},
	{
		"name": "chevron-down",
		"tuiName": "@tui.chevron-down",
		"category": "arrows",
		"keywords": ["expand", "dropdown"],
		"aliases": ["@tui.chevron-down"],
		"filled": false,
		"source": "atralume",
		"mirrorInRtl": false
	},
	{
		"name": "info",
		"tuiName": "@tui.info",
		"category": "status-feedback",
		"keywords": ["information", "help"],
		"aliases": ["@tui.info"],
		"filled": false,
		"source": "atralume",
		"mirrorInRtl": false
	},
	{
		"name": "warning",
		"tuiName": "@tui.warning",
		"category": "status-feedback",
		"keywords": ["alert", "caution"],
		"aliases": ["@tui.triangle-alert"],
		"filled": false,
		"source": "atralume",
		"mirrorInRtl": false
	},
	{
		"name": "user",
		"tuiName": "@tui.user",
		"category": "users",
		"keywords": [
			"person",
			"profile",
			"account"
		],
		"aliases": ["@tui.user"],
		"filled": false,
		"source": "atralume",
		"mirrorInRtl": false
	},
	{
		"name": "menu",
		"tuiName": "@tui.menu",
		"category": "navigation",
		"keywords": ["hamburger", "navigation"],
		"aliases": ["@tui.menu"],
		"filled": false,
		"source": "atralume",
		"mirrorInRtl": false
	},
	{
		"name": "a-arrow-down",
		"tuiName": "@tui.a-arrow-down",
		"category": "custom",
		"keywords": [
			"a",
			"arrow",
			"down"
		],
		"aliases": ["@tui.a-arrow-down", "@tui.a-arrow-down-filled"],
		"filled": true,
		"filledName": "a-arrow-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "a-arrow-up",
		"tuiName": "@tui.a-arrow-up",
		"category": "custom",
		"keywords": [
			"a",
			"arrow",
			"up"
		],
		"aliases": ["@tui.a-arrow-up", "@tui.a-arrow-up-filled"],
		"filled": true,
		"filledName": "a-arrow-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "a-large-small",
		"tuiName": "@tui.a-large-small",
		"category": "custom",
		"keywords": [
			"a",
			"large",
			"small"
		],
		"aliases": ["@tui.a-large-small", "@tui.a-large-small-filled"],
		"filled": true,
		"filledName": "a-large-small-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "accessibility",
		"tuiName": "@tui.accessibility",
		"category": "accessibility",
		"keywords": ["accessibility"],
		"aliases": ["@tui.accessibility", "@tui.accessibility-filled"],
		"filled": true,
		"filledName": "accessibility-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "activity",
		"tuiName": "@tui.activity",
		"category": "custom",
		"keywords": ["activity"],
		"aliases": ["@tui.activity", "@tui.activity-filled"],
		"filled": true,
		"filledName": "activity-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "activity-square",
		"tuiName": "@tui.activity-square",
		"category": "custom",
		"keywords": ["activity", "square"],
		"aliases": ["@tui.activity-square", "@tui.activity-square-filled"],
		"filled": true,
		"filledName": "activity-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ad",
		"tuiName": "@tui.ad",
		"category": "custom",
		"keywords": ["ad"],
		"aliases": ["@tui.ad", "@tui.ad-filled"],
		"filled": true,
		"filledName": "ad-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "air-vent",
		"tuiName": "@tui.air-vent",
		"category": "custom",
		"keywords": ["air", "vent"],
		"aliases": ["@tui.air-vent", "@tui.air-vent-filled"],
		"filled": true,
		"filledName": "air-vent-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "airplay",
		"tuiName": "@tui.airplay",
		"category": "custom",
		"keywords": ["airplay"],
		"aliases": ["@tui.airplay", "@tui.airplay-filled"],
		"filled": true,
		"filledName": "airplay-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "alarm-check",
		"tuiName": "@tui.alarm-check",
		"category": "calendar-time",
		"keywords": ["alarm", "check"],
		"aliases": ["@tui.alarm-check", "@tui.alarm-check-filled"],
		"filled": true,
		"filledName": "alarm-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "alarm-clock",
		"tuiName": "@tui.alarm-clock",
		"category": "calendar-time",
		"keywords": ["alarm", "clock"],
		"aliases": ["@tui.alarm-clock", "@tui.alarm-clock-filled"],
		"filled": true,
		"filledName": "alarm-clock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "alarm-clock-check",
		"tuiName": "@tui.alarm-clock-check",
		"category": "calendar-time",
		"keywords": [
			"alarm",
			"clock",
			"check"
		],
		"aliases": ["@tui.alarm-clock-check", "@tui.alarm-clock-check-filled"],
		"filled": true,
		"filledName": "alarm-clock-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "alarm-clock-minus",
		"tuiName": "@tui.alarm-clock-minus",
		"category": "calendar-time",
		"keywords": [
			"alarm",
			"clock",
			"minus"
		],
		"aliases": ["@tui.alarm-clock-minus", "@tui.alarm-clock-minus-filled"],
		"filled": true,
		"filledName": "alarm-clock-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "alarm-clock-off",
		"tuiName": "@tui.alarm-clock-off",
		"category": "calendar-time",
		"keywords": [
			"alarm",
			"clock",
			"off"
		],
		"aliases": ["@tui.alarm-clock-off", "@tui.alarm-clock-off-filled"],
		"filled": true,
		"filledName": "alarm-clock-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "alarm-clock-plus",
		"tuiName": "@tui.alarm-clock-plus",
		"category": "calendar-time",
		"keywords": [
			"alarm",
			"clock",
			"plus"
		],
		"aliases": ["@tui.alarm-clock-plus", "@tui.alarm-clock-plus-filled"],
		"filled": true,
		"filledName": "alarm-clock-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "alarm-minus",
		"tuiName": "@tui.alarm-minus",
		"category": "calendar-time",
		"keywords": ["alarm", "minus"],
		"aliases": ["@tui.alarm-minus", "@tui.alarm-minus-filled"],
		"filled": true,
		"filledName": "alarm-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "alarm-plus",
		"tuiName": "@tui.alarm-plus",
		"category": "calendar-time",
		"keywords": ["alarm", "plus"],
		"aliases": ["@tui.alarm-plus", "@tui.alarm-plus-filled"],
		"filled": true,
		"filledName": "alarm-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "alarm-smoke",
		"tuiName": "@tui.alarm-smoke",
		"category": "calendar-time",
		"keywords": ["alarm", "smoke"],
		"aliases": ["@tui.alarm-smoke", "@tui.alarm-smoke-filled"],
		"filled": true,
		"filledName": "alarm-smoke-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "album",
		"tuiName": "@tui.album",
		"category": "custom",
		"keywords": ["album"],
		"aliases": ["@tui.album", "@tui.album-filled"],
		"filled": true,
		"filledName": "album-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "alert-circle",
		"tuiName": "@tui.alert-circle",
		"category": "status-feedback",
		"keywords": ["alert", "circle"],
		"aliases": ["@tui.alert-circle", "@tui.alert-circle-filled"],
		"filled": true,
		"filledName": "alert-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "alert-octagon",
		"tuiName": "@tui.alert-octagon",
		"category": "status-feedback",
		"keywords": ["alert", "octagon"],
		"aliases": ["@tui.alert-octagon", "@tui.alert-octagon-filled"],
		"filled": true,
		"filledName": "alert-octagon-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "alert-triangle",
		"tuiName": "@tui.alert-triangle",
		"category": "status-feedback",
		"keywords": ["alert", "triangle"],
		"aliases": ["@tui.alert-triangle", "@tui.alert-triangle-filled"],
		"filled": true,
		"filledName": "alert-triangle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ali-pay",
		"tuiName": "@tui.ali-pay",
		"category": "custom",
		"keywords": ["ali", "pay"],
		"aliases": ["@tui.ali-pay"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-center",
		"tuiName": "@tui.align-center",
		"category": "navigation",
		"keywords": ["align", "center"],
		"aliases": ["@tui.align-center", "@tui.align-center-filled"],
		"filled": true,
		"filledName": "align-center-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-center-horizontal",
		"tuiName": "@tui.align-center-horizontal",
		"category": "navigation",
		"keywords": [
			"align",
			"center",
			"horizontal"
		],
		"aliases": ["@tui.align-center-horizontal", "@tui.align-center-horizontal-filled"],
		"filled": true,
		"filledName": "align-center-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-center-vertical",
		"tuiName": "@tui.align-center-vertical",
		"category": "navigation",
		"keywords": [
			"align",
			"center",
			"vertical"
		],
		"aliases": ["@tui.align-center-vertical", "@tui.align-center-vertical-filled"],
		"filled": true,
		"filledName": "align-center-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-end-horizontal",
		"tuiName": "@tui.align-end-horizontal",
		"category": "navigation",
		"keywords": [
			"align",
			"end",
			"horizontal"
		],
		"aliases": ["@tui.align-end-horizontal", "@tui.align-end-horizontal-filled"],
		"filled": true,
		"filledName": "align-end-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-end-vertical",
		"tuiName": "@tui.align-end-vertical",
		"category": "navigation",
		"keywords": [
			"align",
			"end",
			"vertical"
		],
		"aliases": ["@tui.align-end-vertical", "@tui.align-end-vertical-filled"],
		"filled": true,
		"filledName": "align-end-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-horizontal-distribute-center",
		"tuiName": "@tui.align-horizontal-distribute-center",
		"category": "navigation",
		"keywords": [
			"align",
			"horizontal",
			"distribute",
			"center"
		],
		"aliases": ["@tui.align-horizontal-distribute-center", "@tui.align-horizontal-distribute-center-filled"],
		"filled": true,
		"filledName": "align-horizontal-distribute-center-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-horizontal-distribute-end",
		"tuiName": "@tui.align-horizontal-distribute-end",
		"category": "navigation",
		"keywords": [
			"align",
			"horizontal",
			"distribute",
			"end"
		],
		"aliases": ["@tui.align-horizontal-distribute-end", "@tui.align-horizontal-distribute-end-filled"],
		"filled": true,
		"filledName": "align-horizontal-distribute-end-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-horizontal-distribute-start",
		"tuiName": "@tui.align-horizontal-distribute-start",
		"category": "navigation",
		"keywords": [
			"align",
			"horizontal",
			"distribute",
			"start"
		],
		"aliases": ["@tui.align-horizontal-distribute-start", "@tui.align-horizontal-distribute-start-filled"],
		"filled": true,
		"filledName": "align-horizontal-distribute-start-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-horizontal-justify-center",
		"tuiName": "@tui.align-horizontal-justify-center",
		"category": "navigation",
		"keywords": [
			"align",
			"horizontal",
			"justify",
			"center"
		],
		"aliases": ["@tui.align-horizontal-justify-center", "@tui.align-horizontal-justify-center-filled"],
		"filled": true,
		"filledName": "align-horizontal-justify-center-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-horizontal-justify-end",
		"tuiName": "@tui.align-horizontal-justify-end",
		"category": "navigation",
		"keywords": [
			"align",
			"horizontal",
			"justify",
			"end"
		],
		"aliases": ["@tui.align-horizontal-justify-end", "@tui.align-horizontal-justify-end-filled"],
		"filled": true,
		"filledName": "align-horizontal-justify-end-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-horizontal-justify-start",
		"tuiName": "@tui.align-horizontal-justify-start",
		"category": "navigation",
		"keywords": [
			"align",
			"horizontal",
			"justify",
			"start"
		],
		"aliases": ["@tui.align-horizontal-justify-start", "@tui.align-horizontal-justify-start-filled"],
		"filled": true,
		"filledName": "align-horizontal-justify-start-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-horizontal-space-around",
		"tuiName": "@tui.align-horizontal-space-around",
		"category": "navigation",
		"keywords": [
			"align",
			"horizontal",
			"space",
			"around"
		],
		"aliases": ["@tui.align-horizontal-space-around", "@tui.align-horizontal-space-around-filled"],
		"filled": true,
		"filledName": "align-horizontal-space-around-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-horizontal-space-between",
		"tuiName": "@tui.align-horizontal-space-between",
		"category": "navigation",
		"keywords": [
			"align",
			"horizontal",
			"space",
			"between"
		],
		"aliases": ["@tui.align-horizontal-space-between", "@tui.align-horizontal-space-between-filled"],
		"filled": true,
		"filledName": "align-horizontal-space-between-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-justify",
		"tuiName": "@tui.align-justify",
		"category": "navigation",
		"keywords": ["align", "justify"],
		"aliases": ["@tui.align-justify", "@tui.align-justify-filled"],
		"filled": true,
		"filledName": "align-justify-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-left",
		"tuiName": "@tui.align-left",
		"category": "navigation",
		"keywords": ["align", "left"],
		"aliases": ["@tui.align-left", "@tui.align-left-filled"],
		"filled": true,
		"filledName": "align-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-right",
		"tuiName": "@tui.align-right",
		"category": "navigation",
		"keywords": ["align", "right"],
		"aliases": ["@tui.align-right", "@tui.align-right-filled"],
		"filled": true,
		"filledName": "align-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-start-horizontal",
		"tuiName": "@tui.align-start-horizontal",
		"category": "navigation",
		"keywords": [
			"align",
			"start",
			"horizontal"
		],
		"aliases": ["@tui.align-start-horizontal", "@tui.align-start-horizontal-filled"],
		"filled": true,
		"filledName": "align-start-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-start-vertical",
		"tuiName": "@tui.align-start-vertical",
		"category": "navigation",
		"keywords": [
			"align",
			"start",
			"vertical"
		],
		"aliases": ["@tui.align-start-vertical", "@tui.align-start-vertical-filled"],
		"filled": true,
		"filledName": "align-start-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-vertical-distribute-center",
		"tuiName": "@tui.align-vertical-distribute-center",
		"category": "navigation",
		"keywords": [
			"align",
			"vertical",
			"distribute",
			"center"
		],
		"aliases": ["@tui.align-vertical-distribute-center", "@tui.align-vertical-distribute-center-filled"],
		"filled": true,
		"filledName": "align-vertical-distribute-center-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-vertical-distribute-end",
		"tuiName": "@tui.align-vertical-distribute-end",
		"category": "navigation",
		"keywords": [
			"align",
			"vertical",
			"distribute",
			"end"
		],
		"aliases": ["@tui.align-vertical-distribute-end", "@tui.align-vertical-distribute-end-filled"],
		"filled": true,
		"filledName": "align-vertical-distribute-end-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-vertical-distribute-start",
		"tuiName": "@tui.align-vertical-distribute-start",
		"category": "navigation",
		"keywords": [
			"align",
			"vertical",
			"distribute",
			"start"
		],
		"aliases": ["@tui.align-vertical-distribute-start", "@tui.align-vertical-distribute-start-filled"],
		"filled": true,
		"filledName": "align-vertical-distribute-start-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-vertical-justify-center",
		"tuiName": "@tui.align-vertical-justify-center",
		"category": "navigation",
		"keywords": [
			"align",
			"vertical",
			"justify",
			"center"
		],
		"aliases": ["@tui.align-vertical-justify-center", "@tui.align-vertical-justify-center-filled"],
		"filled": true,
		"filledName": "align-vertical-justify-center-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-vertical-justify-end",
		"tuiName": "@tui.align-vertical-justify-end",
		"category": "navigation",
		"keywords": [
			"align",
			"vertical",
			"justify",
			"end"
		],
		"aliases": ["@tui.align-vertical-justify-end", "@tui.align-vertical-justify-end-filled"],
		"filled": true,
		"filledName": "align-vertical-justify-end-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-vertical-justify-start",
		"tuiName": "@tui.align-vertical-justify-start",
		"category": "navigation",
		"keywords": [
			"align",
			"vertical",
			"justify",
			"start"
		],
		"aliases": ["@tui.align-vertical-justify-start", "@tui.align-vertical-justify-start-filled"],
		"filled": true,
		"filledName": "align-vertical-justify-start-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-vertical-space-around",
		"tuiName": "@tui.align-vertical-space-around",
		"category": "navigation",
		"keywords": [
			"align",
			"vertical",
			"space",
			"around"
		],
		"aliases": ["@tui.align-vertical-space-around", "@tui.align-vertical-space-around-filled"],
		"filled": true,
		"filledName": "align-vertical-space-around-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "align-vertical-space-between",
		"tuiName": "@tui.align-vertical-space-between",
		"category": "navigation",
		"keywords": [
			"align",
			"vertical",
			"space",
			"between"
		],
		"aliases": ["@tui.align-vertical-space-between", "@tui.align-vertical-space-between-filled"],
		"filled": true,
		"filledName": "align-vertical-space-between-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "amazon-pay",
		"tuiName": "@tui.amazon-pay",
		"category": "custom",
		"keywords": ["amazon", "pay"],
		"aliases": ["@tui.amazon-pay"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ambulance",
		"tuiName": "@tui.ambulance",
		"category": "custom",
		"keywords": ["ambulance"],
		"aliases": ["@tui.ambulance", "@tui.ambulance-filled"],
		"filled": true,
		"filledName": "ambulance-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "amex",
		"tuiName": "@tui.amex",
		"category": "custom",
		"keywords": ["amex"],
		"aliases": ["@tui.amex"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ampersand",
		"tuiName": "@tui.ampersand",
		"category": "custom",
		"keywords": ["ampersand"],
		"aliases": ["@tui.ampersand", "@tui.ampersand-filled"],
		"filled": true,
		"filledName": "ampersand-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ampersands",
		"tuiName": "@tui.ampersands",
		"category": "custom",
		"keywords": ["ampersands"],
		"aliases": ["@tui.ampersands", "@tui.ampersands-filled"],
		"filled": true,
		"filledName": "ampersands-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "amphora",
		"tuiName": "@tui.amphora",
		"category": "custom",
		"keywords": ["amphora"],
		"aliases": ["@tui.amphora", "@tui.amphora-filled"],
		"filled": true,
		"filledName": "amphora-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "anchor",
		"tuiName": "@tui.anchor",
		"category": "maps-location",
		"keywords": ["anchor"],
		"aliases": ["@tui.anchor", "@tui.anchor-filled"],
		"filled": true,
		"filledName": "anchor-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "android-pay",
		"tuiName": "@tui.android-pay",
		"category": "custom",
		"keywords": ["android", "pay"],
		"aliases": ["@tui.android-pay"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "angle",
		"tuiName": "@tui.angle",
		"category": "custom",
		"keywords": ["angle"],
		"aliases": ["@tui.angle", "@tui.angle-filled"],
		"filled": true,
		"filledName": "angle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "angry",
		"tuiName": "@tui.angry",
		"category": "custom",
		"keywords": ["angry"],
		"aliases": ["@tui.angry", "@tui.angry-filled"],
		"filled": true,
		"filledName": "angry-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "annoyed",
		"tuiName": "@tui.annoyed",
		"category": "custom",
		"keywords": ["annoyed"],
		"aliases": ["@tui.annoyed", "@tui.annoyed-filled"],
		"filled": true,
		"filledName": "annoyed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "antenna",
		"tuiName": "@tui.antenna",
		"category": "social",
		"keywords": ["antenna"],
		"aliases": ["@tui.antenna", "@tui.antenna-filled"],
		"filled": true,
		"filledName": "antenna-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "anvil",
		"tuiName": "@tui.anvil",
		"category": "custom",
		"keywords": ["anvil"],
		"aliases": ["@tui.anvil", "@tui.anvil-filled"],
		"filled": true,
		"filledName": "anvil-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "aperture",
		"tuiName": "@tui.aperture",
		"category": "media",
		"keywords": ["aperture"],
		"aliases": ["@tui.aperture", "@tui.aperture-filled"],
		"filled": true,
		"filledName": "aperture-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "app-window",
		"tuiName": "@tui.app-window",
		"category": "navigation",
		"keywords": ["app", "window"],
		"aliases": ["@tui.app-window", "@tui.app-window-filled"],
		"filled": true,
		"filledName": "app-window-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "app-window-mac",
		"tuiName": "@tui.app-window-mac",
		"category": "navigation",
		"keywords": [
			"app",
			"window",
			"mac"
		],
		"aliases": ["@tui.app-window-mac", "@tui.app-window-mac-filled"],
		"filled": true,
		"filledName": "app-window-mac-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "apple",
		"tuiName": "@tui.apple",
		"category": "custom",
		"keywords": ["apple"],
		"aliases": ["@tui.apple", "@tui.apple-filled"],
		"filled": true,
		"filledName": "apple-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "apple-pay",
		"tuiName": "@tui.apple-pay",
		"category": "custom",
		"keywords": ["apple", "pay"],
		"aliases": ["@tui.apple-pay"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "archive",
		"tuiName": "@tui.archive",
		"category": "files",
		"keywords": ["archive"],
		"aliases": ["@tui.archive", "@tui.archive-filled"],
		"filled": true,
		"filledName": "archive-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "archive-restore",
		"tuiName": "@tui.archive-restore",
		"category": "files",
		"keywords": ["archive", "restore"],
		"aliases": ["@tui.archive-restore", "@tui.archive-restore-filled"],
		"filled": true,
		"filledName": "archive-restore-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "archive-x",
		"tuiName": "@tui.archive-x",
		"category": "files",
		"keywords": ["archive", "x"],
		"aliases": ["@tui.archive-x", "@tui.archive-x-filled"],
		"filled": true,
		"filledName": "archive-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "area-chart",
		"tuiName": "@tui.area-chart",
		"category": "custom",
		"keywords": ["area", "chart"],
		"aliases": ["@tui.area-chart", "@tui.area-chart-filled"],
		"filled": true,
		"filledName": "area-chart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "armchair",
		"tuiName": "@tui.armchair",
		"category": "custom",
		"keywords": ["armchair"],
		"aliases": ["@tui.armchair", "@tui.armchair-filled"],
		"filled": true,
		"filledName": "armchair-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "armenian-dram",
		"tuiName": "@tui.armenian-dram",
		"category": "custom",
		"keywords": ["armenian", "dram"],
		"aliases": ["@tui.armenian-dram", "@tui.armenian-dram-filled"],
		"filled": true,
		"filledName": "armenian-dram-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-big-down",
		"tuiName": "@tui.arrow-big-down",
		"category": "arrows",
		"keywords": [
			"arrow",
			"big",
			"down"
		],
		"aliases": ["@tui.arrow-big-down", "@tui.arrow-big-down-filled"],
		"filled": true,
		"filledName": "arrow-big-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-big-down-dash",
		"tuiName": "@tui.arrow-big-down-dash",
		"category": "arrows",
		"keywords": [
			"arrow",
			"big",
			"down",
			"dash"
		],
		"aliases": ["@tui.arrow-big-down-dash", "@tui.arrow-big-down-dash-filled"],
		"filled": true,
		"filledName": "arrow-big-down-dash-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-big-left",
		"tuiName": "@tui.arrow-big-left",
		"category": "arrows",
		"keywords": [
			"arrow",
			"big",
			"left"
		],
		"aliases": ["@tui.arrow-big-left", "@tui.arrow-big-left-filled"],
		"filled": true,
		"filledName": "arrow-big-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-big-left-dash",
		"tuiName": "@tui.arrow-big-left-dash",
		"category": "arrows",
		"keywords": [
			"arrow",
			"big",
			"left",
			"dash"
		],
		"aliases": ["@tui.arrow-big-left-dash", "@tui.arrow-big-left-dash-filled"],
		"filled": true,
		"filledName": "arrow-big-left-dash-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-big-right",
		"tuiName": "@tui.arrow-big-right",
		"category": "arrows",
		"keywords": [
			"arrow",
			"big",
			"right"
		],
		"aliases": ["@tui.arrow-big-right", "@tui.arrow-big-right-filled"],
		"filled": true,
		"filledName": "arrow-big-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-big-right-dash",
		"tuiName": "@tui.arrow-big-right-dash",
		"category": "arrows",
		"keywords": [
			"arrow",
			"big",
			"right",
			"dash"
		],
		"aliases": ["@tui.arrow-big-right-dash", "@tui.arrow-big-right-dash-filled"],
		"filled": true,
		"filledName": "arrow-big-right-dash-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-big-up",
		"tuiName": "@tui.arrow-big-up",
		"category": "arrows",
		"keywords": [
			"arrow",
			"big",
			"up"
		],
		"aliases": ["@tui.arrow-big-up", "@tui.arrow-big-up-filled"],
		"filled": true,
		"filledName": "arrow-big-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-big-up-dash",
		"tuiName": "@tui.arrow-big-up-dash",
		"category": "arrows",
		"keywords": [
			"arrow",
			"big",
			"up",
			"dash"
		],
		"aliases": ["@tui.arrow-big-up-dash", "@tui.arrow-big-up-dash-filled"],
		"filled": true,
		"filledName": "arrow-big-up-dash-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down",
		"tuiName": "@tui.arrow-down",
		"category": "arrows",
		"keywords": ["arrow", "down"],
		"aliases": ["@tui.arrow-down", "@tui.arrow-down-filled"],
		"filled": true,
		"filledName": "arrow-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-0-1",
		"tuiName": "@tui.arrow-down-0-1",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"0",
			"1"
		],
		"aliases": ["@tui.arrow-down-0-1", "@tui.arrow-down-0-1-filled"],
		"filled": true,
		"filledName": "arrow-down-0-1-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-01",
		"tuiName": "@tui.arrow-down-01",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"01"
		],
		"aliases": ["@tui.arrow-down-01", "@tui.arrow-down-01-filled"],
		"filled": true,
		"filledName": "arrow-down-01-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-1-0",
		"tuiName": "@tui.arrow-down-1-0",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"1",
			"0"
		],
		"aliases": ["@tui.arrow-down-1-0", "@tui.arrow-down-1-0-filled"],
		"filled": true,
		"filledName": "arrow-down-1-0-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-10",
		"tuiName": "@tui.arrow-down-10",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"10"
		],
		"aliases": ["@tui.arrow-down-10", "@tui.arrow-down-10-filled"],
		"filled": true,
		"filledName": "arrow-down-10-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-a-z",
		"tuiName": "@tui.arrow-down-a-z",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"a",
			"z"
		],
		"aliases": ["@tui.arrow-down-a-z", "@tui.arrow-down-a-z-filled"],
		"filled": true,
		"filledName": "arrow-down-a-z-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-az",
		"tuiName": "@tui.arrow-down-az",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"az"
		],
		"aliases": ["@tui.arrow-down-az", "@tui.arrow-down-az-filled"],
		"filled": true,
		"filledName": "arrow-down-az-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-circle",
		"tuiName": "@tui.arrow-down-circle",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"circle"
		],
		"aliases": ["@tui.arrow-down-circle", "@tui.arrow-down-circle-filled"],
		"filled": true,
		"filledName": "arrow-down-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-from-line",
		"tuiName": "@tui.arrow-down-from-line",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"from",
			"line"
		],
		"aliases": ["@tui.arrow-down-from-line", "@tui.arrow-down-from-line-filled"],
		"filled": true,
		"filledName": "arrow-down-from-line-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-left",
		"tuiName": "@tui.arrow-down-left",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"left"
		],
		"aliases": ["@tui.arrow-down-left", "@tui.arrow-down-left-filled"],
		"filled": true,
		"filledName": "arrow-down-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-left-from-circle",
		"tuiName": "@tui.arrow-down-left-from-circle",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"left",
			"from",
			"circle"
		],
		"aliases": ["@tui.arrow-down-left-from-circle", "@tui.arrow-down-left-from-circle-filled"],
		"filled": true,
		"filledName": "arrow-down-left-from-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-left-from-square",
		"tuiName": "@tui.arrow-down-left-from-square",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"left",
			"from",
			"square"
		],
		"aliases": ["@tui.arrow-down-left-from-square", "@tui.arrow-down-left-from-square-filled"],
		"filled": true,
		"filledName": "arrow-down-left-from-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-left-square",
		"tuiName": "@tui.arrow-down-left-square",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"left",
			"square"
		],
		"aliases": ["@tui.arrow-down-left-square", "@tui.arrow-down-left-square-filled"],
		"filled": true,
		"filledName": "arrow-down-left-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-narrow-wide",
		"tuiName": "@tui.arrow-down-narrow-wide",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"narrow",
			"wide"
		],
		"aliases": ["@tui.arrow-down-narrow-wide", "@tui.arrow-down-narrow-wide-filled"],
		"filled": true,
		"filledName": "arrow-down-narrow-wide-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-right",
		"tuiName": "@tui.arrow-down-right",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"right"
		],
		"aliases": ["@tui.arrow-down-right", "@tui.arrow-down-right-filled"],
		"filled": true,
		"filledName": "arrow-down-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-right-from-circle",
		"tuiName": "@tui.arrow-down-right-from-circle",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"right",
			"from",
			"circle"
		],
		"aliases": ["@tui.arrow-down-right-from-circle", "@tui.arrow-down-right-from-circle-filled"],
		"filled": true,
		"filledName": "arrow-down-right-from-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-right-from-square",
		"tuiName": "@tui.arrow-down-right-from-square",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"right",
			"from",
			"square"
		],
		"aliases": ["@tui.arrow-down-right-from-square", "@tui.arrow-down-right-from-square-filled"],
		"filled": true,
		"filledName": "arrow-down-right-from-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-right-square",
		"tuiName": "@tui.arrow-down-right-square",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"right",
			"square"
		],
		"aliases": ["@tui.arrow-down-right-square", "@tui.arrow-down-right-square-filled"],
		"filled": true,
		"filledName": "arrow-down-right-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-square",
		"tuiName": "@tui.arrow-down-square",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"square"
		],
		"aliases": ["@tui.arrow-down-square", "@tui.arrow-down-square-filled"],
		"filled": true,
		"filledName": "arrow-down-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-to-dot",
		"tuiName": "@tui.arrow-down-to-dot",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"to",
			"dot"
		],
		"aliases": ["@tui.arrow-down-to-dot", "@tui.arrow-down-to-dot-filled"],
		"filled": true,
		"filledName": "arrow-down-to-dot-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-to-line",
		"tuiName": "@tui.arrow-down-to-line",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"to",
			"line"
		],
		"aliases": ["@tui.arrow-down-to-line", "@tui.arrow-down-to-line-filled"],
		"filled": true,
		"filledName": "arrow-down-to-line-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-up",
		"tuiName": "@tui.arrow-down-up",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"up"
		],
		"aliases": ["@tui.arrow-down-up", "@tui.arrow-down-up-filled"],
		"filled": true,
		"filledName": "arrow-down-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-wide-narrow",
		"tuiName": "@tui.arrow-down-wide-narrow",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"wide",
			"narrow"
		],
		"aliases": ["@tui.arrow-down-wide-narrow", "@tui.arrow-down-wide-narrow-filled"],
		"filled": true,
		"filledName": "arrow-down-wide-narrow-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-z-a",
		"tuiName": "@tui.arrow-down-z-a",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"z",
			"a"
		],
		"aliases": ["@tui.arrow-down-z-a", "@tui.arrow-down-z-a-filled"],
		"filled": true,
		"filledName": "arrow-down-z-a-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-down-za",
		"tuiName": "@tui.arrow-down-za",
		"category": "arrows",
		"keywords": [
			"arrow",
			"down",
			"za"
		],
		"aliases": ["@tui.arrow-down-za", "@tui.arrow-down-za-filled"],
		"filled": true,
		"filledName": "arrow-down-za-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-left",
		"tuiName": "@tui.arrow-left",
		"category": "arrows",
		"keywords": ["arrow", "left"],
		"aliases": ["@tui.arrow-left", "@tui.arrow-left-filled"],
		"filled": true,
		"filledName": "arrow-left-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "arrow-left-circle",
		"tuiName": "@tui.arrow-left-circle",
		"category": "arrows",
		"keywords": [
			"arrow",
			"left",
			"circle"
		],
		"aliases": ["@tui.arrow-left-circle", "@tui.arrow-left-circle-filled"],
		"filled": true,
		"filledName": "arrow-left-circle-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "arrow-left-from-line",
		"tuiName": "@tui.arrow-left-from-line",
		"category": "arrows",
		"keywords": [
			"arrow",
			"left",
			"from",
			"line"
		],
		"aliases": ["@tui.arrow-left-from-line", "@tui.arrow-left-from-line-filled"],
		"filled": true,
		"filledName": "arrow-left-from-line-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "arrow-left-right",
		"tuiName": "@tui.arrow-left-right",
		"category": "arrows",
		"keywords": [
			"arrow",
			"left",
			"right"
		],
		"aliases": ["@tui.arrow-left-right", "@tui.arrow-left-right-filled"],
		"filled": true,
		"filledName": "arrow-left-right-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "arrow-left-square",
		"tuiName": "@tui.arrow-left-square",
		"category": "arrows",
		"keywords": [
			"arrow",
			"left",
			"square"
		],
		"aliases": ["@tui.arrow-left-square", "@tui.arrow-left-square-filled"],
		"filled": true,
		"filledName": "arrow-left-square-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "arrow-left-to-line",
		"tuiName": "@tui.arrow-left-to-line",
		"category": "arrows",
		"keywords": [
			"arrow",
			"left",
			"to",
			"line"
		],
		"aliases": ["@tui.arrow-left-to-line", "@tui.arrow-left-to-line-filled"],
		"filled": true,
		"filledName": "arrow-left-to-line-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "arrow-right",
		"tuiName": "@tui.arrow-right",
		"category": "arrows",
		"keywords": ["arrow", "right"],
		"aliases": ["@tui.arrow-right", "@tui.arrow-right-filled"],
		"filled": true,
		"filledName": "arrow-right-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "arrow-right-circle",
		"tuiName": "@tui.arrow-right-circle",
		"category": "arrows",
		"keywords": [
			"arrow",
			"right",
			"circle"
		],
		"aliases": ["@tui.arrow-right-circle", "@tui.arrow-right-circle-filled"],
		"filled": true,
		"filledName": "arrow-right-circle-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "arrow-right-from-line",
		"tuiName": "@tui.arrow-right-from-line",
		"category": "arrows",
		"keywords": [
			"arrow",
			"right",
			"from",
			"line"
		],
		"aliases": ["@tui.arrow-right-from-line", "@tui.arrow-right-from-line-filled"],
		"filled": true,
		"filledName": "arrow-right-from-line-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "arrow-right-left",
		"tuiName": "@tui.arrow-right-left",
		"category": "arrows",
		"keywords": [
			"arrow",
			"right",
			"left"
		],
		"aliases": ["@tui.arrow-right-left", "@tui.arrow-right-left-filled"],
		"filled": true,
		"filledName": "arrow-right-left-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "arrow-right-square",
		"tuiName": "@tui.arrow-right-square",
		"category": "arrows",
		"keywords": [
			"arrow",
			"right",
			"square"
		],
		"aliases": ["@tui.arrow-right-square", "@tui.arrow-right-square-filled"],
		"filled": true,
		"filledName": "arrow-right-square-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "arrow-right-to-line",
		"tuiName": "@tui.arrow-right-to-line",
		"category": "arrows",
		"keywords": [
			"arrow",
			"right",
			"to",
			"line"
		],
		"aliases": ["@tui.arrow-right-to-line", "@tui.arrow-right-to-line-filled"],
		"filled": true,
		"filledName": "arrow-right-to-line-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "arrow-up",
		"tuiName": "@tui.arrow-up",
		"category": "arrows",
		"keywords": ["arrow", "up"],
		"aliases": ["@tui.arrow-up", "@tui.arrow-up-filled"],
		"filled": true,
		"filledName": "arrow-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-0-1",
		"tuiName": "@tui.arrow-up-0-1",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"0",
			"1"
		],
		"aliases": ["@tui.arrow-up-0-1", "@tui.arrow-up-0-1-filled"],
		"filled": true,
		"filledName": "arrow-up-0-1-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-01",
		"tuiName": "@tui.arrow-up-01",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"01"
		],
		"aliases": ["@tui.arrow-up-01", "@tui.arrow-up-01-filled"],
		"filled": true,
		"filledName": "arrow-up-01-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-1-0",
		"tuiName": "@tui.arrow-up-1-0",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"1",
			"0"
		],
		"aliases": ["@tui.arrow-up-1-0", "@tui.arrow-up-1-0-filled"],
		"filled": true,
		"filledName": "arrow-up-1-0-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-10",
		"tuiName": "@tui.arrow-up-10",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"10"
		],
		"aliases": ["@tui.arrow-up-10", "@tui.arrow-up-10-filled"],
		"filled": true,
		"filledName": "arrow-up-10-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-a-z",
		"tuiName": "@tui.arrow-up-a-z",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"a",
			"z"
		],
		"aliases": ["@tui.arrow-up-a-z", "@tui.arrow-up-a-z-filled"],
		"filled": true,
		"filledName": "arrow-up-a-z-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-az",
		"tuiName": "@tui.arrow-up-az",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"az"
		],
		"aliases": ["@tui.arrow-up-az", "@tui.arrow-up-az-filled"],
		"filled": true,
		"filledName": "arrow-up-az-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-circle",
		"tuiName": "@tui.arrow-up-circle",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"circle"
		],
		"aliases": ["@tui.arrow-up-circle", "@tui.arrow-up-circle-filled"],
		"filled": true,
		"filledName": "arrow-up-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-down",
		"tuiName": "@tui.arrow-up-down",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"down"
		],
		"aliases": ["@tui.arrow-up-down", "@tui.arrow-up-down-filled"],
		"filled": true,
		"filledName": "arrow-up-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-from-dot",
		"tuiName": "@tui.arrow-up-from-dot",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"from",
			"dot"
		],
		"aliases": ["@tui.arrow-up-from-dot", "@tui.arrow-up-from-dot-filled"],
		"filled": true,
		"filledName": "arrow-up-from-dot-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-from-line",
		"tuiName": "@tui.arrow-up-from-line",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"from",
			"line"
		],
		"aliases": ["@tui.arrow-up-from-line", "@tui.arrow-up-from-line-filled"],
		"filled": true,
		"filledName": "arrow-up-from-line-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-left",
		"tuiName": "@tui.arrow-up-left",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"left"
		],
		"aliases": ["@tui.arrow-up-left", "@tui.arrow-up-left-filled"],
		"filled": true,
		"filledName": "arrow-up-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-left-from-circle",
		"tuiName": "@tui.arrow-up-left-from-circle",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"left",
			"from",
			"circle"
		],
		"aliases": ["@tui.arrow-up-left-from-circle", "@tui.arrow-up-left-from-circle-filled"],
		"filled": true,
		"filledName": "arrow-up-left-from-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-left-from-square",
		"tuiName": "@tui.arrow-up-left-from-square",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"left",
			"from",
			"square"
		],
		"aliases": ["@tui.arrow-up-left-from-square", "@tui.arrow-up-left-from-square-filled"],
		"filled": true,
		"filledName": "arrow-up-left-from-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-left-square",
		"tuiName": "@tui.arrow-up-left-square",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"left",
			"square"
		],
		"aliases": ["@tui.arrow-up-left-square", "@tui.arrow-up-left-square-filled"],
		"filled": true,
		"filledName": "arrow-up-left-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-narrow-wide",
		"tuiName": "@tui.arrow-up-narrow-wide",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"narrow",
			"wide"
		],
		"aliases": ["@tui.arrow-up-narrow-wide", "@tui.arrow-up-narrow-wide-filled"],
		"filled": true,
		"filledName": "arrow-up-narrow-wide-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-right",
		"tuiName": "@tui.arrow-up-right",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"right"
		],
		"aliases": ["@tui.arrow-up-right", "@tui.arrow-up-right-filled"],
		"filled": true,
		"filledName": "arrow-up-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-right-from-circle",
		"tuiName": "@tui.arrow-up-right-from-circle",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"right",
			"from",
			"circle"
		],
		"aliases": ["@tui.arrow-up-right-from-circle", "@tui.arrow-up-right-from-circle-filled"],
		"filled": true,
		"filledName": "arrow-up-right-from-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-right-from-square",
		"tuiName": "@tui.arrow-up-right-from-square",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"right",
			"from",
			"square"
		],
		"aliases": ["@tui.arrow-up-right-from-square", "@tui.arrow-up-right-from-square-filled"],
		"filled": true,
		"filledName": "arrow-up-right-from-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-right-square",
		"tuiName": "@tui.arrow-up-right-square",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"right",
			"square"
		],
		"aliases": ["@tui.arrow-up-right-square", "@tui.arrow-up-right-square-filled"],
		"filled": true,
		"filledName": "arrow-up-right-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-square",
		"tuiName": "@tui.arrow-up-square",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"square"
		],
		"aliases": ["@tui.arrow-up-square", "@tui.arrow-up-square-filled"],
		"filled": true,
		"filledName": "arrow-up-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-to-line",
		"tuiName": "@tui.arrow-up-to-line",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"to",
			"line"
		],
		"aliases": ["@tui.arrow-up-to-line", "@tui.arrow-up-to-line-filled"],
		"filled": true,
		"filledName": "arrow-up-to-line-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-wide-narrow",
		"tuiName": "@tui.arrow-up-wide-narrow",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"wide",
			"narrow"
		],
		"aliases": ["@tui.arrow-up-wide-narrow", "@tui.arrow-up-wide-narrow-filled"],
		"filled": true,
		"filledName": "arrow-up-wide-narrow-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-z-a",
		"tuiName": "@tui.arrow-up-z-a",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"z",
			"a"
		],
		"aliases": ["@tui.arrow-up-z-a", "@tui.arrow-up-z-a-filled"],
		"filled": true,
		"filledName": "arrow-up-z-a-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrow-up-za",
		"tuiName": "@tui.arrow-up-za",
		"category": "arrows",
		"keywords": [
			"arrow",
			"up",
			"za"
		],
		"aliases": ["@tui.arrow-up-za", "@tui.arrow-up-za-filled"],
		"filled": true,
		"filledName": "arrow-up-za-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "arrows-up-from-line",
		"tuiName": "@tui.arrows-up-from-line",
		"category": "arrows",
		"keywords": [
			"arrows",
			"up",
			"from",
			"line"
		],
		"aliases": ["@tui.arrows-up-from-line", "@tui.arrows-up-from-line-filled"],
		"filled": true,
		"filledName": "arrows-up-from-line-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "asterisk",
		"tuiName": "@tui.asterisk",
		"category": "custom",
		"keywords": ["asterisk"],
		"aliases": ["@tui.asterisk", "@tui.asterisk-filled"],
		"filled": true,
		"filledName": "asterisk-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "asterisk-square",
		"tuiName": "@tui.asterisk-square",
		"category": "custom",
		"keywords": ["asterisk", "square"],
		"aliases": ["@tui.asterisk-square", "@tui.asterisk-square-filled"],
		"filled": true,
		"filledName": "asterisk-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "astroid",
		"tuiName": "@tui.astroid",
		"category": "custom",
		"keywords": ["astroid"],
		"aliases": ["@tui.astroid", "@tui.astroid-filled"],
		"filled": true,
		"filledName": "astroid-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "at-sign",
		"tuiName": "@tui.at-sign",
		"category": "communication",
		"keywords": ["at", "sign"],
		"aliases": ["@tui.at-sign", "@tui.at-sign-filled"],
		"filled": true,
		"filledName": "at-sign-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "atom",
		"tuiName": "@tui.atom",
		"category": "custom",
		"keywords": ["atom"],
		"aliases": ["@tui.atom", "@tui.atom-filled"],
		"filled": true,
		"filledName": "atom-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "audio-lines",
		"tuiName": "@tui.audio-lines",
		"category": "media",
		"keywords": ["audio", "lines"],
		"aliases": ["@tui.audio-lines", "@tui.audio-lines-filled"],
		"filled": true,
		"filledName": "audio-lines-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "audio-lines-off",
		"tuiName": "@tui.audio-lines-off",
		"category": "media",
		"keywords": [
			"audio",
			"lines",
			"off"
		],
		"aliases": ["@tui.audio-lines-off", "@tui.audio-lines-off-filled"],
		"filled": true,
		"filledName": "audio-lines-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "audio-lines-x",
		"tuiName": "@tui.audio-lines-x",
		"category": "media",
		"keywords": [
			"audio",
			"lines",
			"x"
		],
		"aliases": ["@tui.audio-lines-x", "@tui.audio-lines-x-filled"],
		"filled": true,
		"filledName": "audio-lines-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "audio-waveform",
		"tuiName": "@tui.audio-waveform",
		"category": "media",
		"keywords": ["audio", "waveform"],
		"aliases": ["@tui.audio-waveform", "@tui.audio-waveform-filled"],
		"filled": true,
		"filledName": "audio-waveform-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "award",
		"tuiName": "@tui.award",
		"category": "custom",
		"keywords": ["award"],
		"aliases": ["@tui.award", "@tui.award-filled"],
		"filled": true,
		"filledName": "award-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "axe",
		"tuiName": "@tui.axe",
		"category": "custom",
		"keywords": ["axe"],
		"aliases": ["@tui.axe", "@tui.axe-filled"],
		"filled": true,
		"filledName": "axe-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "axis-3-d",
		"tuiName": "@tui.axis-3-d",
		"category": "custom",
		"keywords": [
			"axis",
			"3",
			"d"
		],
		"aliases": ["@tui.axis-3-d", "@tui.axis-3-d-filled"],
		"filled": true,
		"filledName": "axis-3-d-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "axis-3d",
		"tuiName": "@tui.axis-3d",
		"category": "custom",
		"keywords": ["axis", "3d"],
		"aliases": ["@tui.axis-3d", "@tui.axis-3d-filled"],
		"filled": true,
		"filledName": "axis-3d-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "baby",
		"tuiName": "@tui.baby",
		"category": "custom",
		"keywords": ["baby"],
		"aliases": ["@tui.baby", "@tui.baby-filled"],
		"filled": true,
		"filledName": "baby-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "backpack",
		"tuiName": "@tui.backpack",
		"category": "custom",
		"keywords": ["backpack"],
		"aliases": ["@tui.backpack", "@tui.backpack-filled"],
		"filled": true,
		"filledName": "backpack-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "badge",
		"tuiName": "@tui.badge",
		"category": "custom",
		"keywords": ["badge"],
		"aliases": ["@tui.badge", "@tui.badge-filled"],
		"filled": true,
		"filledName": "badge-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "badge-alert",
		"tuiName": "@tui.badge-alert",
		"category": "status-feedback",
		"keywords": ["badge", "alert"],
		"aliases": ["@tui.badge-alert", "@tui.badge-alert-filled"],
		"filled": true,
		"filledName": "badge-alert-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "badge-cent",
		"tuiName": "@tui.badge-cent",
		"category": "custom",
		"keywords": ["badge", "cent"],
		"aliases": ["@tui.badge-cent", "@tui.badge-cent-filled"],
		"filled": true,
		"filledName": "badge-cent-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "badge-check",
		"tuiName": "@tui.badge-check",
		"category": "users",
		"keywords": ["badge", "check"],
		"aliases": ["@tui.badge-check", "@tui.badge-check-filled"],
		"filled": true,
		"filledName": "badge-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "badge-dollar-sign",
		"tuiName": "@tui.badge-dollar-sign",
		"category": "finance",
		"keywords": [
			"badge",
			"dollar",
			"sign"
		],
		"aliases": ["@tui.badge-dollar-sign", "@tui.badge-dollar-sign-filled"],
		"filled": true,
		"filledName": "badge-dollar-sign-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "badge-euro",
		"tuiName": "@tui.badge-euro",
		"category": "custom",
		"keywords": ["badge", "euro"],
		"aliases": ["@tui.badge-euro", "@tui.badge-euro-filled"],
		"filled": true,
		"filledName": "badge-euro-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "badge-help",
		"tuiName": "@tui.badge-help",
		"category": "custom",
		"keywords": ["badge", "help"],
		"aliases": ["@tui.badge-help", "@tui.badge-help-filled"],
		"filled": true,
		"filledName": "badge-help-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "badge-indian-rupee",
		"tuiName": "@tui.badge-indian-rupee",
		"category": "custom",
		"keywords": [
			"badge",
			"indian",
			"rupee"
		],
		"aliases": ["@tui.badge-indian-rupee", "@tui.badge-indian-rupee-filled"],
		"filled": true,
		"filledName": "badge-indian-rupee-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "badge-info",
		"tuiName": "@tui.badge-info",
		"category": "status-feedback",
		"keywords": ["badge", "info"],
		"aliases": ["@tui.badge-info", "@tui.badge-info-filled"],
		"filled": true,
		"filledName": "badge-info-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "badge-japanese-yen",
		"tuiName": "@tui.badge-japanese-yen",
		"category": "custom",
		"keywords": [
			"badge",
			"japanese",
			"yen"
		],
		"aliases": ["@tui.badge-japanese-yen", "@tui.badge-japanese-yen-filled"],
		"filled": true,
		"filledName": "badge-japanese-yen-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "badge-minus",
		"tuiName": "@tui.badge-minus",
		"category": "status-feedback",
		"keywords": ["badge", "minus"],
		"aliases": ["@tui.badge-minus", "@tui.badge-minus-filled"],
		"filled": true,
		"filledName": "badge-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "badge-percent",
		"tuiName": "@tui.badge-percent",
		"category": "custom",
		"keywords": ["badge", "percent"],
		"aliases": ["@tui.badge-percent", "@tui.badge-percent-filled"],
		"filled": true,
		"filledName": "badge-percent-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "badge-plus",
		"tuiName": "@tui.badge-plus",
		"category": "status-feedback",
		"keywords": ["badge", "plus"],
		"aliases": ["@tui.badge-plus", "@tui.badge-plus-filled"],
		"filled": true,
		"filledName": "badge-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "badge-pound-sterling",
		"tuiName": "@tui.badge-pound-sterling",
		"category": "custom",
		"keywords": [
			"badge",
			"pound",
			"sterling"
		],
		"aliases": ["@tui.badge-pound-sterling", "@tui.badge-pound-sterling-filled"],
		"filled": true,
		"filledName": "badge-pound-sterling-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "badge-question-mark",
		"tuiName": "@tui.badge-question-mark",
		"category": "custom",
		"keywords": [
			"badge",
			"question",
			"mark"
		],
		"aliases": ["@tui.badge-question-mark", "@tui.badge-question-mark-filled"],
		"filled": true,
		"filledName": "badge-question-mark-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "badge-russian-ruble",
		"tuiName": "@tui.badge-russian-ruble",
		"category": "custom",
		"keywords": [
			"badge",
			"russian",
			"ruble"
		],
		"aliases": ["@tui.badge-russian-ruble", "@tui.badge-russian-ruble-filled"],
		"filled": true,
		"filledName": "badge-russian-ruble-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "badge-swiss-franc",
		"tuiName": "@tui.badge-swiss-franc",
		"category": "custom",
		"keywords": [
			"badge",
			"swiss",
			"franc"
		],
		"aliases": ["@tui.badge-swiss-franc", "@tui.badge-swiss-franc-filled"],
		"filled": true,
		"filledName": "badge-swiss-franc-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "badge-turkish-lira",
		"tuiName": "@tui.badge-turkish-lira",
		"category": "custom",
		"keywords": [
			"badge",
			"turkish",
			"lira"
		],
		"aliases": ["@tui.badge-turkish-lira", "@tui.badge-turkish-lira-filled"],
		"filled": true,
		"filledName": "badge-turkish-lira-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "badge-x",
		"tuiName": "@tui.badge-x",
		"category": "status-feedback",
		"keywords": ["badge", "x"],
		"aliases": ["@tui.badge-x", "@tui.badge-x-filled"],
		"filled": true,
		"filledName": "badge-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "baggage-claim",
		"tuiName": "@tui.baggage-claim",
		"category": "commerce",
		"keywords": ["baggage", "claim"],
		"aliases": ["@tui.baggage-claim", "@tui.baggage-claim-filled"],
		"filled": true,
		"filledName": "baggage-claim-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "balloon",
		"tuiName": "@tui.balloon",
		"category": "custom",
		"keywords": ["balloon"],
		"aliases": ["@tui.balloon", "@tui.balloon-filled"],
		"filled": true,
		"filledName": "balloon-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ban",
		"tuiName": "@tui.ban",
		"category": "security",
		"keywords": ["ban"],
		"aliases": ["@tui.ban", "@tui.ban-filled"],
		"filled": true,
		"filledName": "ban-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "banana",
		"tuiName": "@tui.banana",
		"category": "security",
		"keywords": ["banana"],
		"aliases": ["@tui.banana", "@tui.banana-filled"],
		"filled": true,
		"filledName": "banana-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bandage",
		"tuiName": "@tui.bandage",
		"category": "security",
		"keywords": ["bandage"],
		"aliases": ["@tui.bandage", "@tui.bandage-filled"],
		"filled": true,
		"filledName": "bandage-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bangladeshi-taka",
		"tuiName": "@tui.bangladeshi-taka",
		"category": "security",
		"keywords": ["bangladeshi", "taka"],
		"aliases": ["@tui.bangladeshi-taka", "@tui.bangladeshi-taka-filled"],
		"filled": true,
		"filledName": "bangladeshi-taka-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "banknote",
		"tuiName": "@tui.banknote",
		"category": "security",
		"keywords": ["banknote"],
		"aliases": ["@tui.banknote", "@tui.banknote-filled"],
		"filled": true,
		"filledName": "banknote-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "banknote-arrow-down",
		"tuiName": "@tui.banknote-arrow-down",
		"category": "security",
		"keywords": [
			"banknote",
			"arrow",
			"down"
		],
		"aliases": ["@tui.banknote-arrow-down", "@tui.banknote-arrow-down-filled"],
		"filled": true,
		"filledName": "banknote-arrow-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "banknote-arrow-up",
		"tuiName": "@tui.banknote-arrow-up",
		"category": "security",
		"keywords": [
			"banknote",
			"arrow",
			"up"
		],
		"aliases": ["@tui.banknote-arrow-up", "@tui.banknote-arrow-up-filled"],
		"filled": true,
		"filledName": "banknote-arrow-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "banknote-check",
		"tuiName": "@tui.banknote-check",
		"category": "security",
		"keywords": ["banknote", "check"],
		"aliases": ["@tui.banknote-check", "@tui.banknote-check-filled"],
		"filled": true,
		"filledName": "banknote-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "banknote-x",
		"tuiName": "@tui.banknote-x",
		"category": "security",
		"keywords": ["banknote", "x"],
		"aliases": ["@tui.banknote-x", "@tui.banknote-x-filled"],
		"filled": true,
		"filledName": "banknote-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bar-chart",
		"tuiName": "@tui.bar-chart",
		"category": "custom",
		"keywords": ["bar", "chart"],
		"aliases": ["@tui.bar-chart", "@tui.bar-chart-filled"],
		"filled": true,
		"filledName": "bar-chart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bar-chart-2",
		"tuiName": "@tui.bar-chart-2",
		"category": "custom",
		"keywords": [
			"bar",
			"chart",
			"2"
		],
		"aliases": ["@tui.bar-chart-2", "@tui.bar-chart-2-filled"],
		"filled": true,
		"filledName": "bar-chart-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bar-chart-3",
		"tuiName": "@tui.bar-chart-3",
		"category": "custom",
		"keywords": [
			"bar",
			"chart",
			"3"
		],
		"aliases": ["@tui.bar-chart-3", "@tui.bar-chart-3-filled"],
		"filled": true,
		"filledName": "bar-chart-3-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bar-chart-4",
		"tuiName": "@tui.bar-chart-4",
		"category": "custom",
		"keywords": [
			"bar",
			"chart",
			"4"
		],
		"aliases": ["@tui.bar-chart-4", "@tui.bar-chart-4-filled"],
		"filled": true,
		"filledName": "bar-chart-4-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bar-chart-big",
		"tuiName": "@tui.bar-chart-big",
		"category": "custom",
		"keywords": [
			"bar",
			"chart",
			"big"
		],
		"aliases": ["@tui.bar-chart-big", "@tui.bar-chart-big-filled"],
		"filled": true,
		"filledName": "bar-chart-big-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bar-chart-horizontal",
		"tuiName": "@tui.bar-chart-horizontal",
		"category": "custom",
		"keywords": [
			"bar",
			"chart",
			"horizontal"
		],
		"aliases": ["@tui.bar-chart-horizontal", "@tui.bar-chart-horizontal-filled"],
		"filled": true,
		"filledName": "bar-chart-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bar-chart-horizontal-big",
		"tuiName": "@tui.bar-chart-horizontal-big",
		"category": "custom",
		"keywords": [
			"bar",
			"chart",
			"horizontal",
			"big"
		],
		"aliases": ["@tui.bar-chart-horizontal-big", "@tui.bar-chart-horizontal-big-filled"],
		"filled": true,
		"filledName": "bar-chart-horizontal-big-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "barcode",
		"tuiName": "@tui.barcode",
		"category": "commerce",
		"keywords": ["barcode"],
		"aliases": ["@tui.barcode", "@tui.barcode-filled"],
		"filled": true,
		"filledName": "barcode-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "barrel",
		"tuiName": "@tui.barrel",
		"category": "custom",
		"keywords": ["barrel"],
		"aliases": ["@tui.barrel", "@tui.barrel-filled"],
		"filled": true,
		"filledName": "barrel-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "baseline",
		"tuiName": "@tui.baseline",
		"category": "custom",
		"keywords": ["baseline"],
		"aliases": ["@tui.baseline", "@tui.baseline-filled"],
		"filled": true,
		"filledName": "baseline-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bath",
		"tuiName": "@tui.bath",
		"category": "custom",
		"keywords": ["bath"],
		"aliases": ["@tui.bath", "@tui.bath-filled"],
		"filled": true,
		"filledName": "bath-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "battery",
		"tuiName": "@tui.battery",
		"category": "devices",
		"keywords": ["battery"],
		"aliases": ["@tui.battery", "@tui.battery-filled"],
		"filled": true,
		"filledName": "battery-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "battery-charging",
		"tuiName": "@tui.battery-charging",
		"category": "devices",
		"keywords": ["battery", "charging"],
		"aliases": ["@tui.battery-charging", "@tui.battery-charging-filled"],
		"filled": true,
		"filledName": "battery-charging-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "battery-full",
		"tuiName": "@tui.battery-full",
		"category": "devices",
		"keywords": ["battery", "full"],
		"aliases": ["@tui.battery-full", "@tui.battery-full-filled"],
		"filled": true,
		"filledName": "battery-full-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "battery-low",
		"tuiName": "@tui.battery-low",
		"category": "devices",
		"keywords": ["battery", "low"],
		"aliases": ["@tui.battery-low", "@tui.battery-low-filled"],
		"filled": true,
		"filledName": "battery-low-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "battery-medium",
		"tuiName": "@tui.battery-medium",
		"category": "devices",
		"keywords": ["battery", "medium"],
		"aliases": ["@tui.battery-medium", "@tui.battery-medium-filled"],
		"filled": true,
		"filledName": "battery-medium-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "battery-plus",
		"tuiName": "@tui.battery-plus",
		"category": "devices",
		"keywords": ["battery", "plus"],
		"aliases": ["@tui.battery-plus", "@tui.battery-plus-filled"],
		"filled": true,
		"filledName": "battery-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "battery-warning",
		"tuiName": "@tui.battery-warning",
		"category": "devices",
		"keywords": ["battery", "warning"],
		"aliases": ["@tui.battery-warning", "@tui.battery-warning-filled"],
		"filled": true,
		"filledName": "battery-warning-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "beaker",
		"tuiName": "@tui.beaker",
		"category": "custom",
		"keywords": ["beaker"],
		"aliases": ["@tui.beaker", "@tui.beaker-filled"],
		"filled": true,
		"filledName": "beaker-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bean",
		"tuiName": "@tui.bean",
		"category": "custom",
		"keywords": ["bean"],
		"aliases": ["@tui.bean", "@tui.bean-filled"],
		"filled": true,
		"filledName": "bean-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bean-off",
		"tuiName": "@tui.bean-off",
		"category": "custom",
		"keywords": ["bean", "off"],
		"aliases": ["@tui.bean-off", "@tui.bean-off-filled"],
		"filled": true,
		"filledName": "bean-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bed",
		"tuiName": "@tui.bed",
		"category": "custom",
		"keywords": ["bed"],
		"aliases": ["@tui.bed", "@tui.bed-filled"],
		"filled": true,
		"filledName": "bed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bed-double",
		"tuiName": "@tui.bed-double",
		"category": "custom",
		"keywords": ["bed", "double"],
		"aliases": ["@tui.bed-double", "@tui.bed-double-filled"],
		"filled": true,
		"filledName": "bed-double-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bed-single",
		"tuiName": "@tui.bed-single",
		"category": "custom",
		"keywords": ["bed", "single"],
		"aliases": ["@tui.bed-single", "@tui.bed-single-filled"],
		"filled": true,
		"filledName": "bed-single-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "beef",
		"tuiName": "@tui.beef",
		"category": "custom",
		"keywords": ["beef"],
		"aliases": ["@tui.beef", "@tui.beef-filled"],
		"filled": true,
		"filledName": "beef-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "beef-off",
		"tuiName": "@tui.beef-off",
		"category": "custom",
		"keywords": ["beef", "off"],
		"aliases": ["@tui.beef-off", "@tui.beef-off-filled"],
		"filled": true,
		"filledName": "beef-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "beer",
		"tuiName": "@tui.beer",
		"category": "custom",
		"keywords": ["beer"],
		"aliases": ["@tui.beer", "@tui.beer-filled"],
		"filled": true,
		"filledName": "beer-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "beer-off",
		"tuiName": "@tui.beer-off",
		"category": "custom",
		"keywords": ["beer", "off"],
		"aliases": ["@tui.beer-off", "@tui.beer-off-filled"],
		"filled": true,
		"filledName": "beer-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "belarusian-ruble",
		"tuiName": "@tui.belarusian-ruble",
		"category": "custom",
		"keywords": ["belarusian", "ruble"],
		"aliases": ["@tui.belarusian-ruble", "@tui.belarusian-ruble-filled"],
		"filled": true,
		"filledName": "belarusian-ruble-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bell",
		"tuiName": "@tui.bell",
		"category": "notifications",
		"keywords": ["bell"],
		"aliases": ["@tui.bell", "@tui.bell-filled"],
		"filled": true,
		"filledName": "bell-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bell-check",
		"tuiName": "@tui.bell-check",
		"category": "notifications",
		"keywords": ["bell", "check"],
		"aliases": ["@tui.bell-check", "@tui.bell-check-filled"],
		"filled": true,
		"filledName": "bell-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bell-dot",
		"tuiName": "@tui.bell-dot",
		"category": "notifications",
		"keywords": ["bell", "dot"],
		"aliases": ["@tui.bell-dot", "@tui.bell-dot-filled"],
		"filled": true,
		"filledName": "bell-dot-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bell-electric",
		"tuiName": "@tui.bell-electric",
		"category": "notifications",
		"keywords": ["bell", "electric"],
		"aliases": ["@tui.bell-electric", "@tui.bell-electric-filled"],
		"filled": true,
		"filledName": "bell-electric-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bell-minus",
		"tuiName": "@tui.bell-minus",
		"category": "notifications",
		"keywords": ["bell", "minus"],
		"aliases": ["@tui.bell-minus", "@tui.bell-minus-filled"],
		"filled": true,
		"filledName": "bell-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bell-off",
		"tuiName": "@tui.bell-off",
		"category": "notifications",
		"keywords": ["bell", "off"],
		"aliases": ["@tui.bell-off", "@tui.bell-off-filled"],
		"filled": true,
		"filledName": "bell-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bell-plus",
		"tuiName": "@tui.bell-plus",
		"category": "notifications",
		"keywords": ["bell", "plus"],
		"aliases": ["@tui.bell-plus", "@tui.bell-plus-filled"],
		"filled": true,
		"filledName": "bell-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bell-ring",
		"tuiName": "@tui.bell-ring",
		"category": "notifications",
		"keywords": ["bell", "ring"],
		"aliases": ["@tui.bell-ring", "@tui.bell-ring-filled"],
		"filled": true,
		"filledName": "bell-ring-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "between-horizonal-end",
		"tuiName": "@tui.between-horizonal-end",
		"category": "custom",
		"keywords": [
			"between",
			"horizonal",
			"end"
		],
		"aliases": ["@tui.between-horizonal-end", "@tui.between-horizonal-end-filled"],
		"filled": true,
		"filledName": "between-horizonal-end-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "between-horizonal-start",
		"tuiName": "@tui.between-horizonal-start",
		"category": "custom",
		"keywords": [
			"between",
			"horizonal",
			"start"
		],
		"aliases": ["@tui.between-horizonal-start", "@tui.between-horizonal-start-filled"],
		"filled": true,
		"filledName": "between-horizonal-start-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "between-horizontal-end",
		"tuiName": "@tui.between-horizontal-end",
		"category": "arrows",
		"keywords": [
			"between",
			"horizontal",
			"end"
		],
		"aliases": ["@tui.between-horizontal-end", "@tui.between-horizontal-end-filled"],
		"filled": true,
		"filledName": "between-horizontal-end-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "between-horizontal-start",
		"tuiName": "@tui.between-horizontal-start",
		"category": "arrows",
		"keywords": [
			"between",
			"horizontal",
			"start"
		],
		"aliases": ["@tui.between-horizontal-start", "@tui.between-horizontal-start-filled"],
		"filled": true,
		"filledName": "between-horizontal-start-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "between-vertical-end",
		"tuiName": "@tui.between-vertical-end",
		"category": "arrows",
		"keywords": [
			"between",
			"vertical",
			"end"
		],
		"aliases": ["@tui.between-vertical-end", "@tui.between-vertical-end-filled"],
		"filled": true,
		"filledName": "between-vertical-end-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "between-vertical-start",
		"tuiName": "@tui.between-vertical-start",
		"category": "arrows",
		"keywords": [
			"between",
			"vertical",
			"start"
		],
		"aliases": ["@tui.between-vertical-start", "@tui.between-vertical-start-filled"],
		"filled": true,
		"filledName": "between-vertical-start-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "biceps-flexed",
		"tuiName": "@tui.biceps-flexed",
		"category": "custom",
		"keywords": ["biceps", "flexed"],
		"aliases": ["@tui.biceps-flexed", "@tui.biceps-flexed-filled"],
		"filled": true,
		"filledName": "biceps-flexed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bike",
		"tuiName": "@tui.bike",
		"category": "maps-location",
		"keywords": ["bike"],
		"aliases": ["@tui.bike", "@tui.bike-filled"],
		"filled": true,
		"filledName": "bike-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "binary",
		"tuiName": "@tui.binary",
		"category": "development",
		"keywords": ["binary"],
		"aliases": ["@tui.binary", "@tui.binary-filled"],
		"filled": true,
		"filledName": "binary-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "binoculars",
		"tuiName": "@tui.binoculars",
		"category": "custom",
		"keywords": ["binoculars"],
		"aliases": ["@tui.binoculars", "@tui.binoculars-filled"],
		"filled": true,
		"filledName": "binoculars-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "biohazard",
		"tuiName": "@tui.biohazard",
		"category": "custom",
		"keywords": ["biohazard"],
		"aliases": ["@tui.biohazard", "@tui.biohazard-filled"],
		"filled": true,
		"filledName": "biohazard-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bird",
		"tuiName": "@tui.bird",
		"category": "custom",
		"keywords": ["bird"],
		"aliases": ["@tui.bird", "@tui.bird-filled"],
		"filled": true,
		"filledName": "bird-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "birdhouse",
		"tuiName": "@tui.birdhouse",
		"category": "custom",
		"keywords": ["birdhouse"],
		"aliases": ["@tui.birdhouse", "@tui.birdhouse-filled"],
		"filled": true,
		"filledName": "birdhouse-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bitcoin",
		"tuiName": "@tui.bitcoin",
		"category": "custom",
		"keywords": ["bitcoin"],
		"aliases": ["@tui.bitcoin", "@tui.bitcoin-filled"],
		"filled": true,
		"filledName": "bitcoin-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "blend",
		"tuiName": "@tui.blend",
		"category": "custom",
		"keywords": ["blend"],
		"aliases": ["@tui.blend", "@tui.blend-filled"],
		"filled": true,
		"filledName": "blend-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "blender",
		"tuiName": "@tui.blender",
		"category": "custom",
		"keywords": ["blender"],
		"aliases": ["@tui.blender", "@tui.blender-filled"],
		"filled": true,
		"filledName": "blender-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "blinds",
		"tuiName": "@tui.blinds",
		"category": "custom",
		"keywords": ["blinds"],
		"aliases": ["@tui.blinds", "@tui.blinds-filled"],
		"filled": true,
		"filledName": "blinds-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "blocks",
		"tuiName": "@tui.blocks",
		"category": "layout",
		"keywords": ["blocks"],
		"aliases": ["@tui.blocks", "@tui.blocks-filled"],
		"filled": true,
		"filledName": "blocks-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bluetooth",
		"tuiName": "@tui.bluetooth",
		"category": "devices",
		"keywords": ["bluetooth"],
		"aliases": ["@tui.bluetooth", "@tui.bluetooth-filled"],
		"filled": true,
		"filledName": "bluetooth-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bluetooth-connected",
		"tuiName": "@tui.bluetooth-connected",
		"category": "devices",
		"keywords": ["bluetooth", "connected"],
		"aliases": ["@tui.bluetooth-connected", "@tui.bluetooth-connected-filled"],
		"filled": true,
		"filledName": "bluetooth-connected-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bluetooth-off",
		"tuiName": "@tui.bluetooth-off",
		"category": "devices",
		"keywords": ["bluetooth", "off"],
		"aliases": ["@tui.bluetooth-off", "@tui.bluetooth-off-filled"],
		"filled": true,
		"filledName": "bluetooth-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bluetooth-searching",
		"tuiName": "@tui.bluetooth-searching",
		"category": "devices",
		"keywords": ["bluetooth", "searching"],
		"aliases": ["@tui.bluetooth-searching", "@tui.bluetooth-searching-filled"],
		"filled": true,
		"filledName": "bluetooth-searching-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bold",
		"tuiName": "@tui.bold",
		"category": "editing",
		"keywords": ["bold"],
		"aliases": ["@tui.bold", "@tui.bold-filled"],
		"filled": true,
		"filledName": "bold-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bolt",
		"tuiName": "@tui.bolt",
		"category": "custom",
		"keywords": ["bolt"],
		"aliases": ["@tui.bolt", "@tui.bolt-filled"],
		"filled": true,
		"filledName": "bolt-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bomb",
		"tuiName": "@tui.bomb",
		"category": "custom",
		"keywords": ["bomb"],
		"aliases": ["@tui.bomb", "@tui.bomb-filled"],
		"filled": true,
		"filledName": "bomb-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bone",
		"tuiName": "@tui.bone",
		"category": "custom",
		"keywords": ["bone"],
		"aliases": ["@tui.bone", "@tui.bone-filled"],
		"filled": true,
		"filledName": "bone-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bone-fracture",
		"tuiName": "@tui.bone-fracture",
		"category": "custom",
		"keywords": ["bone", "fracture"],
		"aliases": ["@tui.bone-fracture", "@tui.bone-fracture-filled"],
		"filled": true,
		"filledName": "bone-fracture-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book",
		"tuiName": "@tui.book",
		"category": "files",
		"keywords": ["book"],
		"aliases": ["@tui.book", "@tui.book-filled"],
		"filled": true,
		"filledName": "book-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-a",
		"tuiName": "@tui.book-a",
		"category": "files",
		"keywords": ["book", "a"],
		"aliases": ["@tui.book-a", "@tui.book-a-filled"],
		"filled": true,
		"filledName": "book-a-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-alert",
		"tuiName": "@tui.book-alert",
		"category": "files",
		"keywords": ["book", "alert"],
		"aliases": ["@tui.book-alert", "@tui.book-alert-filled"],
		"filled": true,
		"filledName": "book-alert-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-audio",
		"tuiName": "@tui.book-audio",
		"category": "files",
		"keywords": ["book", "audio"],
		"aliases": ["@tui.book-audio", "@tui.book-audio-filled"],
		"filled": true,
		"filledName": "book-audio-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-bookmark",
		"tuiName": "@tui.book-bookmark",
		"category": "files",
		"keywords": ["book", "bookmark"],
		"aliases": ["@tui.book-bookmark", "@tui.book-bookmark-filled"],
		"filled": true,
		"filledName": "book-bookmark-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-check",
		"tuiName": "@tui.book-check",
		"category": "files",
		"keywords": ["book", "check"],
		"aliases": ["@tui.book-check", "@tui.book-check-filled"],
		"filled": true,
		"filledName": "book-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-copy",
		"tuiName": "@tui.book-copy",
		"category": "files",
		"keywords": ["book", "copy"],
		"aliases": ["@tui.book-copy", "@tui.book-copy-filled"],
		"filled": true,
		"filledName": "book-copy-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-dashed",
		"tuiName": "@tui.book-dashed",
		"category": "files",
		"keywords": ["book", "dashed"],
		"aliases": ["@tui.book-dashed", "@tui.book-dashed-filled"],
		"filled": true,
		"filledName": "book-dashed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-down",
		"tuiName": "@tui.book-down",
		"category": "files",
		"keywords": ["book", "down"],
		"aliases": ["@tui.book-down", "@tui.book-down-filled"],
		"filled": true,
		"filledName": "book-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-headphones",
		"tuiName": "@tui.book-headphones",
		"category": "files",
		"keywords": ["book", "headphones"],
		"aliases": ["@tui.book-headphones", "@tui.book-headphones-filled"],
		"filled": true,
		"filledName": "book-headphones-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-heart",
		"tuiName": "@tui.book-heart",
		"category": "files",
		"keywords": ["book", "heart"],
		"aliases": ["@tui.book-heart", "@tui.book-heart-filled"],
		"filled": true,
		"filledName": "book-heart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-image",
		"tuiName": "@tui.book-image",
		"category": "files",
		"keywords": ["book", "image"],
		"aliases": ["@tui.book-image", "@tui.book-image-filled"],
		"filled": true,
		"filledName": "book-image-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-key",
		"tuiName": "@tui.book-key",
		"category": "files",
		"keywords": ["book", "key"],
		"aliases": ["@tui.book-key", "@tui.book-key-filled"],
		"filled": true,
		"filledName": "book-key-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-lock",
		"tuiName": "@tui.book-lock",
		"category": "files",
		"keywords": ["book", "lock"],
		"aliases": ["@tui.book-lock", "@tui.book-lock-filled"],
		"filled": true,
		"filledName": "book-lock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-marked",
		"tuiName": "@tui.book-marked",
		"category": "files",
		"keywords": ["book", "marked"],
		"aliases": ["@tui.book-marked", "@tui.book-marked-filled"],
		"filled": true,
		"filledName": "book-marked-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-minus",
		"tuiName": "@tui.book-minus",
		"category": "files",
		"keywords": ["book", "minus"],
		"aliases": ["@tui.book-minus", "@tui.book-minus-filled"],
		"filled": true,
		"filledName": "book-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-open",
		"tuiName": "@tui.book-open",
		"category": "files",
		"keywords": ["book", "open"],
		"aliases": ["@tui.book-open", "@tui.book-open-filled"],
		"filled": true,
		"filledName": "book-open-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-open-check",
		"tuiName": "@tui.book-open-check",
		"category": "files",
		"keywords": [
			"book",
			"open",
			"check"
		],
		"aliases": ["@tui.book-open-check", "@tui.book-open-check-filled"],
		"filled": true,
		"filledName": "book-open-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-open-text",
		"tuiName": "@tui.book-open-text",
		"category": "files",
		"keywords": [
			"book",
			"open",
			"text"
		],
		"aliases": ["@tui.book-open-text", "@tui.book-open-text-filled"],
		"filled": true,
		"filledName": "book-open-text-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-plus",
		"tuiName": "@tui.book-plus",
		"category": "files",
		"keywords": ["book", "plus"],
		"aliases": ["@tui.book-plus", "@tui.book-plus-filled"],
		"filled": true,
		"filledName": "book-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-search",
		"tuiName": "@tui.book-search",
		"category": "files",
		"keywords": ["book", "search"],
		"aliases": ["@tui.book-search", "@tui.book-search-filled"],
		"filled": true,
		"filledName": "book-search-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-template",
		"tuiName": "@tui.book-template",
		"category": "files",
		"keywords": ["book", "template"],
		"aliases": ["@tui.book-template", "@tui.book-template-filled"],
		"filled": true,
		"filledName": "book-template-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-text",
		"tuiName": "@tui.book-text",
		"category": "files",
		"keywords": ["book", "text"],
		"aliases": ["@tui.book-text", "@tui.book-text-filled"],
		"filled": true,
		"filledName": "book-text-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-type",
		"tuiName": "@tui.book-type",
		"category": "files",
		"keywords": ["book", "type"],
		"aliases": ["@tui.book-type", "@tui.book-type-filled"],
		"filled": true,
		"filledName": "book-type-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-up",
		"tuiName": "@tui.book-up",
		"category": "files",
		"keywords": ["book", "up"],
		"aliases": ["@tui.book-up", "@tui.book-up-filled"],
		"filled": true,
		"filledName": "book-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-up-2",
		"tuiName": "@tui.book-up-2",
		"category": "files",
		"keywords": [
			"book",
			"up",
			"2"
		],
		"aliases": ["@tui.book-up-2", "@tui.book-up-2-filled"],
		"filled": true,
		"filledName": "book-up-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-user",
		"tuiName": "@tui.book-user",
		"category": "files",
		"keywords": ["book", "user"],
		"aliases": ["@tui.book-user", "@tui.book-user-filled"],
		"filled": true,
		"filledName": "book-user-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "book-x",
		"tuiName": "@tui.book-x",
		"category": "files",
		"keywords": ["book", "x"],
		"aliases": ["@tui.book-x", "@tui.book-x-filled"],
		"filled": true,
		"filledName": "book-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bookmark",
		"tuiName": "@tui.bookmark",
		"category": "files",
		"keywords": ["bookmark"],
		"aliases": ["@tui.bookmark", "@tui.bookmark-filled"],
		"filled": true,
		"filledName": "bookmark-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bookmark-check",
		"tuiName": "@tui.bookmark-check",
		"category": "files",
		"keywords": ["bookmark", "check"],
		"aliases": ["@tui.bookmark-check", "@tui.bookmark-check-filled"],
		"filled": true,
		"filledName": "bookmark-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bookmark-minus",
		"tuiName": "@tui.bookmark-minus",
		"category": "files",
		"keywords": ["bookmark", "minus"],
		"aliases": ["@tui.bookmark-minus", "@tui.bookmark-minus-filled"],
		"filled": true,
		"filledName": "bookmark-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bookmark-off",
		"tuiName": "@tui.bookmark-off",
		"category": "files",
		"keywords": ["bookmark", "off"],
		"aliases": ["@tui.bookmark-off", "@tui.bookmark-off-filled"],
		"filled": true,
		"filledName": "bookmark-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bookmark-plus",
		"tuiName": "@tui.bookmark-plus",
		"category": "files",
		"keywords": ["bookmark", "plus"],
		"aliases": ["@tui.bookmark-plus", "@tui.bookmark-plus-filled"],
		"filled": true,
		"filledName": "bookmark-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bookmark-x",
		"tuiName": "@tui.bookmark-x",
		"category": "files",
		"keywords": ["bookmark", "x"],
		"aliases": ["@tui.bookmark-x", "@tui.bookmark-x-filled"],
		"filled": true,
		"filledName": "bookmark-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "boom-box",
		"tuiName": "@tui.boom-box",
		"category": "custom",
		"keywords": ["boom", "box"],
		"aliases": ["@tui.boom-box", "@tui.boom-box-filled"],
		"filled": true,
		"filledName": "boom-box-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bot",
		"tuiName": "@tui.bot",
		"category": "development",
		"keywords": ["bot"],
		"aliases": ["@tui.bot", "@tui.bot-filled"],
		"filled": true,
		"filledName": "bot-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bot-message-square",
		"tuiName": "@tui.bot-message-square",
		"category": "development",
		"keywords": [
			"bot",
			"message",
			"square"
		],
		"aliases": ["@tui.bot-message-square", "@tui.bot-message-square-filled"],
		"filled": true,
		"filledName": "bot-message-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bot-off",
		"tuiName": "@tui.bot-off",
		"category": "development",
		"keywords": ["bot", "off"],
		"aliases": ["@tui.bot-off", "@tui.bot-off-filled"],
		"filled": true,
		"filledName": "bot-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bottle-wine",
		"tuiName": "@tui.bottle-wine",
		"category": "development",
		"keywords": ["bottle", "wine"],
		"aliases": ["@tui.bottle-wine", "@tui.bottle-wine-filled"],
		"filled": true,
		"filledName": "bottle-wine-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bow-arrow",
		"tuiName": "@tui.bow-arrow",
		"category": "custom",
		"keywords": ["bow", "arrow"],
		"aliases": ["@tui.bow-arrow", "@tui.bow-arrow-filled"],
		"filled": true,
		"filledName": "bow-arrow-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "box",
		"tuiName": "@tui.box",
		"category": "layout",
		"keywords": ["box"],
		"aliases": ["@tui.box", "@tui.box-filled"],
		"filled": true,
		"filledName": "box-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "box-select",
		"tuiName": "@tui.box-select",
		"category": "layout",
		"keywords": ["box", "select"],
		"aliases": ["@tui.box-select", "@tui.box-select-filled"],
		"filled": true,
		"filledName": "box-select-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "boxes",
		"tuiName": "@tui.boxes",
		"category": "layout",
		"keywords": ["boxes"],
		"aliases": ["@tui.boxes", "@tui.boxes-filled"],
		"filled": true,
		"filledName": "boxes-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "braces",
		"tuiName": "@tui.braces",
		"category": "development",
		"keywords": ["braces"],
		"aliases": ["@tui.braces", "@tui.braces-filled"],
		"filled": true,
		"filledName": "braces-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "brackets",
		"tuiName": "@tui.brackets",
		"category": "development",
		"keywords": ["brackets"],
		"aliases": ["@tui.brackets", "@tui.brackets-filled"],
		"filled": true,
		"filledName": "brackets-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "brain",
		"tuiName": "@tui.brain",
		"category": "custom",
		"keywords": ["brain"],
		"aliases": ["@tui.brain", "@tui.brain-filled"],
		"filled": true,
		"filledName": "brain-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "brain-circuit",
		"tuiName": "@tui.brain-circuit",
		"category": "custom",
		"keywords": ["brain", "circuit"],
		"aliases": ["@tui.brain-circuit", "@tui.brain-circuit-filled"],
		"filled": true,
		"filledName": "brain-circuit-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "brain-cog",
		"tuiName": "@tui.brain-cog",
		"category": "custom",
		"keywords": ["brain", "cog"],
		"aliases": ["@tui.brain-cog", "@tui.brain-cog-filled"],
		"filled": true,
		"filledName": "brain-cog-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "brick-wall",
		"tuiName": "@tui.brick-wall",
		"category": "custom",
		"keywords": ["brick", "wall"],
		"aliases": ["@tui.brick-wall", "@tui.brick-wall-filled"],
		"filled": true,
		"filledName": "brick-wall-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "brick-wall-fire",
		"tuiName": "@tui.brick-wall-fire",
		"category": "custom",
		"keywords": [
			"brick",
			"wall",
			"fire"
		],
		"aliases": ["@tui.brick-wall-fire", "@tui.brick-wall-fire-filled"],
		"filled": true,
		"filledName": "brick-wall-fire-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "brick-wall-shield",
		"tuiName": "@tui.brick-wall-shield",
		"category": "custom",
		"keywords": [
			"brick",
			"wall",
			"shield"
		],
		"aliases": ["@tui.brick-wall-shield", "@tui.brick-wall-shield-filled"],
		"filled": true,
		"filledName": "brick-wall-shield-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bridge",
		"tuiName": "@tui.bridge",
		"category": "custom",
		"keywords": ["bridge"],
		"aliases": ["@tui.bridge", "@tui.bridge-filled"],
		"filled": true,
		"filledName": "bridge-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "briefcase",
		"tuiName": "@tui.briefcase",
		"category": "custom",
		"keywords": ["briefcase"],
		"aliases": ["@tui.briefcase", "@tui.briefcase-filled"],
		"filled": true,
		"filledName": "briefcase-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "briefcase-business",
		"tuiName": "@tui.briefcase-business",
		"category": "custom",
		"keywords": ["briefcase", "business"],
		"aliases": ["@tui.briefcase-business", "@tui.briefcase-business-filled"],
		"filled": true,
		"filledName": "briefcase-business-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "briefcase-conveyor-belt",
		"tuiName": "@tui.briefcase-conveyor-belt",
		"category": "custom",
		"keywords": [
			"briefcase",
			"conveyor",
			"belt"
		],
		"aliases": ["@tui.briefcase-conveyor-belt", "@tui.briefcase-conveyor-belt-filled"],
		"filled": true,
		"filledName": "briefcase-conveyor-belt-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "briefcase-medical",
		"tuiName": "@tui.briefcase-medical",
		"category": "custom",
		"keywords": ["briefcase", "medical"],
		"aliases": ["@tui.briefcase-medical", "@tui.briefcase-medical-filled"],
		"filled": true,
		"filledName": "briefcase-medical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "briefcase-plus",
		"tuiName": "@tui.briefcase-plus",
		"category": "custom",
		"keywords": ["briefcase", "plus"],
		"aliases": ["@tui.briefcase-plus", "@tui.briefcase-plus-filled"],
		"filled": true,
		"filledName": "briefcase-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bring-to-front",
		"tuiName": "@tui.bring-to-front",
		"category": "layout",
		"keywords": [
			"bring",
			"to",
			"front"
		],
		"aliases": ["@tui.bring-to-front", "@tui.bring-to-front-filled"],
		"filled": true,
		"filledName": "bring-to-front-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "broccoli",
		"tuiName": "@tui.broccoli",
		"category": "custom",
		"keywords": ["broccoli"],
		"aliases": ["@tui.broccoli", "@tui.broccoli-filled"],
		"filled": true,
		"filledName": "broccoli-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "broom",
		"tuiName": "@tui.broom",
		"category": "custom",
		"keywords": ["broom"],
		"aliases": ["@tui.broom", "@tui.broom-filled"],
		"filled": true,
		"filledName": "broom-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "broom-sparkles",
		"tuiName": "@tui.broom-sparkles",
		"category": "custom",
		"keywords": ["broom", "sparkles"],
		"aliases": ["@tui.broom-sparkles", "@tui.broom-sparkles-filled"],
		"filled": true,
		"filledName": "broom-sparkles-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "brush",
		"tuiName": "@tui.brush",
		"category": "editing",
		"keywords": ["brush"],
		"aliases": ["@tui.brush", "@tui.brush-filled"],
		"filled": true,
		"filledName": "brush-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "brush-cleaning",
		"tuiName": "@tui.brush-cleaning",
		"category": "editing",
		"keywords": ["brush", "cleaning"],
		"aliases": ["@tui.brush-cleaning", "@tui.brush-cleaning-filled"],
		"filled": true,
		"filledName": "brush-cleaning-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bubbles",
		"tuiName": "@tui.bubbles",
		"category": "custom",
		"keywords": ["bubbles"],
		"aliases": ["@tui.bubbles", "@tui.bubbles-filled"],
		"filled": true,
		"filledName": "bubbles-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bug",
		"tuiName": "@tui.bug",
		"category": "development",
		"keywords": ["bug"],
		"aliases": ["@tui.bug", "@tui.bug-filled"],
		"filled": true,
		"filledName": "bug-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bug-off",
		"tuiName": "@tui.bug-off",
		"category": "development",
		"keywords": ["bug", "off"],
		"aliases": ["@tui.bug-off", "@tui.bug-off-filled"],
		"filled": true,
		"filledName": "bug-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bug-play",
		"tuiName": "@tui.bug-play",
		"category": "development",
		"keywords": ["bug", "play"],
		"aliases": ["@tui.bug-play", "@tui.bug-play-filled"],
		"filled": true,
		"filledName": "bug-play-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "building",
		"tuiName": "@tui.building",
		"category": "maps-location",
		"keywords": ["building"],
		"aliases": ["@tui.building", "@tui.building-filled"],
		"filled": true,
		"filledName": "building-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "building-2",
		"tuiName": "@tui.building-2",
		"category": "maps-location",
		"keywords": ["building", "2"],
		"aliases": ["@tui.building-2", "@tui.building-2-filled"],
		"filled": true,
		"filledName": "building-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "building-complex",
		"tuiName": "@tui.building-complex",
		"category": "maps-location",
		"keywords": ["building", "complex"],
		"aliases": ["@tui.building-complex", "@tui.building-complex-filled"],
		"filled": true,
		"filledName": "building-complex-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "building-complex-plus",
		"tuiName": "@tui.building-complex-plus",
		"category": "maps-location",
		"keywords": [
			"building",
			"complex",
			"plus"
		],
		"aliases": ["@tui.building-complex-plus", "@tui.building-complex-plus-filled"],
		"filled": true,
		"filledName": "building-complex-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bus",
		"tuiName": "@tui.bus",
		"category": "maps-location",
		"keywords": ["bus"],
		"aliases": ["@tui.bus", "@tui.bus-filled"],
		"filled": true,
		"filledName": "bus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "bus-front",
		"tuiName": "@tui.bus-front",
		"category": "maps-location",
		"keywords": ["bus", "front"],
		"aliases": ["@tui.bus-front", "@tui.bus-front-filled"],
		"filled": true,
		"filledName": "bus-front-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cable",
		"tuiName": "@tui.cable",
		"category": "custom",
		"keywords": ["cable"],
		"aliases": ["@tui.cable", "@tui.cable-filled"],
		"filled": true,
		"filledName": "cable-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cable-car",
		"tuiName": "@tui.cable-car",
		"category": "custom",
		"keywords": ["cable", "car"],
		"aliases": ["@tui.cable-car", "@tui.cable-car-filled"],
		"filled": true,
		"filledName": "cable-car-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cake",
		"tuiName": "@tui.cake",
		"category": "custom",
		"keywords": ["cake"],
		"aliases": ["@tui.cake", "@tui.cake-filled"],
		"filled": true,
		"filledName": "cake-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cake-slice",
		"tuiName": "@tui.cake-slice",
		"category": "custom",
		"keywords": ["cake", "slice"],
		"aliases": ["@tui.cake-slice", "@tui.cake-slice-filled"],
		"filled": true,
		"filledName": "cake-slice-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calculator",
		"tuiName": "@tui.calculator",
		"category": "custom",
		"keywords": ["calculator"],
		"aliases": ["@tui.calculator", "@tui.calculator-filled"],
		"filled": true,
		"filledName": "calculator-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar",
		"tuiName": "@tui.calendar",
		"category": "calendar-time",
		"keywords": ["calendar"],
		"aliases": ["@tui.calendar", "@tui.calendar-filled"],
		"filled": true,
		"filledName": "calendar-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-1",
		"tuiName": "@tui.calendar-1",
		"category": "calendar-time",
		"keywords": ["calendar", "1"],
		"aliases": ["@tui.calendar-1", "@tui.calendar-1-filled"],
		"filled": true,
		"filledName": "calendar-1-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-arrow-down",
		"tuiName": "@tui.calendar-arrow-down",
		"category": "calendar-time",
		"keywords": [
			"calendar",
			"arrow",
			"down"
		],
		"aliases": ["@tui.calendar-arrow-down", "@tui.calendar-arrow-down-filled"],
		"filled": true,
		"filledName": "calendar-arrow-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-arrow-up",
		"tuiName": "@tui.calendar-arrow-up",
		"category": "calendar-time",
		"keywords": [
			"calendar",
			"arrow",
			"up"
		],
		"aliases": ["@tui.calendar-arrow-up", "@tui.calendar-arrow-up-filled"],
		"filled": true,
		"filledName": "calendar-arrow-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-check",
		"tuiName": "@tui.calendar-check",
		"category": "calendar-time",
		"keywords": ["calendar", "check"],
		"aliases": ["@tui.calendar-check", "@tui.calendar-check-filled"],
		"filled": true,
		"filledName": "calendar-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-check-2",
		"tuiName": "@tui.calendar-check-2",
		"category": "calendar-time",
		"keywords": [
			"calendar",
			"check",
			"2"
		],
		"aliases": ["@tui.calendar-check-2", "@tui.calendar-check-2-filled"],
		"filled": true,
		"filledName": "calendar-check-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-chevrons-left",
		"tuiName": "@tui.calendar-chevrons-left",
		"category": "calendar-time",
		"keywords": [
			"calendar",
			"chevrons",
			"left"
		],
		"aliases": ["@tui.calendar-chevrons-left", "@tui.calendar-chevrons-left-filled"],
		"filled": true,
		"filledName": "calendar-chevrons-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-chevrons-right",
		"tuiName": "@tui.calendar-chevrons-right",
		"category": "calendar-time",
		"keywords": [
			"calendar",
			"chevrons",
			"right"
		],
		"aliases": ["@tui.calendar-chevrons-right", "@tui.calendar-chevrons-right-filled"],
		"filled": true,
		"filledName": "calendar-chevrons-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-clock",
		"tuiName": "@tui.calendar-clock",
		"category": "calendar-time",
		"keywords": ["calendar", "clock"],
		"aliases": ["@tui.calendar-clock", "@tui.calendar-clock-filled"],
		"filled": true,
		"filledName": "calendar-clock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-cog",
		"tuiName": "@tui.calendar-cog",
		"category": "calendar-time",
		"keywords": ["calendar", "cog"],
		"aliases": ["@tui.calendar-cog", "@tui.calendar-cog-filled"],
		"filled": true,
		"filledName": "calendar-cog-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-days",
		"tuiName": "@tui.calendar-days",
		"category": "calendar-time",
		"keywords": ["calendar", "days"],
		"aliases": ["@tui.calendar-days", "@tui.calendar-days-filled"],
		"filled": true,
		"filledName": "calendar-days-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-fold",
		"tuiName": "@tui.calendar-fold",
		"category": "calendar-time",
		"keywords": ["calendar", "fold"],
		"aliases": ["@tui.calendar-fold", "@tui.calendar-fold-filled"],
		"filled": true,
		"filledName": "calendar-fold-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-heart",
		"tuiName": "@tui.calendar-heart",
		"category": "calendar-time",
		"keywords": ["calendar", "heart"],
		"aliases": ["@tui.calendar-heart", "@tui.calendar-heart-filled"],
		"filled": true,
		"filledName": "calendar-heart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-minus",
		"tuiName": "@tui.calendar-minus",
		"category": "calendar-time",
		"keywords": ["calendar", "minus"],
		"aliases": ["@tui.calendar-minus", "@tui.calendar-minus-filled"],
		"filled": true,
		"filledName": "calendar-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-minus-2",
		"tuiName": "@tui.calendar-minus-2",
		"category": "calendar-time",
		"keywords": [
			"calendar",
			"minus",
			"2"
		],
		"aliases": ["@tui.calendar-minus-2", "@tui.calendar-minus-2-filled"],
		"filled": true,
		"filledName": "calendar-minus-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-off",
		"tuiName": "@tui.calendar-off",
		"category": "calendar-time",
		"keywords": ["calendar", "off"],
		"aliases": ["@tui.calendar-off", "@tui.calendar-off-filled"],
		"filled": true,
		"filledName": "calendar-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-plus",
		"tuiName": "@tui.calendar-plus",
		"category": "calendar-time",
		"keywords": ["calendar", "plus"],
		"aliases": ["@tui.calendar-plus", "@tui.calendar-plus-filled"],
		"filled": true,
		"filledName": "calendar-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-plus-2",
		"tuiName": "@tui.calendar-plus-2",
		"category": "calendar-time",
		"keywords": [
			"calendar",
			"plus",
			"2"
		],
		"aliases": ["@tui.calendar-plus-2", "@tui.calendar-plus-2-filled"],
		"filled": true,
		"filledName": "calendar-plus-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-range",
		"tuiName": "@tui.calendar-range",
		"category": "calendar-time",
		"keywords": ["calendar", "range"],
		"aliases": ["@tui.calendar-range", "@tui.calendar-range-filled"],
		"filled": true,
		"filledName": "calendar-range-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-search",
		"tuiName": "@tui.calendar-search",
		"category": "calendar-time",
		"keywords": ["calendar", "search"],
		"aliases": ["@tui.calendar-search", "@tui.calendar-search-filled"],
		"filled": true,
		"filledName": "calendar-search-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-sync",
		"tuiName": "@tui.calendar-sync",
		"category": "calendar-time",
		"keywords": ["calendar", "sync"],
		"aliases": ["@tui.calendar-sync", "@tui.calendar-sync-filled"],
		"filled": true,
		"filledName": "calendar-sync-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-x",
		"tuiName": "@tui.calendar-x",
		"category": "calendar-time",
		"keywords": ["calendar", "x"],
		"aliases": ["@tui.calendar-x", "@tui.calendar-x-filled"],
		"filled": true,
		"filledName": "calendar-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendar-x-2",
		"tuiName": "@tui.calendar-x-2",
		"category": "calendar-time",
		"keywords": [
			"calendar",
			"x",
			"2"
		],
		"aliases": ["@tui.calendar-x-2", "@tui.calendar-x-2-filled"],
		"filled": true,
		"filledName": "calendar-x-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "calendars",
		"tuiName": "@tui.calendars",
		"category": "calendar-time",
		"keywords": ["calendars"],
		"aliases": ["@tui.calendars", "@tui.calendars-filled"],
		"filled": true,
		"filledName": "calendars-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "camera",
		"tuiName": "@tui.camera",
		"category": "media",
		"keywords": ["camera"],
		"aliases": ["@tui.camera", "@tui.camera-filled"],
		"filled": true,
		"filledName": "camera-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "camera-off",
		"tuiName": "@tui.camera-off",
		"category": "media",
		"keywords": ["camera", "off"],
		"aliases": ["@tui.camera-off", "@tui.camera-off-filled"],
		"filled": true,
		"filledName": "camera-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "can",
		"tuiName": "@tui.can",
		"category": "custom",
		"keywords": ["can"],
		"aliases": ["@tui.can", "@tui.can-filled"],
		"filled": true,
		"filledName": "can-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "can-soda",
		"tuiName": "@tui.can-soda",
		"category": "custom",
		"keywords": ["can", "soda"],
		"aliases": ["@tui.can-soda", "@tui.can-soda-filled"],
		"filled": true,
		"filledName": "can-soda-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "candlestick-chart",
		"tuiName": "@tui.candlestick-chart",
		"category": "custom",
		"keywords": ["candlestick", "chart"],
		"aliases": ["@tui.candlestick-chart", "@tui.candlestick-chart-filled"],
		"filled": true,
		"filledName": "candlestick-chart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "candy",
		"tuiName": "@tui.candy",
		"category": "custom",
		"keywords": ["candy"],
		"aliases": ["@tui.candy", "@tui.candy-filled"],
		"filled": true,
		"filledName": "candy-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "candy-cane",
		"tuiName": "@tui.candy-cane",
		"category": "custom",
		"keywords": ["candy", "cane"],
		"aliases": ["@tui.candy-cane", "@tui.candy-cane-filled"],
		"filled": true,
		"filledName": "candy-cane-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "candy-off",
		"tuiName": "@tui.candy-off",
		"category": "custom",
		"keywords": ["candy", "off"],
		"aliases": ["@tui.candy-off", "@tui.candy-off-filled"],
		"filled": true,
		"filledName": "candy-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cannabis",
		"tuiName": "@tui.cannabis",
		"category": "custom",
		"keywords": ["cannabis"],
		"aliases": ["@tui.cannabis", "@tui.cannabis-filled"],
		"filled": true,
		"filledName": "cannabis-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cannabis-off",
		"tuiName": "@tui.cannabis-off",
		"category": "custom",
		"keywords": ["cannabis", "off"],
		"aliases": ["@tui.cannabis-off", "@tui.cannabis-off-filled"],
		"filled": true,
		"filledName": "cannabis-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "captions",
		"tuiName": "@tui.captions",
		"category": "custom",
		"keywords": ["captions"],
		"aliases": ["@tui.captions", "@tui.captions-filled"],
		"filled": true,
		"filledName": "captions-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "captions-off",
		"tuiName": "@tui.captions-off",
		"category": "custom",
		"keywords": ["captions", "off"],
		"aliases": ["@tui.captions-off", "@tui.captions-off-filled"],
		"filled": true,
		"filledName": "captions-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "car",
		"tuiName": "@tui.car",
		"category": "maps-location",
		"keywords": ["car"],
		"aliases": ["@tui.car", "@tui.car-filled"],
		"filled": true,
		"filledName": "car-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "car-battery",
		"tuiName": "@tui.car-battery",
		"category": "maps-location",
		"keywords": ["car", "battery"],
		"aliases": ["@tui.car-battery", "@tui.car-battery-filled"],
		"filled": true,
		"filledName": "car-battery-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "car-front",
		"tuiName": "@tui.car-front",
		"category": "maps-location",
		"keywords": ["car", "front"],
		"aliases": ["@tui.car-front", "@tui.car-front-filled"],
		"filled": true,
		"filledName": "car-front-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "car-taxi-front",
		"tuiName": "@tui.car-taxi-front",
		"category": "maps-location",
		"keywords": [
			"car",
			"taxi",
			"front"
		],
		"aliases": ["@tui.car-taxi-front", "@tui.car-taxi-front-filled"],
		"filled": true,
		"filledName": "car-taxi-front-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "caravan",
		"tuiName": "@tui.caravan",
		"category": "maps-location",
		"keywords": ["caravan"],
		"aliases": ["@tui.caravan", "@tui.caravan-filled"],
		"filled": true,
		"filledName": "caravan-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "card-sim",
		"tuiName": "@tui.card-sim",
		"category": "maps-location",
		"keywords": ["card", "sim"],
		"aliases": ["@tui.card-sim", "@tui.card-sim-filled"],
		"filled": true,
		"filledName": "card-sim-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "carrot",
		"tuiName": "@tui.carrot",
		"category": "maps-location",
		"keywords": ["carrot"],
		"aliases": ["@tui.carrot", "@tui.carrot-filled"],
		"filled": true,
		"filledName": "carrot-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "carton",
		"tuiName": "@tui.carton",
		"category": "commerce",
		"keywords": ["carton"],
		"aliases": ["@tui.carton", "@tui.carton-filled"],
		"filled": true,
		"filledName": "carton-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "carton-off",
		"tuiName": "@tui.carton-off",
		"category": "commerce",
		"keywords": ["carton", "off"],
		"aliases": ["@tui.carton-off", "@tui.carton-off-filled"],
		"filled": true,
		"filledName": "carton-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "case-lower",
		"tuiName": "@tui.case-lower",
		"category": "editing",
		"keywords": ["case", "lower"],
		"aliases": ["@tui.case-lower", "@tui.case-lower-filled"],
		"filled": true,
		"filledName": "case-lower-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "case-sensitive",
		"tuiName": "@tui.case-sensitive",
		"category": "editing",
		"keywords": ["case", "sensitive"],
		"aliases": ["@tui.case-sensitive", "@tui.case-sensitive-filled"],
		"filled": true,
		"filledName": "case-sensitive-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "case-upper",
		"tuiName": "@tui.case-upper",
		"category": "editing",
		"keywords": ["case", "upper"],
		"aliases": ["@tui.case-upper", "@tui.case-upper-filled"],
		"filled": true,
		"filledName": "case-upper-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cassette-tape",
		"tuiName": "@tui.cassette-tape",
		"category": "custom",
		"keywords": ["cassette", "tape"],
		"aliases": ["@tui.cassette-tape", "@tui.cassette-tape-filled"],
		"filled": true,
		"filledName": "cassette-tape-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cast",
		"tuiName": "@tui.cast",
		"category": "social",
		"keywords": ["cast"],
		"aliases": ["@tui.cast", "@tui.cast-filled"],
		"filled": true,
		"filledName": "cast-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "castle",
		"tuiName": "@tui.castle",
		"category": "social",
		"keywords": ["castle"],
		"aliases": ["@tui.castle", "@tui.castle-filled"],
		"filled": true,
		"filledName": "castle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cat",
		"tuiName": "@tui.cat",
		"category": "custom",
		"keywords": ["cat"],
		"aliases": ["@tui.cat", "@tui.cat-filled"],
		"filled": true,
		"filledName": "cat-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cctv",
		"tuiName": "@tui.cctv",
		"category": "custom",
		"keywords": ["cctv"],
		"aliases": ["@tui.cctv", "@tui.cctv-filled"],
		"filled": true,
		"filledName": "cctv-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cctv-off",
		"tuiName": "@tui.cctv-off",
		"category": "custom",
		"keywords": ["cctv", "off"],
		"aliases": ["@tui.cctv-off", "@tui.cctv-off-filled"],
		"filled": true,
		"filledName": "cctv-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-area",
		"tuiName": "@tui.chart-area",
		"category": "custom",
		"keywords": ["chart", "area"],
		"aliases": ["@tui.chart-area", "@tui.chart-area-filled"],
		"filled": true,
		"filledName": "chart-area-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-bar",
		"tuiName": "@tui.chart-bar",
		"category": "custom",
		"keywords": ["chart", "bar"],
		"aliases": ["@tui.chart-bar", "@tui.chart-bar-filled"],
		"filled": true,
		"filledName": "chart-bar-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-bar-big",
		"tuiName": "@tui.chart-bar-big",
		"category": "custom",
		"keywords": [
			"chart",
			"bar",
			"big"
		],
		"aliases": ["@tui.chart-bar-big", "@tui.chart-bar-big-filled"],
		"filled": true,
		"filledName": "chart-bar-big-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-bar-decreasing",
		"tuiName": "@tui.chart-bar-decreasing",
		"category": "custom",
		"keywords": [
			"chart",
			"bar",
			"decreasing"
		],
		"aliases": ["@tui.chart-bar-decreasing", "@tui.chart-bar-decreasing-filled"],
		"filled": true,
		"filledName": "chart-bar-decreasing-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-bar-increasing",
		"tuiName": "@tui.chart-bar-increasing",
		"category": "custom",
		"keywords": [
			"chart",
			"bar",
			"increasing"
		],
		"aliases": ["@tui.chart-bar-increasing", "@tui.chart-bar-increasing-filled"],
		"filled": true,
		"filledName": "chart-bar-increasing-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-bar-stacked",
		"tuiName": "@tui.chart-bar-stacked",
		"category": "custom",
		"keywords": [
			"chart",
			"bar",
			"stacked"
		],
		"aliases": ["@tui.chart-bar-stacked", "@tui.chart-bar-stacked-filled"],
		"filled": true,
		"filledName": "chart-bar-stacked-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-candlestick",
		"tuiName": "@tui.chart-candlestick",
		"category": "finance",
		"keywords": ["chart", "candlestick"],
		"aliases": ["@tui.chart-candlestick", "@tui.chart-candlestick-filled"],
		"filled": true,
		"filledName": "chart-candlestick-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-column",
		"tuiName": "@tui.chart-column",
		"category": "custom",
		"keywords": ["chart", "column"],
		"aliases": ["@tui.chart-column", "@tui.chart-column-filled"],
		"filled": true,
		"filledName": "chart-column-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-column-big",
		"tuiName": "@tui.chart-column-big",
		"category": "custom",
		"keywords": [
			"chart",
			"column",
			"big"
		],
		"aliases": ["@tui.chart-column-big", "@tui.chart-column-big-filled"],
		"filled": true,
		"filledName": "chart-column-big-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-column-decreasing",
		"tuiName": "@tui.chart-column-decreasing",
		"category": "custom",
		"keywords": [
			"chart",
			"column",
			"decreasing"
		],
		"aliases": ["@tui.chart-column-decreasing", "@tui.chart-column-decreasing-filled"],
		"filled": true,
		"filledName": "chart-column-decreasing-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-column-increasing",
		"tuiName": "@tui.chart-column-increasing",
		"category": "custom",
		"keywords": [
			"chart",
			"column",
			"increasing"
		],
		"aliases": ["@tui.chart-column-increasing", "@tui.chart-column-increasing-filled"],
		"filled": true,
		"filledName": "chart-column-increasing-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-column-stacked",
		"tuiName": "@tui.chart-column-stacked",
		"category": "custom",
		"keywords": [
			"chart",
			"column",
			"stacked"
		],
		"aliases": ["@tui.chart-column-stacked", "@tui.chart-column-stacked-filled"],
		"filled": true,
		"filledName": "chart-column-stacked-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-gantt",
		"tuiName": "@tui.chart-gantt",
		"category": "custom",
		"keywords": ["chart", "gantt"],
		"aliases": ["@tui.chart-gantt", "@tui.chart-gantt-filled"],
		"filled": true,
		"filledName": "chart-gantt-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-line",
		"tuiName": "@tui.chart-line",
		"category": "custom",
		"keywords": ["chart", "line"],
		"aliases": ["@tui.chart-line", "@tui.chart-line-filled"],
		"filled": true,
		"filledName": "chart-line-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-network",
		"tuiName": "@tui.chart-network",
		"category": "custom",
		"keywords": ["chart", "network"],
		"aliases": ["@tui.chart-network", "@tui.chart-network-filled"],
		"filled": true,
		"filledName": "chart-network-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-no-axes-column",
		"tuiName": "@tui.chart-no-axes-column",
		"category": "custom",
		"keywords": [
			"chart",
			"no",
			"axes",
			"column"
		],
		"aliases": ["@tui.chart-no-axes-column", "@tui.chart-no-axes-column-filled"],
		"filled": true,
		"filledName": "chart-no-axes-column-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-no-axes-column-decreasing",
		"tuiName": "@tui.chart-no-axes-column-decreasing",
		"category": "custom",
		"keywords": [
			"chart",
			"no",
			"axes",
			"column",
			"decreasing"
		],
		"aliases": ["@tui.chart-no-axes-column-decreasing", "@tui.chart-no-axes-column-decreasing-filled"],
		"filled": true,
		"filledName": "chart-no-axes-column-decreasing-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-no-axes-column-increasing",
		"tuiName": "@tui.chart-no-axes-column-increasing",
		"category": "custom",
		"keywords": [
			"chart",
			"no",
			"axes",
			"column",
			"increasing"
		],
		"aliases": ["@tui.chart-no-axes-column-increasing", "@tui.chart-no-axes-column-increasing-filled"],
		"filled": true,
		"filledName": "chart-no-axes-column-increasing-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-no-axes-combined",
		"tuiName": "@tui.chart-no-axes-combined",
		"category": "custom",
		"keywords": [
			"chart",
			"no",
			"axes",
			"combined"
		],
		"aliases": ["@tui.chart-no-axes-combined", "@tui.chart-no-axes-combined-filled"],
		"filled": true,
		"filledName": "chart-no-axes-combined-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-no-axes-gantt",
		"tuiName": "@tui.chart-no-axes-gantt",
		"category": "custom",
		"keywords": [
			"chart",
			"no",
			"axes",
			"gantt"
		],
		"aliases": ["@tui.chart-no-axes-gantt", "@tui.chart-no-axes-gantt-filled"],
		"filled": true,
		"filledName": "chart-no-axes-gantt-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-pie",
		"tuiName": "@tui.chart-pie",
		"category": "custom",
		"keywords": ["chart", "pie"],
		"aliases": ["@tui.chart-pie", "@tui.chart-pie-filled"],
		"filled": true,
		"filledName": "chart-pie-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-scatter",
		"tuiName": "@tui.chart-scatter",
		"category": "custom",
		"keywords": ["chart", "scatter"],
		"aliases": ["@tui.chart-scatter", "@tui.chart-scatter-filled"],
		"filled": true,
		"filledName": "chart-scatter-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chart-spline",
		"tuiName": "@tui.chart-spline",
		"category": "custom",
		"keywords": ["chart", "spline"],
		"aliases": ["@tui.chart-spline", "@tui.chart-spline-filled"],
		"filled": true,
		"filledName": "chart-spline-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "check",
		"tuiName": "@tui.check",
		"category": "status-feedback",
		"keywords": ["check"],
		"aliases": ["@tui.check", "@tui.check-filled"],
		"filled": true,
		"filledName": "check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "check-check",
		"tuiName": "@tui.check-check",
		"category": "status-feedback",
		"keywords": ["check", "check"],
		"aliases": ["@tui.check-check", "@tui.check-check-filled"],
		"filled": true,
		"filledName": "check-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "check-circle",
		"tuiName": "@tui.check-circle",
		"category": "status-feedback",
		"keywords": ["check", "circle"],
		"aliases": ["@tui.check-circle", "@tui.check-circle-filled"],
		"filled": true,
		"filledName": "check-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "check-circle-2",
		"tuiName": "@tui.check-circle-2",
		"category": "status-feedback",
		"keywords": [
			"check",
			"circle",
			"2"
		],
		"aliases": ["@tui.check-circle-2", "@tui.check-circle-2-filled"],
		"filled": true,
		"filledName": "check-circle-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "check-line",
		"tuiName": "@tui.check-line",
		"category": "status-feedback",
		"keywords": ["check", "line"],
		"aliases": ["@tui.check-line", "@tui.check-line-filled"],
		"filled": true,
		"filledName": "check-line-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "check-square",
		"tuiName": "@tui.check-square",
		"category": "status-feedback",
		"keywords": ["check", "square"],
		"aliases": ["@tui.check-square", "@tui.check-square-filled"],
		"filled": true,
		"filledName": "check-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "check-square-2",
		"tuiName": "@tui.check-square-2",
		"category": "status-feedback",
		"keywords": [
			"check",
			"square",
			"2"
		],
		"aliases": ["@tui.check-square-2", "@tui.check-square-2-filled"],
		"filled": true,
		"filledName": "check-square-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chef-hat",
		"tuiName": "@tui.chef-hat",
		"category": "custom",
		"keywords": ["chef", "hat"],
		"aliases": ["@tui.chef-hat", "@tui.chef-hat-filled"],
		"filled": true,
		"filledName": "chef-hat-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cherry",
		"tuiName": "@tui.cherry",
		"category": "custom",
		"keywords": ["cherry"],
		"aliases": ["@tui.cherry", "@tui.cherry-filled"],
		"filled": true,
		"filledName": "cherry-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chess-bishop",
		"tuiName": "@tui.chess-bishop",
		"category": "custom",
		"keywords": ["chess", "bishop"],
		"aliases": ["@tui.chess-bishop", "@tui.chess-bishop-filled"],
		"filled": true,
		"filledName": "chess-bishop-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chess-king",
		"tuiName": "@tui.chess-king",
		"category": "custom",
		"keywords": ["chess", "king"],
		"aliases": ["@tui.chess-king", "@tui.chess-king-filled"],
		"filled": true,
		"filledName": "chess-king-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chess-knight",
		"tuiName": "@tui.chess-knight",
		"category": "custom",
		"keywords": ["chess", "knight"],
		"aliases": ["@tui.chess-knight", "@tui.chess-knight-filled"],
		"filled": true,
		"filledName": "chess-knight-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chess-pawn",
		"tuiName": "@tui.chess-pawn",
		"category": "custom",
		"keywords": ["chess", "pawn"],
		"aliases": ["@tui.chess-pawn", "@tui.chess-pawn-filled"],
		"filled": true,
		"filledName": "chess-pawn-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chess-queen",
		"tuiName": "@tui.chess-queen",
		"category": "custom",
		"keywords": ["chess", "queen"],
		"aliases": ["@tui.chess-queen", "@tui.chess-queen-filled"],
		"filled": true,
		"filledName": "chess-queen-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chess-rook",
		"tuiName": "@tui.chess-rook",
		"category": "custom",
		"keywords": ["chess", "rook"],
		"aliases": ["@tui.chess-rook", "@tui.chess-rook-filled"],
		"filled": true,
		"filledName": "chess-rook-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chevron-down",
		"tuiName": "@tui.chevron-down",
		"category": "arrows",
		"keywords": ["chevron", "down"],
		"aliases": ["@tui.chevron-down", "@tui.chevron-down-filled"],
		"filled": true,
		"filledName": "chevron-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chevron-down-circle",
		"tuiName": "@tui.chevron-down-circle",
		"category": "arrows",
		"keywords": [
			"chevron",
			"down",
			"circle"
		],
		"aliases": ["@tui.chevron-down-circle", "@tui.chevron-down-circle-filled"],
		"filled": true,
		"filledName": "chevron-down-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chevron-down-square",
		"tuiName": "@tui.chevron-down-square",
		"category": "arrows",
		"keywords": [
			"chevron",
			"down",
			"square"
		],
		"aliases": ["@tui.chevron-down-square", "@tui.chevron-down-square-filled"],
		"filled": true,
		"filledName": "chevron-down-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chevron-first",
		"tuiName": "@tui.chevron-first",
		"category": "arrows",
		"keywords": ["chevron", "first"],
		"aliases": ["@tui.chevron-first", "@tui.chevron-first-filled"],
		"filled": true,
		"filledName": "chevron-first-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chevron-last",
		"tuiName": "@tui.chevron-last",
		"category": "arrows",
		"keywords": ["chevron", "last"],
		"aliases": ["@tui.chevron-last", "@tui.chevron-last-filled"],
		"filled": true,
		"filledName": "chevron-last-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chevron-left",
		"tuiName": "@tui.chevron-left",
		"category": "arrows",
		"keywords": ["chevron", "left"],
		"aliases": ["@tui.chevron-left", "@tui.chevron-left-filled"],
		"filled": true,
		"filledName": "chevron-left-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "chevron-left-circle",
		"tuiName": "@tui.chevron-left-circle",
		"category": "arrows",
		"keywords": [
			"chevron",
			"left",
			"circle"
		],
		"aliases": ["@tui.chevron-left-circle", "@tui.chevron-left-circle-filled"],
		"filled": true,
		"filledName": "chevron-left-circle-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "chevron-left-square",
		"tuiName": "@tui.chevron-left-square",
		"category": "arrows",
		"keywords": [
			"chevron",
			"left",
			"square"
		],
		"aliases": ["@tui.chevron-left-square", "@tui.chevron-left-square-filled"],
		"filled": true,
		"filledName": "chevron-left-square-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "chevron-right",
		"tuiName": "@tui.chevron-right",
		"category": "arrows",
		"keywords": ["chevron", "right"],
		"aliases": ["@tui.chevron-right", "@tui.chevron-right-filled"],
		"filled": true,
		"filledName": "chevron-right-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "chevron-right-circle",
		"tuiName": "@tui.chevron-right-circle",
		"category": "arrows",
		"keywords": [
			"chevron",
			"right",
			"circle"
		],
		"aliases": ["@tui.chevron-right-circle", "@tui.chevron-right-circle-filled"],
		"filled": true,
		"filledName": "chevron-right-circle-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "chevron-right-square",
		"tuiName": "@tui.chevron-right-square",
		"category": "arrows",
		"keywords": [
			"chevron",
			"right",
			"square"
		],
		"aliases": ["@tui.chevron-right-square", "@tui.chevron-right-square-filled"],
		"filled": true,
		"filledName": "chevron-right-square-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "chevron-up",
		"tuiName": "@tui.chevron-up",
		"category": "arrows",
		"keywords": ["chevron", "up"],
		"aliases": ["@tui.chevron-up", "@tui.chevron-up-filled"],
		"filled": true,
		"filledName": "chevron-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chevron-up-circle",
		"tuiName": "@tui.chevron-up-circle",
		"category": "arrows",
		"keywords": [
			"chevron",
			"up",
			"circle"
		],
		"aliases": ["@tui.chevron-up-circle", "@tui.chevron-up-circle-filled"],
		"filled": true,
		"filledName": "chevron-up-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chevron-up-square",
		"tuiName": "@tui.chevron-up-square",
		"category": "arrows",
		"keywords": [
			"chevron",
			"up",
			"square"
		],
		"aliases": ["@tui.chevron-up-square", "@tui.chevron-up-square-filled"],
		"filled": true,
		"filledName": "chevron-up-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chevrons-down",
		"tuiName": "@tui.chevrons-down",
		"category": "arrows",
		"keywords": ["chevrons", "down"],
		"aliases": ["@tui.chevrons-down", "@tui.chevrons-down-filled"],
		"filled": true,
		"filledName": "chevrons-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chevrons-down-up",
		"tuiName": "@tui.chevrons-down-up",
		"category": "arrows",
		"keywords": [
			"chevrons",
			"down",
			"up"
		],
		"aliases": ["@tui.chevrons-down-up", "@tui.chevrons-down-up-filled"],
		"filled": true,
		"filledName": "chevrons-down-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chevrons-left",
		"tuiName": "@tui.chevrons-left",
		"category": "arrows",
		"keywords": ["chevrons", "left"],
		"aliases": ["@tui.chevrons-left", "@tui.chevrons-left-filled"],
		"filled": true,
		"filledName": "chevrons-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chevrons-left-right",
		"tuiName": "@tui.chevrons-left-right",
		"category": "arrows",
		"keywords": [
			"chevrons",
			"left",
			"right"
		],
		"aliases": ["@tui.chevrons-left-right", "@tui.chevrons-left-right-filled"],
		"filled": true,
		"filledName": "chevrons-left-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chevrons-left-right-ellipsis",
		"tuiName": "@tui.chevrons-left-right-ellipsis",
		"category": "arrows",
		"keywords": [
			"chevrons",
			"left",
			"right",
			"ellipsis"
		],
		"aliases": ["@tui.chevrons-left-right-ellipsis", "@tui.chevrons-left-right-ellipsis-filled"],
		"filled": true,
		"filledName": "chevrons-left-right-ellipsis-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chevrons-right",
		"tuiName": "@tui.chevrons-right",
		"category": "arrows",
		"keywords": ["chevrons", "right"],
		"aliases": ["@tui.chevrons-right", "@tui.chevrons-right-filled"],
		"filled": true,
		"filledName": "chevrons-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chevrons-right-left",
		"tuiName": "@tui.chevrons-right-left",
		"category": "arrows",
		"keywords": [
			"chevrons",
			"right",
			"left"
		],
		"aliases": ["@tui.chevrons-right-left", "@tui.chevrons-right-left-filled"],
		"filled": true,
		"filledName": "chevrons-right-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chevrons-up",
		"tuiName": "@tui.chevrons-up",
		"category": "arrows",
		"keywords": ["chevrons", "up"],
		"aliases": ["@tui.chevrons-up", "@tui.chevrons-up-filled"],
		"filled": true,
		"filledName": "chevrons-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "chevrons-up-down",
		"tuiName": "@tui.chevrons-up-down",
		"category": "arrows",
		"keywords": [
			"chevrons",
			"up",
			"down"
		],
		"aliases": ["@tui.chevrons-up-down", "@tui.chevrons-up-down-filled"],
		"filled": true,
		"filledName": "chevrons-up-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "church",
		"tuiName": "@tui.church",
		"category": "custom",
		"keywords": ["church"],
		"aliases": ["@tui.church", "@tui.church-filled"],
		"filled": true,
		"filledName": "church-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cigarette",
		"tuiName": "@tui.cigarette",
		"category": "custom",
		"keywords": ["cigarette"],
		"aliases": ["@tui.cigarette", "@tui.cigarette-filled"],
		"filled": true,
		"filledName": "cigarette-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cigarette-off",
		"tuiName": "@tui.cigarette-off",
		"category": "custom",
		"keywords": ["cigarette", "off"],
		"aliases": ["@tui.cigarette-off", "@tui.cigarette-off-filled"],
		"filled": true,
		"filledName": "cigarette-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle",
		"tuiName": "@tui.circle",
		"category": "layout",
		"keywords": ["circle"],
		"aliases": ["@tui.circle", "@tui.circle-filled"],
		"filled": true,
		"filledName": "circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-alert",
		"tuiName": "@tui.circle-alert",
		"category": "status-feedback",
		"keywords": ["circle", "alert"],
		"aliases": ["@tui.circle-alert", "@tui.circle-alert-filled"],
		"filled": true,
		"filledName": "circle-alert-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-arrow-down",
		"tuiName": "@tui.circle-arrow-down",
		"category": "layout",
		"keywords": [
			"circle",
			"arrow",
			"down"
		],
		"aliases": ["@tui.circle-arrow-down", "@tui.circle-arrow-down-filled"],
		"filled": true,
		"filledName": "circle-arrow-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-arrow-left",
		"tuiName": "@tui.circle-arrow-left",
		"category": "layout",
		"keywords": [
			"circle",
			"arrow",
			"left"
		],
		"aliases": ["@tui.circle-arrow-left", "@tui.circle-arrow-left-filled"],
		"filled": true,
		"filledName": "circle-arrow-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-arrow-out-down-left",
		"tuiName": "@tui.circle-arrow-out-down-left",
		"category": "layout",
		"keywords": [
			"circle",
			"arrow",
			"out",
			"down",
			"left"
		],
		"aliases": ["@tui.circle-arrow-out-down-left", "@tui.circle-arrow-out-down-left-filled"],
		"filled": true,
		"filledName": "circle-arrow-out-down-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-arrow-out-down-right",
		"tuiName": "@tui.circle-arrow-out-down-right",
		"category": "layout",
		"keywords": [
			"circle",
			"arrow",
			"out",
			"down",
			"right"
		],
		"aliases": ["@tui.circle-arrow-out-down-right", "@tui.circle-arrow-out-down-right-filled"],
		"filled": true,
		"filledName": "circle-arrow-out-down-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-arrow-out-up-left",
		"tuiName": "@tui.circle-arrow-out-up-left",
		"category": "layout",
		"keywords": [
			"circle",
			"arrow",
			"out",
			"up",
			"left"
		],
		"aliases": ["@tui.circle-arrow-out-up-left", "@tui.circle-arrow-out-up-left-filled"],
		"filled": true,
		"filledName": "circle-arrow-out-up-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-arrow-out-up-right",
		"tuiName": "@tui.circle-arrow-out-up-right",
		"category": "layout",
		"keywords": [
			"circle",
			"arrow",
			"out",
			"up",
			"right"
		],
		"aliases": ["@tui.circle-arrow-out-up-right", "@tui.circle-arrow-out-up-right-filled"],
		"filled": true,
		"filledName": "circle-arrow-out-up-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-arrow-right",
		"tuiName": "@tui.circle-arrow-right",
		"category": "layout",
		"keywords": [
			"circle",
			"arrow",
			"right"
		],
		"aliases": ["@tui.circle-arrow-right", "@tui.circle-arrow-right-filled"],
		"filled": true,
		"filledName": "circle-arrow-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-arrow-up",
		"tuiName": "@tui.circle-arrow-up",
		"category": "layout",
		"keywords": [
			"circle",
			"arrow",
			"up"
		],
		"aliases": ["@tui.circle-arrow-up", "@tui.circle-arrow-up-filled"],
		"filled": true,
		"filledName": "circle-arrow-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-check",
		"tuiName": "@tui.circle-check",
		"category": "status-feedback",
		"keywords": ["circle", "check"],
		"aliases": ["@tui.circle-check", "@tui.circle-check-filled"],
		"filled": true,
		"filledName": "circle-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-check-big",
		"tuiName": "@tui.circle-check-big",
		"category": "status-feedback",
		"keywords": [
			"circle",
			"check",
			"big"
		],
		"aliases": ["@tui.circle-check-big", "@tui.circle-check-big-filled"],
		"filled": true,
		"filledName": "circle-check-big-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-chevron-down",
		"tuiName": "@tui.circle-chevron-down",
		"category": "layout",
		"keywords": [
			"circle",
			"chevron",
			"down"
		],
		"aliases": ["@tui.circle-chevron-down", "@tui.circle-chevron-down-filled"],
		"filled": true,
		"filledName": "circle-chevron-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-chevron-left",
		"tuiName": "@tui.circle-chevron-left",
		"category": "layout",
		"keywords": [
			"circle",
			"chevron",
			"left"
		],
		"aliases": ["@tui.circle-chevron-left", "@tui.circle-chevron-left-filled"],
		"filled": true,
		"filledName": "circle-chevron-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-chevron-right",
		"tuiName": "@tui.circle-chevron-right",
		"category": "layout",
		"keywords": [
			"circle",
			"chevron",
			"right"
		],
		"aliases": ["@tui.circle-chevron-right", "@tui.circle-chevron-right-filled"],
		"filled": true,
		"filledName": "circle-chevron-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-chevron-up",
		"tuiName": "@tui.circle-chevron-up",
		"category": "layout",
		"keywords": [
			"circle",
			"chevron",
			"up"
		],
		"aliases": ["@tui.circle-chevron-up", "@tui.circle-chevron-up-filled"],
		"filled": true,
		"filledName": "circle-chevron-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-dashed",
		"tuiName": "@tui.circle-dashed",
		"category": "layout",
		"keywords": ["circle", "dashed"],
		"aliases": ["@tui.circle-dashed", "@tui.circle-dashed-filled"],
		"filled": true,
		"filledName": "circle-dashed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-dashed-check",
		"tuiName": "@tui.circle-dashed-check",
		"category": "layout",
		"keywords": [
			"circle",
			"dashed",
			"check"
		],
		"aliases": ["@tui.circle-dashed-check", "@tui.circle-dashed-check-filled"],
		"filled": true,
		"filledName": "circle-dashed-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-divide",
		"tuiName": "@tui.circle-divide",
		"category": "layout",
		"keywords": ["circle", "divide"],
		"aliases": ["@tui.circle-divide", "@tui.circle-divide-filled"],
		"filled": true,
		"filledName": "circle-divide-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-dollar-sign",
		"tuiName": "@tui.circle-dollar-sign",
		"category": "finance",
		"keywords": [
			"circle",
			"dollar",
			"sign"
		],
		"aliases": ["@tui.circle-dollar-sign", "@tui.circle-dollar-sign-filled"],
		"filled": true,
		"filledName": "circle-dollar-sign-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-dot",
		"tuiName": "@tui.circle-dot",
		"category": "layout",
		"keywords": ["circle", "dot"],
		"aliases": ["@tui.circle-dot", "@tui.circle-dot-filled"],
		"filled": true,
		"filledName": "circle-dot-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-dot-dashed",
		"tuiName": "@tui.circle-dot-dashed",
		"category": "layout",
		"keywords": [
			"circle",
			"dot",
			"dashed"
		],
		"aliases": ["@tui.circle-dot-dashed", "@tui.circle-dot-dashed-filled"],
		"filled": true,
		"filledName": "circle-dot-dashed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-ellipsis",
		"tuiName": "@tui.circle-ellipsis",
		"category": "layout",
		"keywords": ["circle", "ellipsis"],
		"aliases": ["@tui.circle-ellipsis", "@tui.circle-ellipsis-filled"],
		"filled": true,
		"filledName": "circle-ellipsis-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-equal",
		"tuiName": "@tui.circle-equal",
		"category": "layout",
		"keywords": ["circle", "equal"],
		"aliases": ["@tui.circle-equal", "@tui.circle-equal-filled"],
		"filled": true,
		"filledName": "circle-equal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-euro",
		"tuiName": "@tui.circle-euro",
		"category": "layout",
		"keywords": ["circle", "euro"],
		"aliases": ["@tui.circle-euro", "@tui.circle-euro-filled"],
		"filled": true,
		"filledName": "circle-euro-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-fading-arrow-up",
		"tuiName": "@tui.circle-fading-arrow-up",
		"category": "layout",
		"keywords": [
			"circle",
			"fading",
			"arrow",
			"up"
		],
		"aliases": ["@tui.circle-fading-arrow-up", "@tui.circle-fading-arrow-up-filled"],
		"filled": true,
		"filledName": "circle-fading-arrow-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-fading-play",
		"tuiName": "@tui.circle-fading-play",
		"category": "layout",
		"keywords": [
			"circle",
			"fading",
			"play"
		],
		"aliases": ["@tui.circle-fading-play", "@tui.circle-fading-play-filled"],
		"filled": true,
		"filledName": "circle-fading-play-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-fading-plus",
		"tuiName": "@tui.circle-fading-plus",
		"category": "layout",
		"keywords": [
			"circle",
			"fading",
			"plus"
		],
		"aliases": ["@tui.circle-fading-plus", "@tui.circle-fading-plus-filled"],
		"filled": true,
		"filledName": "circle-fading-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-gauge",
		"tuiName": "@tui.circle-gauge",
		"category": "layout",
		"keywords": ["circle", "gauge"],
		"aliases": ["@tui.circle-gauge", "@tui.circle-gauge-filled"],
		"filled": true,
		"filledName": "circle-gauge-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-help",
		"tuiName": "@tui.circle-help",
		"category": "status-feedback",
		"keywords": ["circle", "help"],
		"aliases": ["@tui.circle-help", "@tui.circle-help-filled"],
		"filled": true,
		"filledName": "circle-help-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-minus",
		"tuiName": "@tui.circle-minus",
		"category": "layout",
		"keywords": ["circle", "minus"],
		"aliases": ["@tui.circle-minus", "@tui.circle-minus-filled"],
		"filled": true,
		"filledName": "circle-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-off",
		"tuiName": "@tui.circle-off",
		"category": "layout",
		"keywords": ["circle", "off"],
		"aliases": ["@tui.circle-off", "@tui.circle-off-filled"],
		"filled": true,
		"filledName": "circle-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-parking",
		"tuiName": "@tui.circle-parking",
		"category": "layout",
		"keywords": ["circle", "parking"],
		"aliases": ["@tui.circle-parking", "@tui.circle-parking-filled"],
		"filled": true,
		"filledName": "circle-parking-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-parking-off",
		"tuiName": "@tui.circle-parking-off",
		"category": "layout",
		"keywords": [
			"circle",
			"parking",
			"off"
		],
		"aliases": ["@tui.circle-parking-off", "@tui.circle-parking-off-filled"],
		"filled": true,
		"filledName": "circle-parking-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-pause",
		"tuiName": "@tui.circle-pause",
		"category": "layout",
		"keywords": ["circle", "pause"],
		"aliases": ["@tui.circle-pause", "@tui.circle-pause-filled"],
		"filled": true,
		"filledName": "circle-pause-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-percent",
		"tuiName": "@tui.circle-percent",
		"category": "layout",
		"keywords": ["circle", "percent"],
		"aliases": ["@tui.circle-percent", "@tui.circle-percent-filled"],
		"filled": true,
		"filledName": "circle-percent-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-pile",
		"tuiName": "@tui.circle-pile",
		"category": "layout",
		"keywords": ["circle", "pile"],
		"aliases": ["@tui.circle-pile", "@tui.circle-pile-filled"],
		"filled": true,
		"filledName": "circle-pile-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-play",
		"tuiName": "@tui.circle-play",
		"category": "layout",
		"keywords": ["circle", "play"],
		"aliases": ["@tui.circle-play", "@tui.circle-play-filled"],
		"filled": true,
		"filledName": "circle-play-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-plus",
		"tuiName": "@tui.circle-plus",
		"category": "layout",
		"keywords": ["circle", "plus"],
		"aliases": ["@tui.circle-plus", "@tui.circle-plus-filled"],
		"filled": true,
		"filledName": "circle-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-pound-sterling",
		"tuiName": "@tui.circle-pound-sterling",
		"category": "layout",
		"keywords": [
			"circle",
			"pound",
			"sterling"
		],
		"aliases": ["@tui.circle-pound-sterling", "@tui.circle-pound-sterling-filled"],
		"filled": true,
		"filledName": "circle-pound-sterling-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-power",
		"tuiName": "@tui.circle-power",
		"category": "layout",
		"keywords": ["circle", "power"],
		"aliases": ["@tui.circle-power", "@tui.circle-power-filled"],
		"filled": true,
		"filledName": "circle-power-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-question-mark",
		"tuiName": "@tui.circle-question-mark",
		"category": "layout",
		"keywords": [
			"circle",
			"question",
			"mark"
		],
		"aliases": ["@tui.circle-question-mark", "@tui.circle-question-mark-filled"],
		"filled": true,
		"filledName": "circle-question-mark-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-slash",
		"tuiName": "@tui.circle-slash",
		"category": "layout",
		"keywords": ["circle", "slash"],
		"aliases": ["@tui.circle-slash", "@tui.circle-slash-filled"],
		"filled": true,
		"filledName": "circle-slash-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-slash-2",
		"tuiName": "@tui.circle-slash-2",
		"category": "layout",
		"keywords": [
			"circle",
			"slash",
			"2"
		],
		"aliases": ["@tui.circle-slash-2", "@tui.circle-slash-2-filled"],
		"filled": true,
		"filledName": "circle-slash-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-slashed",
		"tuiName": "@tui.circle-slashed",
		"category": "layout",
		"keywords": ["circle", "slashed"],
		"aliases": ["@tui.circle-slashed", "@tui.circle-slashed-filled"],
		"filled": true,
		"filledName": "circle-slashed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-small",
		"tuiName": "@tui.circle-small",
		"category": "layout",
		"keywords": ["circle", "small"],
		"aliases": ["@tui.circle-small", "@tui.circle-small-filled"],
		"filled": true,
		"filledName": "circle-small-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-star",
		"tuiName": "@tui.circle-star",
		"category": "layout",
		"keywords": ["circle", "star"],
		"aliases": ["@tui.circle-star", "@tui.circle-star-filled"],
		"filled": true,
		"filledName": "circle-star-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-stop",
		"tuiName": "@tui.circle-stop",
		"category": "layout",
		"keywords": ["circle", "stop"],
		"aliases": ["@tui.circle-stop", "@tui.circle-stop-filled"],
		"filled": true,
		"filledName": "circle-stop-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-user",
		"tuiName": "@tui.circle-user",
		"category": "users",
		"keywords": ["circle", "user"],
		"aliases": ["@tui.circle-user", "@tui.circle-user-filled"],
		"filled": true,
		"filledName": "circle-user-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-user-round",
		"tuiName": "@tui.circle-user-round",
		"category": "users",
		"keywords": [
			"circle",
			"user",
			"round"
		],
		"aliases": ["@tui.circle-user-round", "@tui.circle-user-round-filled"],
		"filled": true,
		"filledName": "circle-user-round-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circle-x",
		"tuiName": "@tui.circle-x",
		"category": "status-feedback",
		"keywords": ["circle", "x"],
		"aliases": ["@tui.circle-x", "@tui.circle-x-filled"],
		"filled": true,
		"filledName": "circle-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "circuit-board",
		"tuiName": "@tui.circuit-board",
		"category": "custom",
		"keywords": ["circuit", "board"],
		"aliases": ["@tui.circuit-board", "@tui.circuit-board-filled"],
		"filled": true,
		"filledName": "circuit-board-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cirrus",
		"tuiName": "@tui.cirrus",
		"category": "custom",
		"keywords": ["cirrus"],
		"aliases": ["@tui.cirrus"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "citrus",
		"tuiName": "@tui.citrus",
		"category": "custom",
		"keywords": ["citrus"],
		"aliases": ["@tui.citrus", "@tui.citrus-filled"],
		"filled": true,
		"filledName": "citrus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clapperboard",
		"tuiName": "@tui.clapperboard",
		"category": "media",
		"keywords": ["clapperboard"],
		"aliases": ["@tui.clapperboard", "@tui.clapperboard-filled"],
		"filled": true,
		"filledName": "clapperboard-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clef-alto",
		"tuiName": "@tui.clef-alto",
		"category": "custom",
		"keywords": ["clef", "alto"],
		"aliases": ["@tui.clef-alto", "@tui.clef-alto-filled"],
		"filled": true,
		"filledName": "clef-alto-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clef-bass",
		"tuiName": "@tui.clef-bass",
		"category": "custom",
		"keywords": ["clef", "bass"],
		"aliases": ["@tui.clef-bass", "@tui.clef-bass-filled"],
		"filled": true,
		"filledName": "clef-bass-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clef-treble",
		"tuiName": "@tui.clef-treble",
		"category": "custom",
		"keywords": ["clef", "treble"],
		"aliases": ["@tui.clef-treble", "@tui.clef-treble-filled"],
		"filled": true,
		"filledName": "clef-treble-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clipboard",
		"tuiName": "@tui.clipboard",
		"category": "files",
		"keywords": ["clipboard"],
		"aliases": ["@tui.clipboard", "@tui.clipboard-filled"],
		"filled": true,
		"filledName": "clipboard-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clipboard-check",
		"tuiName": "@tui.clipboard-check",
		"category": "files",
		"keywords": ["clipboard", "check"],
		"aliases": ["@tui.clipboard-check", "@tui.clipboard-check-filled"],
		"filled": true,
		"filledName": "clipboard-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clipboard-clock",
		"tuiName": "@tui.clipboard-clock",
		"category": "files",
		"keywords": ["clipboard", "clock"],
		"aliases": ["@tui.clipboard-clock", "@tui.clipboard-clock-filled"],
		"filled": true,
		"filledName": "clipboard-clock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clipboard-copy",
		"tuiName": "@tui.clipboard-copy",
		"category": "files",
		"keywords": ["clipboard", "copy"],
		"aliases": ["@tui.clipboard-copy", "@tui.clipboard-copy-filled"],
		"filled": true,
		"filledName": "clipboard-copy-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clipboard-edit",
		"tuiName": "@tui.clipboard-edit",
		"category": "files",
		"keywords": ["clipboard", "edit"],
		"aliases": ["@tui.clipboard-edit", "@tui.clipboard-edit-filled"],
		"filled": true,
		"filledName": "clipboard-edit-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clipboard-list",
		"tuiName": "@tui.clipboard-list",
		"category": "files",
		"keywords": ["clipboard", "list"],
		"aliases": ["@tui.clipboard-list", "@tui.clipboard-list-filled"],
		"filled": true,
		"filledName": "clipboard-list-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clipboard-minus",
		"tuiName": "@tui.clipboard-minus",
		"category": "files",
		"keywords": ["clipboard", "minus"],
		"aliases": ["@tui.clipboard-minus", "@tui.clipboard-minus-filled"],
		"filled": true,
		"filledName": "clipboard-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clipboard-paste",
		"tuiName": "@tui.clipboard-paste",
		"category": "files",
		"keywords": ["clipboard", "paste"],
		"aliases": ["@tui.clipboard-paste", "@tui.clipboard-paste-filled"],
		"filled": true,
		"filledName": "clipboard-paste-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clipboard-pen",
		"tuiName": "@tui.clipboard-pen",
		"category": "files",
		"keywords": ["clipboard", "pen"],
		"aliases": ["@tui.clipboard-pen", "@tui.clipboard-pen-filled"],
		"filled": true,
		"filledName": "clipboard-pen-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clipboard-pen-line",
		"tuiName": "@tui.clipboard-pen-line",
		"category": "files",
		"keywords": [
			"clipboard",
			"pen",
			"line"
		],
		"aliases": ["@tui.clipboard-pen-line", "@tui.clipboard-pen-line-filled"],
		"filled": true,
		"filledName": "clipboard-pen-line-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clipboard-plus",
		"tuiName": "@tui.clipboard-plus",
		"category": "files",
		"keywords": ["clipboard", "plus"],
		"aliases": ["@tui.clipboard-plus", "@tui.clipboard-plus-filled"],
		"filled": true,
		"filledName": "clipboard-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clipboard-signature",
		"tuiName": "@tui.clipboard-signature",
		"category": "files",
		"keywords": ["clipboard", "signature"],
		"aliases": ["@tui.clipboard-signature", "@tui.clipboard-signature-filled"],
		"filled": true,
		"filledName": "clipboard-signature-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clipboard-type",
		"tuiName": "@tui.clipboard-type",
		"category": "files",
		"keywords": ["clipboard", "type"],
		"aliases": ["@tui.clipboard-type", "@tui.clipboard-type-filled"],
		"filled": true,
		"filledName": "clipboard-type-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clipboard-x",
		"tuiName": "@tui.clipboard-x",
		"category": "files",
		"keywords": ["clipboard", "x"],
		"aliases": ["@tui.clipboard-x", "@tui.clipboard-x-filled"],
		"filled": true,
		"filledName": "clipboard-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clock",
		"tuiName": "@tui.clock",
		"category": "calendar-time",
		"keywords": ["clock"],
		"aliases": ["@tui.clock", "@tui.clock-filled"],
		"filled": true,
		"filledName": "clock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clock-1",
		"tuiName": "@tui.clock-1",
		"category": "calendar-time",
		"keywords": ["clock", "1"],
		"aliases": ["@tui.clock-1", "@tui.clock-1-filled"],
		"filled": true,
		"filledName": "clock-1-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clock-10",
		"tuiName": "@tui.clock-10",
		"category": "calendar-time",
		"keywords": ["clock", "10"],
		"aliases": ["@tui.clock-10", "@tui.clock-10-filled"],
		"filled": true,
		"filledName": "clock-10-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clock-11",
		"tuiName": "@tui.clock-11",
		"category": "calendar-time",
		"keywords": ["clock", "11"],
		"aliases": ["@tui.clock-11", "@tui.clock-11-filled"],
		"filled": true,
		"filledName": "clock-11-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clock-12",
		"tuiName": "@tui.clock-12",
		"category": "calendar-time",
		"keywords": ["clock", "12"],
		"aliases": ["@tui.clock-12", "@tui.clock-12-filled"],
		"filled": true,
		"filledName": "clock-12-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clock-2",
		"tuiName": "@tui.clock-2",
		"category": "calendar-time",
		"keywords": ["clock", "2"],
		"aliases": ["@tui.clock-2", "@tui.clock-2-filled"],
		"filled": true,
		"filledName": "clock-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clock-3",
		"tuiName": "@tui.clock-3",
		"category": "calendar-time",
		"keywords": ["clock", "3"],
		"aliases": ["@tui.clock-3", "@tui.clock-3-filled"],
		"filled": true,
		"filledName": "clock-3-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clock-4",
		"tuiName": "@tui.clock-4",
		"category": "calendar-time",
		"keywords": ["clock", "4"],
		"aliases": ["@tui.clock-4", "@tui.clock-4-filled"],
		"filled": true,
		"filledName": "clock-4-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clock-5",
		"tuiName": "@tui.clock-5",
		"category": "calendar-time",
		"keywords": ["clock", "5"],
		"aliases": ["@tui.clock-5", "@tui.clock-5-filled"],
		"filled": true,
		"filledName": "clock-5-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clock-6",
		"tuiName": "@tui.clock-6",
		"category": "calendar-time",
		"keywords": ["clock", "6"],
		"aliases": ["@tui.clock-6", "@tui.clock-6-filled"],
		"filled": true,
		"filledName": "clock-6-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clock-7",
		"tuiName": "@tui.clock-7",
		"category": "calendar-time",
		"keywords": ["clock", "7"],
		"aliases": ["@tui.clock-7", "@tui.clock-7-filled"],
		"filled": true,
		"filledName": "clock-7-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clock-8",
		"tuiName": "@tui.clock-8",
		"category": "calendar-time",
		"keywords": ["clock", "8"],
		"aliases": ["@tui.clock-8", "@tui.clock-8-filled"],
		"filled": true,
		"filledName": "clock-8-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clock-9",
		"tuiName": "@tui.clock-9",
		"category": "calendar-time",
		"keywords": ["clock", "9"],
		"aliases": ["@tui.clock-9", "@tui.clock-9-filled"],
		"filled": true,
		"filledName": "clock-9-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clock-alert",
		"tuiName": "@tui.clock-alert",
		"category": "calendar-time",
		"keywords": ["clock", "alert"],
		"aliases": ["@tui.clock-alert", "@tui.clock-alert-filled"],
		"filled": true,
		"filledName": "clock-alert-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clock-arrow-down",
		"tuiName": "@tui.clock-arrow-down",
		"category": "calendar-time",
		"keywords": [
			"clock",
			"arrow",
			"down"
		],
		"aliases": ["@tui.clock-arrow-down", "@tui.clock-arrow-down-filled"],
		"filled": true,
		"filledName": "clock-arrow-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clock-arrow-left",
		"tuiName": "@tui.clock-arrow-left",
		"category": "calendar-time",
		"keywords": [
			"clock",
			"arrow",
			"left"
		],
		"aliases": ["@tui.clock-arrow-left", "@tui.clock-arrow-left-filled"],
		"filled": true,
		"filledName": "clock-arrow-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clock-arrow-right",
		"tuiName": "@tui.clock-arrow-right",
		"category": "calendar-time",
		"keywords": [
			"clock",
			"arrow",
			"right"
		],
		"aliases": ["@tui.clock-arrow-right", "@tui.clock-arrow-right-filled"],
		"filled": true,
		"filledName": "clock-arrow-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clock-arrow-up",
		"tuiName": "@tui.clock-arrow-up",
		"category": "calendar-time",
		"keywords": [
			"clock",
			"arrow",
			"up"
		],
		"aliases": ["@tui.clock-arrow-up", "@tui.clock-arrow-up-filled"],
		"filled": true,
		"filledName": "clock-arrow-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clock-check",
		"tuiName": "@tui.clock-check",
		"category": "calendar-time",
		"keywords": ["clock", "check"],
		"aliases": ["@tui.clock-check", "@tui.clock-check-filled"],
		"filled": true,
		"filledName": "clock-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clock-fading",
		"tuiName": "@tui.clock-fading",
		"category": "calendar-time",
		"keywords": ["clock", "fading"],
		"aliases": ["@tui.clock-fading", "@tui.clock-fading-filled"],
		"filled": true,
		"filledName": "clock-fading-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clock-plus",
		"tuiName": "@tui.clock-plus",
		"category": "calendar-time",
		"keywords": ["clock", "plus"],
		"aliases": ["@tui.clock-plus", "@tui.clock-plus-filled"],
		"filled": true,
		"filledName": "clock-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "closed-caption",
		"tuiName": "@tui.closed-caption",
		"category": "actions",
		"keywords": ["closed", "caption"],
		"aliases": ["@tui.closed-caption", "@tui.closed-caption-filled"],
		"filled": true,
		"filledName": "closed-caption-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cloud",
		"tuiName": "@tui.cloud",
		"category": "custom",
		"keywords": ["cloud"],
		"aliases": ["@tui.cloud", "@tui.cloud-filled"],
		"filled": true,
		"filledName": "cloud-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cloud-alert",
		"tuiName": "@tui.cloud-alert",
		"category": "custom",
		"keywords": ["cloud", "alert"],
		"aliases": ["@tui.cloud-alert", "@tui.cloud-alert-filled"],
		"filled": true,
		"filledName": "cloud-alert-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cloud-backup",
		"tuiName": "@tui.cloud-backup",
		"category": "custom",
		"keywords": ["cloud", "backup"],
		"aliases": ["@tui.cloud-backup", "@tui.cloud-backup-filled"],
		"filled": true,
		"filledName": "cloud-backup-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cloud-check",
		"tuiName": "@tui.cloud-check",
		"category": "custom",
		"keywords": ["cloud", "check"],
		"aliases": ["@tui.cloud-check", "@tui.cloud-check-filled"],
		"filled": true,
		"filledName": "cloud-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cloud-cog",
		"tuiName": "@tui.cloud-cog",
		"category": "custom",
		"keywords": ["cloud", "cog"],
		"aliases": ["@tui.cloud-cog", "@tui.cloud-cog-filled"],
		"filled": true,
		"filledName": "cloud-cog-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cloud-download",
		"tuiName": "@tui.cloud-download",
		"category": "custom",
		"keywords": ["cloud", "download"],
		"aliases": ["@tui.cloud-download", "@tui.cloud-download-filled"],
		"filled": true,
		"filledName": "cloud-download-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cloud-drizzle",
		"tuiName": "@tui.cloud-drizzle",
		"category": "custom",
		"keywords": ["cloud", "drizzle"],
		"aliases": ["@tui.cloud-drizzle", "@tui.cloud-drizzle-filled"],
		"filled": true,
		"filledName": "cloud-drizzle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cloud-fog",
		"tuiName": "@tui.cloud-fog",
		"category": "custom",
		"keywords": ["cloud", "fog"],
		"aliases": ["@tui.cloud-fog", "@tui.cloud-fog-filled"],
		"filled": true,
		"filledName": "cloud-fog-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cloud-hail",
		"tuiName": "@tui.cloud-hail",
		"category": "custom",
		"keywords": ["cloud", "hail"],
		"aliases": ["@tui.cloud-hail", "@tui.cloud-hail-filled"],
		"filled": true,
		"filledName": "cloud-hail-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cloud-lightning",
		"tuiName": "@tui.cloud-lightning",
		"category": "custom",
		"keywords": ["cloud", "lightning"],
		"aliases": ["@tui.cloud-lightning", "@tui.cloud-lightning-filled"],
		"filled": true,
		"filledName": "cloud-lightning-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cloud-moon",
		"tuiName": "@tui.cloud-moon",
		"category": "custom",
		"keywords": ["cloud", "moon"],
		"aliases": ["@tui.cloud-moon", "@tui.cloud-moon-filled"],
		"filled": true,
		"filledName": "cloud-moon-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cloud-moon-rain",
		"tuiName": "@tui.cloud-moon-rain",
		"category": "custom",
		"keywords": [
			"cloud",
			"moon",
			"rain"
		],
		"aliases": ["@tui.cloud-moon-rain", "@tui.cloud-moon-rain-filled"],
		"filled": true,
		"filledName": "cloud-moon-rain-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cloud-off",
		"tuiName": "@tui.cloud-off",
		"category": "custom",
		"keywords": ["cloud", "off"],
		"aliases": ["@tui.cloud-off", "@tui.cloud-off-filled"],
		"filled": true,
		"filledName": "cloud-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cloud-rain",
		"tuiName": "@tui.cloud-rain",
		"category": "custom",
		"keywords": ["cloud", "rain"],
		"aliases": ["@tui.cloud-rain", "@tui.cloud-rain-filled"],
		"filled": true,
		"filledName": "cloud-rain-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cloud-rain-wind",
		"tuiName": "@tui.cloud-rain-wind",
		"category": "custom",
		"keywords": [
			"cloud",
			"rain",
			"wind"
		],
		"aliases": ["@tui.cloud-rain-wind", "@tui.cloud-rain-wind-filled"],
		"filled": true,
		"filledName": "cloud-rain-wind-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cloud-snow",
		"tuiName": "@tui.cloud-snow",
		"category": "custom",
		"keywords": ["cloud", "snow"],
		"aliases": ["@tui.cloud-snow", "@tui.cloud-snow-filled"],
		"filled": true,
		"filledName": "cloud-snow-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cloud-sun",
		"tuiName": "@tui.cloud-sun",
		"category": "custom",
		"keywords": ["cloud", "sun"],
		"aliases": ["@tui.cloud-sun", "@tui.cloud-sun-filled"],
		"filled": true,
		"filledName": "cloud-sun-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cloud-sun-rain",
		"tuiName": "@tui.cloud-sun-rain",
		"category": "custom",
		"keywords": [
			"cloud",
			"sun",
			"rain"
		],
		"aliases": ["@tui.cloud-sun-rain", "@tui.cloud-sun-rain-filled"],
		"filled": true,
		"filledName": "cloud-sun-rain-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cloud-sync",
		"tuiName": "@tui.cloud-sync",
		"category": "custom",
		"keywords": ["cloud", "sync"],
		"aliases": ["@tui.cloud-sync", "@tui.cloud-sync-filled"],
		"filled": true,
		"filledName": "cloud-sync-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cloud-upload",
		"tuiName": "@tui.cloud-upload",
		"category": "custom",
		"keywords": ["cloud", "upload"],
		"aliases": ["@tui.cloud-upload", "@tui.cloud-upload-filled"],
		"filled": true,
		"filledName": "cloud-upload-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cloudy",
		"tuiName": "@tui.cloudy",
		"category": "custom",
		"keywords": ["cloudy"],
		"aliases": ["@tui.cloudy", "@tui.cloudy-filled"],
		"filled": true,
		"filledName": "cloudy-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "clover",
		"tuiName": "@tui.clover",
		"category": "custom",
		"keywords": ["clover"],
		"aliases": ["@tui.clover", "@tui.clover-filled"],
		"filled": true,
		"filledName": "clover-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "club",
		"tuiName": "@tui.club",
		"category": "custom",
		"keywords": ["club"],
		"aliases": ["@tui.club", "@tui.club-filled"],
		"filled": true,
		"filledName": "club-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "code",
		"tuiName": "@tui.code",
		"category": "development",
		"keywords": ["code"],
		"aliases": ["@tui.code", "@tui.code-filled"],
		"filled": true,
		"filledName": "code-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "code-2",
		"tuiName": "@tui.code-2",
		"category": "development",
		"keywords": ["code", "2"],
		"aliases": ["@tui.code-2", "@tui.code-2-filled"],
		"filled": true,
		"filledName": "code-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "code-square",
		"tuiName": "@tui.code-square",
		"category": "development",
		"keywords": ["code", "square"],
		"aliases": ["@tui.code-square", "@tui.code-square-filled"],
		"filled": true,
		"filledName": "code-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "code-xml",
		"tuiName": "@tui.code-xml",
		"category": "development",
		"keywords": ["code", "xml"],
		"aliases": ["@tui.code-xml", "@tui.code-xml-filled"],
		"filled": true,
		"filledName": "code-xml-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "coffee",
		"tuiName": "@tui.coffee",
		"category": "custom",
		"keywords": ["coffee"],
		"aliases": ["@tui.coffee", "@tui.coffee-filled"],
		"filled": true,
		"filledName": "coffee-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cog",
		"tuiName": "@tui.cog",
		"category": "custom",
		"keywords": ["cog"],
		"aliases": ["@tui.cog", "@tui.cog-filled"],
		"filled": true,
		"filledName": "cog-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "coins",
		"tuiName": "@tui.coins",
		"category": "finance",
		"keywords": ["coins"],
		"aliases": ["@tui.coins", "@tui.coins-filled"],
		"filled": true,
		"filledName": "coins-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "columns",
		"tuiName": "@tui.columns",
		"category": "navigation",
		"keywords": ["columns"],
		"aliases": ["@tui.columns", "@tui.columns-filled"],
		"filled": true,
		"filledName": "columns-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "columns-2",
		"tuiName": "@tui.columns-2",
		"category": "navigation",
		"keywords": ["columns", "2"],
		"aliases": ["@tui.columns-2", "@tui.columns-2-filled"],
		"filled": true,
		"filledName": "columns-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "columns-3",
		"tuiName": "@tui.columns-3",
		"category": "navigation",
		"keywords": ["columns", "3"],
		"aliases": ["@tui.columns-3", "@tui.columns-3-filled"],
		"filled": true,
		"filledName": "columns-3-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "columns-3-cog",
		"tuiName": "@tui.columns-3-cog",
		"category": "navigation",
		"keywords": [
			"columns",
			"3",
			"cog"
		],
		"aliases": ["@tui.columns-3-cog", "@tui.columns-3-cog-filled"],
		"filled": true,
		"filledName": "columns-3-cog-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "columns-4",
		"tuiName": "@tui.columns-4",
		"category": "navigation",
		"keywords": ["columns", "4"],
		"aliases": ["@tui.columns-4", "@tui.columns-4-filled"],
		"filled": true,
		"filledName": "columns-4-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "columns-settings",
		"tuiName": "@tui.columns-settings",
		"category": "navigation",
		"keywords": ["columns", "settings"],
		"aliases": ["@tui.columns-settings", "@tui.columns-settings-filled"],
		"filled": true,
		"filledName": "columns-settings-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "combine",
		"tuiName": "@tui.combine",
		"category": "custom",
		"keywords": ["combine"],
		"aliases": ["@tui.combine", "@tui.combine-filled"],
		"filled": true,
		"filledName": "combine-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "command",
		"tuiName": "@tui.command",
		"category": "custom",
		"keywords": ["command"],
		"aliases": ["@tui.command", "@tui.command-filled"],
		"filled": true,
		"filledName": "command-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "compass",
		"tuiName": "@tui.compass",
		"category": "maps-location",
		"keywords": ["compass"],
		"aliases": ["@tui.compass", "@tui.compass-filled"],
		"filled": true,
		"filledName": "compass-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "component",
		"tuiName": "@tui.component",
		"category": "layout",
		"keywords": ["component"],
		"aliases": ["@tui.component", "@tui.component-filled"],
		"filled": true,
		"filledName": "component-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "computer",
		"tuiName": "@tui.computer",
		"category": "custom",
		"keywords": ["computer"],
		"aliases": ["@tui.computer", "@tui.computer-filled"],
		"filled": true,
		"filledName": "computer-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "concierge-bell",
		"tuiName": "@tui.concierge-bell",
		"category": "custom",
		"keywords": ["concierge", "bell"],
		"aliases": ["@tui.concierge-bell", "@tui.concierge-bell-filled"],
		"filled": true,
		"filledName": "concierge-bell-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cone",
		"tuiName": "@tui.cone",
		"category": "custom",
		"keywords": ["cone"],
		"aliases": ["@tui.cone", "@tui.cone-filled"],
		"filled": true,
		"filledName": "cone-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "construction",
		"tuiName": "@tui.construction",
		"category": "custom",
		"keywords": ["construction"],
		"aliases": ["@tui.construction", "@tui.construction-filled"],
		"filled": true,
		"filledName": "construction-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "contact",
		"tuiName": "@tui.contact",
		"category": "communication",
		"keywords": ["contact"],
		"aliases": ["@tui.contact", "@tui.contact-filled"],
		"filled": true,
		"filledName": "contact-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "contact-2",
		"tuiName": "@tui.contact-2",
		"category": "communication",
		"keywords": ["contact", "2"],
		"aliases": ["@tui.contact-2", "@tui.contact-2-filled"],
		"filled": true,
		"filledName": "contact-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "contact-round",
		"tuiName": "@tui.contact-round",
		"category": "communication",
		"keywords": ["contact", "round"],
		"aliases": ["@tui.contact-round", "@tui.contact-round-filled"],
		"filled": true,
		"filledName": "contact-round-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "container",
		"tuiName": "@tui.container",
		"category": "custom",
		"keywords": ["container"],
		"aliases": ["@tui.container", "@tui.container-filled"],
		"filled": true,
		"filledName": "container-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "contrast",
		"tuiName": "@tui.contrast",
		"category": "custom",
		"keywords": ["contrast"],
		"aliases": ["@tui.contrast", "@tui.contrast-filled"],
		"filled": true,
		"filledName": "contrast-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cookie",
		"tuiName": "@tui.cookie",
		"category": "custom",
		"keywords": ["cookie"],
		"aliases": ["@tui.cookie", "@tui.cookie-filled"],
		"filled": true,
		"filledName": "cookie-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cooking-pot",
		"tuiName": "@tui.cooking-pot",
		"category": "custom",
		"keywords": ["cooking", "pot"],
		"aliases": ["@tui.cooking-pot", "@tui.cooking-pot-filled"],
		"filled": true,
		"filledName": "cooking-pot-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "copy",
		"tuiName": "@tui.copy",
		"category": "actions",
		"keywords": ["copy"],
		"aliases": ["@tui.copy", "@tui.copy-filled"],
		"filled": true,
		"filledName": "copy-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "copy-check",
		"tuiName": "@tui.copy-check",
		"category": "actions",
		"keywords": ["copy", "check"],
		"aliases": ["@tui.copy-check", "@tui.copy-check-filled"],
		"filled": true,
		"filledName": "copy-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "copy-minus",
		"tuiName": "@tui.copy-minus",
		"category": "actions",
		"keywords": ["copy", "minus"],
		"aliases": ["@tui.copy-minus", "@tui.copy-minus-filled"],
		"filled": true,
		"filledName": "copy-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "copy-plus",
		"tuiName": "@tui.copy-plus",
		"category": "actions",
		"keywords": ["copy", "plus"],
		"aliases": ["@tui.copy-plus", "@tui.copy-plus-filled"],
		"filled": true,
		"filledName": "copy-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "copy-slash",
		"tuiName": "@tui.copy-slash",
		"category": "actions",
		"keywords": ["copy", "slash"],
		"aliases": ["@tui.copy-slash", "@tui.copy-slash-filled"],
		"filled": true,
		"filledName": "copy-slash-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "copy-x",
		"tuiName": "@tui.copy-x",
		"category": "actions",
		"keywords": ["copy", "x"],
		"aliases": ["@tui.copy-x", "@tui.copy-x-filled"],
		"filled": true,
		"filledName": "copy-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "copyleft",
		"tuiName": "@tui.copyleft",
		"category": "actions",
		"keywords": ["copyleft"],
		"aliases": ["@tui.copyleft", "@tui.copyleft-filled"],
		"filled": true,
		"filledName": "copyleft-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "copyright",
		"tuiName": "@tui.copyright",
		"category": "actions",
		"keywords": ["copyright"],
		"aliases": ["@tui.copyright", "@tui.copyright-filled"],
		"filled": true,
		"filledName": "copyright-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "corner-down-left",
		"tuiName": "@tui.corner-down-left",
		"category": "arrows",
		"keywords": [
			"corner",
			"down",
			"left"
		],
		"aliases": ["@tui.corner-down-left", "@tui.corner-down-left-filled"],
		"filled": true,
		"filledName": "corner-down-left-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "corner-down-right",
		"tuiName": "@tui.corner-down-right",
		"category": "arrows",
		"keywords": [
			"corner",
			"down",
			"right"
		],
		"aliases": ["@tui.corner-down-right", "@tui.corner-down-right-filled"],
		"filled": true,
		"filledName": "corner-down-right-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "corner-left-down",
		"tuiName": "@tui.corner-left-down",
		"category": "arrows",
		"keywords": [
			"corner",
			"left",
			"down"
		],
		"aliases": ["@tui.corner-left-down", "@tui.corner-left-down-filled"],
		"filled": true,
		"filledName": "corner-left-down-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "corner-left-up",
		"tuiName": "@tui.corner-left-up",
		"category": "arrows",
		"keywords": [
			"corner",
			"left",
			"up"
		],
		"aliases": ["@tui.corner-left-up", "@tui.corner-left-up-filled"],
		"filled": true,
		"filledName": "corner-left-up-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "corner-right-down",
		"tuiName": "@tui.corner-right-down",
		"category": "arrows",
		"keywords": [
			"corner",
			"right",
			"down"
		],
		"aliases": ["@tui.corner-right-down", "@tui.corner-right-down-filled"],
		"filled": true,
		"filledName": "corner-right-down-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "corner-right-up",
		"tuiName": "@tui.corner-right-up",
		"category": "arrows",
		"keywords": [
			"corner",
			"right",
			"up"
		],
		"aliases": ["@tui.corner-right-up", "@tui.corner-right-up-filled"],
		"filled": true,
		"filledName": "corner-right-up-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "corner-up-left",
		"tuiName": "@tui.corner-up-left",
		"category": "arrows",
		"keywords": [
			"corner",
			"up",
			"left"
		],
		"aliases": ["@tui.corner-up-left", "@tui.corner-up-left-filled"],
		"filled": true,
		"filledName": "corner-up-left-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "corner-up-right",
		"tuiName": "@tui.corner-up-right",
		"category": "arrows",
		"keywords": [
			"corner",
			"up",
			"right"
		],
		"aliases": ["@tui.corner-up-right", "@tui.corner-up-right-filled"],
		"filled": true,
		"filledName": "corner-up-right-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "cpu",
		"tuiName": "@tui.cpu",
		"category": "devices",
		"keywords": ["cpu"],
		"aliases": ["@tui.cpu", "@tui.cpu-filled"],
		"filled": true,
		"filledName": "cpu-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cpu-ai",
		"tuiName": "@tui.cpu-ai",
		"category": "devices",
		"keywords": ["cpu", "ai"],
		"aliases": ["@tui.cpu-ai", "@tui.cpu-ai-filled"],
		"filled": true,
		"filledName": "cpu-ai-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "creative-commons",
		"tuiName": "@tui.creative-commons",
		"category": "custom",
		"keywords": ["creative", "commons"],
		"aliases": ["@tui.creative-commons", "@tui.creative-commons-filled"],
		"filled": true,
		"filledName": "creative-commons-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "credit-card",
		"tuiName": "@tui.credit-card",
		"category": "finance",
		"keywords": ["credit", "card"],
		"aliases": ["@tui.credit-card", "@tui.credit-card-filled"],
		"filled": true,
		"filledName": "credit-card-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "credit-card-check",
		"tuiName": "@tui.credit-card-check",
		"category": "finance",
		"keywords": [
			"credit",
			"card",
			"check"
		],
		"aliases": ["@tui.credit-card-check", "@tui.credit-card-check-filled"],
		"filled": true,
		"filledName": "credit-card-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "credit-card-minus",
		"tuiName": "@tui.credit-card-minus",
		"category": "finance",
		"keywords": [
			"credit",
			"card",
			"minus"
		],
		"aliases": ["@tui.credit-card-minus", "@tui.credit-card-minus-filled"],
		"filled": true,
		"filledName": "credit-card-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "credit-card-plus",
		"tuiName": "@tui.credit-card-plus",
		"category": "finance",
		"keywords": [
			"credit",
			"card",
			"plus"
		],
		"aliases": ["@tui.credit-card-plus", "@tui.credit-card-plus-filled"],
		"filled": true,
		"filledName": "credit-card-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "credit-card-reader",
		"tuiName": "@tui.credit-card-reader",
		"category": "finance",
		"keywords": [
			"credit",
			"card",
			"reader"
		],
		"aliases": ["@tui.credit-card-reader", "@tui.credit-card-reader-filled"],
		"filled": true,
		"filledName": "credit-card-reader-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "credit-card-x",
		"tuiName": "@tui.credit-card-x",
		"category": "finance",
		"keywords": [
			"credit",
			"card",
			"x"
		],
		"aliases": ["@tui.credit-card-x", "@tui.credit-card-x-filled"],
		"filled": true,
		"filledName": "credit-card-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "croissant",
		"tuiName": "@tui.croissant",
		"category": "custom",
		"keywords": ["croissant"],
		"aliases": ["@tui.croissant", "@tui.croissant-filled"],
		"filled": true,
		"filledName": "croissant-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "crop",
		"tuiName": "@tui.crop",
		"category": "editing",
		"keywords": ["crop"],
		"aliases": ["@tui.crop", "@tui.crop-filled"],
		"filled": true,
		"filledName": "crop-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cross",
		"tuiName": "@tui.cross",
		"category": "custom",
		"keywords": ["cross"],
		"aliases": ["@tui.cross", "@tui.cross-filled"],
		"filled": true,
		"filledName": "cross-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "crosshair",
		"tuiName": "@tui.crosshair",
		"category": "custom",
		"keywords": ["crosshair"],
		"aliases": ["@tui.crosshair", "@tui.crosshair-filled"],
		"filled": true,
		"filledName": "crosshair-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "crown",
		"tuiName": "@tui.crown",
		"category": "custom",
		"keywords": ["crown"],
		"aliases": ["@tui.crown", "@tui.crown-filled"],
		"filled": true,
		"filledName": "crown-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cuboid",
		"tuiName": "@tui.cuboid",
		"category": "custom",
		"keywords": ["cuboid"],
		"aliases": ["@tui.cuboid", "@tui.cuboid-filled"],
		"filled": true,
		"filledName": "cuboid-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cup-soda",
		"tuiName": "@tui.cup-soda",
		"category": "custom",
		"keywords": ["cup", "soda"],
		"aliases": ["@tui.cup-soda", "@tui.cup-soda-filled"],
		"filled": true,
		"filledName": "cup-soda-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cupcake",
		"tuiName": "@tui.cupcake",
		"category": "custom",
		"keywords": ["cupcake"],
		"aliases": ["@tui.cupcake", "@tui.cupcake-filled"],
		"filled": true,
		"filledName": "cupcake-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "curly-braces",
		"tuiName": "@tui.curly-braces",
		"category": "custom",
		"keywords": ["curly", "braces"],
		"aliases": ["@tui.curly-braces", "@tui.curly-braces-filled"],
		"filled": true,
		"filledName": "curly-braces-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "currency",
		"tuiName": "@tui.currency",
		"category": "custom",
		"keywords": ["currency"],
		"aliases": ["@tui.currency", "@tui.currency-filled"],
		"filled": true,
		"filledName": "currency-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "cylinder",
		"tuiName": "@tui.cylinder",
		"category": "custom",
		"keywords": ["cylinder"],
		"aliases": ["@tui.cylinder", "@tui.cylinder-filled"],
		"filled": true,
		"filledName": "cylinder-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "dam",
		"tuiName": "@tui.dam",
		"category": "custom",
		"keywords": ["dam"],
		"aliases": ["@tui.dam", "@tui.dam-filled"],
		"filled": true,
		"filledName": "dam-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "database",
		"tuiName": "@tui.database",
		"category": "development",
		"keywords": ["database"],
		"aliases": ["@tui.database", "@tui.database-filled"],
		"filled": true,
		"filledName": "database-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "database-arrow-down",
		"tuiName": "@tui.database-arrow-down",
		"category": "development",
		"keywords": [
			"database",
			"arrow",
			"down"
		],
		"aliases": ["@tui.database-arrow-down", "@tui.database-arrow-down-filled"],
		"filled": true,
		"filledName": "database-arrow-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "database-arrow-up",
		"tuiName": "@tui.database-arrow-up",
		"category": "development",
		"keywords": [
			"database",
			"arrow",
			"up"
		],
		"aliases": ["@tui.database-arrow-up", "@tui.database-arrow-up-filled"],
		"filled": true,
		"filledName": "database-arrow-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "database-backup",
		"tuiName": "@tui.database-backup",
		"category": "development",
		"keywords": ["database", "backup"],
		"aliases": ["@tui.database-backup", "@tui.database-backup-filled"],
		"filled": true,
		"filledName": "database-backup-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "database-check",
		"tuiName": "@tui.database-check",
		"category": "development",
		"keywords": ["database", "check"],
		"aliases": ["@tui.database-check", "@tui.database-check-filled"],
		"filled": true,
		"filledName": "database-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "database-minus",
		"tuiName": "@tui.database-minus",
		"category": "development",
		"keywords": ["database", "minus"],
		"aliases": ["@tui.database-minus", "@tui.database-minus-filled"],
		"filled": true,
		"filledName": "database-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "database-plus",
		"tuiName": "@tui.database-plus",
		"category": "development",
		"keywords": ["database", "plus"],
		"aliases": ["@tui.database-plus", "@tui.database-plus-filled"],
		"filled": true,
		"filledName": "database-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "database-search",
		"tuiName": "@tui.database-search",
		"category": "development",
		"keywords": ["database", "search"],
		"aliases": ["@tui.database-search", "@tui.database-search-filled"],
		"filled": true,
		"filledName": "database-search-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "database-x",
		"tuiName": "@tui.database-x",
		"category": "development",
		"keywords": ["database", "x"],
		"aliases": ["@tui.database-x", "@tui.database-x-filled"],
		"filled": true,
		"filledName": "database-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "database-zap",
		"tuiName": "@tui.database-zap",
		"category": "development",
		"keywords": ["database", "zap"],
		"aliases": ["@tui.database-zap", "@tui.database-zap-filled"],
		"filled": true,
		"filledName": "database-zap-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "decimals-arrow-left",
		"tuiName": "@tui.decimals-arrow-left",
		"category": "custom",
		"keywords": [
			"decimals",
			"arrow",
			"left"
		],
		"aliases": ["@tui.decimals-arrow-left", "@tui.decimals-arrow-left-filled"],
		"filled": true,
		"filledName": "decimals-arrow-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "decimals-arrow-right",
		"tuiName": "@tui.decimals-arrow-right",
		"category": "custom",
		"keywords": [
			"decimals",
			"arrow",
			"right"
		],
		"aliases": ["@tui.decimals-arrow-right", "@tui.decimals-arrow-right-filled"],
		"filled": true,
		"filledName": "decimals-arrow-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "delete",
		"tuiName": "@tui.delete",
		"category": "custom",
		"keywords": ["delete"],
		"aliases": ["@tui.delete", "@tui.delete-filled"],
		"filled": true,
		"filledName": "delete-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "dessert",
		"tuiName": "@tui.dessert",
		"category": "custom",
		"keywords": ["dessert"],
		"aliases": ["@tui.dessert", "@tui.dessert-filled"],
		"filled": true,
		"filledName": "dessert-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "diameter",
		"tuiName": "@tui.diameter",
		"category": "custom",
		"keywords": ["diameter"],
		"aliases": ["@tui.diameter", "@tui.diameter-filled"],
		"filled": true,
		"filledName": "diameter-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "diamond",
		"tuiName": "@tui.diamond",
		"category": "custom",
		"keywords": ["diamond"],
		"aliases": ["@tui.diamond", "@tui.diamond-filled"],
		"filled": true,
		"filledName": "diamond-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "diamond-minus",
		"tuiName": "@tui.diamond-minus",
		"category": "custom",
		"keywords": ["diamond", "minus"],
		"aliases": ["@tui.diamond-minus", "@tui.diamond-minus-filled"],
		"filled": true,
		"filledName": "diamond-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "diamond-percent",
		"tuiName": "@tui.diamond-percent",
		"category": "custom",
		"keywords": ["diamond", "percent"],
		"aliases": ["@tui.diamond-percent", "@tui.diamond-percent-filled"],
		"filled": true,
		"filledName": "diamond-percent-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "diamond-plus",
		"tuiName": "@tui.diamond-plus",
		"category": "custom",
		"keywords": ["diamond", "plus"],
		"aliases": ["@tui.diamond-plus", "@tui.diamond-plus-filled"],
		"filled": true,
		"filledName": "diamond-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "dice-1",
		"tuiName": "@tui.dice-1",
		"category": "custom",
		"keywords": ["dice", "1"],
		"aliases": ["@tui.dice-1", "@tui.dice-1-filled"],
		"filled": true,
		"filledName": "dice-1-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "dice-2",
		"tuiName": "@tui.dice-2",
		"category": "custom",
		"keywords": ["dice", "2"],
		"aliases": ["@tui.dice-2", "@tui.dice-2-filled"],
		"filled": true,
		"filledName": "dice-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "dice-3",
		"tuiName": "@tui.dice-3",
		"category": "custom",
		"keywords": ["dice", "3"],
		"aliases": ["@tui.dice-3", "@tui.dice-3-filled"],
		"filled": true,
		"filledName": "dice-3-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "dice-4",
		"tuiName": "@tui.dice-4",
		"category": "custom",
		"keywords": ["dice", "4"],
		"aliases": ["@tui.dice-4", "@tui.dice-4-filled"],
		"filled": true,
		"filledName": "dice-4-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "dice-5",
		"tuiName": "@tui.dice-5",
		"category": "custom",
		"keywords": ["dice", "5"],
		"aliases": ["@tui.dice-5", "@tui.dice-5-filled"],
		"filled": true,
		"filledName": "dice-5-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "dice-6",
		"tuiName": "@tui.dice-6",
		"category": "custom",
		"keywords": ["dice", "6"],
		"aliases": ["@tui.dice-6", "@tui.dice-6-filled"],
		"filled": true,
		"filledName": "dice-6-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "dices",
		"tuiName": "@tui.dices",
		"category": "custom",
		"keywords": ["dices"],
		"aliases": ["@tui.dices", "@tui.dices-filled"],
		"filled": true,
		"filledName": "dices-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "diff",
		"tuiName": "@tui.diff",
		"category": "custom",
		"keywords": ["diff"],
		"aliases": ["@tui.diff", "@tui.diff-filled"],
		"filled": true,
		"filledName": "diff-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "diners-club",
		"tuiName": "@tui.diners-club",
		"category": "custom",
		"keywords": ["diners", "club"],
		"aliases": ["@tui.diners-club"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "disc",
		"tuiName": "@tui.disc",
		"category": "custom",
		"keywords": ["disc"],
		"aliases": ["@tui.disc", "@tui.disc-filled"],
		"filled": true,
		"filledName": "disc-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "disc-2",
		"tuiName": "@tui.disc-2",
		"category": "custom",
		"keywords": ["disc", "2"],
		"aliases": ["@tui.disc-2", "@tui.disc-2-filled"],
		"filled": true,
		"filledName": "disc-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "disc-3",
		"tuiName": "@tui.disc-3",
		"category": "custom",
		"keywords": ["disc", "3"],
		"aliases": ["@tui.disc-3", "@tui.disc-3-filled"],
		"filled": true,
		"filledName": "disc-3-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "disc-album",
		"tuiName": "@tui.disc-album",
		"category": "custom",
		"keywords": ["disc", "album"],
		"aliases": ["@tui.disc-album", "@tui.disc-album-filled"],
		"filled": true,
		"filledName": "disc-album-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "discover",
		"tuiName": "@tui.discover",
		"category": "custom",
		"keywords": ["discover"],
		"aliases": ["@tui.discover"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "divide",
		"tuiName": "@tui.divide",
		"category": "custom",
		"keywords": ["divide"],
		"aliases": ["@tui.divide", "@tui.divide-filled"],
		"filled": true,
		"filledName": "divide-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "divide-circle",
		"tuiName": "@tui.divide-circle",
		"category": "custom",
		"keywords": ["divide", "circle"],
		"aliases": ["@tui.divide-circle", "@tui.divide-circle-filled"],
		"filled": true,
		"filledName": "divide-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "divide-square",
		"tuiName": "@tui.divide-square",
		"category": "custom",
		"keywords": ["divide", "square"],
		"aliases": ["@tui.divide-square", "@tui.divide-square-filled"],
		"filled": true,
		"filledName": "divide-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "dna",
		"tuiName": "@tui.dna",
		"category": "custom",
		"keywords": ["dna"],
		"aliases": ["@tui.dna", "@tui.dna-filled"],
		"filled": true,
		"filledName": "dna-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "dna-off",
		"tuiName": "@tui.dna-off",
		"category": "custom",
		"keywords": ["dna", "off"],
		"aliases": ["@tui.dna-off", "@tui.dna-off-filled"],
		"filled": true,
		"filledName": "dna-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "dock",
		"tuiName": "@tui.dock",
		"category": "custom",
		"keywords": ["dock"],
		"aliases": ["@tui.dock", "@tui.dock-filled"],
		"filled": true,
		"filledName": "dock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "dog",
		"tuiName": "@tui.dog",
		"category": "custom",
		"keywords": ["dog"],
		"aliases": ["@tui.dog", "@tui.dog-filled"],
		"filled": true,
		"filledName": "dog-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "dollar-sign",
		"tuiName": "@tui.dollar-sign",
		"category": "custom",
		"keywords": ["dollar", "sign"],
		"aliases": ["@tui.dollar-sign", "@tui.dollar-sign-filled"],
		"filled": true,
		"filledName": "dollar-sign-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "dome",
		"tuiName": "@tui.dome",
		"category": "custom",
		"keywords": ["dome"],
		"aliases": ["@tui.dome", "@tui.dome-filled"],
		"filled": true,
		"filledName": "dome-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "donut",
		"tuiName": "@tui.donut",
		"category": "custom",
		"keywords": ["donut"],
		"aliases": ["@tui.donut", "@tui.donut-filled"],
		"filled": true,
		"filledName": "donut-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "door-closed",
		"tuiName": "@tui.door-closed",
		"category": "custom",
		"keywords": ["door", "closed"],
		"aliases": ["@tui.door-closed", "@tui.door-closed-filled"],
		"filled": true,
		"filledName": "door-closed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "door-closed-cog",
		"tuiName": "@tui.door-closed-cog",
		"category": "custom",
		"keywords": [
			"door",
			"closed",
			"cog"
		],
		"aliases": ["@tui.door-closed-cog", "@tui.door-closed-cog-filled"],
		"filled": true,
		"filledName": "door-closed-cog-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "door-closed-locked",
		"tuiName": "@tui.door-closed-locked",
		"category": "custom",
		"keywords": [
			"door",
			"closed",
			"locked"
		],
		"aliases": ["@tui.door-closed-locked", "@tui.door-closed-locked-filled"],
		"filled": true,
		"filledName": "door-closed-locked-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "door-closed-package",
		"tuiName": "@tui.door-closed-package",
		"category": "custom",
		"keywords": [
			"door",
			"closed",
			"package"
		],
		"aliases": ["@tui.door-closed-package", "@tui.door-closed-package-filled"],
		"filled": true,
		"filledName": "door-closed-package-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "door-open",
		"tuiName": "@tui.door-open",
		"category": "custom",
		"keywords": ["door", "open"],
		"aliases": ["@tui.door-open", "@tui.door-open-filled"],
		"filled": true,
		"filledName": "door-open-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "door-stairwell",
		"tuiName": "@tui.door-stairwell",
		"category": "custom",
		"keywords": ["door", "stairwell"],
		"aliases": ["@tui.door-stairwell", "@tui.door-stairwell-filled"],
		"filled": true,
		"filledName": "door-stairwell-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "dot",
		"tuiName": "@tui.dot",
		"category": "custom",
		"keywords": ["dot"],
		"aliases": ["@tui.dot", "@tui.dot-filled"],
		"filled": true,
		"filledName": "dot-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "dot-square",
		"tuiName": "@tui.dot-square",
		"category": "custom",
		"keywords": ["dot", "square"],
		"aliases": ["@tui.dot-square", "@tui.dot-square-filled"],
		"filled": true,
		"filledName": "dot-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "download",
		"tuiName": "@tui.download",
		"category": "actions",
		"keywords": ["download"],
		"aliases": ["@tui.download", "@tui.download-filled"],
		"filled": true,
		"filledName": "download-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "download-cloud",
		"tuiName": "@tui.download-cloud",
		"category": "actions",
		"keywords": ["download", "cloud"],
		"aliases": ["@tui.download-cloud", "@tui.download-cloud-filled"],
		"filled": true,
		"filledName": "download-cloud-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "drafting-compass",
		"tuiName": "@tui.drafting-compass",
		"category": "custom",
		"keywords": ["drafting", "compass"],
		"aliases": ["@tui.drafting-compass", "@tui.drafting-compass-filled"],
		"filled": true,
		"filledName": "drafting-compass-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "drama",
		"tuiName": "@tui.drama",
		"category": "custom",
		"keywords": ["drama"],
		"aliases": ["@tui.drama", "@tui.drama-filled"],
		"filled": true,
		"filledName": "drama-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "drill",
		"tuiName": "@tui.drill",
		"category": "custom",
		"keywords": ["drill"],
		"aliases": ["@tui.drill", "@tui.drill-filled"],
		"filled": true,
		"filledName": "drill-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "drone",
		"tuiName": "@tui.drone",
		"category": "custom",
		"keywords": ["drone"],
		"aliases": ["@tui.drone", "@tui.drone-filled"],
		"filled": true,
		"filledName": "drone-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "droplet",
		"tuiName": "@tui.droplet",
		"category": "custom",
		"keywords": ["droplet"],
		"aliases": ["@tui.droplet", "@tui.droplet-filled"],
		"filled": true,
		"filledName": "droplet-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "droplet-off",
		"tuiName": "@tui.droplet-off",
		"category": "custom",
		"keywords": ["droplet", "off"],
		"aliases": ["@tui.droplet-off", "@tui.droplet-off-filled"],
		"filled": true,
		"filledName": "droplet-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "droplets",
		"tuiName": "@tui.droplets",
		"category": "custom",
		"keywords": ["droplets"],
		"aliases": ["@tui.droplets", "@tui.droplets-filled"],
		"filled": true,
		"filledName": "droplets-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "drum",
		"tuiName": "@tui.drum",
		"category": "custom",
		"keywords": ["drum"],
		"aliases": ["@tui.drum", "@tui.drum-filled"],
		"filled": true,
		"filledName": "drum-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "drumstick",
		"tuiName": "@tui.drumstick",
		"category": "custom",
		"keywords": ["drumstick"],
		"aliases": ["@tui.drumstick", "@tui.drumstick-filled"],
		"filled": true,
		"filledName": "drumstick-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "dumbbell",
		"tuiName": "@tui.dumbbell",
		"category": "custom",
		"keywords": ["dumbbell"],
		"aliases": ["@tui.dumbbell", "@tui.dumbbell-filled"],
		"filled": true,
		"filledName": "dumbbell-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ear",
		"tuiName": "@tui.ear",
		"category": "accessibility",
		"keywords": ["ear"],
		"aliases": ["@tui.ear", "@tui.ear-filled"],
		"filled": true,
		"filledName": "ear-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ear-off",
		"tuiName": "@tui.ear-off",
		"category": "accessibility",
		"keywords": ["ear", "off"],
		"aliases": ["@tui.ear-off", "@tui.ear-off-filled"],
		"filled": true,
		"filledName": "ear-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "earth",
		"tuiName": "@tui.earth",
		"category": "accessibility",
		"keywords": ["earth"],
		"aliases": ["@tui.earth", "@tui.earth-filled"],
		"filled": true,
		"filledName": "earth-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "earth-lock",
		"tuiName": "@tui.earth-lock",
		"category": "accessibility",
		"keywords": ["earth", "lock"],
		"aliases": ["@tui.earth-lock", "@tui.earth-lock-filled"],
		"filled": true,
		"filledName": "earth-lock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "eclipse",
		"tuiName": "@tui.eclipse",
		"category": "custom",
		"keywords": ["eclipse"],
		"aliases": ["@tui.eclipse", "@tui.eclipse-filled"],
		"filled": true,
		"filledName": "eclipse-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "edit",
		"tuiName": "@tui.edit",
		"category": "actions",
		"keywords": ["edit"],
		"aliases": ["@tui.edit", "@tui.edit-filled"],
		"filled": true,
		"filledName": "edit-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "edit-2",
		"tuiName": "@tui.edit-2",
		"category": "actions",
		"keywords": ["edit", "2"],
		"aliases": ["@tui.edit-2", "@tui.edit-2-filled"],
		"filled": true,
		"filledName": "edit-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "edit-3",
		"tuiName": "@tui.edit-3",
		"category": "actions",
		"keywords": ["edit", "3"],
		"aliases": ["@tui.edit-3", "@tui.edit-3-filled"],
		"filled": true,
		"filledName": "edit-3-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "egg",
		"tuiName": "@tui.egg",
		"category": "custom",
		"keywords": ["egg"],
		"aliases": ["@tui.egg", "@tui.egg-filled"],
		"filled": true,
		"filledName": "egg-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "egg-fried",
		"tuiName": "@tui.egg-fried",
		"category": "custom",
		"keywords": ["egg", "fried"],
		"aliases": ["@tui.egg-fried", "@tui.egg-fried-filled"],
		"filled": true,
		"filledName": "egg-fried-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "egg-off",
		"tuiName": "@tui.egg-off",
		"category": "custom",
		"keywords": ["egg", "off"],
		"aliases": ["@tui.egg-off", "@tui.egg-off-filled"],
		"filled": true,
		"filledName": "egg-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "eject",
		"tuiName": "@tui.eject",
		"category": "custom",
		"keywords": ["eject"],
		"aliases": ["@tui.eject", "@tui.eject-filled"],
		"filled": true,
		"filledName": "eject-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "electron",
		"tuiName": "@tui.electron",
		"category": "custom",
		"keywords": ["electron"],
		"aliases": ["@tui.electron"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "electron-mono",
		"tuiName": "@tui.electron-mono",
		"category": "custom",
		"keywords": ["electron", "mono"],
		"aliases": ["@tui.electron-mono"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ellipse",
		"tuiName": "@tui.ellipse",
		"category": "custom",
		"keywords": ["ellipse"],
		"aliases": ["@tui.ellipse", "@tui.ellipse-filled"],
		"filled": true,
		"filledName": "ellipse-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ellipsis",
		"tuiName": "@tui.ellipsis",
		"category": "actions",
		"keywords": ["ellipsis"],
		"aliases": ["@tui.ellipsis", "@tui.ellipsis-filled"],
		"filled": true,
		"filledName": "ellipsis-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ellipsis-vertical",
		"tuiName": "@tui.ellipsis-vertical",
		"category": "actions",
		"keywords": ["ellipsis", "vertical"],
		"aliases": ["@tui.ellipsis-vertical", "@tui.ellipsis-vertical-filled"],
		"filled": true,
		"filledName": "ellipsis-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "engine",
		"tuiName": "@tui.engine",
		"category": "custom",
		"keywords": ["engine"],
		"aliases": ["@tui.engine", "@tui.engine-filled"],
		"filled": true,
		"filledName": "engine-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "equal",
		"tuiName": "@tui.equal",
		"category": "custom",
		"keywords": ["equal"],
		"aliases": ["@tui.equal", "@tui.equal-filled"],
		"filled": true,
		"filledName": "equal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "equal-approximately",
		"tuiName": "@tui.equal-approximately",
		"category": "custom",
		"keywords": ["equal", "approximately"],
		"aliases": ["@tui.equal-approximately", "@tui.equal-approximately-filled"],
		"filled": true,
		"filledName": "equal-approximately-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "equal-approximately-not",
		"tuiName": "@tui.equal-approximately-not",
		"category": "custom",
		"keywords": [
			"equal",
			"approximately",
			"not"
		],
		"aliases": ["@tui.equal-approximately-not", "@tui.equal-approximately-not-filled"],
		"filled": true,
		"filledName": "equal-approximately-not-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "equal-not",
		"tuiName": "@tui.equal-not",
		"category": "custom",
		"keywords": ["equal", "not"],
		"aliases": ["@tui.equal-not", "@tui.equal-not-filled"],
		"filled": true,
		"filledName": "equal-not-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "equal-square",
		"tuiName": "@tui.equal-square",
		"category": "custom",
		"keywords": ["equal", "square"],
		"aliases": ["@tui.equal-square", "@tui.equal-square-filled"],
		"filled": true,
		"filledName": "equal-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "eraser",
		"tuiName": "@tui.eraser",
		"category": "editing",
		"keywords": ["eraser"],
		"aliases": ["@tui.eraser", "@tui.eraser-filled"],
		"filled": true,
		"filledName": "eraser-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ethernet-port",
		"tuiName": "@tui.ethernet-port",
		"category": "custom",
		"keywords": ["ethernet", "port"],
		"aliases": ["@tui.ethernet-port", "@tui.ethernet-port-filled"],
		"filled": true,
		"filledName": "ethernet-port-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "euro",
		"tuiName": "@tui.euro",
		"category": "custom",
		"keywords": ["euro"],
		"aliases": ["@tui.euro", "@tui.euro-filled"],
		"filled": true,
		"filledName": "euro-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ev-charger",
		"tuiName": "@tui.ev-charger",
		"category": "custom",
		"keywords": ["ev", "charger"],
		"aliases": ["@tui.ev-charger", "@tui.ev-charger-filled"],
		"filled": true,
		"filledName": "ev-charger-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "expand",
		"tuiName": "@tui.expand",
		"category": "arrows",
		"keywords": ["expand"],
		"aliases": ["@tui.expand", "@tui.expand-filled"],
		"filled": true,
		"filledName": "expand-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "external-link",
		"tuiName": "@tui.external-link",
		"category": "social",
		"keywords": ["external", "link"],
		"aliases": ["@tui.external-link", "@tui.external-link-filled"],
		"filled": true,
		"filledName": "external-link-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "eye",
		"tuiName": "@tui.eye",
		"category": "accessibility",
		"keywords": ["eye"],
		"aliases": ["@tui.eye", "@tui.eye-filled"],
		"filled": true,
		"filledName": "eye-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "eye-closed",
		"tuiName": "@tui.eye-closed",
		"category": "accessibility",
		"keywords": ["eye", "closed"],
		"aliases": ["@tui.eye-closed", "@tui.eye-closed-filled"],
		"filled": true,
		"filledName": "eye-closed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "eye-dashed",
		"tuiName": "@tui.eye-dashed",
		"category": "accessibility",
		"keywords": ["eye", "dashed"],
		"aliases": ["@tui.eye-dashed", "@tui.eye-dashed-filled"],
		"filled": true,
		"filledName": "eye-dashed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "eye-off",
		"tuiName": "@tui.eye-off",
		"category": "accessibility",
		"keywords": ["eye", "off"],
		"aliases": ["@tui.eye-off", "@tui.eye-off-filled"],
		"filled": true,
		"filledName": "eye-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "face-angry",
		"tuiName": "@tui.face-angry",
		"category": "custom",
		"keywords": ["face", "angry"],
		"aliases": ["@tui.face-angry", "@tui.face-angry-filled"],
		"filled": true,
		"filledName": "face-angry-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "face-expressionless",
		"tuiName": "@tui.face-expressionless",
		"category": "custom",
		"keywords": ["face", "expressionless"],
		"aliases": ["@tui.face-expressionless", "@tui.face-expressionless-filled"],
		"filled": true,
		"filledName": "face-expressionless-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "face-grinning",
		"tuiName": "@tui.face-grinning",
		"category": "custom",
		"keywords": ["face", "grinning"],
		"aliases": ["@tui.face-grinning", "@tui.face-grinning-filled"],
		"filled": true,
		"filledName": "face-grinning-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "face-neutral",
		"tuiName": "@tui.face-neutral",
		"category": "custom",
		"keywords": ["face", "neutral"],
		"aliases": ["@tui.face-neutral", "@tui.face-neutral-filled"],
		"filled": true,
		"filledName": "face-neutral-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "face-slightly-frowning",
		"tuiName": "@tui.face-slightly-frowning",
		"category": "custom",
		"keywords": [
			"face",
			"slightly",
			"frowning"
		],
		"aliases": ["@tui.face-slightly-frowning", "@tui.face-slightly-frowning-filled"],
		"filled": true,
		"filledName": "face-slightly-frowning-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "face-slightly-smiling",
		"tuiName": "@tui.face-slightly-smiling",
		"category": "custom",
		"keywords": [
			"face",
			"slightly",
			"smiling"
		],
		"aliases": ["@tui.face-slightly-smiling", "@tui.face-slightly-smiling-filled"],
		"filled": true,
		"filledName": "face-slightly-smiling-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "face-slightly-smiling-plus",
		"tuiName": "@tui.face-slightly-smiling-plus",
		"category": "custom",
		"keywords": [
			"face",
			"slightly",
			"smiling",
			"plus"
		],
		"aliases": ["@tui.face-slightly-smiling-plus", "@tui.face-slightly-smiling-plus-filled"],
		"filled": true,
		"filledName": "face-slightly-smiling-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "factory",
		"tuiName": "@tui.factory",
		"category": "custom",
		"keywords": ["factory"],
		"aliases": ["@tui.factory", "@tui.factory-filled"],
		"filled": true,
		"filledName": "factory-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "fan",
		"tuiName": "@tui.fan",
		"category": "custom",
		"keywords": ["fan"],
		"aliases": ["@tui.fan", "@tui.fan-filled"],
		"filled": true,
		"filledName": "fan-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "fast-forward",
		"tuiName": "@tui.fast-forward",
		"category": "media",
		"keywords": ["fast", "forward"],
		"aliases": ["@tui.fast-forward", "@tui.fast-forward-filled"],
		"filled": true,
		"filledName": "fast-forward-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "faucet",
		"tuiName": "@tui.faucet",
		"category": "custom",
		"keywords": ["faucet"],
		"aliases": ["@tui.faucet", "@tui.faucet-filled"],
		"filled": true,
		"filledName": "faucet-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "feather",
		"tuiName": "@tui.feather",
		"category": "custom",
		"keywords": ["feather"],
		"aliases": ["@tui.feather", "@tui.feather-filled"],
		"filled": true,
		"filledName": "feather-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "fence",
		"tuiName": "@tui.fence",
		"category": "custom",
		"keywords": ["fence"],
		"aliases": ["@tui.fence", "@tui.fence-filled"],
		"filled": true,
		"filledName": "fence-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ferris-wheel",
		"tuiName": "@tui.ferris-wheel",
		"category": "custom",
		"keywords": ["ferris", "wheel"],
		"aliases": ["@tui.ferris-wheel", "@tui.ferris-wheel-filled"],
		"filled": true,
		"filledName": "ferris-wheel-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file",
		"tuiName": "@tui.file",
		"category": "files",
		"keywords": ["file"],
		"aliases": ["@tui.file", "@tui.file-filled"],
		"filled": true,
		"filledName": "file-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-archive",
		"tuiName": "@tui.file-archive",
		"category": "files",
		"keywords": ["file", "archive"],
		"aliases": ["@tui.file-archive", "@tui.file-archive-filled"],
		"filled": true,
		"filledName": "file-archive-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-audio",
		"tuiName": "@tui.file-audio",
		"category": "files",
		"keywords": ["file", "audio"],
		"aliases": ["@tui.file-audio", "@tui.file-audio-filled"],
		"filled": true,
		"filledName": "file-audio-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-audio-2",
		"tuiName": "@tui.file-audio-2",
		"category": "files",
		"keywords": [
			"file",
			"audio",
			"2"
		],
		"aliases": ["@tui.file-audio-2", "@tui.file-audio-2-filled"],
		"filled": true,
		"filledName": "file-audio-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-axis-3-d",
		"tuiName": "@tui.file-axis-3-d",
		"category": "files",
		"keywords": [
			"file",
			"axis",
			"3",
			"d"
		],
		"aliases": ["@tui.file-axis-3-d", "@tui.file-axis-3-d-filled"],
		"filled": true,
		"filledName": "file-axis-3-d-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-axis-3d",
		"tuiName": "@tui.file-axis-3d",
		"category": "files",
		"keywords": [
			"file",
			"axis",
			"3d"
		],
		"aliases": ["@tui.file-axis-3d", "@tui.file-axis-3d-filled"],
		"filled": true,
		"filledName": "file-axis-3d-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-badge",
		"tuiName": "@tui.file-badge",
		"category": "files",
		"keywords": ["file", "badge"],
		"aliases": ["@tui.file-badge", "@tui.file-badge-filled"],
		"filled": true,
		"filledName": "file-badge-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-badge-2",
		"tuiName": "@tui.file-badge-2",
		"category": "files",
		"keywords": [
			"file",
			"badge",
			"2"
		],
		"aliases": ["@tui.file-badge-2", "@tui.file-badge-2-filled"],
		"filled": true,
		"filledName": "file-badge-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-bar-chart",
		"tuiName": "@tui.file-bar-chart",
		"category": "files",
		"keywords": [
			"file",
			"bar",
			"chart"
		],
		"aliases": ["@tui.file-bar-chart", "@tui.file-bar-chart-filled"],
		"filled": true,
		"filledName": "file-bar-chart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-bar-chart-2",
		"tuiName": "@tui.file-bar-chart-2",
		"category": "files",
		"keywords": [
			"file",
			"bar",
			"chart",
			"2"
		],
		"aliases": ["@tui.file-bar-chart-2", "@tui.file-bar-chart-2-filled"],
		"filled": true,
		"filledName": "file-bar-chart-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-box",
		"tuiName": "@tui.file-box",
		"category": "files",
		"keywords": ["file", "box"],
		"aliases": ["@tui.file-box", "@tui.file-box-filled"],
		"filled": true,
		"filledName": "file-box-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-braces",
		"tuiName": "@tui.file-braces",
		"category": "files",
		"keywords": ["file", "braces"],
		"aliases": ["@tui.file-braces", "@tui.file-braces-filled"],
		"filled": true,
		"filledName": "file-braces-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-braces-corner",
		"tuiName": "@tui.file-braces-corner",
		"category": "files",
		"keywords": [
			"file",
			"braces",
			"corner"
		],
		"aliases": ["@tui.file-braces-corner", "@tui.file-braces-corner-filled"],
		"filled": true,
		"filledName": "file-braces-corner-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-chart-column",
		"tuiName": "@tui.file-chart-column",
		"category": "files",
		"keywords": [
			"file",
			"chart",
			"column"
		],
		"aliases": ["@tui.file-chart-column", "@tui.file-chart-column-filled"],
		"filled": true,
		"filledName": "file-chart-column-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-chart-column-increasing",
		"tuiName": "@tui.file-chart-column-increasing",
		"category": "files",
		"keywords": [
			"file",
			"chart",
			"column",
			"increasing"
		],
		"aliases": ["@tui.file-chart-column-increasing", "@tui.file-chart-column-increasing-filled"],
		"filled": true,
		"filledName": "file-chart-column-increasing-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-chart-line",
		"tuiName": "@tui.file-chart-line",
		"category": "files",
		"keywords": [
			"file",
			"chart",
			"line"
		],
		"aliases": ["@tui.file-chart-line", "@tui.file-chart-line-filled"],
		"filled": true,
		"filledName": "file-chart-line-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-chart-pie",
		"tuiName": "@tui.file-chart-pie",
		"category": "files",
		"keywords": [
			"file",
			"chart",
			"pie"
		],
		"aliases": ["@tui.file-chart-pie", "@tui.file-chart-pie-filled"],
		"filled": true,
		"filledName": "file-chart-pie-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-check",
		"tuiName": "@tui.file-check",
		"category": "files",
		"keywords": ["file", "check"],
		"aliases": ["@tui.file-check", "@tui.file-check-filled"],
		"filled": true,
		"filledName": "file-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-check-2",
		"tuiName": "@tui.file-check-2",
		"category": "files",
		"keywords": [
			"file",
			"check",
			"2"
		],
		"aliases": ["@tui.file-check-2", "@tui.file-check-2-filled"],
		"filled": true,
		"filledName": "file-check-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-check-corner",
		"tuiName": "@tui.file-check-corner",
		"category": "files",
		"keywords": [
			"file",
			"check",
			"corner"
		],
		"aliases": ["@tui.file-check-corner", "@tui.file-check-corner-filled"],
		"filled": true,
		"filledName": "file-check-corner-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-clock",
		"tuiName": "@tui.file-clock",
		"category": "files",
		"keywords": ["file", "clock"],
		"aliases": ["@tui.file-clock", "@tui.file-clock-filled"],
		"filled": true,
		"filledName": "file-clock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-code",
		"tuiName": "@tui.file-code",
		"category": "files",
		"keywords": ["file", "code"],
		"aliases": ["@tui.file-code", "@tui.file-code-filled"],
		"filled": true,
		"filledName": "file-code-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-code-2",
		"tuiName": "@tui.file-code-2",
		"category": "files",
		"keywords": [
			"file",
			"code",
			"2"
		],
		"aliases": ["@tui.file-code-2", "@tui.file-code-2-filled"],
		"filled": true,
		"filledName": "file-code-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-code-corner",
		"tuiName": "@tui.file-code-corner",
		"category": "files",
		"keywords": [
			"file",
			"code",
			"corner"
		],
		"aliases": ["@tui.file-code-corner", "@tui.file-code-corner-filled"],
		"filled": true,
		"filledName": "file-code-corner-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-cog",
		"tuiName": "@tui.file-cog",
		"category": "files",
		"keywords": ["file", "cog"],
		"aliases": ["@tui.file-cog", "@tui.file-cog-filled"],
		"filled": true,
		"filledName": "file-cog-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-cog-2",
		"tuiName": "@tui.file-cog-2",
		"category": "files",
		"keywords": [
			"file",
			"cog",
			"2"
		],
		"aliases": ["@tui.file-cog-2", "@tui.file-cog-2-filled"],
		"filled": true,
		"filledName": "file-cog-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-diff",
		"tuiName": "@tui.file-diff",
		"category": "files",
		"keywords": ["file", "diff"],
		"aliases": ["@tui.file-diff", "@tui.file-diff-filled"],
		"filled": true,
		"filledName": "file-diff-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-digit",
		"tuiName": "@tui.file-digit",
		"category": "files",
		"keywords": ["file", "digit"],
		"aliases": ["@tui.file-digit", "@tui.file-digit-filled"],
		"filled": true,
		"filledName": "file-digit-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-down",
		"tuiName": "@tui.file-down",
		"category": "files",
		"keywords": ["file", "down"],
		"aliases": ["@tui.file-down", "@tui.file-down-filled"],
		"filled": true,
		"filledName": "file-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-edit",
		"tuiName": "@tui.file-edit",
		"category": "files",
		"keywords": ["file", "edit"],
		"aliases": ["@tui.file-edit", "@tui.file-edit-filled"],
		"filled": true,
		"filledName": "file-edit-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-exclamation-point",
		"tuiName": "@tui.file-exclamation-point",
		"category": "files",
		"keywords": [
			"file",
			"exclamation",
			"point"
		],
		"aliases": ["@tui.file-exclamation-point", "@tui.file-exclamation-point-filled"],
		"filled": true,
		"filledName": "file-exclamation-point-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-headphone",
		"tuiName": "@tui.file-headphone",
		"category": "files",
		"keywords": ["file", "headphone"],
		"aliases": ["@tui.file-headphone", "@tui.file-headphone-filled"],
		"filled": true,
		"filledName": "file-headphone-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-heart",
		"tuiName": "@tui.file-heart",
		"category": "files",
		"keywords": ["file", "heart"],
		"aliases": ["@tui.file-heart", "@tui.file-heart-filled"],
		"filled": true,
		"filledName": "file-heart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-image",
		"tuiName": "@tui.file-image",
		"category": "files",
		"keywords": ["file", "image"],
		"aliases": ["@tui.file-image", "@tui.file-image-filled"],
		"filled": true,
		"filledName": "file-image-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-input",
		"tuiName": "@tui.file-input",
		"category": "files",
		"keywords": ["file", "input"],
		"aliases": ["@tui.file-input", "@tui.file-input-filled"],
		"filled": true,
		"filledName": "file-input-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-json",
		"tuiName": "@tui.file-json",
		"category": "files",
		"keywords": ["file", "json"],
		"aliases": ["@tui.file-json", "@tui.file-json-filled"],
		"filled": true,
		"filledName": "file-json-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-json-2",
		"tuiName": "@tui.file-json-2",
		"category": "files",
		"keywords": [
			"file",
			"json",
			"2"
		],
		"aliases": ["@tui.file-json-2", "@tui.file-json-2-filled"],
		"filled": true,
		"filledName": "file-json-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-key",
		"tuiName": "@tui.file-key",
		"category": "files",
		"keywords": ["file", "key"],
		"aliases": ["@tui.file-key", "@tui.file-key-filled"],
		"filled": true,
		"filledName": "file-key-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-key-2",
		"tuiName": "@tui.file-key-2",
		"category": "files",
		"keywords": [
			"file",
			"key",
			"2"
		],
		"aliases": ["@tui.file-key-2", "@tui.file-key-2-filled"],
		"filled": true,
		"filledName": "file-key-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-line-chart",
		"tuiName": "@tui.file-line-chart",
		"category": "files",
		"keywords": [
			"file",
			"line",
			"chart"
		],
		"aliases": ["@tui.file-line-chart", "@tui.file-line-chart-filled"],
		"filled": true,
		"filledName": "file-line-chart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-lock",
		"tuiName": "@tui.file-lock",
		"category": "files",
		"keywords": ["file", "lock"],
		"aliases": ["@tui.file-lock", "@tui.file-lock-filled"],
		"filled": true,
		"filledName": "file-lock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-lock-2",
		"tuiName": "@tui.file-lock-2",
		"category": "files",
		"keywords": [
			"file",
			"lock",
			"2"
		],
		"aliases": ["@tui.file-lock-2", "@tui.file-lock-2-filled"],
		"filled": true,
		"filledName": "file-lock-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-minus",
		"tuiName": "@tui.file-minus",
		"category": "files",
		"keywords": ["file", "minus"],
		"aliases": ["@tui.file-minus", "@tui.file-minus-filled"],
		"filled": true,
		"filledName": "file-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-minus-2",
		"tuiName": "@tui.file-minus-2",
		"category": "files",
		"keywords": [
			"file",
			"minus",
			"2"
		],
		"aliases": ["@tui.file-minus-2", "@tui.file-minus-2-filled"],
		"filled": true,
		"filledName": "file-minus-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-minus-corner",
		"tuiName": "@tui.file-minus-corner",
		"category": "files",
		"keywords": [
			"file",
			"minus",
			"corner"
		],
		"aliases": ["@tui.file-minus-corner", "@tui.file-minus-corner-filled"],
		"filled": true,
		"filledName": "file-minus-corner-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-music",
		"tuiName": "@tui.file-music",
		"category": "files",
		"keywords": ["file", "music"],
		"aliases": ["@tui.file-music", "@tui.file-music-filled"],
		"filled": true,
		"filledName": "file-music-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-output",
		"tuiName": "@tui.file-output",
		"category": "files",
		"keywords": ["file", "output"],
		"aliases": ["@tui.file-output", "@tui.file-output-filled"],
		"filled": true,
		"filledName": "file-output-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-pen",
		"tuiName": "@tui.file-pen",
		"category": "files",
		"keywords": ["file", "pen"],
		"aliases": ["@tui.file-pen", "@tui.file-pen-filled"],
		"filled": true,
		"filledName": "file-pen-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-pen-line",
		"tuiName": "@tui.file-pen-line",
		"category": "files",
		"keywords": [
			"file",
			"pen",
			"line"
		],
		"aliases": ["@tui.file-pen-line", "@tui.file-pen-line-filled"],
		"filled": true,
		"filledName": "file-pen-line-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-pie-chart",
		"tuiName": "@tui.file-pie-chart",
		"category": "files",
		"keywords": [
			"file",
			"pie",
			"chart"
		],
		"aliases": ["@tui.file-pie-chart", "@tui.file-pie-chart-filled"],
		"filled": true,
		"filledName": "file-pie-chart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-play",
		"tuiName": "@tui.file-play",
		"category": "files",
		"keywords": ["file", "play"],
		"aliases": ["@tui.file-play", "@tui.file-play-filled"],
		"filled": true,
		"filledName": "file-play-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-plus",
		"tuiName": "@tui.file-plus",
		"category": "files",
		"keywords": ["file", "plus"],
		"aliases": ["@tui.file-plus", "@tui.file-plus-filled"],
		"filled": true,
		"filledName": "file-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-plus-2",
		"tuiName": "@tui.file-plus-2",
		"category": "files",
		"keywords": [
			"file",
			"plus",
			"2"
		],
		"aliases": ["@tui.file-plus-2", "@tui.file-plus-2-filled"],
		"filled": true,
		"filledName": "file-plus-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-plus-corner",
		"tuiName": "@tui.file-plus-corner",
		"category": "files",
		"keywords": [
			"file",
			"plus",
			"corner"
		],
		"aliases": ["@tui.file-plus-corner", "@tui.file-plus-corner-filled"],
		"filled": true,
		"filledName": "file-plus-corner-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-question",
		"tuiName": "@tui.file-question",
		"category": "files",
		"keywords": ["file", "question"],
		"aliases": ["@tui.file-question", "@tui.file-question-filled"],
		"filled": true,
		"filledName": "file-question-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-question-mark",
		"tuiName": "@tui.file-question-mark",
		"category": "files",
		"keywords": [
			"file",
			"question",
			"mark"
		],
		"aliases": ["@tui.file-question-mark", "@tui.file-question-mark-filled"],
		"filled": true,
		"filledName": "file-question-mark-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-scan",
		"tuiName": "@tui.file-scan",
		"category": "files",
		"keywords": ["file", "scan"],
		"aliases": ["@tui.file-scan", "@tui.file-scan-filled"],
		"filled": true,
		"filledName": "file-scan-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-search",
		"tuiName": "@tui.file-search",
		"category": "files",
		"keywords": ["file", "search"],
		"aliases": ["@tui.file-search", "@tui.file-search-filled"],
		"filled": true,
		"filledName": "file-search-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-search-2",
		"tuiName": "@tui.file-search-2",
		"category": "files",
		"keywords": [
			"file",
			"search",
			"2"
		],
		"aliases": ["@tui.file-search-2", "@tui.file-search-2-filled"],
		"filled": true,
		"filledName": "file-search-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-search-corner",
		"tuiName": "@tui.file-search-corner",
		"category": "files",
		"keywords": [
			"file",
			"search",
			"corner"
		],
		"aliases": ["@tui.file-search-corner", "@tui.file-search-corner-filled"],
		"filled": true,
		"filledName": "file-search-corner-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-signal",
		"tuiName": "@tui.file-signal",
		"category": "files",
		"keywords": ["file", "signal"],
		"aliases": ["@tui.file-signal", "@tui.file-signal-filled"],
		"filled": true,
		"filledName": "file-signal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-signature",
		"tuiName": "@tui.file-signature",
		"category": "files",
		"keywords": ["file", "signature"],
		"aliases": ["@tui.file-signature", "@tui.file-signature-filled"],
		"filled": true,
		"filledName": "file-signature-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-sliders",
		"tuiName": "@tui.file-sliders",
		"category": "files",
		"keywords": ["file", "sliders"],
		"aliases": ["@tui.file-sliders", "@tui.file-sliders-filled"],
		"filled": true,
		"filledName": "file-sliders-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-spreadsheet",
		"tuiName": "@tui.file-spreadsheet",
		"category": "files",
		"keywords": ["file", "spreadsheet"],
		"aliases": ["@tui.file-spreadsheet", "@tui.file-spreadsheet-filled"],
		"filled": true,
		"filledName": "file-spreadsheet-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-stack",
		"tuiName": "@tui.file-stack",
		"category": "files",
		"keywords": ["file", "stack"],
		"aliases": ["@tui.file-stack", "@tui.file-stack-filled"],
		"filled": true,
		"filledName": "file-stack-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-symlink",
		"tuiName": "@tui.file-symlink",
		"category": "files",
		"keywords": ["file", "symlink"],
		"aliases": ["@tui.file-symlink", "@tui.file-symlink-filled"],
		"filled": true,
		"filledName": "file-symlink-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-terminal",
		"tuiName": "@tui.file-terminal",
		"category": "files",
		"keywords": ["file", "terminal"],
		"aliases": ["@tui.file-terminal", "@tui.file-terminal-filled"],
		"filled": true,
		"filledName": "file-terminal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-text",
		"tuiName": "@tui.file-text",
		"category": "files",
		"keywords": ["file", "text"],
		"aliases": ["@tui.file-text", "@tui.file-text-filled"],
		"filled": true,
		"filledName": "file-text-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-type",
		"tuiName": "@tui.file-type",
		"category": "files",
		"keywords": ["file", "type"],
		"aliases": ["@tui.file-type", "@tui.file-type-filled"],
		"filled": true,
		"filledName": "file-type-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-type-2",
		"tuiName": "@tui.file-type-2",
		"category": "files",
		"keywords": [
			"file",
			"type",
			"2"
		],
		"aliases": ["@tui.file-type-2", "@tui.file-type-2-filled"],
		"filled": true,
		"filledName": "file-type-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-type-corner",
		"tuiName": "@tui.file-type-corner",
		"category": "files",
		"keywords": [
			"file",
			"type",
			"corner"
		],
		"aliases": ["@tui.file-type-corner", "@tui.file-type-corner-filled"],
		"filled": true,
		"filledName": "file-type-corner-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-up",
		"tuiName": "@tui.file-up",
		"category": "files",
		"keywords": ["file", "up"],
		"aliases": ["@tui.file-up", "@tui.file-up-filled"],
		"filled": true,
		"filledName": "file-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-user",
		"tuiName": "@tui.file-user",
		"category": "files",
		"keywords": ["file", "user"],
		"aliases": ["@tui.file-user", "@tui.file-user-filled"],
		"filled": true,
		"filledName": "file-user-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-video",
		"tuiName": "@tui.file-video",
		"category": "files",
		"keywords": ["file", "video"],
		"aliases": ["@tui.file-video", "@tui.file-video-filled"],
		"filled": true,
		"filledName": "file-video-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-video-2",
		"tuiName": "@tui.file-video-2",
		"category": "files",
		"keywords": [
			"file",
			"video",
			"2"
		],
		"aliases": ["@tui.file-video-2", "@tui.file-video-2-filled"],
		"filled": true,
		"filledName": "file-video-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-video-camera",
		"tuiName": "@tui.file-video-camera",
		"category": "files",
		"keywords": [
			"file",
			"video",
			"camera"
		],
		"aliases": ["@tui.file-video-camera", "@tui.file-video-camera-filled"],
		"filled": true,
		"filledName": "file-video-camera-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-volume",
		"tuiName": "@tui.file-volume",
		"category": "files",
		"keywords": ["file", "volume"],
		"aliases": ["@tui.file-volume", "@tui.file-volume-filled"],
		"filled": true,
		"filledName": "file-volume-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-volume-2",
		"tuiName": "@tui.file-volume-2",
		"category": "files",
		"keywords": [
			"file",
			"volume",
			"2"
		],
		"aliases": ["@tui.file-volume-2", "@tui.file-volume-2-filled"],
		"filled": true,
		"filledName": "file-volume-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-warning",
		"tuiName": "@tui.file-warning",
		"category": "files",
		"keywords": ["file", "warning"],
		"aliases": ["@tui.file-warning", "@tui.file-warning-filled"],
		"filled": true,
		"filledName": "file-warning-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-x",
		"tuiName": "@tui.file-x",
		"category": "files",
		"keywords": ["file", "x"],
		"aliases": ["@tui.file-x", "@tui.file-x-filled"],
		"filled": true,
		"filledName": "file-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-x-2",
		"tuiName": "@tui.file-x-2",
		"category": "files",
		"keywords": [
			"file",
			"x",
			"2"
		],
		"aliases": ["@tui.file-x-2", "@tui.file-x-2-filled"],
		"filled": true,
		"filledName": "file-x-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "file-x-corner",
		"tuiName": "@tui.file-x-corner",
		"category": "files",
		"keywords": [
			"file",
			"x",
			"corner"
		],
		"aliases": ["@tui.file-x-corner", "@tui.file-x-corner-filled"],
		"filled": true,
		"filledName": "file-x-corner-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "files",
		"tuiName": "@tui.files",
		"category": "files",
		"keywords": ["files"],
		"aliases": ["@tui.files", "@tui.files-filled"],
		"filled": true,
		"filledName": "files-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "film",
		"tuiName": "@tui.film",
		"category": "media",
		"keywords": ["film"],
		"aliases": ["@tui.film", "@tui.film-filled"],
		"filled": true,
		"filledName": "film-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "filter",
		"tuiName": "@tui.filter",
		"category": "actions",
		"keywords": ["filter"],
		"aliases": ["@tui.filter", "@tui.filter-filled"],
		"filled": true,
		"filledName": "filter-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "filter-x",
		"tuiName": "@tui.filter-x",
		"category": "actions",
		"keywords": ["filter", "x"],
		"aliases": ["@tui.filter-x", "@tui.filter-x-filled"],
		"filled": true,
		"filledName": "filter-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "fingerprint",
		"tuiName": "@tui.fingerprint",
		"category": "security",
		"keywords": ["fingerprint"],
		"aliases": ["@tui.fingerprint", "@tui.fingerprint-filled"],
		"filled": true,
		"filledName": "fingerprint-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "fingerprint-pattern",
		"tuiName": "@tui.fingerprint-pattern",
		"category": "security",
		"keywords": ["fingerprint", "pattern"],
		"aliases": ["@tui.fingerprint-pattern", "@tui.fingerprint-pattern-filled"],
		"filled": true,
		"filledName": "fingerprint-pattern-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "fire-extinguisher",
		"tuiName": "@tui.fire-extinguisher",
		"category": "custom",
		"keywords": ["fire", "extinguisher"],
		"aliases": ["@tui.fire-extinguisher", "@tui.fire-extinguisher-filled"],
		"filled": true,
		"filledName": "fire-extinguisher-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "fish",
		"tuiName": "@tui.fish",
		"category": "custom",
		"keywords": ["fish"],
		"aliases": ["@tui.fish", "@tui.fish-filled"],
		"filled": true,
		"filledName": "fish-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "fish-off",
		"tuiName": "@tui.fish-off",
		"category": "custom",
		"keywords": ["fish", "off"],
		"aliases": ["@tui.fish-off", "@tui.fish-off-filled"],
		"filled": true,
		"filledName": "fish-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "fish-symbol",
		"tuiName": "@tui.fish-symbol",
		"category": "custom",
		"keywords": ["fish", "symbol"],
		"aliases": ["@tui.fish-symbol", "@tui.fish-symbol-filled"],
		"filled": true,
		"filledName": "fish-symbol-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "fishing-hook",
		"tuiName": "@tui.fishing-hook",
		"category": "custom",
		"keywords": ["fishing", "hook"],
		"aliases": ["@tui.fishing-hook", "@tui.fishing-hook-filled"],
		"filled": true,
		"filledName": "fishing-hook-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "fishing-rod",
		"tuiName": "@tui.fishing-rod",
		"category": "custom",
		"keywords": ["fishing", "rod"],
		"aliases": ["@tui.fishing-rod", "@tui.fishing-rod-filled"],
		"filled": true,
		"filledName": "fishing-rod-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "flag",
		"tuiName": "@tui.flag",
		"category": "custom",
		"keywords": ["flag"],
		"aliases": ["@tui.flag", "@tui.flag-filled"],
		"filled": true,
		"filledName": "flag-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "flag-off",
		"tuiName": "@tui.flag-off",
		"category": "custom",
		"keywords": ["flag", "off"],
		"aliases": ["@tui.flag-off", "@tui.flag-off-filled"],
		"filled": true,
		"filledName": "flag-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "flag-triangle-left",
		"tuiName": "@tui.flag-triangle-left",
		"category": "custom",
		"keywords": [
			"flag",
			"triangle",
			"left"
		],
		"aliases": ["@tui.flag-triangle-left", "@tui.flag-triangle-left-filled"],
		"filled": true,
		"filledName": "flag-triangle-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "flag-triangle-right",
		"tuiName": "@tui.flag-triangle-right",
		"category": "custom",
		"keywords": [
			"flag",
			"triangle",
			"right"
		],
		"aliases": ["@tui.flag-triangle-right", "@tui.flag-triangle-right-filled"],
		"filled": true,
		"filledName": "flag-triangle-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "flame",
		"tuiName": "@tui.flame",
		"category": "custom",
		"keywords": ["flame"],
		"aliases": ["@tui.flame", "@tui.flame-filled"],
		"filled": true,
		"filledName": "flame-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "flame-kindling",
		"tuiName": "@tui.flame-kindling",
		"category": "custom",
		"keywords": ["flame", "kindling"],
		"aliases": ["@tui.flame-kindling", "@tui.flame-kindling-filled"],
		"filled": true,
		"filledName": "flame-kindling-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "flashlight",
		"tuiName": "@tui.flashlight",
		"category": "custom",
		"keywords": ["flashlight"],
		"aliases": ["@tui.flashlight", "@tui.flashlight-filled"],
		"filled": true,
		"filledName": "flashlight-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "flashlight-off",
		"tuiName": "@tui.flashlight-off",
		"category": "custom",
		"keywords": ["flashlight", "off"],
		"aliases": ["@tui.flashlight-off", "@tui.flashlight-off-filled"],
		"filled": true,
		"filledName": "flashlight-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "flask-conical",
		"tuiName": "@tui.flask-conical",
		"category": "custom",
		"keywords": ["flask", "conical"],
		"aliases": ["@tui.flask-conical", "@tui.flask-conical-filled"],
		"filled": true,
		"filledName": "flask-conical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "flask-conical-off",
		"tuiName": "@tui.flask-conical-off",
		"category": "custom",
		"keywords": [
			"flask",
			"conical",
			"off"
		],
		"aliases": ["@tui.flask-conical-off", "@tui.flask-conical-off-filled"],
		"filled": true,
		"filledName": "flask-conical-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "flask-round",
		"tuiName": "@tui.flask-round",
		"category": "custom",
		"keywords": ["flask", "round"],
		"aliases": ["@tui.flask-round", "@tui.flask-round-filled"],
		"filled": true,
		"filledName": "flask-round-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "flip-horizontal",
		"tuiName": "@tui.flip-horizontal",
		"category": "layout",
		"keywords": ["flip", "horizontal"],
		"aliases": ["@tui.flip-horizontal", "@tui.flip-horizontal-filled"],
		"filled": true,
		"filledName": "flip-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "flip-horizontal-2",
		"tuiName": "@tui.flip-horizontal-2",
		"category": "layout",
		"keywords": [
			"flip",
			"horizontal",
			"2"
		],
		"aliases": ["@tui.flip-horizontal-2", "@tui.flip-horizontal-2-filled"],
		"filled": true,
		"filledName": "flip-horizontal-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "flip-vertical",
		"tuiName": "@tui.flip-vertical",
		"category": "layout",
		"keywords": ["flip", "vertical"],
		"aliases": ["@tui.flip-vertical", "@tui.flip-vertical-filled"],
		"filled": true,
		"filledName": "flip-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "flip-vertical-2",
		"tuiName": "@tui.flip-vertical-2",
		"category": "layout",
		"keywords": [
			"flip",
			"vertical",
			"2"
		],
		"aliases": ["@tui.flip-vertical-2", "@tui.flip-vertical-2-filled"],
		"filled": true,
		"filledName": "flip-vertical-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "flower",
		"tuiName": "@tui.flower",
		"category": "custom",
		"keywords": ["flower"],
		"aliases": ["@tui.flower", "@tui.flower-filled"],
		"filled": true,
		"filledName": "flower-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "flower-2",
		"tuiName": "@tui.flower-2",
		"category": "custom",
		"keywords": ["flower", "2"],
		"aliases": ["@tui.flower-2", "@tui.flower-2-filled"],
		"filled": true,
		"filledName": "flower-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "focus",
		"tuiName": "@tui.focus",
		"category": "media",
		"keywords": ["focus"],
		"aliases": ["@tui.focus", "@tui.focus-filled"],
		"filled": true,
		"filledName": "focus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "fold-horizontal",
		"tuiName": "@tui.fold-horizontal",
		"category": "arrows",
		"keywords": ["fold", "horizontal"],
		"aliases": ["@tui.fold-horizontal", "@tui.fold-horizontal-filled"],
		"filled": true,
		"filledName": "fold-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "fold-vertical",
		"tuiName": "@tui.fold-vertical",
		"category": "arrows",
		"keywords": ["fold", "vertical"],
		"aliases": ["@tui.fold-vertical", "@tui.fold-vertical-filled"],
		"filled": true,
		"filledName": "fold-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder",
		"tuiName": "@tui.folder",
		"category": "arrows",
		"keywords": ["folder"],
		"aliases": ["@tui.folder", "@tui.folder-filled"],
		"filled": true,
		"filledName": "folder-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-archive",
		"tuiName": "@tui.folder-archive",
		"category": "arrows",
		"keywords": ["folder", "archive"],
		"aliases": ["@tui.folder-archive", "@tui.folder-archive-filled"],
		"filled": true,
		"filledName": "folder-archive-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-bookmark",
		"tuiName": "@tui.folder-bookmark",
		"category": "arrows",
		"keywords": ["folder", "bookmark"],
		"aliases": ["@tui.folder-bookmark", "@tui.folder-bookmark-filled"],
		"filled": true,
		"filledName": "folder-bookmark-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-check",
		"tuiName": "@tui.folder-check",
		"category": "arrows",
		"keywords": ["folder", "check"],
		"aliases": ["@tui.folder-check", "@tui.folder-check-filled"],
		"filled": true,
		"filledName": "folder-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-clock",
		"tuiName": "@tui.folder-clock",
		"category": "arrows",
		"keywords": ["folder", "clock"],
		"aliases": ["@tui.folder-clock", "@tui.folder-clock-filled"],
		"filled": true,
		"filledName": "folder-clock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-closed",
		"tuiName": "@tui.folder-closed",
		"category": "arrows",
		"keywords": ["folder", "closed"],
		"aliases": ["@tui.folder-closed", "@tui.folder-closed-filled"],
		"filled": true,
		"filledName": "folder-closed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-code",
		"tuiName": "@tui.folder-code",
		"category": "arrows",
		"keywords": ["folder", "code"],
		"aliases": ["@tui.folder-code", "@tui.folder-code-filled"],
		"filled": true,
		"filledName": "folder-code-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-cog",
		"tuiName": "@tui.folder-cog",
		"category": "arrows",
		"keywords": ["folder", "cog"],
		"aliases": ["@tui.folder-cog", "@tui.folder-cog-filled"],
		"filled": true,
		"filledName": "folder-cog-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-cog-2",
		"tuiName": "@tui.folder-cog-2",
		"category": "arrows",
		"keywords": [
			"folder",
			"cog",
			"2"
		],
		"aliases": ["@tui.folder-cog-2", "@tui.folder-cog-2-filled"],
		"filled": true,
		"filledName": "folder-cog-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-dot",
		"tuiName": "@tui.folder-dot",
		"category": "arrows",
		"keywords": ["folder", "dot"],
		"aliases": ["@tui.folder-dot", "@tui.folder-dot-filled"],
		"filled": true,
		"filledName": "folder-dot-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-down",
		"tuiName": "@tui.folder-down",
		"category": "arrows",
		"keywords": ["folder", "down"],
		"aliases": ["@tui.folder-down", "@tui.folder-down-filled"],
		"filled": true,
		"filledName": "folder-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-edit",
		"tuiName": "@tui.folder-edit",
		"category": "arrows",
		"keywords": ["folder", "edit"],
		"aliases": ["@tui.folder-edit", "@tui.folder-edit-filled"],
		"filled": true,
		"filledName": "folder-edit-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-git",
		"tuiName": "@tui.folder-git",
		"category": "arrows",
		"keywords": ["folder", "git"],
		"aliases": ["@tui.folder-git", "@tui.folder-git-filled"],
		"filled": true,
		"filledName": "folder-git-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-git-2",
		"tuiName": "@tui.folder-git-2",
		"category": "arrows",
		"keywords": [
			"folder",
			"git",
			"2"
		],
		"aliases": ["@tui.folder-git-2", "@tui.folder-git-2-filled"],
		"filled": true,
		"filledName": "folder-git-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-heart",
		"tuiName": "@tui.folder-heart",
		"category": "arrows",
		"keywords": ["folder", "heart"],
		"aliases": ["@tui.folder-heart", "@tui.folder-heart-filled"],
		"filled": true,
		"filledName": "folder-heart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-input",
		"tuiName": "@tui.folder-input",
		"category": "arrows",
		"keywords": ["folder", "input"],
		"aliases": ["@tui.folder-input", "@tui.folder-input-filled"],
		"filled": true,
		"filledName": "folder-input-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-kanban",
		"tuiName": "@tui.folder-kanban",
		"category": "arrows",
		"keywords": ["folder", "kanban"],
		"aliases": ["@tui.folder-kanban", "@tui.folder-kanban-filled"],
		"filled": true,
		"filledName": "folder-kanban-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-key",
		"tuiName": "@tui.folder-key",
		"category": "arrows",
		"keywords": ["folder", "key"],
		"aliases": ["@tui.folder-key", "@tui.folder-key-filled"],
		"filled": true,
		"filledName": "folder-key-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-lock",
		"tuiName": "@tui.folder-lock",
		"category": "arrows",
		"keywords": ["folder", "lock"],
		"aliases": ["@tui.folder-lock", "@tui.folder-lock-filled"],
		"filled": true,
		"filledName": "folder-lock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-minus",
		"tuiName": "@tui.folder-minus",
		"category": "arrows",
		"keywords": ["folder", "minus"],
		"aliases": ["@tui.folder-minus", "@tui.folder-minus-filled"],
		"filled": true,
		"filledName": "folder-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-open",
		"tuiName": "@tui.folder-open",
		"category": "arrows",
		"keywords": ["folder", "open"],
		"aliases": ["@tui.folder-open", "@tui.folder-open-filled"],
		"filled": true,
		"filledName": "folder-open-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-open-dot",
		"tuiName": "@tui.folder-open-dot",
		"category": "arrows",
		"keywords": [
			"folder",
			"open",
			"dot"
		],
		"aliases": ["@tui.folder-open-dot", "@tui.folder-open-dot-filled"],
		"filled": true,
		"filledName": "folder-open-dot-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-output",
		"tuiName": "@tui.folder-output",
		"category": "arrows",
		"keywords": ["folder", "output"],
		"aliases": ["@tui.folder-output", "@tui.folder-output-filled"],
		"filled": true,
		"filledName": "folder-output-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-pen",
		"tuiName": "@tui.folder-pen",
		"category": "arrows",
		"keywords": ["folder", "pen"],
		"aliases": ["@tui.folder-pen", "@tui.folder-pen-filled"],
		"filled": true,
		"filledName": "folder-pen-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-plus",
		"tuiName": "@tui.folder-plus",
		"category": "arrows",
		"keywords": ["folder", "plus"],
		"aliases": ["@tui.folder-plus", "@tui.folder-plus-filled"],
		"filled": true,
		"filledName": "folder-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-root",
		"tuiName": "@tui.folder-root",
		"category": "arrows",
		"keywords": ["folder", "root"],
		"aliases": ["@tui.folder-root", "@tui.folder-root-filled"],
		"filled": true,
		"filledName": "folder-root-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-search",
		"tuiName": "@tui.folder-search",
		"category": "arrows",
		"keywords": ["folder", "search"],
		"aliases": ["@tui.folder-search", "@tui.folder-search-filled"],
		"filled": true,
		"filledName": "folder-search-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-search-2",
		"tuiName": "@tui.folder-search-2",
		"category": "arrows",
		"keywords": [
			"folder",
			"search",
			"2"
		],
		"aliases": ["@tui.folder-search-2", "@tui.folder-search-2-filled"],
		"filled": true,
		"filledName": "folder-search-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-symlink",
		"tuiName": "@tui.folder-symlink",
		"category": "arrows",
		"keywords": ["folder", "symlink"],
		"aliases": ["@tui.folder-symlink", "@tui.folder-symlink-filled"],
		"filled": true,
		"filledName": "folder-symlink-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-sync",
		"tuiName": "@tui.folder-sync",
		"category": "arrows",
		"keywords": ["folder", "sync"],
		"aliases": ["@tui.folder-sync", "@tui.folder-sync-filled"],
		"filled": true,
		"filledName": "folder-sync-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-tree",
		"tuiName": "@tui.folder-tree",
		"category": "arrows",
		"keywords": ["folder", "tree"],
		"aliases": ["@tui.folder-tree", "@tui.folder-tree-filled"],
		"filled": true,
		"filledName": "folder-tree-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-up",
		"tuiName": "@tui.folder-up",
		"category": "arrows",
		"keywords": ["folder", "up"],
		"aliases": ["@tui.folder-up", "@tui.folder-up-filled"],
		"filled": true,
		"filledName": "folder-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-user",
		"tuiName": "@tui.folder-user",
		"category": "arrows",
		"keywords": ["folder", "user"],
		"aliases": ["@tui.folder-user", "@tui.folder-user-filled"],
		"filled": true,
		"filledName": "folder-user-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-users",
		"tuiName": "@tui.folder-users",
		"category": "arrows",
		"keywords": ["folder", "users"],
		"aliases": ["@tui.folder-users", "@tui.folder-users-filled"],
		"filled": true,
		"filledName": "folder-users-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folder-x",
		"tuiName": "@tui.folder-x",
		"category": "arrows",
		"keywords": ["folder", "x"],
		"aliases": ["@tui.folder-x", "@tui.folder-x-filled"],
		"filled": true,
		"filledName": "folder-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "folders",
		"tuiName": "@tui.folders",
		"category": "arrows",
		"keywords": ["folders"],
		"aliases": ["@tui.folders", "@tui.folders-filled"],
		"filled": true,
		"filledName": "folders-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "footprints",
		"tuiName": "@tui.footprints",
		"category": "custom",
		"keywords": ["footprints"],
		"aliases": ["@tui.footprints", "@tui.footprints-filled"],
		"filled": true,
		"filledName": "footprints-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "fork-knife",
		"tuiName": "@tui.fork-knife",
		"category": "custom",
		"keywords": ["fork", "knife"],
		"aliases": ["@tui.fork-knife", "@tui.fork-knife-filled"],
		"filled": true,
		"filledName": "fork-knife-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "fork-knife-crossed",
		"tuiName": "@tui.fork-knife-crossed",
		"category": "custom",
		"keywords": [
			"fork",
			"knife",
			"crossed"
		],
		"aliases": ["@tui.fork-knife-crossed", "@tui.fork-knife-crossed-filled"],
		"filled": true,
		"filledName": "fork-knife-crossed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "forklift",
		"tuiName": "@tui.forklift",
		"category": "custom",
		"keywords": ["forklift"],
		"aliases": ["@tui.forklift", "@tui.forklift-filled"],
		"filled": true,
		"filledName": "forklift-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "form",
		"tuiName": "@tui.form",
		"category": "custom",
		"keywords": ["form"],
		"aliases": ["@tui.form", "@tui.form-filled"],
		"filled": true,
		"filledName": "form-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "form-input",
		"tuiName": "@tui.form-input",
		"category": "custom",
		"keywords": ["form", "input"],
		"aliases": ["@tui.form-input", "@tui.form-input-filled"],
		"filled": true,
		"filledName": "form-input-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "forward",
		"tuiName": "@tui.forward",
		"category": "arrows",
		"keywords": ["forward"],
		"aliases": ["@tui.forward", "@tui.forward-filled"],
		"filled": true,
		"filledName": "forward-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "frame",
		"tuiName": "@tui.frame",
		"category": "custom",
		"keywords": ["frame"],
		"aliases": ["@tui.frame", "@tui.frame-filled"],
		"filled": true,
		"filledName": "frame-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "frown",
		"tuiName": "@tui.frown",
		"category": "status-feedback",
		"keywords": ["frown"],
		"aliases": ["@tui.frown", "@tui.frown-filled"],
		"filled": true,
		"filledName": "frown-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "fuel",
		"tuiName": "@tui.fuel",
		"category": "custom",
		"keywords": ["fuel"],
		"aliases": ["@tui.fuel", "@tui.fuel-filled"],
		"filled": true,
		"filledName": "fuel-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "fullscreen",
		"tuiName": "@tui.fullscreen",
		"category": "actions",
		"keywords": ["fullscreen"],
		"aliases": ["@tui.fullscreen", "@tui.fullscreen-filled"],
		"filled": true,
		"filledName": "fullscreen-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "function-square",
		"tuiName": "@tui.function-square",
		"category": "custom",
		"keywords": ["function", "square"],
		"aliases": ["@tui.function-square", "@tui.function-square-filled"],
		"filled": true,
		"filledName": "function-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "funnel",
		"tuiName": "@tui.funnel",
		"category": "custom",
		"keywords": ["funnel"],
		"aliases": ["@tui.funnel", "@tui.funnel-filled"],
		"filled": true,
		"filledName": "funnel-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "funnel-plus",
		"tuiName": "@tui.funnel-plus",
		"category": "custom",
		"keywords": ["funnel", "plus"],
		"aliases": ["@tui.funnel-plus", "@tui.funnel-plus-filled"],
		"filled": true,
		"filledName": "funnel-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "funnel-x",
		"tuiName": "@tui.funnel-x",
		"category": "custom",
		"keywords": ["funnel", "x"],
		"aliases": ["@tui.funnel-x", "@tui.funnel-x-filled"],
		"filled": true,
		"filledName": "funnel-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "galaxy",
		"tuiName": "@tui.galaxy",
		"category": "custom",
		"keywords": ["galaxy"],
		"aliases": ["@tui.galaxy", "@tui.galaxy-filled"],
		"filled": true,
		"filledName": "galaxy-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "gallery-horizontal",
		"tuiName": "@tui.gallery-horizontal",
		"category": "navigation",
		"keywords": ["gallery", "horizontal"],
		"aliases": ["@tui.gallery-horizontal", "@tui.gallery-horizontal-filled"],
		"filled": true,
		"filledName": "gallery-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "gallery-horizontal-end",
		"tuiName": "@tui.gallery-horizontal-end",
		"category": "navigation",
		"keywords": [
			"gallery",
			"horizontal",
			"end"
		],
		"aliases": ["@tui.gallery-horizontal-end", "@tui.gallery-horizontal-end-filled"],
		"filled": true,
		"filledName": "gallery-horizontal-end-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "gallery-thumbnails",
		"tuiName": "@tui.gallery-thumbnails",
		"category": "media",
		"keywords": ["gallery", "thumbnails"],
		"aliases": ["@tui.gallery-thumbnails", "@tui.gallery-thumbnails-filled"],
		"filled": true,
		"filledName": "gallery-thumbnails-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "gallery-vertical",
		"tuiName": "@tui.gallery-vertical",
		"category": "navigation",
		"keywords": ["gallery", "vertical"],
		"aliases": ["@tui.gallery-vertical", "@tui.gallery-vertical-filled"],
		"filled": true,
		"filledName": "gallery-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "gallery-vertical-end",
		"tuiName": "@tui.gallery-vertical-end",
		"category": "navigation",
		"keywords": [
			"gallery",
			"vertical",
			"end"
		],
		"aliases": ["@tui.gallery-vertical-end", "@tui.gallery-vertical-end-filled"],
		"filled": true,
		"filledName": "gallery-vertical-end-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "gamepad",
		"tuiName": "@tui.gamepad",
		"category": "devices",
		"keywords": ["gamepad"],
		"aliases": ["@tui.gamepad", "@tui.gamepad-filled"],
		"filled": true,
		"filledName": "gamepad-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "gamepad-2",
		"tuiName": "@tui.gamepad-2",
		"category": "devices",
		"keywords": ["gamepad", "2"],
		"aliases": ["@tui.gamepad-2", "@tui.gamepad-2-filled"],
		"filled": true,
		"filledName": "gamepad-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "gamepad-directional",
		"tuiName": "@tui.gamepad-directional",
		"category": "devices",
		"keywords": ["gamepad", "directional"],
		"aliases": ["@tui.gamepad-directional", "@tui.gamepad-directional-filled"],
		"filled": true,
		"filledName": "gamepad-directional-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "gantt-chart",
		"tuiName": "@tui.gantt-chart",
		"category": "custom",
		"keywords": ["gantt", "chart"],
		"aliases": ["@tui.gantt-chart", "@tui.gantt-chart-filled"],
		"filled": true,
		"filledName": "gantt-chart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "gantt-chart-square",
		"tuiName": "@tui.gantt-chart-square",
		"category": "custom",
		"keywords": [
			"gantt",
			"chart",
			"square"
		],
		"aliases": ["@tui.gantt-chart-square", "@tui.gantt-chart-square-filled"],
		"filled": true,
		"filledName": "gantt-chart-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "gap-horizontal",
		"tuiName": "@tui.gap-horizontal",
		"category": "navigation",
		"keywords": ["gap", "horizontal"],
		"aliases": ["@tui.gap-horizontal", "@tui.gap-horizontal-filled"],
		"filled": true,
		"filledName": "gap-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "gap-vertical",
		"tuiName": "@tui.gap-vertical",
		"category": "navigation",
		"keywords": ["gap", "vertical"],
		"aliases": ["@tui.gap-vertical", "@tui.gap-vertical-filled"],
		"filled": true,
		"filledName": "gap-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "gauge",
		"tuiName": "@tui.gauge",
		"category": "custom",
		"keywords": ["gauge"],
		"aliases": ["@tui.gauge", "@tui.gauge-filled"],
		"filled": true,
		"filledName": "gauge-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "gauge-circle",
		"tuiName": "@tui.gauge-circle",
		"category": "custom",
		"keywords": ["gauge", "circle"],
		"aliases": ["@tui.gauge-circle", "@tui.gauge-circle-filled"],
		"filled": true,
		"filledName": "gauge-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "gavel",
		"tuiName": "@tui.gavel",
		"category": "custom",
		"keywords": ["gavel"],
		"aliases": ["@tui.gavel", "@tui.gavel-filled"],
		"filled": true,
		"filledName": "gavel-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "gem",
		"tuiName": "@tui.gem",
		"category": "custom",
		"keywords": ["gem"],
		"aliases": ["@tui.gem", "@tui.gem-filled"],
		"filled": true,
		"filledName": "gem-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "georgian-lari",
		"tuiName": "@tui.georgian-lari",
		"category": "custom",
		"keywords": ["georgian", "lari"],
		"aliases": ["@tui.georgian-lari", "@tui.georgian-lari-filled"],
		"filled": true,
		"filledName": "georgian-lari-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "germ",
		"tuiName": "@tui.germ",
		"category": "custom",
		"keywords": ["germ"],
		"aliases": ["@tui.germ", "@tui.germ-filled"],
		"filled": true,
		"filledName": "germ-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "germ-off",
		"tuiName": "@tui.germ-off",
		"category": "custom",
		"keywords": ["germ", "off"],
		"aliases": ["@tui.germ-off", "@tui.germ-off-filled"],
		"filled": true,
		"filledName": "germ-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ghost",
		"tuiName": "@tui.ghost",
		"category": "custom",
		"keywords": ["ghost"],
		"aliases": ["@tui.ghost", "@tui.ghost-filled"],
		"filled": true,
		"filledName": "ghost-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "gift",
		"tuiName": "@tui.gift",
		"category": "commerce",
		"keywords": ["gift"],
		"aliases": ["@tui.gift", "@tui.gift-filled"],
		"filled": true,
		"filledName": "gift-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "git-branch",
		"tuiName": "@tui.git-branch",
		"category": "development",
		"keywords": ["git", "branch"],
		"aliases": ["@tui.git-branch", "@tui.git-branch-filled"],
		"filled": true,
		"filledName": "git-branch-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "git-branch-minus",
		"tuiName": "@tui.git-branch-minus",
		"category": "development",
		"keywords": [
			"git",
			"branch",
			"minus"
		],
		"aliases": ["@tui.git-branch-minus", "@tui.git-branch-minus-filled"],
		"filled": true,
		"filledName": "git-branch-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "git-branch-plus",
		"tuiName": "@tui.git-branch-plus",
		"category": "development",
		"keywords": [
			"git",
			"branch",
			"plus"
		],
		"aliases": ["@tui.git-branch-plus", "@tui.git-branch-plus-filled"],
		"filled": true,
		"filledName": "git-branch-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "git-commit",
		"tuiName": "@tui.git-commit",
		"category": "development",
		"keywords": ["git", "commit"],
		"aliases": ["@tui.git-commit", "@tui.git-commit-filled"],
		"filled": true,
		"filledName": "git-commit-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "git-commit-horizontal",
		"tuiName": "@tui.git-commit-horizontal",
		"category": "development",
		"keywords": [
			"git",
			"commit",
			"horizontal"
		],
		"aliases": ["@tui.git-commit-horizontal", "@tui.git-commit-horizontal-filled"],
		"filled": true,
		"filledName": "git-commit-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "git-commit-vertical",
		"tuiName": "@tui.git-commit-vertical",
		"category": "development",
		"keywords": [
			"git",
			"commit",
			"vertical"
		],
		"aliases": ["@tui.git-commit-vertical", "@tui.git-commit-vertical-filled"],
		"filled": true,
		"filledName": "git-commit-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "git-compare",
		"tuiName": "@tui.git-compare",
		"category": "development",
		"keywords": ["git", "compare"],
		"aliases": ["@tui.git-compare", "@tui.git-compare-filled"],
		"filled": true,
		"filledName": "git-compare-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "git-compare-arrows",
		"tuiName": "@tui.git-compare-arrows",
		"category": "development",
		"keywords": [
			"git",
			"compare",
			"arrows"
		],
		"aliases": ["@tui.git-compare-arrows", "@tui.git-compare-arrows-filled"],
		"filled": true,
		"filledName": "git-compare-arrows-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "git-fork",
		"tuiName": "@tui.git-fork",
		"category": "development",
		"keywords": ["git", "fork"],
		"aliases": ["@tui.git-fork", "@tui.git-fork-filled"],
		"filled": true,
		"filledName": "git-fork-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "git-graph",
		"tuiName": "@tui.git-graph",
		"category": "development",
		"keywords": ["git", "graph"],
		"aliases": ["@tui.git-graph", "@tui.git-graph-filled"],
		"filled": true,
		"filledName": "git-graph-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "git-merge",
		"tuiName": "@tui.git-merge",
		"category": "development",
		"keywords": ["git", "merge"],
		"aliases": ["@tui.git-merge", "@tui.git-merge-filled"],
		"filled": true,
		"filledName": "git-merge-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "git-merge-conflict",
		"tuiName": "@tui.git-merge-conflict",
		"category": "development",
		"keywords": [
			"git",
			"merge",
			"conflict"
		],
		"aliases": ["@tui.git-merge-conflict", "@tui.git-merge-conflict-filled"],
		"filled": true,
		"filledName": "git-merge-conflict-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "git-pull-request",
		"tuiName": "@tui.git-pull-request",
		"category": "development",
		"keywords": [
			"git",
			"pull",
			"request"
		],
		"aliases": ["@tui.git-pull-request", "@tui.git-pull-request-filled"],
		"filled": true,
		"filledName": "git-pull-request-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "git-pull-request-arrow",
		"tuiName": "@tui.git-pull-request-arrow",
		"category": "development",
		"keywords": [
			"git",
			"pull",
			"request",
			"arrow"
		],
		"aliases": ["@tui.git-pull-request-arrow", "@tui.git-pull-request-arrow-filled"],
		"filled": true,
		"filledName": "git-pull-request-arrow-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "git-pull-request-closed",
		"tuiName": "@tui.git-pull-request-closed",
		"category": "development",
		"keywords": [
			"git",
			"pull",
			"request",
			"closed"
		],
		"aliases": ["@tui.git-pull-request-closed", "@tui.git-pull-request-closed-filled"],
		"filled": true,
		"filledName": "git-pull-request-closed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "git-pull-request-create",
		"tuiName": "@tui.git-pull-request-create",
		"category": "development",
		"keywords": [
			"git",
			"pull",
			"request",
			"create"
		],
		"aliases": ["@tui.git-pull-request-create", "@tui.git-pull-request-create-filled"],
		"filled": true,
		"filledName": "git-pull-request-create-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "git-pull-request-create-arrow",
		"tuiName": "@tui.git-pull-request-create-arrow",
		"category": "development",
		"keywords": [
			"git",
			"pull",
			"request",
			"create",
			"arrow"
		],
		"aliases": ["@tui.git-pull-request-create-arrow", "@tui.git-pull-request-create-arrow-filled"],
		"filled": true,
		"filledName": "git-pull-request-create-arrow-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "git-pull-request-draft",
		"tuiName": "@tui.git-pull-request-draft",
		"category": "development",
		"keywords": [
			"git",
			"pull",
			"request",
			"draft"
		],
		"aliases": ["@tui.git-pull-request-draft", "@tui.git-pull-request-draft-filled"],
		"filled": true,
		"filledName": "git-pull-request-draft-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "github",
		"tuiName": "@tui.github",
		"category": "development",
		"keywords": ["github"],
		"aliases": ["@tui.github"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "glass-water",
		"tuiName": "@tui.glass-water",
		"category": "custom",
		"keywords": ["glass", "water"],
		"aliases": ["@tui.glass-water", "@tui.glass-water-filled"],
		"filled": true,
		"filledName": "glass-water-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "glasses",
		"tuiName": "@tui.glasses",
		"category": "accessibility",
		"keywords": ["glasses"],
		"aliases": ["@tui.glasses", "@tui.glasses-filled"],
		"filled": true,
		"filledName": "glasses-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "globe",
		"tuiName": "@tui.globe",
		"category": "maps-location",
		"keywords": ["globe"],
		"aliases": ["@tui.globe", "@tui.globe-filled"],
		"filled": true,
		"filledName": "globe-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "globe-2",
		"tuiName": "@tui.globe-2",
		"category": "maps-location",
		"keywords": ["globe", "2"],
		"aliases": ["@tui.globe-2", "@tui.globe-2-filled"],
		"filled": true,
		"filledName": "globe-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "globe-check",
		"tuiName": "@tui.globe-check",
		"category": "maps-location",
		"keywords": ["globe", "check"],
		"aliases": ["@tui.globe-check", "@tui.globe-check-filled"],
		"filled": true,
		"filledName": "globe-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "globe-code",
		"tuiName": "@tui.globe-code",
		"category": "maps-location",
		"keywords": ["globe", "code"],
		"aliases": ["@tui.globe-code", "@tui.globe-code-filled"],
		"filled": true,
		"filledName": "globe-code-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "globe-lock",
		"tuiName": "@tui.globe-lock",
		"category": "maps-location",
		"keywords": ["globe", "lock"],
		"aliases": ["@tui.globe-lock", "@tui.globe-lock-filled"],
		"filled": true,
		"filledName": "globe-lock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "globe-off",
		"tuiName": "@tui.globe-off",
		"category": "maps-location",
		"keywords": ["globe", "off"],
		"aliases": ["@tui.globe-off", "@tui.globe-off-filled"],
		"filled": true,
		"filledName": "globe-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "globe-x",
		"tuiName": "@tui.globe-x",
		"category": "maps-location",
		"keywords": ["globe", "x"],
		"aliases": ["@tui.globe-x", "@tui.globe-x-filled"],
		"filled": true,
		"filledName": "globe-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "goal",
		"tuiName": "@tui.goal",
		"category": "custom",
		"keywords": ["goal"],
		"aliases": ["@tui.goal", "@tui.goal-filled"],
		"filled": true,
		"filledName": "goal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "google-pay",
		"tuiName": "@tui.google-pay",
		"category": "custom",
		"keywords": ["google", "pay"],
		"aliases": ["@tui.google-pay"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "gpu",
		"tuiName": "@tui.gpu",
		"category": "custom",
		"keywords": ["gpu"],
		"aliases": ["@tui.gpu", "@tui.gpu-filled"],
		"filled": true,
		"filledName": "gpu-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "grab",
		"tuiName": "@tui.grab",
		"category": "custom",
		"keywords": ["grab"],
		"aliases": ["@tui.grab", "@tui.grab-filled"],
		"filled": true,
		"filledName": "grab-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "graduation-cap",
		"tuiName": "@tui.graduation-cap",
		"category": "custom",
		"keywords": ["graduation", "cap"],
		"aliases": ["@tui.graduation-cap", "@tui.graduation-cap-filled"],
		"filled": true,
		"filledName": "graduation-cap-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "grape",
		"tuiName": "@tui.grape",
		"category": "custom",
		"keywords": ["grape"],
		"aliases": ["@tui.grape", "@tui.grape-filled"],
		"filled": true,
		"filledName": "grape-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "graph-star",
		"tuiName": "@tui.graph-star",
		"category": "custom",
		"keywords": ["graph", "star"],
		"aliases": ["@tui.graph-star", "@tui.graph-star-filled"],
		"filled": true,
		"filledName": "graph-star-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "grid",
		"tuiName": "@tui.grid",
		"category": "layout",
		"keywords": ["grid"],
		"aliases": ["@tui.grid", "@tui.grid-filled"],
		"filled": true,
		"filledName": "grid-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "grid-2-x-2",
		"tuiName": "@tui.grid-2-x-2",
		"category": "layout",
		"keywords": [
			"grid",
			"2",
			"x",
			"2"
		],
		"aliases": ["@tui.grid-2-x-2", "@tui.grid-2-x-2-filled"],
		"filled": true,
		"filledName": "grid-2-x-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "grid-2-x-2-check",
		"tuiName": "@tui.grid-2-x-2-check",
		"category": "layout",
		"keywords": [
			"grid",
			"2",
			"x",
			"2",
			"check"
		],
		"aliases": ["@tui.grid-2-x-2-check", "@tui.grid-2-x-2-check-filled"],
		"filled": true,
		"filledName": "grid-2-x-2-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "grid-2-x-2-plus",
		"tuiName": "@tui.grid-2-x-2-plus",
		"category": "layout",
		"keywords": [
			"grid",
			"2",
			"x",
			"2",
			"plus"
		],
		"aliases": ["@tui.grid-2-x-2-plus", "@tui.grid-2-x-2-plus-filled"],
		"filled": true,
		"filledName": "grid-2-x-2-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "grid-2-x-2-x",
		"tuiName": "@tui.grid-2-x-2-x",
		"category": "layout",
		"keywords": [
			"grid",
			"2",
			"x",
			"2",
			"x"
		],
		"aliases": ["@tui.grid-2-x-2-x", "@tui.grid-2-x-2-x-filled"],
		"filled": true,
		"filledName": "grid-2-x-2-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "grid-2x2",
		"tuiName": "@tui.grid-2x2",
		"category": "layout",
		"keywords": ["grid", "2x2"],
		"aliases": ["@tui.grid-2x2", "@tui.grid-2x2-filled"],
		"filled": true,
		"filledName": "grid-2x2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "grid-2x2-check",
		"tuiName": "@tui.grid-2x2-check",
		"category": "layout",
		"keywords": [
			"grid",
			"2x2",
			"check"
		],
		"aliases": ["@tui.grid-2x2-check", "@tui.grid-2x2-check-filled"],
		"filled": true,
		"filledName": "grid-2x2-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "grid-2x2-plus",
		"tuiName": "@tui.grid-2x2-plus",
		"category": "layout",
		"keywords": [
			"grid",
			"2x2",
			"plus"
		],
		"aliases": ["@tui.grid-2x2-plus", "@tui.grid-2x2-plus-filled"],
		"filled": true,
		"filledName": "grid-2x2-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "grid-2x2-x",
		"tuiName": "@tui.grid-2x2-x",
		"category": "layout",
		"keywords": [
			"grid",
			"2x2",
			"x"
		],
		"aliases": ["@tui.grid-2x2-x", "@tui.grid-2x2-x-filled"],
		"filled": true,
		"filledName": "grid-2x2-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "grid-3-x-3",
		"tuiName": "@tui.grid-3-x-3",
		"category": "layout",
		"keywords": [
			"grid",
			"3",
			"x",
			"3"
		],
		"aliases": ["@tui.grid-3-x-3", "@tui.grid-3-x-3-filled"],
		"filled": true,
		"filledName": "grid-3-x-3-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "grid-3x2",
		"tuiName": "@tui.grid-3x2",
		"category": "layout",
		"keywords": ["grid", "3x2"],
		"aliases": ["@tui.grid-3x2", "@tui.grid-3x2-filled"],
		"filled": true,
		"filledName": "grid-3x2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "grid-3x3",
		"tuiName": "@tui.grid-3x3",
		"category": "layout",
		"keywords": ["grid", "3x3"],
		"aliases": ["@tui.grid-3x3", "@tui.grid-3x3-filled"],
		"filled": true,
		"filledName": "grid-3x3-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "grip",
		"tuiName": "@tui.grip",
		"category": "custom",
		"keywords": ["grip"],
		"aliases": ["@tui.grip", "@tui.grip-filled"],
		"filled": true,
		"filledName": "grip-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "grip-horizontal",
		"tuiName": "@tui.grip-horizontal",
		"category": "custom",
		"keywords": ["grip", "horizontal"],
		"aliases": ["@tui.grip-horizontal", "@tui.grip-horizontal-filled"],
		"filled": true,
		"filledName": "grip-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "grip-vertical",
		"tuiName": "@tui.grip-vertical",
		"category": "custom",
		"keywords": ["grip", "vertical"],
		"aliases": ["@tui.grip-vertical", "@tui.grip-vertical-filled"],
		"filled": true,
		"filledName": "grip-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "groceries",
		"tuiName": "@tui.groceries",
		"category": "custom",
		"keywords": ["groceries"],
		"aliases": ["@tui.groceries", "@tui.groceries-filled"],
		"filled": true,
		"filledName": "groceries-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "group",
		"tuiName": "@tui.group",
		"category": "layout",
		"keywords": ["group"],
		"aliases": ["@tui.group", "@tui.group-filled"],
		"filled": true,
		"filledName": "group-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "guitar",
		"tuiName": "@tui.guitar",
		"category": "custom",
		"keywords": ["guitar"],
		"aliases": ["@tui.guitar", "@tui.guitar-filled"],
		"filled": true,
		"filledName": "guitar-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "guitar-electric",
		"tuiName": "@tui.guitar-electric",
		"category": "custom",
		"keywords": ["guitar", "electric"],
		"aliases": ["@tui.guitar-electric", "@tui.guitar-electric-filled"],
		"filled": true,
		"filledName": "guitar-electric-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ham",
		"tuiName": "@tui.ham",
		"category": "custom",
		"keywords": ["ham"],
		"aliases": ["@tui.ham", "@tui.ham-filled"],
		"filled": true,
		"filledName": "ham-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hamburger",
		"tuiName": "@tui.hamburger",
		"category": "custom",
		"keywords": ["hamburger"],
		"aliases": ["@tui.hamburger", "@tui.hamburger-filled"],
		"filled": true,
		"filledName": "hamburger-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hammer",
		"tuiName": "@tui.hammer",
		"category": "actions",
		"keywords": ["hammer"],
		"aliases": ["@tui.hammer", "@tui.hammer-filled"],
		"filled": true,
		"filledName": "hammer-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hand",
		"tuiName": "@tui.hand",
		"category": "custom",
		"keywords": ["hand"],
		"aliases": ["@tui.hand", "@tui.hand-filled"],
		"filled": true,
		"filledName": "hand-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hand-coins",
		"tuiName": "@tui.hand-coins",
		"category": "finance",
		"keywords": ["hand", "coins"],
		"aliases": ["@tui.hand-coins", "@tui.hand-coins-filled"],
		"filled": true,
		"filledName": "hand-coins-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hand-fist",
		"tuiName": "@tui.hand-fist",
		"category": "custom",
		"keywords": ["hand", "fist"],
		"aliases": ["@tui.hand-fist", "@tui.hand-fist-filled"],
		"filled": true,
		"filledName": "hand-fist-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hand-grab",
		"tuiName": "@tui.hand-grab",
		"category": "custom",
		"keywords": ["hand", "grab"],
		"aliases": ["@tui.hand-grab", "@tui.hand-grab-filled"],
		"filled": true,
		"filledName": "hand-grab-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hand-heart",
		"tuiName": "@tui.hand-heart",
		"category": "custom",
		"keywords": ["hand", "heart"],
		"aliases": ["@tui.hand-heart", "@tui.hand-heart-filled"],
		"filled": true,
		"filledName": "hand-heart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hand-helping",
		"tuiName": "@tui.hand-helping",
		"category": "custom",
		"keywords": ["hand", "helping"],
		"aliases": ["@tui.hand-helping", "@tui.hand-helping-filled"],
		"filled": true,
		"filledName": "hand-helping-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hand-metal",
		"tuiName": "@tui.hand-metal",
		"category": "custom",
		"keywords": ["hand", "metal"],
		"aliases": ["@tui.hand-metal", "@tui.hand-metal-filled"],
		"filled": true,
		"filledName": "hand-metal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hand-platter",
		"tuiName": "@tui.hand-platter",
		"category": "custom",
		"keywords": ["hand", "platter"],
		"aliases": ["@tui.hand-platter", "@tui.hand-platter-filled"],
		"filled": true,
		"filledName": "hand-platter-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "handbag",
		"tuiName": "@tui.handbag",
		"category": "custom",
		"keywords": ["handbag"],
		"aliases": ["@tui.handbag", "@tui.handbag-filled"],
		"filled": true,
		"filledName": "handbag-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "handle-bottom-right",
		"tuiName": "@tui.handle-bottom-right",
		"category": "custom",
		"keywords": [
			"handle",
			"bottom",
			"right"
		],
		"aliases": ["@tui.handle-bottom-right", "@tui.handle-bottom-right-filled"],
		"filled": true,
		"filledName": "handle-bottom-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "handshake",
		"tuiName": "@tui.handshake",
		"category": "custom",
		"keywords": ["handshake"],
		"aliases": ["@tui.handshake", "@tui.handshake-filled"],
		"filled": true,
		"filledName": "handshake-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hard-drive",
		"tuiName": "@tui.hard-drive",
		"category": "devices",
		"keywords": ["hard", "drive"],
		"aliases": ["@tui.hard-drive", "@tui.hard-drive-filled"],
		"filled": true,
		"filledName": "hard-drive-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hard-drive-download",
		"tuiName": "@tui.hard-drive-download",
		"category": "devices",
		"keywords": [
			"hard",
			"drive",
			"download"
		],
		"aliases": ["@tui.hard-drive-download", "@tui.hard-drive-download-filled"],
		"filled": true,
		"filledName": "hard-drive-download-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hard-drive-upload",
		"tuiName": "@tui.hard-drive-upload",
		"category": "devices",
		"keywords": [
			"hard",
			"drive",
			"upload"
		],
		"aliases": ["@tui.hard-drive-upload", "@tui.hard-drive-upload-filled"],
		"filled": true,
		"filledName": "hard-drive-upload-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hard-hat",
		"tuiName": "@tui.hard-hat",
		"category": "custom",
		"keywords": ["hard", "hat"],
		"aliases": ["@tui.hard-hat", "@tui.hard-hat-filled"],
		"filled": true,
		"filledName": "hard-hat-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hash",
		"tuiName": "@tui.hash",
		"category": "custom",
		"keywords": ["hash"],
		"aliases": ["@tui.hash", "@tui.hash-filled"],
		"filled": true,
		"filledName": "hash-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hat-glasses",
		"tuiName": "@tui.hat-glasses",
		"category": "custom",
		"keywords": ["hat", "glasses"],
		"aliases": ["@tui.hat-glasses", "@tui.hat-glasses-filled"],
		"filled": true,
		"filledName": "hat-glasses-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "haze",
		"tuiName": "@tui.haze",
		"category": "custom",
		"keywords": ["haze"],
		"aliases": ["@tui.haze", "@tui.haze-filled"],
		"filled": true,
		"filledName": "haze-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hd",
		"tuiName": "@tui.hd",
		"category": "custom",
		"keywords": ["hd"],
		"aliases": ["@tui.hd", "@tui.hd-filled"],
		"filled": true,
		"filledName": "hd-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hdmi-port",
		"tuiName": "@tui.hdmi-port",
		"category": "custom",
		"keywords": ["hdmi", "port"],
		"aliases": ["@tui.hdmi-port", "@tui.hdmi-port-filled"],
		"filled": true,
		"filledName": "hdmi-port-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "heading",
		"tuiName": "@tui.heading",
		"category": "custom",
		"keywords": ["heading"],
		"aliases": ["@tui.heading", "@tui.heading-filled"],
		"filled": true,
		"filledName": "heading-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "heading-1",
		"tuiName": "@tui.heading-1",
		"category": "custom",
		"keywords": ["heading", "1"],
		"aliases": ["@tui.heading-1", "@tui.heading-1-filled"],
		"filled": true,
		"filledName": "heading-1-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "heading-2",
		"tuiName": "@tui.heading-2",
		"category": "custom",
		"keywords": ["heading", "2"],
		"aliases": ["@tui.heading-2", "@tui.heading-2-filled"],
		"filled": true,
		"filledName": "heading-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "heading-3",
		"tuiName": "@tui.heading-3",
		"category": "custom",
		"keywords": ["heading", "3"],
		"aliases": ["@tui.heading-3", "@tui.heading-3-filled"],
		"filled": true,
		"filledName": "heading-3-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "heading-4",
		"tuiName": "@tui.heading-4",
		"category": "custom",
		"keywords": ["heading", "4"],
		"aliases": ["@tui.heading-4", "@tui.heading-4-filled"],
		"filled": true,
		"filledName": "heading-4-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "heading-5",
		"tuiName": "@tui.heading-5",
		"category": "custom",
		"keywords": ["heading", "5"],
		"aliases": ["@tui.heading-5", "@tui.heading-5-filled"],
		"filled": true,
		"filledName": "heading-5-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "heading-6",
		"tuiName": "@tui.heading-6",
		"category": "custom",
		"keywords": ["heading", "6"],
		"aliases": ["@tui.heading-6", "@tui.heading-6-filled"],
		"filled": true,
		"filledName": "heading-6-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "headphone-off",
		"tuiName": "@tui.headphone-off",
		"category": "custom",
		"keywords": ["headphone", "off"],
		"aliases": ["@tui.headphone-off", "@tui.headphone-off-filled"],
		"filled": true,
		"filledName": "headphone-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "headphones",
		"tuiName": "@tui.headphones",
		"category": "custom",
		"keywords": ["headphones"],
		"aliases": ["@tui.headphones", "@tui.headphones-filled"],
		"filled": true,
		"filledName": "headphones-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "headset",
		"tuiName": "@tui.headset",
		"category": "custom",
		"keywords": ["headset"],
		"aliases": ["@tui.headset", "@tui.headset-filled"],
		"filled": true,
		"filledName": "headset-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "heart",
		"tuiName": "@tui.heart",
		"category": "status-feedback",
		"keywords": ["heart"],
		"aliases": ["@tui.heart", "@tui.heart-filled"],
		"filled": true,
		"filledName": "heart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "heart-crack",
		"tuiName": "@tui.heart-crack",
		"category": "status-feedback",
		"keywords": ["heart", "crack"],
		"aliases": ["@tui.heart-crack", "@tui.heart-crack-filled"],
		"filled": true,
		"filledName": "heart-crack-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "heart-handshake",
		"tuiName": "@tui.heart-handshake",
		"category": "status-feedback",
		"keywords": ["heart", "handshake"],
		"aliases": ["@tui.heart-handshake", "@tui.heart-handshake-filled"],
		"filled": true,
		"filledName": "heart-handshake-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "heart-minus",
		"tuiName": "@tui.heart-minus",
		"category": "status-feedback",
		"keywords": ["heart", "minus"],
		"aliases": ["@tui.heart-minus", "@tui.heart-minus-filled"],
		"filled": true,
		"filledName": "heart-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "heart-off",
		"tuiName": "@tui.heart-off",
		"category": "status-feedback",
		"keywords": ["heart", "off"],
		"aliases": ["@tui.heart-off", "@tui.heart-off-filled"],
		"filled": true,
		"filledName": "heart-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "heart-plus",
		"tuiName": "@tui.heart-plus",
		"category": "status-feedback",
		"keywords": ["heart", "plus"],
		"aliases": ["@tui.heart-plus", "@tui.heart-plus-filled"],
		"filled": true,
		"filledName": "heart-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "heart-pulse",
		"tuiName": "@tui.heart-pulse",
		"category": "status-feedback",
		"keywords": ["heart", "pulse"],
		"aliases": ["@tui.heart-pulse", "@tui.heart-pulse-filled"],
		"filled": true,
		"filledName": "heart-pulse-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "heart-x",
		"tuiName": "@tui.heart-x",
		"category": "status-feedback",
		"keywords": ["heart", "x"],
		"aliases": ["@tui.heart-x", "@tui.heart-x-filled"],
		"filled": true,
		"filledName": "heart-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "heater",
		"tuiName": "@tui.heater",
		"category": "custom",
		"keywords": ["heater"],
		"aliases": ["@tui.heater", "@tui.heater-filled"],
		"filled": true,
		"filledName": "heater-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "helicopter",
		"tuiName": "@tui.helicopter",
		"category": "custom",
		"keywords": ["helicopter"],
		"aliases": ["@tui.helicopter", "@tui.helicopter-filled"],
		"filled": true,
		"filledName": "helicopter-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "help-circle",
		"tuiName": "@tui.help-circle",
		"category": "status-feedback",
		"keywords": ["help", "circle"],
		"aliases": ["@tui.help-circle", "@tui.help-circle-filled"],
		"filled": true,
		"filledName": "help-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "helping-hand",
		"tuiName": "@tui.helping-hand",
		"category": "status-feedback",
		"keywords": ["helping", "hand"],
		"aliases": ["@tui.helping-hand", "@tui.helping-hand-filled"],
		"filled": true,
		"filledName": "helping-hand-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hexagon",
		"tuiName": "@tui.hexagon",
		"category": "custom",
		"keywords": ["hexagon"],
		"aliases": ["@tui.hexagon", "@tui.hexagon-filled"],
		"filled": true,
		"filledName": "hexagon-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "highlighter",
		"tuiName": "@tui.highlighter",
		"category": "editing",
		"keywords": ["highlighter"],
		"aliases": ["@tui.highlighter", "@tui.highlighter-filled"],
		"filled": true,
		"filledName": "highlighter-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hiking-stick",
		"tuiName": "@tui.hiking-stick",
		"category": "custom",
		"keywords": ["hiking", "stick"],
		"aliases": ["@tui.hiking-stick", "@tui.hiking-stick-filled"],
		"filled": true,
		"filledName": "hiking-stick-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "history",
		"tuiName": "@tui.history",
		"category": "calendar-time",
		"keywords": ["history"],
		"aliases": ["@tui.history", "@tui.history-filled"],
		"filled": true,
		"filledName": "history-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "home",
		"tuiName": "@tui.home",
		"category": "navigation",
		"keywords": ["home"],
		"aliases": ["@tui.home", "@tui.home-filled"],
		"filled": true,
		"filledName": "home-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hop",
		"tuiName": "@tui.hop",
		"category": "custom",
		"keywords": ["hop"],
		"aliases": ["@tui.hop", "@tui.hop-filled"],
		"filled": true,
		"filledName": "hop-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hop-off",
		"tuiName": "@tui.hop-off",
		"category": "custom",
		"keywords": ["hop", "off"],
		"aliases": ["@tui.hop-off", "@tui.hop-off-filled"],
		"filled": true,
		"filledName": "hop-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hospital",
		"tuiName": "@tui.hospital",
		"category": "custom",
		"keywords": ["hospital"],
		"aliases": ["@tui.hospital", "@tui.hospital-filled"],
		"filled": true,
		"filledName": "hospital-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hotel",
		"tuiName": "@tui.hotel",
		"category": "maps-location",
		"keywords": ["hotel"],
		"aliases": ["@tui.hotel", "@tui.hotel-filled"],
		"filled": true,
		"filledName": "hotel-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hourglass",
		"tuiName": "@tui.hourglass",
		"category": "calendar-time",
		"keywords": ["hourglass"],
		"aliases": ["@tui.hourglass", "@tui.hourglass-filled"],
		"filled": true,
		"filledName": "hourglass-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "hourglass-cog",
		"tuiName": "@tui.hourglass-cog",
		"category": "calendar-time",
		"keywords": ["hourglass", "cog"],
		"aliases": ["@tui.hourglass-cog", "@tui.hourglass-cog-filled"],
		"filled": true,
		"filledName": "hourglass-cog-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "house",
		"tuiName": "@tui.house",
		"category": "custom",
		"keywords": ["house"],
		"aliases": ["@tui.house", "@tui.house-filled"],
		"filled": true,
		"filledName": "house-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "house-cog",
		"tuiName": "@tui.house-cog",
		"category": "custom",
		"keywords": ["house", "cog"],
		"aliases": ["@tui.house-cog", "@tui.house-cog-filled"],
		"filled": true,
		"filledName": "house-cog-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "house-heart",
		"tuiName": "@tui.house-heart",
		"category": "custom",
		"keywords": ["house", "heart"],
		"aliases": ["@tui.house-heart", "@tui.house-heart-filled"],
		"filled": true,
		"filledName": "house-heart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "house-plug",
		"tuiName": "@tui.house-plug",
		"category": "custom",
		"keywords": ["house", "plug"],
		"aliases": ["@tui.house-plug", "@tui.house-plug-filled"],
		"filled": true,
		"filledName": "house-plug-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "house-plus",
		"tuiName": "@tui.house-plus",
		"category": "custom",
		"keywords": ["house", "plus"],
		"aliases": ["@tui.house-plus", "@tui.house-plus-filled"],
		"filled": true,
		"filledName": "house-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "house-wifi",
		"tuiName": "@tui.house-wifi",
		"category": "custom",
		"keywords": ["house", "wifi"],
		"aliases": ["@tui.house-wifi", "@tui.house-wifi-filled"],
		"filled": true,
		"filledName": "house-wifi-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "houses",
		"tuiName": "@tui.houses",
		"category": "custom",
		"keywords": ["houses"],
		"aliases": ["@tui.houses", "@tui.houses-filled"],
		"filled": true,
		"filledName": "houses-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "humo",
		"tuiName": "@tui.humo",
		"category": "custom",
		"keywords": ["humo"],
		"aliases": ["@tui.humo"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ice-cream",
		"tuiName": "@tui.ice-cream",
		"category": "custom",
		"keywords": ["ice", "cream"],
		"aliases": ["@tui.ice-cream", "@tui.ice-cream-filled"],
		"filled": true,
		"filledName": "ice-cream-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ice-cream-2",
		"tuiName": "@tui.ice-cream-2",
		"category": "custom",
		"keywords": [
			"ice",
			"cream",
			"2"
		],
		"aliases": ["@tui.ice-cream-2", "@tui.ice-cream-2-filled"],
		"filled": true,
		"filledName": "ice-cream-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ice-cream-bowl",
		"tuiName": "@tui.ice-cream-bowl",
		"category": "custom",
		"keywords": [
			"ice",
			"cream",
			"bowl"
		],
		"aliases": ["@tui.ice-cream-bowl", "@tui.ice-cream-bowl-filled"],
		"filled": true,
		"filledName": "ice-cream-bowl-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ice-cream-cone",
		"tuiName": "@tui.ice-cream-cone",
		"category": "custom",
		"keywords": [
			"ice",
			"cream",
			"cone"
		],
		"aliases": ["@tui.ice-cream-cone", "@tui.ice-cream-cone-filled"],
		"filled": true,
		"filledName": "ice-cream-cone-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "id-card",
		"tuiName": "@tui.id-card",
		"category": "users",
		"keywords": ["id", "card"],
		"aliases": ["@tui.id-card", "@tui.id-card-filled"],
		"filled": true,
		"filledName": "id-card-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "id-card-lanyard",
		"tuiName": "@tui.id-card-lanyard",
		"category": "users",
		"keywords": [
			"id",
			"card",
			"lanyard"
		],
		"aliases": ["@tui.id-card-lanyard", "@tui.id-card-lanyard-filled"],
		"filled": true,
		"filledName": "id-card-lanyard-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "image",
		"tuiName": "@tui.image",
		"category": "media",
		"keywords": ["image"],
		"aliases": ["@tui.image", "@tui.image-filled"],
		"filled": true,
		"filledName": "image-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "image-down",
		"tuiName": "@tui.image-down",
		"category": "media",
		"keywords": ["image", "down"],
		"aliases": ["@tui.image-down", "@tui.image-down-filled"],
		"filled": true,
		"filledName": "image-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "image-minus",
		"tuiName": "@tui.image-minus",
		"category": "media",
		"keywords": ["image", "minus"],
		"aliases": ["@tui.image-minus", "@tui.image-minus-filled"],
		"filled": true,
		"filledName": "image-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "image-off",
		"tuiName": "@tui.image-off",
		"category": "media",
		"keywords": ["image", "off"],
		"aliases": ["@tui.image-off", "@tui.image-off-filled"],
		"filled": true,
		"filledName": "image-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "image-play",
		"tuiName": "@tui.image-play",
		"category": "media",
		"keywords": ["image", "play"],
		"aliases": ["@tui.image-play", "@tui.image-play-filled"],
		"filled": true,
		"filledName": "image-play-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "image-plus",
		"tuiName": "@tui.image-plus",
		"category": "media",
		"keywords": ["image", "plus"],
		"aliases": ["@tui.image-plus", "@tui.image-plus-filled"],
		"filled": true,
		"filledName": "image-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "image-up",
		"tuiName": "@tui.image-up",
		"category": "media",
		"keywords": ["image", "up"],
		"aliases": ["@tui.image-up", "@tui.image-up-filled"],
		"filled": true,
		"filledName": "image-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "image-upscale",
		"tuiName": "@tui.image-upscale",
		"category": "media",
		"keywords": ["image", "upscale"],
		"aliases": ["@tui.image-upscale", "@tui.image-upscale-filled"],
		"filled": true,
		"filledName": "image-upscale-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "images",
		"tuiName": "@tui.images",
		"category": "media",
		"keywords": ["images"],
		"aliases": ["@tui.images", "@tui.images-filled"],
		"filled": true,
		"filledName": "images-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "import",
		"tuiName": "@tui.import",
		"category": "actions",
		"keywords": ["import"],
		"aliases": ["@tui.import", "@tui.import-filled"],
		"filled": true,
		"filledName": "import-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "inbox",
		"tuiName": "@tui.inbox",
		"category": "communication",
		"keywords": ["inbox"],
		"aliases": ["@tui.inbox", "@tui.inbox-filled"],
		"filled": true,
		"filledName": "inbox-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "indent",
		"tuiName": "@tui.indent",
		"category": "editing",
		"keywords": ["indent"],
		"aliases": ["@tui.indent", "@tui.indent-filled"],
		"filled": true,
		"filledName": "indent-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "indent-decrease",
		"tuiName": "@tui.indent-decrease",
		"category": "editing",
		"keywords": ["indent", "decrease"],
		"aliases": ["@tui.indent-decrease", "@tui.indent-decrease-filled"],
		"filled": true,
		"filledName": "indent-decrease-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "indent-increase",
		"tuiName": "@tui.indent-increase",
		"category": "editing",
		"keywords": ["indent", "increase"],
		"aliases": ["@tui.indent-increase", "@tui.indent-increase-filled"],
		"filled": true,
		"filledName": "indent-increase-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "indian-rupee",
		"tuiName": "@tui.indian-rupee",
		"category": "custom",
		"keywords": ["indian", "rupee"],
		"aliases": ["@tui.indian-rupee", "@tui.indian-rupee-filled"],
		"filled": true,
		"filledName": "indian-rupee-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "infinity",
		"tuiName": "@tui.infinity",
		"category": "custom",
		"keywords": ["infinity"],
		"aliases": ["@tui.infinity", "@tui.infinity-filled"],
		"filled": true,
		"filledName": "infinity-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "info",
		"tuiName": "@tui.info",
		"category": "status-feedback",
		"keywords": ["info"],
		"aliases": ["@tui.info", "@tui.info-filled"],
		"filled": true,
		"filledName": "info-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "inspect",
		"tuiName": "@tui.inspect",
		"category": "custom",
		"keywords": ["inspect"],
		"aliases": ["@tui.inspect", "@tui.inspect-filled"],
		"filled": true,
		"filledName": "inspect-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "inspection-panel",
		"tuiName": "@tui.inspection-panel",
		"category": "custom",
		"keywords": ["inspection", "panel"],
		"aliases": ["@tui.inspection-panel", "@tui.inspection-panel-filled"],
		"filled": true,
		"filledName": "inspection-panel-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "italic",
		"tuiName": "@tui.italic",
		"category": "editing",
		"keywords": ["italic"],
		"aliases": ["@tui.italic", "@tui.italic-filled"],
		"filled": true,
		"filledName": "italic-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "iteration-ccw",
		"tuiName": "@tui.iteration-ccw",
		"category": "custom",
		"keywords": ["iteration", "ccw"],
		"aliases": ["@tui.iteration-ccw", "@tui.iteration-ccw-filled"],
		"filled": true,
		"filledName": "iteration-ccw-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "iteration-cw",
		"tuiName": "@tui.iteration-cw",
		"category": "custom",
		"keywords": ["iteration", "cw"],
		"aliases": ["@tui.iteration-cw", "@tui.iteration-cw-filled"],
		"filled": true,
		"filledName": "iteration-cw-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "iv-bag",
		"tuiName": "@tui.iv-bag",
		"category": "custom",
		"keywords": ["iv", "bag"],
		"aliases": ["@tui.iv-bag", "@tui.iv-bag-filled"],
		"filled": true,
		"filledName": "iv-bag-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "japanese-yen",
		"tuiName": "@tui.japanese-yen",
		"category": "custom",
		"keywords": ["japanese", "yen"],
		"aliases": ["@tui.japanese-yen", "@tui.japanese-yen-filled"],
		"filled": true,
		"filledName": "japanese-yen-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "jcb",
		"tuiName": "@tui.jcb",
		"category": "custom",
		"keywords": ["jcb"],
		"aliases": ["@tui.jcb"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "joystick",
		"tuiName": "@tui.joystick",
		"category": "custom",
		"keywords": ["joystick"],
		"aliases": ["@tui.joystick", "@tui.joystick-filled"],
		"filled": true,
		"filledName": "joystick-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "kanban",
		"tuiName": "@tui.kanban",
		"category": "custom",
		"keywords": ["kanban"],
		"aliases": ["@tui.kanban", "@tui.kanban-filled"],
		"filled": true,
		"filledName": "kanban-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "kanban-square",
		"tuiName": "@tui.kanban-square",
		"category": "custom",
		"keywords": ["kanban", "square"],
		"aliases": ["@tui.kanban-square", "@tui.kanban-square-filled"],
		"filled": true,
		"filledName": "kanban-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "kanban-square-dashed",
		"tuiName": "@tui.kanban-square-dashed",
		"category": "custom",
		"keywords": [
			"kanban",
			"square",
			"dashed"
		],
		"aliases": ["@tui.kanban-square-dashed", "@tui.kanban-square-dashed-filled"],
		"filled": true,
		"filledName": "kanban-square-dashed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "kayak",
		"tuiName": "@tui.kayak",
		"category": "custom",
		"keywords": ["kayak"],
		"aliases": ["@tui.kayak", "@tui.kayak-filled"],
		"filled": true,
		"filledName": "kayak-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "kazakh-tenge",
		"tuiName": "@tui.kazakh-tenge",
		"category": "custom",
		"keywords": ["kazakh", "tenge"],
		"aliases": ["@tui.kazakh-tenge", "@tui.kazakh-tenge-filled"],
		"filled": true,
		"filledName": "kazakh-tenge-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "key",
		"tuiName": "@tui.key",
		"category": "security",
		"keywords": ["key"],
		"aliases": ["@tui.key", "@tui.key-filled"],
		"filled": true,
		"filledName": "key-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "key-round",
		"tuiName": "@tui.key-round",
		"category": "security",
		"keywords": ["key", "round"],
		"aliases": ["@tui.key-round", "@tui.key-round-filled"],
		"filled": true,
		"filledName": "key-round-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "key-square",
		"tuiName": "@tui.key-square",
		"category": "security",
		"keywords": ["key", "square"],
		"aliases": ["@tui.key-square", "@tui.key-square-filled"],
		"filled": true,
		"filledName": "key-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "keyboard",
		"tuiName": "@tui.keyboard",
		"category": "devices",
		"keywords": ["keyboard"],
		"aliases": ["@tui.keyboard", "@tui.keyboard-filled"],
		"filled": true,
		"filledName": "keyboard-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "keyboard-music",
		"tuiName": "@tui.keyboard-music",
		"category": "devices",
		"keywords": ["keyboard", "music"],
		"aliases": ["@tui.keyboard-music", "@tui.keyboard-music-filled"],
		"filled": true,
		"filledName": "keyboard-music-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "keyboard-off",
		"tuiName": "@tui.keyboard-off",
		"category": "devices",
		"keywords": ["keyboard", "off"],
		"aliases": ["@tui.keyboard-off", "@tui.keyboard-off-filled"],
		"filled": true,
		"filledName": "keyboard-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "lambda",
		"tuiName": "@tui.lambda",
		"category": "custom",
		"keywords": ["lambda"],
		"aliases": ["@tui.lambda", "@tui.lambda-filled"],
		"filled": true,
		"filledName": "lambda-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "lamp",
		"tuiName": "@tui.lamp",
		"category": "custom",
		"keywords": ["lamp"],
		"aliases": ["@tui.lamp", "@tui.lamp-filled"],
		"filled": true,
		"filledName": "lamp-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "lamp-ceiling",
		"tuiName": "@tui.lamp-ceiling",
		"category": "custom",
		"keywords": ["lamp", "ceiling"],
		"aliases": ["@tui.lamp-ceiling", "@tui.lamp-ceiling-filled"],
		"filled": true,
		"filledName": "lamp-ceiling-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "lamp-desk",
		"tuiName": "@tui.lamp-desk",
		"category": "custom",
		"keywords": ["lamp", "desk"],
		"aliases": ["@tui.lamp-desk", "@tui.lamp-desk-filled"],
		"filled": true,
		"filledName": "lamp-desk-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "lamp-floor",
		"tuiName": "@tui.lamp-floor",
		"category": "custom",
		"keywords": ["lamp", "floor"],
		"aliases": ["@tui.lamp-floor", "@tui.lamp-floor-filled"],
		"filled": true,
		"filledName": "lamp-floor-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "lamp-wall-down",
		"tuiName": "@tui.lamp-wall-down",
		"category": "custom",
		"keywords": [
			"lamp",
			"wall",
			"down"
		],
		"aliases": ["@tui.lamp-wall-down", "@tui.lamp-wall-down-filled"],
		"filled": true,
		"filledName": "lamp-wall-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "lamp-wall-up",
		"tuiName": "@tui.lamp-wall-up",
		"category": "custom",
		"keywords": [
			"lamp",
			"wall",
			"up"
		],
		"aliases": ["@tui.lamp-wall-up", "@tui.lamp-wall-up-filled"],
		"filled": true,
		"filledName": "lamp-wall-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "land-plot",
		"tuiName": "@tui.land-plot",
		"category": "custom",
		"keywords": ["land", "plot"],
		"aliases": ["@tui.land-plot", "@tui.land-plot-filled"],
		"filled": true,
		"filledName": "land-plot-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "landmark",
		"tuiName": "@tui.landmark",
		"category": "finance",
		"keywords": ["landmark"],
		"aliases": ["@tui.landmark", "@tui.landmark-filled"],
		"filled": true,
		"filledName": "landmark-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "languages",
		"tuiName": "@tui.languages",
		"category": "custom",
		"keywords": ["languages"],
		"aliases": ["@tui.languages", "@tui.languages-filled"],
		"filled": true,
		"filledName": "languages-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "laptop",
		"tuiName": "@tui.laptop",
		"category": "devices",
		"keywords": ["laptop"],
		"aliases": ["@tui.laptop", "@tui.laptop-filled"],
		"filled": true,
		"filledName": "laptop-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "laptop-2",
		"tuiName": "@tui.laptop-2",
		"category": "devices",
		"keywords": ["laptop", "2"],
		"aliases": ["@tui.laptop-2", "@tui.laptop-2-filled"],
		"filled": true,
		"filledName": "laptop-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "laptop-minimal",
		"tuiName": "@tui.laptop-minimal",
		"category": "devices",
		"keywords": ["laptop", "minimal"],
		"aliases": ["@tui.laptop-minimal", "@tui.laptop-minimal-filled"],
		"filled": true,
		"filledName": "laptop-minimal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "laptop-minimal-check",
		"tuiName": "@tui.laptop-minimal-check",
		"category": "devices",
		"keywords": [
			"laptop",
			"minimal",
			"check"
		],
		"aliases": ["@tui.laptop-minimal-check", "@tui.laptop-minimal-check-filled"],
		"filled": true,
		"filledName": "laptop-minimal-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "lasso",
		"tuiName": "@tui.lasso",
		"category": "custom",
		"keywords": ["lasso"],
		"aliases": ["@tui.lasso", "@tui.lasso-filled"],
		"filled": true,
		"filledName": "lasso-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "lasso-select",
		"tuiName": "@tui.lasso-select",
		"category": "custom",
		"keywords": ["lasso", "select"],
		"aliases": ["@tui.lasso-select", "@tui.lasso-select-filled"],
		"filled": true,
		"filledName": "lasso-select-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "laugh",
		"tuiName": "@tui.laugh",
		"category": "custom",
		"keywords": ["laugh"],
		"aliases": ["@tui.laugh", "@tui.laugh-filled"],
		"filled": true,
		"filledName": "laugh-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "layer-arrow-down",
		"tuiName": "@tui.layer-arrow-down",
		"category": "custom",
		"keywords": [
			"layer",
			"arrow",
			"down"
		],
		"aliases": ["@tui.layer-arrow-down", "@tui.layer-arrow-down-filled"],
		"filled": true,
		"filledName": "layer-arrow-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "layer-arrow-up",
		"tuiName": "@tui.layer-arrow-up",
		"category": "custom",
		"keywords": [
			"layer",
			"arrow",
			"up"
		],
		"aliases": ["@tui.layer-arrow-up", "@tui.layer-arrow-up-filled"],
		"filled": true,
		"filledName": "layer-arrow-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "layers",
		"tuiName": "@tui.layers",
		"category": "layout",
		"keywords": ["layers"],
		"aliases": ["@tui.layers", "@tui.layers-filled"],
		"filled": true,
		"filledName": "layers-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "layers-2",
		"tuiName": "@tui.layers-2",
		"category": "layout",
		"keywords": ["layers", "2"],
		"aliases": ["@tui.layers-2", "@tui.layers-2-filled"],
		"filled": true,
		"filledName": "layers-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "layers-3",
		"tuiName": "@tui.layers-3",
		"category": "layout",
		"keywords": ["layers", "3"],
		"aliases": ["@tui.layers-3", "@tui.layers-3-filled"],
		"filled": true,
		"filledName": "layers-3-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "layers-arrow-down",
		"tuiName": "@tui.layers-arrow-down",
		"category": "layout",
		"keywords": [
			"layers",
			"arrow",
			"down"
		],
		"aliases": ["@tui.layers-arrow-down", "@tui.layers-arrow-down-filled"],
		"filled": true,
		"filledName": "layers-arrow-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "layers-arrow-up",
		"tuiName": "@tui.layers-arrow-up",
		"category": "layout",
		"keywords": [
			"layers",
			"arrow",
			"up"
		],
		"aliases": ["@tui.layers-arrow-up", "@tui.layers-arrow-up-filled"],
		"filled": true,
		"filledName": "layers-arrow-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "layers-minus",
		"tuiName": "@tui.layers-minus",
		"category": "layout",
		"keywords": ["layers", "minus"],
		"aliases": ["@tui.layers-minus", "@tui.layers-minus-filled"],
		"filled": true,
		"filledName": "layers-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "layers-plus",
		"tuiName": "@tui.layers-plus",
		"category": "layout",
		"keywords": ["layers", "plus"],
		"aliases": ["@tui.layers-plus", "@tui.layers-plus-filled"],
		"filled": true,
		"filledName": "layers-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "layout",
		"tuiName": "@tui.layout",
		"category": "navigation",
		"keywords": ["layout"],
		"aliases": ["@tui.layout", "@tui.layout-filled"],
		"filled": true,
		"filledName": "layout-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "layout-arrow-down",
		"tuiName": "@tui.layout-arrow-down",
		"category": "navigation",
		"keywords": [
			"layout",
			"arrow",
			"down"
		],
		"aliases": ["@tui.layout-arrow-down", "@tui.layout-arrow-down-filled"],
		"filled": true,
		"filledName": "layout-arrow-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "layout-arrow-right",
		"tuiName": "@tui.layout-arrow-right",
		"category": "navigation",
		"keywords": [
			"layout",
			"arrow",
			"right"
		],
		"aliases": ["@tui.layout-arrow-right", "@tui.layout-arrow-right-filled"],
		"filled": true,
		"filledName": "layout-arrow-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "layout-dashboard",
		"tuiName": "@tui.layout-dashboard",
		"category": "navigation",
		"keywords": ["layout", "dashboard"],
		"aliases": ["@tui.layout-dashboard", "@tui.layout-dashboard-filled"],
		"filled": true,
		"filledName": "layout-dashboard-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "layout-freeform",
		"tuiName": "@tui.layout-freeform",
		"category": "navigation",
		"keywords": ["layout", "freeform"],
		"aliases": ["@tui.layout-freeform", "@tui.layout-freeform-filled"],
		"filled": true,
		"filledName": "layout-freeform-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "layout-grid",
		"tuiName": "@tui.layout-grid",
		"category": "navigation",
		"keywords": ["layout", "grid"],
		"aliases": ["@tui.layout-grid", "@tui.layout-grid-filled"],
		"filled": true,
		"filledName": "layout-grid-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "layout-grid-circles",
		"tuiName": "@tui.layout-grid-circles",
		"category": "navigation",
		"keywords": [
			"layout",
			"grid",
			"circles"
		],
		"aliases": ["@tui.layout-grid-circles", "@tui.layout-grid-circles-filled"],
		"filled": true,
		"filledName": "layout-grid-circles-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "layout-list",
		"tuiName": "@tui.layout-list",
		"category": "navigation",
		"keywords": ["layout", "list"],
		"aliases": ["@tui.layout-list", "@tui.layout-list-filled"],
		"filled": true,
		"filledName": "layout-list-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "layout-panel-left",
		"tuiName": "@tui.layout-panel-left",
		"category": "navigation",
		"keywords": [
			"layout",
			"panel",
			"left"
		],
		"aliases": ["@tui.layout-panel-left", "@tui.layout-panel-left-filled"],
		"filled": true,
		"filledName": "layout-panel-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "layout-panel-top",
		"tuiName": "@tui.layout-panel-top",
		"category": "navigation",
		"keywords": [
			"layout",
			"panel",
			"top"
		],
		"aliases": ["@tui.layout-panel-top", "@tui.layout-panel-top-filled"],
		"filled": true,
		"filledName": "layout-panel-top-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "layout-template",
		"tuiName": "@tui.layout-template",
		"category": "navigation",
		"keywords": ["layout", "template"],
		"aliases": ["@tui.layout-template", "@tui.layout-template-filled"],
		"filled": true,
		"filledName": "layout-template-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "leaf",
		"tuiName": "@tui.leaf",
		"category": "custom",
		"keywords": ["leaf"],
		"aliases": ["@tui.leaf", "@tui.leaf-filled"],
		"filled": true,
		"filledName": "leaf-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "leafy-green",
		"tuiName": "@tui.leafy-green",
		"category": "custom",
		"keywords": ["leafy", "green"],
		"aliases": ["@tui.leafy-green", "@tui.leafy-green-filled"],
		"filled": true,
		"filledName": "leafy-green-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "lectern",
		"tuiName": "@tui.lectern",
		"category": "custom",
		"keywords": ["lectern"],
		"aliases": ["@tui.lectern", "@tui.lectern-filled"],
		"filled": true,
		"filledName": "lectern-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "lens",
		"tuiName": "@tui.lens",
		"category": "custom",
		"keywords": ["lens"],
		"aliases": ["@tui.lens", "@tui.lens-filled"],
		"filled": true,
		"filledName": "lens-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "lens-concave",
		"tuiName": "@tui.lens-concave",
		"category": "custom",
		"keywords": ["lens", "concave"],
		"aliases": ["@tui.lens-concave", "@tui.lens-concave-filled"],
		"filled": true,
		"filledName": "lens-concave-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "lens-convex",
		"tuiName": "@tui.lens-convex",
		"category": "custom",
		"keywords": ["lens", "convex"],
		"aliases": ["@tui.lens-convex", "@tui.lens-convex-filled"],
		"filled": true,
		"filledName": "lens-convex-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "letter-text",
		"tuiName": "@tui.letter-text",
		"category": "custom",
		"keywords": ["letter", "text"],
		"aliases": ["@tui.letter-text", "@tui.letter-text-filled"],
		"filled": true,
		"filledName": "letter-text-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "letters",
		"tuiName": "@tui.letters",
		"category": "custom",
		"keywords": ["letters"],
		"aliases": ["@tui.letters", "@tui.letters-filled"],
		"filled": true,
		"filledName": "letters-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "library",
		"tuiName": "@tui.library",
		"category": "custom",
		"keywords": ["library"],
		"aliases": ["@tui.library", "@tui.library-filled"],
		"filled": true,
		"filledName": "library-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "library-big",
		"tuiName": "@tui.library-big",
		"category": "custom",
		"keywords": ["library", "big"],
		"aliases": ["@tui.library-big", "@tui.library-big-filled"],
		"filled": true,
		"filledName": "library-big-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "library-square",
		"tuiName": "@tui.library-square",
		"category": "custom",
		"keywords": ["library", "square"],
		"aliases": ["@tui.library-square", "@tui.library-square-filled"],
		"filled": true,
		"filledName": "library-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "life-buoy",
		"tuiName": "@tui.life-buoy",
		"category": "custom",
		"keywords": ["life", "buoy"],
		"aliases": ["@tui.life-buoy", "@tui.life-buoy-filled"],
		"filled": true,
		"filledName": "life-buoy-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ligature",
		"tuiName": "@tui.ligature",
		"category": "custom",
		"keywords": ["ligature"],
		"aliases": ["@tui.ligature", "@tui.ligature-filled"],
		"filled": true,
		"filledName": "ligature-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "lightbulb",
		"tuiName": "@tui.lightbulb",
		"category": "custom",
		"keywords": ["lightbulb"],
		"aliases": ["@tui.lightbulb", "@tui.lightbulb-filled"],
		"filled": true,
		"filledName": "lightbulb-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "lightbulb-off",
		"tuiName": "@tui.lightbulb-off",
		"category": "custom",
		"keywords": ["lightbulb", "off"],
		"aliases": ["@tui.lightbulb-off", "@tui.lightbulb-off-filled"],
		"filled": true,
		"filledName": "lightbulb-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "lighthouse",
		"tuiName": "@tui.lighthouse",
		"category": "custom",
		"keywords": ["lighthouse"],
		"aliases": ["@tui.lighthouse", "@tui.lighthouse-filled"],
		"filled": true,
		"filledName": "lighthouse-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "line-chart",
		"tuiName": "@tui.line-chart",
		"category": "custom",
		"keywords": ["line", "chart"],
		"aliases": ["@tui.line-chart", "@tui.line-chart-filled"],
		"filled": true,
		"filledName": "line-chart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "line-dot-bottom-vertical",
		"tuiName": "@tui.line-dot-bottom-vertical",
		"category": "custom",
		"keywords": [
			"line",
			"dot",
			"bottom",
			"vertical"
		],
		"aliases": ["@tui.line-dot-bottom-vertical", "@tui.line-dot-bottom-vertical-filled"],
		"filled": true,
		"filledName": "line-dot-bottom-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "line-dot-left-horizontal",
		"tuiName": "@tui.line-dot-left-horizontal",
		"category": "custom",
		"keywords": [
			"line",
			"dot",
			"left",
			"horizontal"
		],
		"aliases": ["@tui.line-dot-left-horizontal", "@tui.line-dot-left-horizontal-filled"],
		"filled": true,
		"filledName": "line-dot-left-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "line-dot-right-horizontal",
		"tuiName": "@tui.line-dot-right-horizontal",
		"category": "custom",
		"keywords": [
			"line",
			"dot",
			"right",
			"horizontal"
		],
		"aliases": ["@tui.line-dot-right-horizontal", "@tui.line-dot-right-horizontal-filled"],
		"filled": true,
		"filledName": "line-dot-right-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "line-dot-top-vertical",
		"tuiName": "@tui.line-dot-top-vertical",
		"category": "custom",
		"keywords": [
			"line",
			"dot",
			"top",
			"vertical"
		],
		"aliases": ["@tui.line-dot-top-vertical", "@tui.line-dot-top-vertical-filled"],
		"filled": true,
		"filledName": "line-dot-top-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "line-squiggle",
		"tuiName": "@tui.line-squiggle",
		"category": "custom",
		"keywords": ["line", "squiggle"],
		"aliases": ["@tui.line-squiggle", "@tui.line-squiggle-filled"],
		"filled": true,
		"filledName": "line-squiggle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "line-style",
		"tuiName": "@tui.line-style",
		"category": "custom",
		"keywords": ["line", "style"],
		"aliases": ["@tui.line-style", "@tui.line-style-filled"],
		"filled": true,
		"filledName": "line-style-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "link",
		"tuiName": "@tui.link",
		"category": "social",
		"keywords": ["link"],
		"aliases": ["@tui.link", "@tui.link-filled"],
		"filled": true,
		"filledName": "link-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "link-2",
		"tuiName": "@tui.link-2",
		"category": "social",
		"keywords": ["link", "2"],
		"aliases": ["@tui.link-2", "@tui.link-2-filled"],
		"filled": true,
		"filledName": "link-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "link-2-off",
		"tuiName": "@tui.link-2-off",
		"category": "social",
		"keywords": [
			"link",
			"2",
			"off"
		],
		"aliases": ["@tui.link-2-off", "@tui.link-2-off-filled"],
		"filled": true,
		"filledName": "link-2-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list",
		"tuiName": "@tui.list",
		"category": "editing",
		"keywords": ["list"],
		"aliases": ["@tui.list", "@tui.list-filled"],
		"filled": true,
		"filledName": "list-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-check",
		"tuiName": "@tui.list-check",
		"category": "editing",
		"keywords": ["list", "check"],
		"aliases": ["@tui.list-check", "@tui.list-check-filled"],
		"filled": true,
		"filledName": "list-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-checks",
		"tuiName": "@tui.list-checks",
		"category": "editing",
		"keywords": ["list", "checks"],
		"aliases": ["@tui.list-checks", "@tui.list-checks-filled"],
		"filled": true,
		"filledName": "list-checks-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-chevrons-down-up",
		"tuiName": "@tui.list-chevrons-down-up",
		"category": "editing",
		"keywords": [
			"list",
			"chevrons",
			"down",
			"up"
		],
		"aliases": ["@tui.list-chevrons-down-up", "@tui.list-chevrons-down-up-filled"],
		"filled": true,
		"filledName": "list-chevrons-down-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-chevrons-up-down",
		"tuiName": "@tui.list-chevrons-up-down",
		"category": "editing",
		"keywords": [
			"list",
			"chevrons",
			"up",
			"down"
		],
		"aliases": ["@tui.list-chevrons-up-down", "@tui.list-chevrons-up-down-filled"],
		"filled": true,
		"filledName": "list-chevrons-up-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-clock",
		"tuiName": "@tui.list-clock",
		"category": "editing",
		"keywords": ["list", "clock"],
		"aliases": ["@tui.list-clock", "@tui.list-clock-filled"],
		"filled": true,
		"filledName": "list-clock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-collapse",
		"tuiName": "@tui.list-collapse",
		"category": "editing",
		"keywords": ["list", "collapse"],
		"aliases": ["@tui.list-collapse", "@tui.list-collapse-filled"],
		"filled": true,
		"filledName": "list-collapse-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-end",
		"tuiName": "@tui.list-end",
		"category": "editing",
		"keywords": ["list", "end"],
		"aliases": ["@tui.list-end", "@tui.list-end-filled"],
		"filled": true,
		"filledName": "list-end-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-filter",
		"tuiName": "@tui.list-filter",
		"category": "editing",
		"keywords": ["list", "filter"],
		"aliases": ["@tui.list-filter", "@tui.list-filter-filled"],
		"filled": true,
		"filledName": "list-filter-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-filter-plus",
		"tuiName": "@tui.list-filter-plus",
		"category": "editing",
		"keywords": [
			"list",
			"filter",
			"plus"
		],
		"aliases": ["@tui.list-filter-plus", "@tui.list-filter-plus-filled"],
		"filled": true,
		"filledName": "list-filter-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-indent-decrease",
		"tuiName": "@tui.list-indent-decrease",
		"category": "editing",
		"keywords": [
			"list",
			"indent",
			"decrease"
		],
		"aliases": ["@tui.list-indent-decrease", "@tui.list-indent-decrease-filled"],
		"filled": true,
		"filledName": "list-indent-decrease-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-indent-increase",
		"tuiName": "@tui.list-indent-increase",
		"category": "editing",
		"keywords": [
			"list",
			"indent",
			"increase"
		],
		"aliases": ["@tui.list-indent-increase", "@tui.list-indent-increase-filled"],
		"filled": true,
		"filledName": "list-indent-increase-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-minus",
		"tuiName": "@tui.list-minus",
		"category": "editing",
		"keywords": ["list", "minus"],
		"aliases": ["@tui.list-minus", "@tui.list-minus-filled"],
		"filled": true,
		"filledName": "list-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-music",
		"tuiName": "@tui.list-music",
		"category": "editing",
		"keywords": ["list", "music"],
		"aliases": ["@tui.list-music", "@tui.list-music-filled"],
		"filled": true,
		"filledName": "list-music-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-ordered",
		"tuiName": "@tui.list-ordered",
		"category": "editing",
		"keywords": ["list", "ordered"],
		"aliases": ["@tui.list-ordered", "@tui.list-ordered-filled"],
		"filled": true,
		"filledName": "list-ordered-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-plus",
		"tuiName": "@tui.list-plus",
		"category": "editing",
		"keywords": ["list", "plus"],
		"aliases": ["@tui.list-plus", "@tui.list-plus-filled"],
		"filled": true,
		"filledName": "list-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-restart",
		"tuiName": "@tui.list-restart",
		"category": "editing",
		"keywords": ["list", "restart"],
		"aliases": ["@tui.list-restart", "@tui.list-restart-filled"],
		"filled": true,
		"filledName": "list-restart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-sort-ascending",
		"tuiName": "@tui.list-sort-ascending",
		"category": "editing",
		"keywords": [
			"list",
			"sort",
			"ascending"
		],
		"aliases": ["@tui.list-sort-ascending", "@tui.list-sort-ascending-filled"],
		"filled": true,
		"filledName": "list-sort-ascending-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-sort-descending",
		"tuiName": "@tui.list-sort-descending",
		"category": "editing",
		"keywords": [
			"list",
			"sort",
			"descending"
		],
		"aliases": ["@tui.list-sort-descending", "@tui.list-sort-descending-filled"],
		"filled": true,
		"filledName": "list-sort-descending-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-start",
		"tuiName": "@tui.list-start",
		"category": "editing",
		"keywords": ["list", "start"],
		"aliases": ["@tui.list-start", "@tui.list-start-filled"],
		"filled": true,
		"filledName": "list-start-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-todo",
		"tuiName": "@tui.list-todo",
		"category": "editing",
		"keywords": ["list", "todo"],
		"aliases": ["@tui.list-todo", "@tui.list-todo-filled"],
		"filled": true,
		"filledName": "list-todo-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-tree",
		"tuiName": "@tui.list-tree",
		"category": "editing",
		"keywords": ["list", "tree"],
		"aliases": ["@tui.list-tree", "@tui.list-tree-filled"],
		"filled": true,
		"filledName": "list-tree-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-video",
		"tuiName": "@tui.list-video",
		"category": "editing",
		"keywords": ["list", "video"],
		"aliases": ["@tui.list-video", "@tui.list-video-filled"],
		"filled": true,
		"filledName": "list-video-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "list-x",
		"tuiName": "@tui.list-x",
		"category": "editing",
		"keywords": ["list", "x"],
		"aliases": ["@tui.list-x", "@tui.list-x-filled"],
		"filled": true,
		"filledName": "list-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "loader",
		"tuiName": "@tui.loader",
		"category": "status-feedback",
		"keywords": ["loader"],
		"aliases": ["@tui.loader", "@tui.loader-filled"],
		"filled": true,
		"filledName": "loader-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "loader-2",
		"tuiName": "@tui.loader-2",
		"category": "status-feedback",
		"keywords": ["loader", "2"],
		"aliases": ["@tui.loader-2", "@tui.loader-2-filled"],
		"filled": true,
		"filledName": "loader-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "loader-circle",
		"tuiName": "@tui.loader-circle",
		"category": "status-feedback",
		"keywords": ["loader", "circle"],
		"aliases": ["@tui.loader-circle", "@tui.loader-circle-filled"],
		"filled": true,
		"filledName": "loader-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "loader-pinwheel",
		"tuiName": "@tui.loader-pinwheel",
		"category": "status-feedback",
		"keywords": ["loader", "pinwheel"],
		"aliases": ["@tui.loader-pinwheel", "@tui.loader-pinwheel-filled"],
		"filled": true,
		"filledName": "loader-pinwheel-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "locate",
		"tuiName": "@tui.locate",
		"category": "maps-location",
		"keywords": ["locate"],
		"aliases": ["@tui.locate", "@tui.locate-filled"],
		"filled": true,
		"filledName": "locate-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "locate-fixed",
		"tuiName": "@tui.locate-fixed",
		"category": "maps-location",
		"keywords": ["locate", "fixed"],
		"aliases": ["@tui.locate-fixed", "@tui.locate-fixed-filled"],
		"filled": true,
		"filledName": "locate-fixed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "locate-off",
		"tuiName": "@tui.locate-off",
		"category": "maps-location",
		"keywords": ["locate", "off"],
		"aliases": ["@tui.locate-off", "@tui.locate-off-filled"],
		"filled": true,
		"filledName": "locate-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "location-edit",
		"tuiName": "@tui.location-edit",
		"category": "custom",
		"keywords": ["location", "edit"],
		"aliases": ["@tui.location-edit", "@tui.location-edit-filled"],
		"filled": true,
		"filledName": "location-edit-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "lock",
		"tuiName": "@tui.lock",
		"category": "security",
		"keywords": ["lock"],
		"aliases": ["@tui.lock", "@tui.lock-filled"],
		"filled": true,
		"filledName": "lock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "lock-keyhole",
		"tuiName": "@tui.lock-keyhole",
		"category": "security",
		"keywords": ["lock", "keyhole"],
		"aliases": ["@tui.lock-keyhole", "@tui.lock-keyhole-filled"],
		"filled": true,
		"filledName": "lock-keyhole-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "lock-keyhole-open",
		"tuiName": "@tui.lock-keyhole-open",
		"category": "security",
		"keywords": [
			"lock",
			"keyhole",
			"open"
		],
		"aliases": ["@tui.lock-keyhole-open", "@tui.lock-keyhole-open-filled"],
		"filled": true,
		"filledName": "lock-keyhole-open-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "lock-open",
		"tuiName": "@tui.lock-open",
		"category": "security",
		"keywords": ["lock", "open"],
		"aliases": ["@tui.lock-open", "@tui.lock-open-filled"],
		"filled": true,
		"filledName": "lock-open-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "log-in",
		"tuiName": "@tui.log-in",
		"category": "actions",
		"keywords": ["log", "in"],
		"aliases": ["@tui.log-in", "@tui.log-in-filled"],
		"filled": true,
		"filledName": "log-in-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "log-out",
		"tuiName": "@tui.log-out",
		"category": "actions",
		"keywords": ["log", "out"],
		"aliases": ["@tui.log-out", "@tui.log-out-filled"],
		"filled": true,
		"filledName": "log-out-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "logs",
		"tuiName": "@tui.logs",
		"category": "custom",
		"keywords": ["logs"],
		"aliases": ["@tui.logs", "@tui.logs-filled"],
		"filled": true,
		"filledName": "logs-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "lollipop",
		"tuiName": "@tui.lollipop",
		"category": "custom",
		"keywords": ["lollipop"],
		"aliases": ["@tui.lollipop", "@tui.lollipop-filled"],
		"filled": true,
		"filledName": "lollipop-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "luggage",
		"tuiName": "@tui.luggage",
		"category": "custom",
		"keywords": ["luggage"],
		"aliases": ["@tui.luggage", "@tui.luggage-filled"],
		"filled": true,
		"filledName": "luggage-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "m-square",
		"tuiName": "@tui.m-square",
		"category": "custom",
		"keywords": ["m", "square"],
		"aliases": ["@tui.m-square", "@tui.m-square-filled"],
		"filled": true,
		"filledName": "m-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "maestro",
		"tuiName": "@tui.maestro",
		"category": "custom",
		"keywords": ["maestro"],
		"aliases": ["@tui.maestro"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "maestro-mono",
		"tuiName": "@tui.maestro-mono",
		"category": "custom",
		"keywords": ["maestro", "mono"],
		"aliases": ["@tui.maestro-mono"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "magnet",
		"tuiName": "@tui.magnet",
		"category": "custom",
		"keywords": ["magnet"],
		"aliases": ["@tui.magnet", "@tui.magnet-filled"],
		"filled": true,
		"filledName": "magnet-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mail",
		"tuiName": "@tui.mail",
		"category": "communication",
		"keywords": ["mail"],
		"aliases": ["@tui.mail", "@tui.mail-filled"],
		"filled": true,
		"filledName": "mail-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mail-badge",
		"tuiName": "@tui.mail-badge",
		"category": "communication",
		"keywords": ["mail", "badge"],
		"aliases": ["@tui.mail-badge", "@tui.mail-badge-filled"],
		"filled": true,
		"filledName": "mail-badge-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mail-check",
		"tuiName": "@tui.mail-check",
		"category": "communication",
		"keywords": ["mail", "check"],
		"aliases": ["@tui.mail-check", "@tui.mail-check-filled"],
		"filled": true,
		"filledName": "mail-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mail-clock",
		"tuiName": "@tui.mail-clock",
		"category": "communication",
		"keywords": ["mail", "clock"],
		"aliases": ["@tui.mail-clock", "@tui.mail-clock-filled"],
		"filled": true,
		"filledName": "mail-clock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mail-dot",
		"tuiName": "@tui.mail-dot",
		"category": "communication",
		"keywords": ["mail", "dot"],
		"aliases": ["@tui.mail-dot", "@tui.mail-dot-filled"],
		"filled": true,
		"filledName": "mail-dot-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mail-minus",
		"tuiName": "@tui.mail-minus",
		"category": "communication",
		"keywords": ["mail", "minus"],
		"aliases": ["@tui.mail-minus", "@tui.mail-minus-filled"],
		"filled": true,
		"filledName": "mail-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mail-open",
		"tuiName": "@tui.mail-open",
		"category": "communication",
		"keywords": ["mail", "open"],
		"aliases": ["@tui.mail-open", "@tui.mail-open-filled"],
		"filled": true,
		"filledName": "mail-open-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mail-pen",
		"tuiName": "@tui.mail-pen",
		"category": "communication",
		"keywords": ["mail", "pen"],
		"aliases": ["@tui.mail-pen", "@tui.mail-pen-filled"],
		"filled": true,
		"filledName": "mail-pen-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mail-plus",
		"tuiName": "@tui.mail-plus",
		"category": "communication",
		"keywords": ["mail", "plus"],
		"aliases": ["@tui.mail-plus", "@tui.mail-plus-filled"],
		"filled": true,
		"filledName": "mail-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mail-question",
		"tuiName": "@tui.mail-question",
		"category": "communication",
		"keywords": ["mail", "question"],
		"aliases": ["@tui.mail-question", "@tui.mail-question-filled"],
		"filled": true,
		"filledName": "mail-question-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mail-question-mark",
		"tuiName": "@tui.mail-question-mark",
		"category": "communication",
		"keywords": [
			"mail",
			"question",
			"mark"
		],
		"aliases": ["@tui.mail-question-mark", "@tui.mail-question-mark-filled"],
		"filled": true,
		"filledName": "mail-question-mark-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mail-search",
		"tuiName": "@tui.mail-search",
		"category": "communication",
		"keywords": ["mail", "search"],
		"aliases": ["@tui.mail-search", "@tui.mail-search-filled"],
		"filled": true,
		"filledName": "mail-search-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mail-warning",
		"tuiName": "@tui.mail-warning",
		"category": "communication",
		"keywords": ["mail", "warning"],
		"aliases": ["@tui.mail-warning", "@tui.mail-warning-filled"],
		"filled": true,
		"filledName": "mail-warning-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mail-x",
		"tuiName": "@tui.mail-x",
		"category": "communication",
		"keywords": ["mail", "x"],
		"aliases": ["@tui.mail-x", "@tui.mail-x-filled"],
		"filled": true,
		"filledName": "mail-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mailbox",
		"tuiName": "@tui.mailbox",
		"category": "communication",
		"keywords": ["mailbox"],
		"aliases": ["@tui.mailbox", "@tui.mailbox-filled"],
		"filled": true,
		"filledName": "mailbox-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mails",
		"tuiName": "@tui.mails",
		"category": "communication",
		"keywords": ["mails"],
		"aliases": ["@tui.mails", "@tui.mails-filled"],
		"filled": true,
		"filledName": "mails-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "map",
		"tuiName": "@tui.map",
		"category": "maps-location",
		"keywords": ["map"],
		"aliases": ["@tui.map", "@tui.map-filled"],
		"filled": true,
		"filledName": "map-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "map-minus",
		"tuiName": "@tui.map-minus",
		"category": "maps-location",
		"keywords": ["map", "minus"],
		"aliases": ["@tui.map-minus", "@tui.map-minus-filled"],
		"filled": true,
		"filledName": "map-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "map-pin",
		"tuiName": "@tui.map-pin",
		"category": "maps-location",
		"keywords": ["map", "pin"],
		"aliases": ["@tui.map-pin", "@tui.map-pin-filled"],
		"filled": true,
		"filledName": "map-pin-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "map-pin-check",
		"tuiName": "@tui.map-pin-check",
		"category": "maps-location",
		"keywords": [
			"map",
			"pin",
			"check"
		],
		"aliases": ["@tui.map-pin-check", "@tui.map-pin-check-filled"],
		"filled": true,
		"filledName": "map-pin-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "map-pin-check-inside",
		"tuiName": "@tui.map-pin-check-inside",
		"category": "maps-location",
		"keywords": [
			"map",
			"pin",
			"check",
			"inside"
		],
		"aliases": ["@tui.map-pin-check-inside", "@tui.map-pin-check-inside-filled"],
		"filled": true,
		"filledName": "map-pin-check-inside-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "map-pin-house",
		"tuiName": "@tui.map-pin-house",
		"category": "maps-location",
		"keywords": [
			"map",
			"pin",
			"house"
		],
		"aliases": ["@tui.map-pin-house", "@tui.map-pin-house-filled"],
		"filled": true,
		"filledName": "map-pin-house-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "map-pin-minus",
		"tuiName": "@tui.map-pin-minus",
		"category": "maps-location",
		"keywords": [
			"map",
			"pin",
			"minus"
		],
		"aliases": ["@tui.map-pin-minus", "@tui.map-pin-minus-filled"],
		"filled": true,
		"filledName": "map-pin-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "map-pin-minus-inside",
		"tuiName": "@tui.map-pin-minus-inside",
		"category": "maps-location",
		"keywords": [
			"map",
			"pin",
			"minus",
			"inside"
		],
		"aliases": ["@tui.map-pin-minus-inside", "@tui.map-pin-minus-inside-filled"],
		"filled": true,
		"filledName": "map-pin-minus-inside-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "map-pin-off",
		"tuiName": "@tui.map-pin-off",
		"category": "maps-location",
		"keywords": [
			"map",
			"pin",
			"off"
		],
		"aliases": ["@tui.map-pin-off", "@tui.map-pin-off-filled"],
		"filled": true,
		"filledName": "map-pin-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "map-pin-pen",
		"tuiName": "@tui.map-pin-pen",
		"category": "maps-location",
		"keywords": [
			"map",
			"pin",
			"pen"
		],
		"aliases": ["@tui.map-pin-pen", "@tui.map-pin-pen-filled"],
		"filled": true,
		"filledName": "map-pin-pen-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "map-pin-plus",
		"tuiName": "@tui.map-pin-plus",
		"category": "maps-location",
		"keywords": [
			"map",
			"pin",
			"plus"
		],
		"aliases": ["@tui.map-pin-plus", "@tui.map-pin-plus-filled"],
		"filled": true,
		"filledName": "map-pin-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "map-pin-plus-inside",
		"tuiName": "@tui.map-pin-plus-inside",
		"category": "maps-location",
		"keywords": [
			"map",
			"pin",
			"plus",
			"inside"
		],
		"aliases": ["@tui.map-pin-plus-inside", "@tui.map-pin-plus-inside-filled"],
		"filled": true,
		"filledName": "map-pin-plus-inside-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "map-pin-search",
		"tuiName": "@tui.map-pin-search",
		"category": "maps-location",
		"keywords": [
			"map",
			"pin",
			"search"
		],
		"aliases": ["@tui.map-pin-search", "@tui.map-pin-search-filled"],
		"filled": true,
		"filledName": "map-pin-search-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "map-pin-x",
		"tuiName": "@tui.map-pin-x",
		"category": "maps-location",
		"keywords": [
			"map",
			"pin",
			"x"
		],
		"aliases": ["@tui.map-pin-x", "@tui.map-pin-x-filled"],
		"filled": true,
		"filledName": "map-pin-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "map-pin-x-inside",
		"tuiName": "@tui.map-pin-x-inside",
		"category": "maps-location",
		"keywords": [
			"map",
			"pin",
			"x",
			"inside"
		],
		"aliases": ["@tui.map-pin-x-inside", "@tui.map-pin-x-inside-filled"],
		"filled": true,
		"filledName": "map-pin-x-inside-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "map-pinned",
		"tuiName": "@tui.map-pinned",
		"category": "maps-location",
		"keywords": ["map", "pinned"],
		"aliases": ["@tui.map-pinned", "@tui.map-pinned-filled"],
		"filled": true,
		"filledName": "map-pinned-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "map-plus",
		"tuiName": "@tui.map-plus",
		"category": "maps-location",
		"keywords": ["map", "plus"],
		"aliases": ["@tui.map-plus", "@tui.map-plus-filled"],
		"filled": true,
		"filledName": "map-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mars",
		"tuiName": "@tui.mars",
		"category": "custom",
		"keywords": ["mars"],
		"aliases": ["@tui.mars", "@tui.mars-filled"],
		"filled": true,
		"filledName": "mars-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mars-stroke",
		"tuiName": "@tui.mars-stroke",
		"category": "custom",
		"keywords": ["mars", "stroke"],
		"aliases": ["@tui.mars-stroke", "@tui.mars-stroke-filled"],
		"filled": true,
		"filledName": "mars-stroke-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "martini",
		"tuiName": "@tui.martini",
		"category": "custom",
		"keywords": ["martini"],
		"aliases": ["@tui.martini", "@tui.martini-filled"],
		"filled": true,
		"filledName": "martini-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mastercard",
		"tuiName": "@tui.mastercard",
		"category": "custom",
		"keywords": ["mastercard"],
		"aliases": ["@tui.mastercard"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mastercard-mono",
		"tuiName": "@tui.mastercard-mono",
		"category": "custom",
		"keywords": ["mastercard", "mono"],
		"aliases": ["@tui.mastercard-mono"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "maximize",
		"tuiName": "@tui.maximize",
		"category": "actions",
		"keywords": ["maximize"],
		"aliases": ["@tui.maximize", "@tui.maximize-filled"],
		"filled": true,
		"filledName": "maximize-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "maximize-2",
		"tuiName": "@tui.maximize-2",
		"category": "actions",
		"keywords": ["maximize", "2"],
		"aliases": ["@tui.maximize-2", "@tui.maximize-2-filled"],
		"filled": true,
		"filledName": "maximize-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "medal",
		"tuiName": "@tui.medal",
		"category": "custom",
		"keywords": ["medal"],
		"aliases": ["@tui.medal", "@tui.medal-filled"],
		"filled": true,
		"filledName": "medal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "megaphone",
		"tuiName": "@tui.megaphone",
		"category": "communication",
		"keywords": ["megaphone"],
		"aliases": ["@tui.megaphone", "@tui.megaphone-filled"],
		"filled": true,
		"filledName": "megaphone-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "megaphone-off",
		"tuiName": "@tui.megaphone-off",
		"category": "communication",
		"keywords": ["megaphone", "off"],
		"aliases": ["@tui.megaphone-off", "@tui.megaphone-off-filled"],
		"filled": true,
		"filledName": "megaphone-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "meh",
		"tuiName": "@tui.meh",
		"category": "status-feedback",
		"keywords": ["meh"],
		"aliases": ["@tui.meh", "@tui.meh-filled"],
		"filled": true,
		"filledName": "meh-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "memory-stick",
		"tuiName": "@tui.memory-stick",
		"category": "custom",
		"keywords": ["memory", "stick"],
		"aliases": ["@tui.memory-stick", "@tui.memory-stick-filled"],
		"filled": true,
		"filledName": "memory-stick-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "menu",
		"tuiName": "@tui.menu",
		"category": "navigation",
		"keywords": ["menu"],
		"aliases": ["@tui.menu", "@tui.menu-filled"],
		"filled": true,
		"filledName": "menu-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "menu-square",
		"tuiName": "@tui.menu-square",
		"category": "navigation",
		"keywords": ["menu", "square"],
		"aliases": ["@tui.menu-square", "@tui.menu-square-filled"],
		"filled": true,
		"filledName": "menu-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "merge",
		"tuiName": "@tui.merge",
		"category": "custom",
		"keywords": ["merge"],
		"aliases": ["@tui.merge", "@tui.merge-filled"],
		"filled": true,
		"filledName": "merge-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-circle",
		"tuiName": "@tui.message-circle",
		"category": "communication",
		"keywords": ["message", "circle"],
		"aliases": ["@tui.message-circle", "@tui.message-circle-filled"],
		"filled": true,
		"filledName": "message-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-circle-check",
		"tuiName": "@tui.message-circle-check",
		"category": "communication",
		"keywords": [
			"message",
			"circle",
			"check"
		],
		"aliases": ["@tui.message-circle-check", "@tui.message-circle-check-filled"],
		"filled": true,
		"filledName": "message-circle-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-circle-code",
		"tuiName": "@tui.message-circle-code",
		"category": "communication",
		"keywords": [
			"message",
			"circle",
			"code"
		],
		"aliases": ["@tui.message-circle-code", "@tui.message-circle-code-filled"],
		"filled": true,
		"filledName": "message-circle-code-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-circle-dashed",
		"tuiName": "@tui.message-circle-dashed",
		"category": "communication",
		"keywords": [
			"message",
			"circle",
			"dashed"
		],
		"aliases": ["@tui.message-circle-dashed", "@tui.message-circle-dashed-filled"],
		"filled": true,
		"filledName": "message-circle-dashed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-circle-dashed-check",
		"tuiName": "@tui.message-circle-dashed-check",
		"category": "communication",
		"keywords": [
			"message",
			"circle",
			"dashed",
			"check"
		],
		"aliases": ["@tui.message-circle-dashed-check", "@tui.message-circle-dashed-check-filled"],
		"filled": true,
		"filledName": "message-circle-dashed-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-circle-heart",
		"tuiName": "@tui.message-circle-heart",
		"category": "communication",
		"keywords": [
			"message",
			"circle",
			"heart"
		],
		"aliases": ["@tui.message-circle-heart", "@tui.message-circle-heart-filled"],
		"filled": true,
		"filledName": "message-circle-heart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-circle-more",
		"tuiName": "@tui.message-circle-more",
		"category": "communication",
		"keywords": [
			"message",
			"circle",
			"more"
		],
		"aliases": ["@tui.message-circle-more", "@tui.message-circle-more-filled"],
		"filled": true,
		"filledName": "message-circle-more-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-circle-off",
		"tuiName": "@tui.message-circle-off",
		"category": "communication",
		"keywords": [
			"message",
			"circle",
			"off"
		],
		"aliases": ["@tui.message-circle-off", "@tui.message-circle-off-filled"],
		"filled": true,
		"filledName": "message-circle-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-circle-plus",
		"tuiName": "@tui.message-circle-plus",
		"category": "communication",
		"keywords": [
			"message",
			"circle",
			"plus"
		],
		"aliases": ["@tui.message-circle-plus", "@tui.message-circle-plus-filled"],
		"filled": true,
		"filledName": "message-circle-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-circle-question",
		"tuiName": "@tui.message-circle-question",
		"category": "communication",
		"keywords": [
			"message",
			"circle",
			"question"
		],
		"aliases": ["@tui.message-circle-question", "@tui.message-circle-question-filled"],
		"filled": true,
		"filledName": "message-circle-question-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-circle-question-mark",
		"tuiName": "@tui.message-circle-question-mark",
		"category": "communication",
		"keywords": [
			"message",
			"circle",
			"question",
			"mark"
		],
		"aliases": ["@tui.message-circle-question-mark", "@tui.message-circle-question-mark-filled"],
		"filled": true,
		"filledName": "message-circle-question-mark-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-circle-reply",
		"tuiName": "@tui.message-circle-reply",
		"category": "communication",
		"keywords": [
			"message",
			"circle",
			"reply"
		],
		"aliases": ["@tui.message-circle-reply", "@tui.message-circle-reply-filled"],
		"filled": true,
		"filledName": "message-circle-reply-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-circle-text",
		"tuiName": "@tui.message-circle-text",
		"category": "communication",
		"keywords": [
			"message",
			"circle",
			"text"
		],
		"aliases": ["@tui.message-circle-text", "@tui.message-circle-text-filled"],
		"filled": true,
		"filledName": "message-circle-text-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-circle-warning",
		"tuiName": "@tui.message-circle-warning",
		"category": "communication",
		"keywords": [
			"message",
			"circle",
			"warning"
		],
		"aliases": ["@tui.message-circle-warning", "@tui.message-circle-warning-filled"],
		"filled": true,
		"filledName": "message-circle-warning-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-circle-x",
		"tuiName": "@tui.message-circle-x",
		"category": "communication",
		"keywords": [
			"message",
			"circle",
			"x"
		],
		"aliases": ["@tui.message-circle-x", "@tui.message-circle-x-filled"],
		"filled": true,
		"filledName": "message-circle-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-square",
		"tuiName": "@tui.message-square",
		"category": "communication",
		"keywords": ["message", "square"],
		"aliases": ["@tui.message-square", "@tui.message-square-filled"],
		"filled": true,
		"filledName": "message-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-square-check",
		"tuiName": "@tui.message-square-check",
		"category": "communication",
		"keywords": [
			"message",
			"square",
			"check"
		],
		"aliases": ["@tui.message-square-check", "@tui.message-square-check-filled"],
		"filled": true,
		"filledName": "message-square-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-square-code",
		"tuiName": "@tui.message-square-code",
		"category": "communication",
		"keywords": [
			"message",
			"square",
			"code"
		],
		"aliases": ["@tui.message-square-code", "@tui.message-square-code-filled"],
		"filled": true,
		"filledName": "message-square-code-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-square-dashed",
		"tuiName": "@tui.message-square-dashed",
		"category": "communication",
		"keywords": [
			"message",
			"square",
			"dashed"
		],
		"aliases": ["@tui.message-square-dashed", "@tui.message-square-dashed-filled"],
		"filled": true,
		"filledName": "message-square-dashed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-square-diff",
		"tuiName": "@tui.message-square-diff",
		"category": "communication",
		"keywords": [
			"message",
			"square",
			"diff"
		],
		"aliases": ["@tui.message-square-diff", "@tui.message-square-diff-filled"],
		"filled": true,
		"filledName": "message-square-diff-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-square-dot",
		"tuiName": "@tui.message-square-dot",
		"category": "communication",
		"keywords": [
			"message",
			"square",
			"dot"
		],
		"aliases": ["@tui.message-square-dot", "@tui.message-square-dot-filled"],
		"filled": true,
		"filledName": "message-square-dot-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-square-heart",
		"tuiName": "@tui.message-square-heart",
		"category": "communication",
		"keywords": [
			"message",
			"square",
			"heart"
		],
		"aliases": ["@tui.message-square-heart", "@tui.message-square-heart-filled"],
		"filled": true,
		"filledName": "message-square-heart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-square-lock",
		"tuiName": "@tui.message-square-lock",
		"category": "communication",
		"keywords": [
			"message",
			"square",
			"lock"
		],
		"aliases": ["@tui.message-square-lock", "@tui.message-square-lock-filled"],
		"filled": true,
		"filledName": "message-square-lock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-square-more",
		"tuiName": "@tui.message-square-more",
		"category": "communication",
		"keywords": [
			"message",
			"square",
			"more"
		],
		"aliases": ["@tui.message-square-more", "@tui.message-square-more-filled"],
		"filled": true,
		"filledName": "message-square-more-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-square-off",
		"tuiName": "@tui.message-square-off",
		"category": "communication",
		"keywords": [
			"message",
			"square",
			"off"
		],
		"aliases": ["@tui.message-square-off", "@tui.message-square-off-filled"],
		"filled": true,
		"filledName": "message-square-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-square-plus",
		"tuiName": "@tui.message-square-plus",
		"category": "communication",
		"keywords": [
			"message",
			"square",
			"plus"
		],
		"aliases": ["@tui.message-square-plus", "@tui.message-square-plus-filled"],
		"filled": true,
		"filledName": "message-square-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-square-quote",
		"tuiName": "@tui.message-square-quote",
		"category": "communication",
		"keywords": [
			"message",
			"square",
			"quote"
		],
		"aliases": ["@tui.message-square-quote", "@tui.message-square-quote-filled"],
		"filled": true,
		"filledName": "message-square-quote-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-square-reply",
		"tuiName": "@tui.message-square-reply",
		"category": "communication",
		"keywords": [
			"message",
			"square",
			"reply"
		],
		"aliases": ["@tui.message-square-reply", "@tui.message-square-reply-filled"],
		"filled": true,
		"filledName": "message-square-reply-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-square-share",
		"tuiName": "@tui.message-square-share",
		"category": "communication",
		"keywords": [
			"message",
			"square",
			"share"
		],
		"aliases": ["@tui.message-square-share", "@tui.message-square-share-filled"],
		"filled": true,
		"filledName": "message-square-share-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-square-text",
		"tuiName": "@tui.message-square-text",
		"category": "communication",
		"keywords": [
			"message",
			"square",
			"text"
		],
		"aliases": ["@tui.message-square-text", "@tui.message-square-text-filled"],
		"filled": true,
		"filledName": "message-square-text-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-square-warning",
		"tuiName": "@tui.message-square-warning",
		"category": "communication",
		"keywords": [
			"message",
			"square",
			"warning"
		],
		"aliases": ["@tui.message-square-warning", "@tui.message-square-warning-filled"],
		"filled": true,
		"filledName": "message-square-warning-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "message-square-x",
		"tuiName": "@tui.message-square-x",
		"category": "communication",
		"keywords": [
			"message",
			"square",
			"x"
		],
		"aliases": ["@tui.message-square-x", "@tui.message-square-x-filled"],
		"filled": true,
		"filledName": "message-square-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "messages-circle",
		"tuiName": "@tui.messages-circle",
		"category": "communication",
		"keywords": ["messages", "circle"],
		"aliases": ["@tui.messages-circle", "@tui.messages-circle-filled"],
		"filled": true,
		"filledName": "messages-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "messages-square",
		"tuiName": "@tui.messages-square",
		"category": "communication",
		"keywords": ["messages", "square"],
		"aliases": ["@tui.messages-square", "@tui.messages-square-filled"],
		"filled": true,
		"filledName": "messages-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "metronome",
		"tuiName": "@tui.metronome",
		"category": "custom",
		"keywords": ["metronome"],
		"aliases": ["@tui.metronome", "@tui.metronome-filled"],
		"filled": true,
		"filledName": "metronome-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mic",
		"tuiName": "@tui.mic",
		"category": "media",
		"keywords": ["mic"],
		"aliases": ["@tui.mic", "@tui.mic-filled"],
		"filled": true,
		"filledName": "mic-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mic-2",
		"tuiName": "@tui.mic-2",
		"category": "media",
		"keywords": ["mic", "2"],
		"aliases": ["@tui.mic-2", "@tui.mic-2-filled"],
		"filled": true,
		"filledName": "mic-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mic-audio-lines",
		"tuiName": "@tui.mic-audio-lines",
		"category": "media",
		"keywords": [
			"mic",
			"audio",
			"lines"
		],
		"aliases": ["@tui.mic-audio-lines", "@tui.mic-audio-lines-filled"],
		"filled": true,
		"filledName": "mic-audio-lines-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mic-off",
		"tuiName": "@tui.mic-off",
		"category": "media",
		"keywords": ["mic", "off"],
		"aliases": ["@tui.mic-off", "@tui.mic-off-filled"],
		"filled": true,
		"filledName": "mic-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mic-signal",
		"tuiName": "@tui.mic-signal",
		"category": "media",
		"keywords": ["mic", "signal"],
		"aliases": ["@tui.mic-signal", "@tui.mic-signal-filled"],
		"filled": true,
		"filledName": "mic-signal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mic-vocal",
		"tuiName": "@tui.mic-vocal",
		"category": "media",
		"keywords": ["mic", "vocal"],
		"aliases": ["@tui.mic-vocal", "@tui.mic-vocal-filled"],
		"filled": true,
		"filledName": "mic-vocal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "microchip",
		"tuiName": "@tui.microchip",
		"category": "media",
		"keywords": ["microchip"],
		"aliases": ["@tui.microchip", "@tui.microchip-filled"],
		"filled": true,
		"filledName": "microchip-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "microscope",
		"tuiName": "@tui.microscope",
		"category": "media",
		"keywords": ["microscope"],
		"aliases": ["@tui.microscope", "@tui.microscope-filled"],
		"filled": true,
		"filledName": "microscope-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "microwave",
		"tuiName": "@tui.microwave",
		"category": "media",
		"keywords": ["microwave"],
		"aliases": ["@tui.microwave", "@tui.microwave-filled"],
		"filled": true,
		"filledName": "microwave-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "midi-port",
		"tuiName": "@tui.midi-port",
		"category": "custom",
		"keywords": ["midi", "port"],
		"aliases": ["@tui.midi-port", "@tui.midi-port-filled"],
		"filled": true,
		"filledName": "midi-port-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "milestone",
		"tuiName": "@tui.milestone",
		"category": "maps-location",
		"keywords": ["milestone"],
		"aliases": ["@tui.milestone", "@tui.milestone-filled"],
		"filled": true,
		"filledName": "milestone-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "milk",
		"tuiName": "@tui.milk",
		"category": "custom",
		"keywords": ["milk"],
		"aliases": ["@tui.milk", "@tui.milk-filled"],
		"filled": true,
		"filledName": "milk-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "milk-off",
		"tuiName": "@tui.milk-off",
		"category": "custom",
		"keywords": ["milk", "off"],
		"aliases": ["@tui.milk-off", "@tui.milk-off-filled"],
		"filled": true,
		"filledName": "milk-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "minimize",
		"tuiName": "@tui.minimize",
		"category": "actions",
		"keywords": ["minimize"],
		"aliases": ["@tui.minimize", "@tui.minimize-filled"],
		"filled": true,
		"filledName": "minimize-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "minimize-2",
		"tuiName": "@tui.minimize-2",
		"category": "actions",
		"keywords": ["minimize", "2"],
		"aliases": ["@tui.minimize-2", "@tui.minimize-2-filled"],
		"filled": true,
		"filledName": "minimize-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "minus",
		"tuiName": "@tui.minus",
		"category": "actions",
		"keywords": ["minus"],
		"aliases": ["@tui.minus", "@tui.minus-filled"],
		"filled": true,
		"filledName": "minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "minus-circle",
		"tuiName": "@tui.minus-circle",
		"category": "actions",
		"keywords": ["minus", "circle"],
		"aliases": ["@tui.minus-circle", "@tui.minus-circle-filled"],
		"filled": true,
		"filledName": "minus-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "minus-square",
		"tuiName": "@tui.minus-square",
		"category": "actions",
		"keywords": ["minus", "square"],
		"aliases": ["@tui.minus-square", "@tui.minus-square-filled"],
		"filled": true,
		"filledName": "minus-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mir",
		"tuiName": "@tui.mir",
		"category": "custom",
		"keywords": ["mir"],
		"aliases": ["@tui.mir"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mir-mono",
		"tuiName": "@tui.mir-mono",
		"category": "custom",
		"keywords": ["mir", "mono"],
		"aliases": ["@tui.mir-mono"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mirror-rectangular",
		"tuiName": "@tui.mirror-rectangular",
		"category": "custom",
		"keywords": ["mirror", "rectangular"],
		"aliases": ["@tui.mirror-rectangular", "@tui.mirror-rectangular-filled"],
		"filled": true,
		"filledName": "mirror-rectangular-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mirror-round",
		"tuiName": "@tui.mirror-round",
		"category": "custom",
		"keywords": ["mirror", "round"],
		"aliases": ["@tui.mirror-round", "@tui.mirror-round-filled"],
		"filled": true,
		"filledName": "mirror-round-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "monitor",
		"tuiName": "@tui.monitor",
		"category": "devices",
		"keywords": ["monitor"],
		"aliases": ["@tui.monitor", "@tui.monitor-filled"],
		"filled": true,
		"filledName": "monitor-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "monitor-check",
		"tuiName": "@tui.monitor-check",
		"category": "devices",
		"keywords": ["monitor", "check"],
		"aliases": ["@tui.monitor-check", "@tui.monitor-check-filled"],
		"filled": true,
		"filledName": "monitor-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "monitor-cloud",
		"tuiName": "@tui.monitor-cloud",
		"category": "devices",
		"keywords": ["monitor", "cloud"],
		"aliases": ["@tui.monitor-cloud", "@tui.monitor-cloud-filled"],
		"filled": true,
		"filledName": "monitor-cloud-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "monitor-cog",
		"tuiName": "@tui.monitor-cog",
		"category": "devices",
		"keywords": ["monitor", "cog"],
		"aliases": ["@tui.monitor-cog", "@tui.monitor-cog-filled"],
		"filled": true,
		"filledName": "monitor-cog-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "monitor-dot",
		"tuiName": "@tui.monitor-dot",
		"category": "devices",
		"keywords": ["monitor", "dot"],
		"aliases": ["@tui.monitor-dot", "@tui.monitor-dot-filled"],
		"filled": true,
		"filledName": "monitor-dot-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "monitor-down",
		"tuiName": "@tui.monitor-down",
		"category": "devices",
		"keywords": ["monitor", "down"],
		"aliases": ["@tui.monitor-down", "@tui.monitor-down-filled"],
		"filled": true,
		"filledName": "monitor-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "monitor-off",
		"tuiName": "@tui.monitor-off",
		"category": "devices",
		"keywords": ["monitor", "off"],
		"aliases": ["@tui.monitor-off", "@tui.monitor-off-filled"],
		"filled": true,
		"filledName": "monitor-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "monitor-pause",
		"tuiName": "@tui.monitor-pause",
		"category": "devices",
		"keywords": ["monitor", "pause"],
		"aliases": ["@tui.monitor-pause", "@tui.monitor-pause-filled"],
		"filled": true,
		"filledName": "monitor-pause-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "monitor-pc",
		"tuiName": "@tui.monitor-pc",
		"category": "devices",
		"keywords": ["monitor", "pc"],
		"aliases": ["@tui.monitor-pc", "@tui.monitor-pc-filled"],
		"filled": true,
		"filledName": "monitor-pc-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "monitor-play",
		"tuiName": "@tui.monitor-play",
		"category": "devices",
		"keywords": ["monitor", "play"],
		"aliases": ["@tui.monitor-play", "@tui.monitor-play-filled"],
		"filled": true,
		"filledName": "monitor-play-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "monitor-smartphone",
		"tuiName": "@tui.monitor-smartphone",
		"category": "devices",
		"keywords": ["monitor", "smartphone"],
		"aliases": ["@tui.monitor-smartphone", "@tui.monitor-smartphone-filled"],
		"filled": true,
		"filledName": "monitor-smartphone-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "monitor-speaker",
		"tuiName": "@tui.monitor-speaker",
		"category": "devices",
		"keywords": ["monitor", "speaker"],
		"aliases": ["@tui.monitor-speaker", "@tui.monitor-speaker-filled"],
		"filled": true,
		"filledName": "monitor-speaker-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "monitor-stop",
		"tuiName": "@tui.monitor-stop",
		"category": "devices",
		"keywords": ["monitor", "stop"],
		"aliases": ["@tui.monitor-stop", "@tui.monitor-stop-filled"],
		"filled": true,
		"filledName": "monitor-stop-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "monitor-up",
		"tuiName": "@tui.monitor-up",
		"category": "devices",
		"keywords": ["monitor", "up"],
		"aliases": ["@tui.monitor-up", "@tui.monitor-up-filled"],
		"filled": true,
		"filledName": "monitor-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "monitor-x",
		"tuiName": "@tui.monitor-x",
		"category": "devices",
		"keywords": ["monitor", "x"],
		"aliases": ["@tui.monitor-x", "@tui.monitor-x-filled"],
		"filled": true,
		"filledName": "monitor-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "moon",
		"tuiName": "@tui.moon",
		"category": "calendar-time",
		"keywords": ["moon"],
		"aliases": ["@tui.moon", "@tui.moon-filled"],
		"filled": true,
		"filledName": "moon-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "moon-star",
		"tuiName": "@tui.moon-star",
		"category": "calendar-time",
		"keywords": ["moon", "star"],
		"aliases": ["@tui.moon-star", "@tui.moon-star-filled"],
		"filled": true,
		"filledName": "moon-star-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mop",
		"tuiName": "@tui.mop",
		"category": "custom",
		"keywords": ["mop"],
		"aliases": ["@tui.mop", "@tui.mop-filled"],
		"filled": true,
		"filledName": "mop-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mop-sparkles",
		"tuiName": "@tui.mop-sparkles",
		"category": "custom",
		"keywords": ["mop", "sparkles"],
		"aliases": ["@tui.mop-sparkles", "@tui.mop-sparkles-filled"],
		"filled": true,
		"filledName": "mop-sparkles-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "more-horizontal",
		"tuiName": "@tui.more-horizontal",
		"category": "actions",
		"keywords": ["more", "horizontal"],
		"aliases": ["@tui.more-horizontal", "@tui.more-horizontal-filled"],
		"filled": true,
		"filledName": "more-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "more-vertical",
		"tuiName": "@tui.more-vertical",
		"category": "actions",
		"keywords": ["more", "vertical"],
		"aliases": ["@tui.more-vertical", "@tui.more-vertical-filled"],
		"filled": true,
		"filledName": "more-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mosque",
		"tuiName": "@tui.mosque",
		"category": "custom",
		"keywords": ["mosque"],
		"aliases": ["@tui.mosque", "@tui.mosque-filled"],
		"filled": true,
		"filledName": "mosque-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "motorbike",
		"tuiName": "@tui.motorbike",
		"category": "custom",
		"keywords": ["motorbike"],
		"aliases": ["@tui.motorbike", "@tui.motorbike-filled"],
		"filled": true,
		"filledName": "motorbike-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mountain",
		"tuiName": "@tui.mountain",
		"category": "custom",
		"keywords": ["mountain"],
		"aliases": ["@tui.mountain", "@tui.mountain-filled"],
		"filled": true,
		"filledName": "mountain-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mountain-snow",
		"tuiName": "@tui.mountain-snow",
		"category": "custom",
		"keywords": ["mountain", "snow"],
		"aliases": ["@tui.mountain-snow", "@tui.mountain-snow-filled"],
		"filled": true,
		"filledName": "mountain-snow-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mouse",
		"tuiName": "@tui.mouse",
		"category": "devices",
		"keywords": ["mouse"],
		"aliases": ["@tui.mouse", "@tui.mouse-filled"],
		"filled": true,
		"filledName": "mouse-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mouse-left",
		"tuiName": "@tui.mouse-left",
		"category": "devices",
		"keywords": ["mouse", "left"],
		"aliases": ["@tui.mouse-left", "@tui.mouse-left-filled"],
		"filled": true,
		"filledName": "mouse-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mouse-off",
		"tuiName": "@tui.mouse-off",
		"category": "devices",
		"keywords": ["mouse", "off"],
		"aliases": ["@tui.mouse-off", "@tui.mouse-off-filled"],
		"filled": true,
		"filledName": "mouse-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mouse-pointer",
		"tuiName": "@tui.mouse-pointer",
		"category": "devices",
		"keywords": ["mouse", "pointer"],
		"aliases": ["@tui.mouse-pointer", "@tui.mouse-pointer-filled"],
		"filled": true,
		"filledName": "mouse-pointer-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mouse-pointer-2",
		"tuiName": "@tui.mouse-pointer-2",
		"category": "devices",
		"keywords": [
			"mouse",
			"pointer",
			"2"
		],
		"aliases": ["@tui.mouse-pointer-2", "@tui.mouse-pointer-2-filled"],
		"filled": true,
		"filledName": "mouse-pointer-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mouse-pointer-2-off",
		"tuiName": "@tui.mouse-pointer-2-off",
		"category": "devices",
		"keywords": [
			"mouse",
			"pointer",
			"2",
			"off"
		],
		"aliases": ["@tui.mouse-pointer-2-off", "@tui.mouse-pointer-2-off-filled"],
		"filled": true,
		"filledName": "mouse-pointer-2-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mouse-pointer-ban",
		"tuiName": "@tui.mouse-pointer-ban",
		"category": "devices",
		"keywords": [
			"mouse",
			"pointer",
			"ban"
		],
		"aliases": ["@tui.mouse-pointer-ban", "@tui.mouse-pointer-ban-filled"],
		"filled": true,
		"filledName": "mouse-pointer-ban-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mouse-pointer-click",
		"tuiName": "@tui.mouse-pointer-click",
		"category": "devices",
		"keywords": [
			"mouse",
			"pointer",
			"click"
		],
		"aliases": ["@tui.mouse-pointer-click", "@tui.mouse-pointer-click-filled"],
		"filled": true,
		"filledName": "mouse-pointer-click-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mouse-pointer-square-dashed",
		"tuiName": "@tui.mouse-pointer-square-dashed",
		"category": "devices",
		"keywords": [
			"mouse",
			"pointer",
			"square",
			"dashed"
		],
		"aliases": ["@tui.mouse-pointer-square-dashed", "@tui.mouse-pointer-square-dashed-filled"],
		"filled": true,
		"filledName": "mouse-pointer-square-dashed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mouse-right",
		"tuiName": "@tui.mouse-right",
		"category": "devices",
		"keywords": ["mouse", "right"],
		"aliases": ["@tui.mouse-right", "@tui.mouse-right-filled"],
		"filled": true,
		"filledName": "mouse-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mouth",
		"tuiName": "@tui.mouth",
		"category": "custom",
		"keywords": ["mouth"],
		"aliases": ["@tui.mouth", "@tui.mouth-filled"],
		"filled": true,
		"filledName": "mouth-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "mouth-off",
		"tuiName": "@tui.mouth-off",
		"category": "custom",
		"keywords": ["mouth", "off"],
		"aliases": ["@tui.mouth-off", "@tui.mouth-off-filled"],
		"filled": true,
		"filledName": "mouth-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "move",
		"tuiName": "@tui.move",
		"category": "custom",
		"keywords": ["move"],
		"aliases": ["@tui.move", "@tui.move-filled"],
		"filled": true,
		"filledName": "move-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "move-3-d",
		"tuiName": "@tui.move-3-d",
		"category": "arrows",
		"keywords": [
			"move",
			"3",
			"d"
		],
		"aliases": ["@tui.move-3-d", "@tui.move-3-d-filled"],
		"filled": true,
		"filledName": "move-3-d-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "move-3d",
		"tuiName": "@tui.move-3d",
		"category": "arrows",
		"keywords": ["move", "3d"],
		"aliases": ["@tui.move-3d", "@tui.move-3d-filled"],
		"filled": true,
		"filledName": "move-3d-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "move-diagonal",
		"tuiName": "@tui.move-diagonal",
		"category": "arrows",
		"keywords": ["move", "diagonal"],
		"aliases": ["@tui.move-diagonal", "@tui.move-diagonal-filled"],
		"filled": true,
		"filledName": "move-diagonal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "move-diagonal-2",
		"tuiName": "@tui.move-diagonal-2",
		"category": "arrows",
		"keywords": [
			"move",
			"diagonal",
			"2"
		],
		"aliases": ["@tui.move-diagonal-2", "@tui.move-diagonal-2-filled"],
		"filled": true,
		"filledName": "move-diagonal-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "move-down",
		"tuiName": "@tui.move-down",
		"category": "arrows",
		"keywords": ["move", "down"],
		"aliases": ["@tui.move-down", "@tui.move-down-filled"],
		"filled": true,
		"filledName": "move-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "move-down-left",
		"tuiName": "@tui.move-down-left",
		"category": "arrows",
		"keywords": [
			"move",
			"down",
			"left"
		],
		"aliases": ["@tui.move-down-left", "@tui.move-down-left-filled"],
		"filled": true,
		"filledName": "move-down-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "move-down-right",
		"tuiName": "@tui.move-down-right",
		"category": "arrows",
		"keywords": [
			"move",
			"down",
			"right"
		],
		"aliases": ["@tui.move-down-right", "@tui.move-down-right-filled"],
		"filled": true,
		"filledName": "move-down-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "move-horizontal",
		"tuiName": "@tui.move-horizontal",
		"category": "arrows",
		"keywords": ["move", "horizontal"],
		"aliases": ["@tui.move-horizontal", "@tui.move-horizontal-filled"],
		"filled": true,
		"filledName": "move-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "move-left",
		"tuiName": "@tui.move-left",
		"category": "arrows",
		"keywords": ["move", "left"],
		"aliases": ["@tui.move-left", "@tui.move-left-filled"],
		"filled": true,
		"filledName": "move-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "move-right",
		"tuiName": "@tui.move-right",
		"category": "arrows",
		"keywords": ["move", "right"],
		"aliases": ["@tui.move-right", "@tui.move-right-filled"],
		"filled": true,
		"filledName": "move-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "move-up",
		"tuiName": "@tui.move-up",
		"category": "arrows",
		"keywords": ["move", "up"],
		"aliases": ["@tui.move-up", "@tui.move-up-filled"],
		"filled": true,
		"filledName": "move-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "move-up-left",
		"tuiName": "@tui.move-up-left",
		"category": "arrows",
		"keywords": [
			"move",
			"up",
			"left"
		],
		"aliases": ["@tui.move-up-left", "@tui.move-up-left-filled"],
		"filled": true,
		"filledName": "move-up-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "move-up-right",
		"tuiName": "@tui.move-up-right",
		"category": "arrows",
		"keywords": [
			"move",
			"up",
			"right"
		],
		"aliases": ["@tui.move-up-right", "@tui.move-up-right-filled"],
		"filled": true,
		"filledName": "move-up-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "move-vertical",
		"tuiName": "@tui.move-vertical",
		"category": "arrows",
		"keywords": ["move", "vertical"],
		"aliases": ["@tui.move-vertical", "@tui.move-vertical-filled"],
		"filled": true,
		"filledName": "move-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "music",
		"tuiName": "@tui.music",
		"category": "media",
		"keywords": ["music"],
		"aliases": ["@tui.music", "@tui.music-filled"],
		"filled": true,
		"filledName": "music-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "music-2",
		"tuiName": "@tui.music-2",
		"category": "media",
		"keywords": ["music", "2"],
		"aliases": ["@tui.music-2", "@tui.music-2-filled"],
		"filled": true,
		"filledName": "music-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "music-3",
		"tuiName": "@tui.music-3",
		"category": "media",
		"keywords": ["music", "3"],
		"aliases": ["@tui.music-3", "@tui.music-3-filled"],
		"filled": true,
		"filledName": "music-3-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "music-4",
		"tuiName": "@tui.music-4",
		"category": "media",
		"keywords": ["music", "4"],
		"aliases": ["@tui.music-4", "@tui.music-4-filled"],
		"filled": true,
		"filledName": "music-4-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "navigation",
		"tuiName": "@tui.navigation",
		"category": "maps-location",
		"keywords": ["navigation"],
		"aliases": ["@tui.navigation", "@tui.navigation-filled"],
		"filled": true,
		"filledName": "navigation-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "navigation-2",
		"tuiName": "@tui.navigation-2",
		"category": "maps-location",
		"keywords": ["navigation", "2"],
		"aliases": ["@tui.navigation-2", "@tui.navigation-2-filled"],
		"filled": true,
		"filledName": "navigation-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "navigation-2-off",
		"tuiName": "@tui.navigation-2-off",
		"category": "maps-location",
		"keywords": [
			"navigation",
			"2",
			"off"
		],
		"aliases": ["@tui.navigation-2-off", "@tui.navigation-2-off-filled"],
		"filled": true,
		"filledName": "navigation-2-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "navigation-off",
		"tuiName": "@tui.navigation-off",
		"category": "maps-location",
		"keywords": ["navigation", "off"],
		"aliases": ["@tui.navigation-off", "@tui.navigation-off-filled"],
		"filled": true,
		"filledName": "navigation-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "nepali-rupee",
		"tuiName": "@tui.nepali-rupee",
		"category": "custom",
		"keywords": ["nepali", "rupee"],
		"aliases": ["@tui.nepali-rupee", "@tui.nepali-rupee-filled"],
		"filled": true,
		"filledName": "nepali-rupee-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "network",
		"tuiName": "@tui.network",
		"category": "custom",
		"keywords": ["network"],
		"aliases": ["@tui.network", "@tui.network-filled"],
		"filled": true,
		"filledName": "network-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "newspaper",
		"tuiName": "@tui.newspaper",
		"category": "custom",
		"keywords": ["newspaper"],
		"aliases": ["@tui.newspaper", "@tui.newspaper-filled"],
		"filled": true,
		"filledName": "newspaper-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "nfc",
		"tuiName": "@tui.nfc",
		"category": "custom",
		"keywords": ["nfc"],
		"aliases": ["@tui.nfc", "@tui.nfc-filled"],
		"filled": true,
		"filledName": "nfc-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "non-binary",
		"tuiName": "@tui.non-binary",
		"category": "custom",
		"keywords": ["non", "binary"],
		"aliases": ["@tui.non-binary", "@tui.non-binary-filled"],
		"filled": true,
		"filledName": "non-binary-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "notebook",
		"tuiName": "@tui.notebook",
		"category": "files",
		"keywords": ["notebook"],
		"aliases": ["@tui.notebook", "@tui.notebook-filled"],
		"filled": true,
		"filledName": "notebook-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "notebook-dot",
		"tuiName": "@tui.notebook-dot",
		"category": "files",
		"keywords": ["notebook", "dot"],
		"aliases": ["@tui.notebook-dot", "@tui.notebook-dot-filled"],
		"filled": true,
		"filledName": "notebook-dot-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "notebook-pen",
		"tuiName": "@tui.notebook-pen",
		"category": "files",
		"keywords": ["notebook", "pen"],
		"aliases": ["@tui.notebook-pen", "@tui.notebook-pen-filled"],
		"filled": true,
		"filledName": "notebook-pen-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "notebook-tabs",
		"tuiName": "@tui.notebook-tabs",
		"category": "files",
		"keywords": ["notebook", "tabs"],
		"aliases": ["@tui.notebook-tabs", "@tui.notebook-tabs-filled"],
		"filled": true,
		"filledName": "notebook-tabs-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "notebook-text",
		"tuiName": "@tui.notebook-text",
		"category": "files",
		"keywords": ["notebook", "text"],
		"aliases": ["@tui.notebook-text", "@tui.notebook-text-filled"],
		"filled": true,
		"filledName": "notebook-text-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "notepad-text",
		"tuiName": "@tui.notepad-text",
		"category": "custom",
		"keywords": ["notepad", "text"],
		"aliases": ["@tui.notepad-text", "@tui.notepad-text-filled"],
		"filled": true,
		"filledName": "notepad-text-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "notepad-text-dashed",
		"tuiName": "@tui.notepad-text-dashed",
		"category": "custom",
		"keywords": [
			"notepad",
			"text",
			"dashed"
		],
		"aliases": ["@tui.notepad-text-dashed", "@tui.notepad-text-dashed-filled"],
		"filled": true,
		"filledName": "notepad-text-dashed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "nut",
		"tuiName": "@tui.nut",
		"category": "custom",
		"keywords": ["nut"],
		"aliases": ["@tui.nut", "@tui.nut-filled"],
		"filled": true,
		"filledName": "nut-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "nut-off",
		"tuiName": "@tui.nut-off",
		"category": "custom",
		"keywords": ["nut", "off"],
		"aliases": ["@tui.nut-off", "@tui.nut-off-filled"],
		"filled": true,
		"filledName": "nut-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "octagon",
		"tuiName": "@tui.octagon",
		"category": "custom",
		"keywords": ["octagon"],
		"aliases": ["@tui.octagon", "@tui.octagon-filled"],
		"filled": true,
		"filledName": "octagon-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "octagon-alert",
		"tuiName": "@tui.octagon-alert",
		"category": "custom",
		"keywords": ["octagon", "alert"],
		"aliases": ["@tui.octagon-alert", "@tui.octagon-alert-filled"],
		"filled": true,
		"filledName": "octagon-alert-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "octagon-minus",
		"tuiName": "@tui.octagon-minus",
		"category": "custom",
		"keywords": ["octagon", "minus"],
		"aliases": ["@tui.octagon-minus", "@tui.octagon-minus-filled"],
		"filled": true,
		"filledName": "octagon-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "octagon-pause",
		"tuiName": "@tui.octagon-pause",
		"category": "custom",
		"keywords": ["octagon", "pause"],
		"aliases": ["@tui.octagon-pause", "@tui.octagon-pause-filled"],
		"filled": true,
		"filledName": "octagon-pause-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "octagon-x",
		"tuiName": "@tui.octagon-x",
		"category": "custom",
		"keywords": ["octagon", "x"],
		"aliases": ["@tui.octagon-x", "@tui.octagon-x-filled"],
		"filled": true,
		"filledName": "octagon-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "omega",
		"tuiName": "@tui.omega",
		"category": "custom",
		"keywords": ["omega"],
		"aliases": ["@tui.omega", "@tui.omega-filled"],
		"filled": true,
		"filledName": "omega-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "option",
		"tuiName": "@tui.option",
		"category": "custom",
		"keywords": ["option"],
		"aliases": ["@tui.option", "@tui.option-filled"],
		"filled": true,
		"filledName": "option-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "orbit",
		"tuiName": "@tui.orbit",
		"category": "custom",
		"keywords": ["orbit"],
		"aliases": ["@tui.orbit", "@tui.orbit-filled"],
		"filled": true,
		"filledName": "orbit-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "origami",
		"tuiName": "@tui.origami",
		"category": "custom",
		"keywords": ["origami"],
		"aliases": ["@tui.origami", "@tui.origami-filled"],
		"filled": true,
		"filledName": "origami-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "outdent",
		"tuiName": "@tui.outdent",
		"category": "editing",
		"keywords": ["outdent"],
		"aliases": ["@tui.outdent", "@tui.outdent-filled"],
		"filled": true,
		"filledName": "outdent-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "package",
		"tuiName": "@tui.package",
		"category": "commerce",
		"keywords": ["package"],
		"aliases": ["@tui.package", "@tui.package-filled"],
		"filled": true,
		"filledName": "package-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "package-2",
		"tuiName": "@tui.package-2",
		"category": "commerce",
		"keywords": ["package", "2"],
		"aliases": ["@tui.package-2", "@tui.package-2-filled"],
		"filled": true,
		"filledName": "package-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "package-check",
		"tuiName": "@tui.package-check",
		"category": "commerce",
		"keywords": ["package", "check"],
		"aliases": ["@tui.package-check", "@tui.package-check-filled"],
		"filled": true,
		"filledName": "package-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "package-minus",
		"tuiName": "@tui.package-minus",
		"category": "commerce",
		"keywords": ["package", "minus"],
		"aliases": ["@tui.package-minus", "@tui.package-minus-filled"],
		"filled": true,
		"filledName": "package-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "package-open",
		"tuiName": "@tui.package-open",
		"category": "commerce",
		"keywords": ["package", "open"],
		"aliases": ["@tui.package-open", "@tui.package-open-filled"],
		"filled": true,
		"filledName": "package-open-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "package-plus",
		"tuiName": "@tui.package-plus",
		"category": "commerce",
		"keywords": ["package", "plus"],
		"aliases": ["@tui.package-plus", "@tui.package-plus-filled"],
		"filled": true,
		"filledName": "package-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "package-search",
		"tuiName": "@tui.package-search",
		"category": "commerce",
		"keywords": ["package", "search"],
		"aliases": ["@tui.package-search", "@tui.package-search-filled"],
		"filled": true,
		"filledName": "package-search-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "package-x",
		"tuiName": "@tui.package-x",
		"category": "commerce",
		"keywords": ["package", "x"],
		"aliases": ["@tui.package-x", "@tui.package-x-filled"],
		"filled": true,
		"filledName": "package-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "paint-bucket",
		"tuiName": "@tui.paint-bucket",
		"category": "editing",
		"keywords": ["paint", "bucket"],
		"aliases": ["@tui.paint-bucket", "@tui.paint-bucket-filled"],
		"filled": true,
		"filledName": "paint-bucket-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "paint-roller",
		"tuiName": "@tui.paint-roller",
		"category": "editing",
		"keywords": ["paint", "roller"],
		"aliases": ["@tui.paint-roller", "@tui.paint-roller-filled"],
		"filled": true,
		"filledName": "paint-roller-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "paintbrush",
		"tuiName": "@tui.paintbrush",
		"category": "editing",
		"keywords": ["paintbrush"],
		"aliases": ["@tui.paintbrush", "@tui.paintbrush-filled"],
		"filled": true,
		"filledName": "paintbrush-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "paintbrush-2",
		"tuiName": "@tui.paintbrush-2",
		"category": "editing",
		"keywords": ["paintbrush", "2"],
		"aliases": ["@tui.paintbrush-2", "@tui.paintbrush-2-filled"],
		"filled": true,
		"filledName": "paintbrush-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "paintbrush-vertical",
		"tuiName": "@tui.paintbrush-vertical",
		"category": "editing",
		"keywords": ["paintbrush", "vertical"],
		"aliases": ["@tui.paintbrush-vertical", "@tui.paintbrush-vertical-filled"],
		"filled": true,
		"filledName": "paintbrush-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "palette",
		"tuiName": "@tui.palette",
		"category": "custom",
		"keywords": ["palette"],
		"aliases": ["@tui.palette", "@tui.palette-filled"],
		"filled": true,
		"filledName": "palette-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "palmtree",
		"tuiName": "@tui.palmtree",
		"category": "custom",
		"keywords": ["palmtree"],
		"aliases": ["@tui.palmtree", "@tui.palmtree-filled"],
		"filled": true,
		"filledName": "palmtree-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "panda",
		"tuiName": "@tui.panda",
		"category": "custom",
		"keywords": ["panda"],
		"aliases": ["@tui.panda", "@tui.panda-filled"],
		"filled": true,
		"filledName": "panda-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "panel-bottom",
		"tuiName": "@tui.panel-bottom",
		"category": "navigation",
		"keywords": ["panel", "bottom"],
		"aliases": ["@tui.panel-bottom", "@tui.panel-bottom-filled"],
		"filled": true,
		"filledName": "panel-bottom-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "panel-bottom-close",
		"tuiName": "@tui.panel-bottom-close",
		"category": "navigation",
		"keywords": [
			"panel",
			"bottom",
			"close"
		],
		"aliases": ["@tui.panel-bottom-close", "@tui.panel-bottom-close-filled"],
		"filled": true,
		"filledName": "panel-bottom-close-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "panel-bottom-dashed",
		"tuiName": "@tui.panel-bottom-dashed",
		"category": "navigation",
		"keywords": [
			"panel",
			"bottom",
			"dashed"
		],
		"aliases": ["@tui.panel-bottom-dashed", "@tui.panel-bottom-dashed-filled"],
		"filled": true,
		"filledName": "panel-bottom-dashed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "panel-bottom-inactive",
		"tuiName": "@tui.panel-bottom-inactive",
		"category": "navigation",
		"keywords": [
			"panel",
			"bottom",
			"inactive"
		],
		"aliases": ["@tui.panel-bottom-inactive", "@tui.panel-bottom-inactive-filled"],
		"filled": true,
		"filledName": "panel-bottom-inactive-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "panel-bottom-open",
		"tuiName": "@tui.panel-bottom-open",
		"category": "navigation",
		"keywords": [
			"panel",
			"bottom",
			"open"
		],
		"aliases": ["@tui.panel-bottom-open", "@tui.panel-bottom-open-filled"],
		"filled": true,
		"filledName": "panel-bottom-open-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "panel-left",
		"tuiName": "@tui.panel-left",
		"category": "navigation",
		"keywords": ["panel", "left"],
		"aliases": ["@tui.panel-left", "@tui.panel-left-filled"],
		"filled": true,
		"filledName": "panel-left-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "panel-left-close",
		"tuiName": "@tui.panel-left-close",
		"category": "navigation",
		"keywords": [
			"panel",
			"left",
			"close"
		],
		"aliases": ["@tui.panel-left-close", "@tui.panel-left-close-filled"],
		"filled": true,
		"filledName": "panel-left-close-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "panel-left-dashed",
		"tuiName": "@tui.panel-left-dashed",
		"category": "navigation",
		"keywords": [
			"panel",
			"left",
			"dashed"
		],
		"aliases": ["@tui.panel-left-dashed", "@tui.panel-left-dashed-filled"],
		"filled": true,
		"filledName": "panel-left-dashed-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "panel-left-inactive",
		"tuiName": "@tui.panel-left-inactive",
		"category": "navigation",
		"keywords": [
			"panel",
			"left",
			"inactive"
		],
		"aliases": ["@tui.panel-left-inactive", "@tui.panel-left-inactive-filled"],
		"filled": true,
		"filledName": "panel-left-inactive-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "panel-left-open",
		"tuiName": "@tui.panel-left-open",
		"category": "navigation",
		"keywords": [
			"panel",
			"left",
			"open"
		],
		"aliases": ["@tui.panel-left-open", "@tui.panel-left-open-filled"],
		"filled": true,
		"filledName": "panel-left-open-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "panel-left-right-dashed",
		"tuiName": "@tui.panel-left-right-dashed",
		"category": "navigation",
		"keywords": [
			"panel",
			"left",
			"right",
			"dashed"
		],
		"aliases": ["@tui.panel-left-right-dashed", "@tui.panel-left-right-dashed-filled"],
		"filled": true,
		"filledName": "panel-left-right-dashed-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "panel-right",
		"tuiName": "@tui.panel-right",
		"category": "navigation",
		"keywords": ["panel", "right"],
		"aliases": ["@tui.panel-right", "@tui.panel-right-filled"],
		"filled": true,
		"filledName": "panel-right-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "panel-right-close",
		"tuiName": "@tui.panel-right-close",
		"category": "navigation",
		"keywords": [
			"panel",
			"right",
			"close"
		],
		"aliases": ["@tui.panel-right-close", "@tui.panel-right-close-filled"],
		"filled": true,
		"filledName": "panel-right-close-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "panel-right-dashed",
		"tuiName": "@tui.panel-right-dashed",
		"category": "navigation",
		"keywords": [
			"panel",
			"right",
			"dashed"
		],
		"aliases": ["@tui.panel-right-dashed", "@tui.panel-right-dashed-filled"],
		"filled": true,
		"filledName": "panel-right-dashed-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "panel-right-inactive",
		"tuiName": "@tui.panel-right-inactive",
		"category": "navigation",
		"keywords": [
			"panel",
			"right",
			"inactive"
		],
		"aliases": ["@tui.panel-right-inactive", "@tui.panel-right-inactive-filled"],
		"filled": true,
		"filledName": "panel-right-inactive-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "panel-right-open",
		"tuiName": "@tui.panel-right-open",
		"category": "navigation",
		"keywords": [
			"panel",
			"right",
			"open"
		],
		"aliases": ["@tui.panel-right-open", "@tui.panel-right-open-filled"],
		"filled": true,
		"filledName": "panel-right-open-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "panel-top",
		"tuiName": "@tui.panel-top",
		"category": "navigation",
		"keywords": ["panel", "top"],
		"aliases": ["@tui.panel-top", "@tui.panel-top-filled"],
		"filled": true,
		"filledName": "panel-top-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "panel-top-bottom-dashed",
		"tuiName": "@tui.panel-top-bottom-dashed",
		"category": "navigation",
		"keywords": [
			"panel",
			"top",
			"bottom",
			"dashed"
		],
		"aliases": ["@tui.panel-top-bottom-dashed", "@tui.panel-top-bottom-dashed-filled"],
		"filled": true,
		"filledName": "panel-top-bottom-dashed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "panel-top-close",
		"tuiName": "@tui.panel-top-close",
		"category": "navigation",
		"keywords": [
			"panel",
			"top",
			"close"
		],
		"aliases": ["@tui.panel-top-close", "@tui.panel-top-close-filled"],
		"filled": true,
		"filledName": "panel-top-close-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "panel-top-dashed",
		"tuiName": "@tui.panel-top-dashed",
		"category": "navigation",
		"keywords": [
			"panel",
			"top",
			"dashed"
		],
		"aliases": ["@tui.panel-top-dashed", "@tui.panel-top-dashed-filled"],
		"filled": true,
		"filledName": "panel-top-dashed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "panel-top-inactive",
		"tuiName": "@tui.panel-top-inactive",
		"category": "navigation",
		"keywords": [
			"panel",
			"top",
			"inactive"
		],
		"aliases": ["@tui.panel-top-inactive", "@tui.panel-top-inactive-filled"],
		"filled": true,
		"filledName": "panel-top-inactive-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "panel-top-open",
		"tuiName": "@tui.panel-top-open",
		"category": "navigation",
		"keywords": [
			"panel",
			"top",
			"open"
		],
		"aliases": ["@tui.panel-top-open", "@tui.panel-top-open-filled"],
		"filled": true,
		"filledName": "panel-top-open-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "panels-left-bottom",
		"tuiName": "@tui.panels-left-bottom",
		"category": "navigation",
		"keywords": [
			"panels",
			"left",
			"bottom"
		],
		"aliases": ["@tui.panels-left-bottom", "@tui.panels-left-bottom-filled"],
		"filled": true,
		"filledName": "panels-left-bottom-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "panels-left-right",
		"tuiName": "@tui.panels-left-right",
		"category": "navigation",
		"keywords": [
			"panels",
			"left",
			"right"
		],
		"aliases": ["@tui.panels-left-right", "@tui.panels-left-right-filled"],
		"filled": true,
		"filledName": "panels-left-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "panels-right-bottom",
		"tuiName": "@tui.panels-right-bottom",
		"category": "navigation",
		"keywords": [
			"panels",
			"right",
			"bottom"
		],
		"aliases": ["@tui.panels-right-bottom", "@tui.panels-right-bottom-filled"],
		"filled": true,
		"filledName": "panels-right-bottom-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "panels-top-bottom",
		"tuiName": "@tui.panels-top-bottom",
		"category": "navigation",
		"keywords": [
			"panels",
			"top",
			"bottom"
		],
		"aliases": ["@tui.panels-top-bottom", "@tui.panels-top-bottom-filled"],
		"filled": true,
		"filledName": "panels-top-bottom-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "panels-top-left",
		"tuiName": "@tui.panels-top-left",
		"category": "navigation",
		"keywords": [
			"panels",
			"top",
			"left"
		],
		"aliases": ["@tui.panels-top-left", "@tui.panels-top-left-filled"],
		"filled": true,
		"filledName": "panels-top-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "paper-bag",
		"tuiName": "@tui.paper-bag",
		"category": "custom",
		"keywords": ["paper", "bag"],
		"aliases": ["@tui.paper-bag", "@tui.paper-bag-filled"],
		"filled": true,
		"filledName": "paper-bag-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "paperclip",
		"tuiName": "@tui.paperclip",
		"category": "files",
		"keywords": ["paperclip"],
		"aliases": ["@tui.paperclip", "@tui.paperclip-filled"],
		"filled": true,
		"filledName": "paperclip-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "parasol",
		"tuiName": "@tui.parasol",
		"category": "custom",
		"keywords": ["parasol"],
		"aliases": ["@tui.parasol", "@tui.parasol-filled"],
		"filled": true,
		"filledName": "parasol-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "parentheses",
		"tuiName": "@tui.parentheses",
		"category": "custom",
		"keywords": ["parentheses"],
		"aliases": ["@tui.parentheses", "@tui.parentheses-filled"],
		"filled": true,
		"filledName": "parentheses-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "park",
		"tuiName": "@tui.park",
		"category": "custom",
		"keywords": ["park"],
		"aliases": ["@tui.park", "@tui.park-filled"],
		"filled": true,
		"filledName": "park-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "parking-circle",
		"tuiName": "@tui.parking-circle",
		"category": "maps-location",
		"keywords": ["parking", "circle"],
		"aliases": ["@tui.parking-circle", "@tui.parking-circle-filled"],
		"filled": true,
		"filledName": "parking-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "parking-circle-off",
		"tuiName": "@tui.parking-circle-off",
		"category": "maps-location",
		"keywords": [
			"parking",
			"circle",
			"off"
		],
		"aliases": ["@tui.parking-circle-off", "@tui.parking-circle-off-filled"],
		"filled": true,
		"filledName": "parking-circle-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "parking-meter",
		"tuiName": "@tui.parking-meter",
		"category": "maps-location",
		"keywords": ["parking", "meter"],
		"aliases": ["@tui.parking-meter", "@tui.parking-meter-filled"],
		"filled": true,
		"filledName": "parking-meter-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "parking-square",
		"tuiName": "@tui.parking-square",
		"category": "maps-location",
		"keywords": ["parking", "square"],
		"aliases": ["@tui.parking-square", "@tui.parking-square-filled"],
		"filled": true,
		"filledName": "parking-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "parking-square-off",
		"tuiName": "@tui.parking-square-off",
		"category": "maps-location",
		"keywords": [
			"parking",
			"square",
			"off"
		],
		"aliases": ["@tui.parking-square-off", "@tui.parking-square-off-filled"],
		"filled": true,
		"filledName": "parking-square-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "party-popper",
		"tuiName": "@tui.party-popper",
		"category": "custom",
		"keywords": ["party", "popper"],
		"aliases": ["@tui.party-popper", "@tui.party-popper-filled"],
		"filled": true,
		"filledName": "party-popper-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pause",
		"tuiName": "@tui.pause",
		"category": "media",
		"keywords": ["pause"],
		"aliases": ["@tui.pause", "@tui.pause-filled"],
		"filled": true,
		"filledName": "pause-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pause-circle",
		"tuiName": "@tui.pause-circle",
		"category": "media",
		"keywords": ["pause", "circle"],
		"aliases": ["@tui.pause-circle", "@tui.pause-circle-filled"],
		"filled": true,
		"filledName": "pause-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pause-octagon",
		"tuiName": "@tui.pause-octagon",
		"category": "media",
		"keywords": ["pause", "octagon"],
		"aliases": ["@tui.pause-octagon", "@tui.pause-octagon-filled"],
		"filled": true,
		"filledName": "pause-octagon-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "paw-print",
		"tuiName": "@tui.paw-print",
		"category": "custom",
		"keywords": ["paw", "print"],
		"aliases": ["@tui.paw-print", "@tui.paw-print-filled"],
		"filled": true,
		"filledName": "paw-print-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pay-pal",
		"tuiName": "@tui.pay-pal",
		"category": "custom",
		"keywords": ["pay", "pal"],
		"aliases": ["@tui.pay-pal"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pc-case",
		"tuiName": "@tui.pc-case",
		"category": "custom",
		"keywords": ["pc", "case"],
		"aliases": ["@tui.pc-case", "@tui.pc-case-filled"],
		"filled": true,
		"filledName": "pc-case-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pen",
		"tuiName": "@tui.pen",
		"category": "editing",
		"keywords": ["pen"],
		"aliases": ["@tui.pen", "@tui.pen-filled"],
		"filled": true,
		"filledName": "pen-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pen-box",
		"tuiName": "@tui.pen-box",
		"category": "editing",
		"keywords": ["pen", "box"],
		"aliases": ["@tui.pen-box", "@tui.pen-box-filled"],
		"filled": true,
		"filledName": "pen-box-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pen-line",
		"tuiName": "@tui.pen-line",
		"category": "editing",
		"keywords": ["pen", "line"],
		"aliases": ["@tui.pen-line", "@tui.pen-line-filled"],
		"filled": true,
		"filledName": "pen-line-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pen-off",
		"tuiName": "@tui.pen-off",
		"category": "editing",
		"keywords": ["pen", "off"],
		"aliases": ["@tui.pen-off", "@tui.pen-off-filled"],
		"filled": true,
		"filledName": "pen-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pen-square",
		"tuiName": "@tui.pen-square",
		"category": "editing",
		"keywords": ["pen", "square"],
		"aliases": ["@tui.pen-square", "@tui.pen-square-filled"],
		"filled": true,
		"filledName": "pen-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pen-tool",
		"tuiName": "@tui.pen-tool",
		"category": "editing",
		"keywords": ["pen", "tool"],
		"aliases": ["@tui.pen-tool", "@tui.pen-tool-filled"],
		"filled": true,
		"filledName": "pen-tool-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pencil",
		"tuiName": "@tui.pencil",
		"category": "editing",
		"keywords": ["pencil"],
		"aliases": ["@tui.pencil", "@tui.pencil-filled"],
		"filled": true,
		"filledName": "pencil-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pencil-line",
		"tuiName": "@tui.pencil-line",
		"category": "editing",
		"keywords": ["pencil", "line"],
		"aliases": ["@tui.pencil-line", "@tui.pencil-line-filled"],
		"filled": true,
		"filledName": "pencil-line-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pencil-off",
		"tuiName": "@tui.pencil-off",
		"category": "editing",
		"keywords": ["pencil", "off"],
		"aliases": ["@tui.pencil-off", "@tui.pencil-off-filled"],
		"filled": true,
		"filledName": "pencil-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pencil-ruler",
		"tuiName": "@tui.pencil-ruler",
		"category": "editing",
		"keywords": ["pencil", "ruler"],
		"aliases": ["@tui.pencil-ruler", "@tui.pencil-ruler-filled"],
		"filled": true,
		"filledName": "pencil-ruler-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pencil-sparkles",
		"tuiName": "@tui.pencil-sparkles",
		"category": "editing",
		"keywords": ["pencil", "sparkles"],
		"aliases": ["@tui.pencil-sparkles", "@tui.pencil-sparkles-filled"],
		"filled": true,
		"filledName": "pencil-sparkles-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pentagon",
		"tuiName": "@tui.pentagon",
		"category": "editing",
		"keywords": ["pentagon"],
		"aliases": ["@tui.pentagon", "@tui.pentagon-filled"],
		"filled": true,
		"filledName": "pentagon-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "percent",
		"tuiName": "@tui.percent",
		"category": "custom",
		"keywords": ["percent"],
		"aliases": ["@tui.percent", "@tui.percent-filled"],
		"filled": true,
		"filledName": "percent-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "percent-circle",
		"tuiName": "@tui.percent-circle",
		"category": "custom",
		"keywords": ["percent", "circle"],
		"aliases": ["@tui.percent-circle", "@tui.percent-circle-filled"],
		"filled": true,
		"filledName": "percent-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "percent-diamond",
		"tuiName": "@tui.percent-diamond",
		"category": "custom",
		"keywords": ["percent", "diamond"],
		"aliases": ["@tui.percent-diamond", "@tui.percent-diamond-filled"],
		"filled": true,
		"filledName": "percent-diamond-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "percent-square",
		"tuiName": "@tui.percent-square",
		"category": "custom",
		"keywords": ["percent", "square"],
		"aliases": ["@tui.percent-square", "@tui.percent-square-filled"],
		"filled": true,
		"filledName": "percent-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "perfume-bottle",
		"tuiName": "@tui.perfume-bottle",
		"category": "custom",
		"keywords": ["perfume", "bottle"],
		"aliases": ["@tui.perfume-bottle", "@tui.perfume-bottle-filled"],
		"filled": true,
		"filledName": "perfume-bottle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "person-standing",
		"tuiName": "@tui.person-standing",
		"category": "accessibility",
		"keywords": ["person", "standing"],
		"aliases": ["@tui.person-standing", "@tui.person-standing-filled"],
		"filled": true,
		"filledName": "person-standing-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "phi",
		"tuiName": "@tui.phi",
		"category": "custom",
		"keywords": ["phi"],
		"aliases": ["@tui.phi", "@tui.phi-filled"],
		"filled": true,
		"filledName": "phi-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "philippine-peso",
		"tuiName": "@tui.philippine-peso",
		"category": "custom",
		"keywords": ["philippine", "peso"],
		"aliases": ["@tui.philippine-peso", "@tui.philippine-peso-filled"],
		"filled": true,
		"filledName": "philippine-peso-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "phone",
		"tuiName": "@tui.phone",
		"category": "communication",
		"keywords": ["phone"],
		"aliases": ["@tui.phone", "@tui.phone-filled"],
		"filled": true,
		"filledName": "phone-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "phone-call",
		"tuiName": "@tui.phone-call",
		"category": "communication",
		"keywords": ["phone", "call"],
		"aliases": ["@tui.phone-call", "@tui.phone-call-filled"],
		"filled": true,
		"filledName": "phone-call-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "phone-forwarded",
		"tuiName": "@tui.phone-forwarded",
		"category": "communication",
		"keywords": ["phone", "forwarded"],
		"aliases": ["@tui.phone-forwarded", "@tui.phone-forwarded-filled"],
		"filled": true,
		"filledName": "phone-forwarded-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "phone-incoming",
		"tuiName": "@tui.phone-incoming",
		"category": "communication",
		"keywords": ["phone", "incoming"],
		"aliases": ["@tui.phone-incoming", "@tui.phone-incoming-filled"],
		"filled": true,
		"filledName": "phone-incoming-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "phone-log",
		"tuiName": "@tui.phone-log",
		"category": "communication",
		"keywords": ["phone", "log"],
		"aliases": ["@tui.phone-log", "@tui.phone-log-filled"],
		"filled": true,
		"filledName": "phone-log-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "phone-missed",
		"tuiName": "@tui.phone-missed",
		"category": "communication",
		"keywords": ["phone", "missed"],
		"aliases": ["@tui.phone-missed", "@tui.phone-missed-filled"],
		"filled": true,
		"filledName": "phone-missed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "phone-off",
		"tuiName": "@tui.phone-off",
		"category": "communication",
		"keywords": ["phone", "off"],
		"aliases": ["@tui.phone-off", "@tui.phone-off-filled"],
		"filled": true,
		"filledName": "phone-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "phone-outgoing",
		"tuiName": "@tui.phone-outgoing",
		"category": "communication",
		"keywords": ["phone", "outgoing"],
		"aliases": ["@tui.phone-outgoing", "@tui.phone-outgoing-filled"],
		"filled": true,
		"filledName": "phone-outgoing-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pi",
		"tuiName": "@tui.pi",
		"category": "custom",
		"keywords": ["pi"],
		"aliases": ["@tui.pi", "@tui.pi-filled"],
		"filled": true,
		"filledName": "pi-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pi-square",
		"tuiName": "@tui.pi-square",
		"category": "custom",
		"keywords": ["pi", "square"],
		"aliases": ["@tui.pi-square", "@tui.pi-square-filled"],
		"filled": true,
		"filledName": "pi-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "piano",
		"tuiName": "@tui.piano",
		"category": "custom",
		"keywords": ["piano"],
		"aliases": ["@tui.piano", "@tui.piano-filled"],
		"filled": true,
		"filledName": "piano-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pickaxe",
		"tuiName": "@tui.pickaxe",
		"category": "custom",
		"keywords": ["pickaxe"],
		"aliases": ["@tui.pickaxe", "@tui.pickaxe-filled"],
		"filled": true,
		"filledName": "pickaxe-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "picture-in-picture",
		"tuiName": "@tui.picture-in-picture",
		"category": "media",
		"keywords": [
			"picture",
			"in",
			"picture"
		],
		"aliases": ["@tui.picture-in-picture", "@tui.picture-in-picture-filled"],
		"filled": true,
		"filledName": "picture-in-picture-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "picture-in-picture-2",
		"tuiName": "@tui.picture-in-picture-2",
		"category": "media",
		"keywords": [
			"picture",
			"in",
			"picture",
			"2"
		],
		"aliases": ["@tui.picture-in-picture-2", "@tui.picture-in-picture-2-filled"],
		"filled": true,
		"filledName": "picture-in-picture-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pie-chart",
		"tuiName": "@tui.pie-chart",
		"category": "custom",
		"keywords": ["pie", "chart"],
		"aliases": ["@tui.pie-chart", "@tui.pie-chart-filled"],
		"filled": true,
		"filledName": "pie-chart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "piggy-bank",
		"tuiName": "@tui.piggy-bank",
		"category": "finance",
		"keywords": ["piggy", "bank"],
		"aliases": ["@tui.piggy-bank", "@tui.piggy-bank-filled"],
		"filled": true,
		"filledName": "piggy-bank-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pilcrow",
		"tuiName": "@tui.pilcrow",
		"category": "custom",
		"keywords": ["pilcrow"],
		"aliases": ["@tui.pilcrow", "@tui.pilcrow-filled"],
		"filled": true,
		"filledName": "pilcrow-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pilcrow-left",
		"tuiName": "@tui.pilcrow-left",
		"category": "custom",
		"keywords": ["pilcrow", "left"],
		"aliases": ["@tui.pilcrow-left", "@tui.pilcrow-left-filled"],
		"filled": true,
		"filledName": "pilcrow-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pilcrow-right",
		"tuiName": "@tui.pilcrow-right",
		"category": "custom",
		"keywords": ["pilcrow", "right"],
		"aliases": ["@tui.pilcrow-right", "@tui.pilcrow-right-filled"],
		"filled": true,
		"filledName": "pilcrow-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pilcrow-square",
		"tuiName": "@tui.pilcrow-square",
		"category": "custom",
		"keywords": ["pilcrow", "square"],
		"aliases": ["@tui.pilcrow-square", "@tui.pilcrow-square-filled"],
		"filled": true,
		"filledName": "pilcrow-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pill",
		"tuiName": "@tui.pill",
		"category": "custom",
		"keywords": ["pill"],
		"aliases": ["@tui.pill", "@tui.pill-filled"],
		"filled": true,
		"filledName": "pill-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pill-bottle",
		"tuiName": "@tui.pill-bottle",
		"category": "custom",
		"keywords": ["pill", "bottle"],
		"aliases": ["@tui.pill-bottle", "@tui.pill-bottle-filled"],
		"filled": true,
		"filledName": "pill-bottle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pin",
		"tuiName": "@tui.pin",
		"category": "maps-location",
		"keywords": ["pin"],
		"aliases": ["@tui.pin", "@tui.pin-filled"],
		"filled": true,
		"filledName": "pin-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pin-off",
		"tuiName": "@tui.pin-off",
		"category": "maps-location",
		"keywords": ["pin", "off"],
		"aliases": ["@tui.pin-off", "@tui.pin-off-filled"],
		"filled": true,
		"filledName": "pin-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pipette",
		"tuiName": "@tui.pipette",
		"category": "custom",
		"keywords": ["pipette"],
		"aliases": ["@tui.pipette", "@tui.pipette-filled"],
		"filled": true,
		"filledName": "pipette-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pizza",
		"tuiName": "@tui.pizza",
		"category": "custom",
		"keywords": ["pizza"],
		"aliases": ["@tui.pizza", "@tui.pizza-filled"],
		"filled": true,
		"filledName": "pizza-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "plane",
		"tuiName": "@tui.plane",
		"category": "maps-location",
		"keywords": ["plane"],
		"aliases": ["@tui.plane", "@tui.plane-filled"],
		"filled": true,
		"filledName": "plane-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "plane-landing",
		"tuiName": "@tui.plane-landing",
		"category": "maps-location",
		"keywords": ["plane", "landing"],
		"aliases": ["@tui.plane-landing", "@tui.plane-landing-filled"],
		"filled": true,
		"filledName": "plane-landing-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "plane-takeoff",
		"tuiName": "@tui.plane-takeoff",
		"category": "maps-location",
		"keywords": ["plane", "takeoff"],
		"aliases": ["@tui.plane-takeoff", "@tui.plane-takeoff-filled"],
		"filled": true,
		"filledName": "plane-takeoff-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "plant-pot",
		"tuiName": "@tui.plant-pot",
		"category": "custom",
		"keywords": ["plant", "pot"],
		"aliases": ["@tui.plant-pot", "@tui.plant-pot-filled"],
		"filled": true,
		"filledName": "plant-pot-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "play",
		"tuiName": "@tui.play",
		"category": "media",
		"keywords": ["play"],
		"aliases": ["@tui.play", "@tui.play-filled"],
		"filled": true,
		"filledName": "play-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "play-circle",
		"tuiName": "@tui.play-circle",
		"category": "media",
		"keywords": ["play", "circle"],
		"aliases": ["@tui.play-circle", "@tui.play-circle-filled"],
		"filled": true,
		"filledName": "play-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "play-off",
		"tuiName": "@tui.play-off",
		"category": "media",
		"keywords": ["play", "off"],
		"aliases": ["@tui.play-off", "@tui.play-off-filled"],
		"filled": true,
		"filledName": "play-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "play-square",
		"tuiName": "@tui.play-square",
		"category": "media",
		"keywords": ["play", "square"],
		"aliases": ["@tui.play-square", "@tui.play-square-filled"],
		"filled": true,
		"filledName": "play-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "playing-card",
		"tuiName": "@tui.playing-card",
		"category": "media",
		"keywords": ["playing", "card"],
		"aliases": ["@tui.playing-card", "@tui.playing-card-filled"],
		"filled": true,
		"filledName": "playing-card-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "playing-cards",
		"tuiName": "@tui.playing-cards",
		"category": "media",
		"keywords": ["playing", "cards"],
		"aliases": ["@tui.playing-cards", "@tui.playing-cards-filled"],
		"filled": true,
		"filledName": "playing-cards-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "playing-cards-fan",
		"tuiName": "@tui.playing-cards-fan",
		"category": "media",
		"keywords": [
			"playing",
			"cards",
			"fan"
		],
		"aliases": ["@tui.playing-cards-fan", "@tui.playing-cards-fan-filled"],
		"filled": true,
		"filledName": "playing-cards-fan-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "plug",
		"tuiName": "@tui.plug",
		"category": "devices",
		"keywords": ["plug"],
		"aliases": ["@tui.plug", "@tui.plug-filled"],
		"filled": true,
		"filledName": "plug-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "plug-2",
		"tuiName": "@tui.plug-2",
		"category": "devices",
		"keywords": ["plug", "2"],
		"aliases": ["@tui.plug-2", "@tui.plug-2-filled"],
		"filled": true,
		"filledName": "plug-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "plug-zap",
		"tuiName": "@tui.plug-zap",
		"category": "devices",
		"keywords": ["plug", "zap"],
		"aliases": ["@tui.plug-zap", "@tui.plug-zap-filled"],
		"filled": true,
		"filledName": "plug-zap-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "plug-zap-2",
		"tuiName": "@tui.plug-zap-2",
		"category": "devices",
		"keywords": [
			"plug",
			"zap",
			"2"
		],
		"aliases": ["@tui.plug-zap-2", "@tui.plug-zap-2-filled"],
		"filled": true,
		"filledName": "plug-zap-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "plus",
		"tuiName": "@tui.plus",
		"category": "actions",
		"keywords": ["plus"],
		"aliases": ["@tui.plus", "@tui.plus-filled"],
		"filled": true,
		"filledName": "plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "plus-circle",
		"tuiName": "@tui.plus-circle",
		"category": "actions",
		"keywords": ["plus", "circle"],
		"aliases": ["@tui.plus-circle", "@tui.plus-circle-filled"],
		"filled": true,
		"filledName": "plus-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "plus-square",
		"tuiName": "@tui.plus-square",
		"category": "actions",
		"keywords": ["plus", "square"],
		"aliases": ["@tui.plus-square", "@tui.plus-square-filled"],
		"filled": true,
		"filledName": "plus-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pocket-knife",
		"tuiName": "@tui.pocket-knife",
		"category": "custom",
		"keywords": ["pocket", "knife"],
		"aliases": ["@tui.pocket-knife", "@tui.pocket-knife-filled"],
		"filled": true,
		"filledName": "pocket-knife-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "podcast",
		"tuiName": "@tui.podcast",
		"category": "communication",
		"keywords": ["podcast"],
		"aliases": ["@tui.podcast", "@tui.podcast-filled"],
		"filled": true,
		"filledName": "podcast-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "podium",
		"tuiName": "@tui.podium",
		"category": "custom",
		"keywords": ["podium"],
		"aliases": ["@tui.podium", "@tui.podium-filled"],
		"filled": true,
		"filledName": "podium-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pointer",
		"tuiName": "@tui.pointer",
		"category": "custom",
		"keywords": ["pointer"],
		"aliases": ["@tui.pointer", "@tui.pointer-filled"],
		"filled": true,
		"filledName": "pointer-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pointer-off",
		"tuiName": "@tui.pointer-off",
		"category": "custom",
		"keywords": ["pointer", "off"],
		"aliases": ["@tui.pointer-off", "@tui.pointer-off-filled"],
		"filled": true,
		"filledName": "pointer-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "popcorn",
		"tuiName": "@tui.popcorn",
		"category": "custom",
		"keywords": ["popcorn"],
		"aliases": ["@tui.popcorn", "@tui.popcorn-filled"],
		"filled": true,
		"filledName": "popcorn-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "popsicle",
		"tuiName": "@tui.popsicle",
		"category": "custom",
		"keywords": ["popsicle"],
		"aliases": ["@tui.popsicle", "@tui.popsicle-filled"],
		"filled": true,
		"filledName": "popsicle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pound-sterling",
		"tuiName": "@tui.pound-sterling",
		"category": "custom",
		"keywords": ["pound", "sterling"],
		"aliases": ["@tui.pound-sterling", "@tui.pound-sterling-filled"],
		"filled": true,
		"filledName": "pound-sterling-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "power",
		"tuiName": "@tui.power",
		"category": "devices",
		"keywords": ["power"],
		"aliases": ["@tui.power", "@tui.power-filled"],
		"filled": true,
		"filledName": "power-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "power-circle",
		"tuiName": "@tui.power-circle",
		"category": "devices",
		"keywords": ["power", "circle"],
		"aliases": ["@tui.power-circle", "@tui.power-circle-filled"],
		"filled": true,
		"filledName": "power-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "power-off",
		"tuiName": "@tui.power-off",
		"category": "devices",
		"keywords": ["power", "off"],
		"aliases": ["@tui.power-off", "@tui.power-off-filled"],
		"filled": true,
		"filledName": "power-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "power-square",
		"tuiName": "@tui.power-square",
		"category": "devices",
		"keywords": ["power", "square"],
		"aliases": ["@tui.power-square", "@tui.power-square-filled"],
		"filled": true,
		"filledName": "power-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "presentation",
		"tuiName": "@tui.presentation",
		"category": "custom",
		"keywords": ["presentation"],
		"aliases": ["@tui.presentation", "@tui.presentation-filled"],
		"filled": true,
		"filledName": "presentation-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "printer",
		"tuiName": "@tui.printer",
		"category": "devices",
		"keywords": ["printer"],
		"aliases": ["@tui.printer", "@tui.printer-filled"],
		"filled": true,
		"filledName": "printer-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "printer-3d",
		"tuiName": "@tui.printer-3d",
		"category": "devices",
		"keywords": ["printer", "3d"],
		"aliases": ["@tui.printer-3d", "@tui.printer-3d-filled"],
		"filled": true,
		"filledName": "printer-3d-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "printer-check",
		"tuiName": "@tui.printer-check",
		"category": "devices",
		"keywords": ["printer", "check"],
		"aliases": ["@tui.printer-check", "@tui.printer-check-filled"],
		"filled": true,
		"filledName": "printer-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "printer-x",
		"tuiName": "@tui.printer-x",
		"category": "devices",
		"keywords": ["printer", "x"],
		"aliases": ["@tui.printer-x", "@tui.printer-x-filled"],
		"filled": true,
		"filledName": "printer-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "projector",
		"tuiName": "@tui.projector",
		"category": "custom",
		"keywords": ["projector"],
		"aliases": ["@tui.projector", "@tui.projector-filled"],
		"filled": true,
		"filledName": "projector-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "proportions",
		"tuiName": "@tui.proportions",
		"category": "custom",
		"keywords": ["proportions"],
		"aliases": ["@tui.proportions", "@tui.proportions-filled"],
		"filled": true,
		"filledName": "proportions-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "puzzle",
		"tuiName": "@tui.puzzle",
		"category": "custom",
		"keywords": ["puzzle"],
		"aliases": ["@tui.puzzle", "@tui.puzzle-filled"],
		"filled": true,
		"filledName": "puzzle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "pyramid",
		"tuiName": "@tui.pyramid",
		"category": "custom",
		"keywords": ["pyramid"],
		"aliases": ["@tui.pyramid", "@tui.pyramid-filled"],
		"filled": true,
		"filledName": "pyramid-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "qr-code",
		"tuiName": "@tui.qr-code",
		"category": "commerce",
		"keywords": ["qr", "code"],
		"aliases": ["@tui.qr-code", "@tui.qr-code-filled"],
		"filled": true,
		"filledName": "qr-code-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "quote",
		"tuiName": "@tui.quote",
		"category": "editing",
		"keywords": ["quote"],
		"aliases": ["@tui.quote", "@tui.quote-filled"],
		"filled": true,
		"filledName": "quote-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rabbit",
		"tuiName": "@tui.rabbit",
		"category": "custom",
		"keywords": ["rabbit"],
		"aliases": ["@tui.rabbit", "@tui.rabbit-filled"],
		"filled": true,
		"filledName": "rabbit-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "radar",
		"tuiName": "@tui.radar",
		"category": "custom",
		"keywords": ["radar"],
		"aliases": ["@tui.radar", "@tui.radar-filled"],
		"filled": true,
		"filledName": "radar-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "radiation",
		"tuiName": "@tui.radiation",
		"category": "custom",
		"keywords": ["radiation"],
		"aliases": ["@tui.radiation", "@tui.radiation-filled"],
		"filled": true,
		"filledName": "radiation-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "radical",
		"tuiName": "@tui.radical",
		"category": "custom",
		"keywords": ["radical"],
		"aliases": ["@tui.radical", "@tui.radical-filled"],
		"filled": true,
		"filledName": "radical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "radio",
		"tuiName": "@tui.radio",
		"category": "devices",
		"keywords": ["radio"],
		"aliases": ["@tui.radio", "@tui.radio-filled"],
		"filled": true,
		"filledName": "radio-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "radio-off",
		"tuiName": "@tui.radio-off",
		"category": "devices",
		"keywords": ["radio", "off"],
		"aliases": ["@tui.radio-off", "@tui.radio-off-filled"],
		"filled": true,
		"filledName": "radio-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "radio-receiver",
		"tuiName": "@tui.radio-receiver",
		"category": "devices",
		"keywords": ["radio", "receiver"],
		"aliases": ["@tui.radio-receiver", "@tui.radio-receiver-filled"],
		"filled": true,
		"filledName": "radio-receiver-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "radio-tower",
		"tuiName": "@tui.radio-tower",
		"category": "devices",
		"keywords": ["radio", "tower"],
		"aliases": ["@tui.radio-tower", "@tui.radio-tower-filled"],
		"filled": true,
		"filledName": "radio-tower-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "radius",
		"tuiName": "@tui.radius",
		"category": "custom",
		"keywords": ["radius"],
		"aliases": ["@tui.radius", "@tui.radius-filled"],
		"filled": true,
		"filledName": "radius-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rainbow",
		"tuiName": "@tui.rainbow",
		"category": "custom",
		"keywords": ["rainbow"],
		"aliases": ["@tui.rainbow", "@tui.rainbow-filled"],
		"filled": true,
		"filledName": "rainbow-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rat",
		"tuiName": "@tui.rat",
		"category": "custom",
		"keywords": ["rat"],
		"aliases": ["@tui.rat", "@tui.rat-filled"],
		"filled": true,
		"filledName": "rat-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ratio",
		"tuiName": "@tui.ratio",
		"category": "custom",
		"keywords": ["ratio"],
		"aliases": ["@tui.ratio", "@tui.ratio-filled"],
		"filled": true,
		"filledName": "ratio-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "receipt",
		"tuiName": "@tui.receipt",
		"category": "commerce",
		"keywords": ["receipt"],
		"aliases": ["@tui.receipt", "@tui.receipt-filled"],
		"filled": true,
		"filledName": "receipt-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "receipt-cent",
		"tuiName": "@tui.receipt-cent",
		"category": "commerce",
		"keywords": ["receipt", "cent"],
		"aliases": ["@tui.receipt-cent", "@tui.receipt-cent-filled"],
		"filled": true,
		"filledName": "receipt-cent-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "receipt-euro",
		"tuiName": "@tui.receipt-euro",
		"category": "commerce",
		"keywords": ["receipt", "euro"],
		"aliases": ["@tui.receipt-euro", "@tui.receipt-euro-filled"],
		"filled": true,
		"filledName": "receipt-euro-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "receipt-indian-rupee",
		"tuiName": "@tui.receipt-indian-rupee",
		"category": "commerce",
		"keywords": [
			"receipt",
			"indian",
			"rupee"
		],
		"aliases": ["@tui.receipt-indian-rupee", "@tui.receipt-indian-rupee-filled"],
		"filled": true,
		"filledName": "receipt-indian-rupee-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "receipt-japanese-yen",
		"tuiName": "@tui.receipt-japanese-yen",
		"category": "commerce",
		"keywords": [
			"receipt",
			"japanese",
			"yen"
		],
		"aliases": ["@tui.receipt-japanese-yen", "@tui.receipt-japanese-yen-filled"],
		"filled": true,
		"filledName": "receipt-japanese-yen-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "receipt-pound-sterling",
		"tuiName": "@tui.receipt-pound-sterling",
		"category": "commerce",
		"keywords": [
			"receipt",
			"pound",
			"sterling"
		],
		"aliases": ["@tui.receipt-pound-sterling", "@tui.receipt-pound-sterling-filled"],
		"filled": true,
		"filledName": "receipt-pound-sterling-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "receipt-russian-ruble",
		"tuiName": "@tui.receipt-russian-ruble",
		"category": "commerce",
		"keywords": [
			"receipt",
			"russian",
			"ruble"
		],
		"aliases": ["@tui.receipt-russian-ruble", "@tui.receipt-russian-ruble-filled"],
		"filled": true,
		"filledName": "receipt-russian-ruble-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "receipt-swiss-franc",
		"tuiName": "@tui.receipt-swiss-franc",
		"category": "commerce",
		"keywords": [
			"receipt",
			"swiss",
			"franc"
		],
		"aliases": ["@tui.receipt-swiss-franc", "@tui.receipt-swiss-franc-filled"],
		"filled": true,
		"filledName": "receipt-swiss-franc-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "receipt-text",
		"tuiName": "@tui.receipt-text",
		"category": "commerce",
		"keywords": ["receipt", "text"],
		"aliases": ["@tui.receipt-text", "@tui.receipt-text-filled"],
		"filled": true,
		"filledName": "receipt-text-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "receipt-turkish-lira",
		"tuiName": "@tui.receipt-turkish-lira",
		"category": "commerce",
		"keywords": [
			"receipt",
			"turkish",
			"lira"
		],
		"aliases": ["@tui.receipt-turkish-lira", "@tui.receipt-turkish-lira-filled"],
		"filled": true,
		"filledName": "receipt-turkish-lira-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rectangle-circle",
		"tuiName": "@tui.rectangle-circle",
		"category": "custom",
		"keywords": ["rectangle", "circle"],
		"aliases": ["@tui.rectangle-circle", "@tui.rectangle-circle-filled"],
		"filled": true,
		"filledName": "rectangle-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rectangle-ellipsis",
		"tuiName": "@tui.rectangle-ellipsis",
		"category": "custom",
		"keywords": ["rectangle", "ellipsis"],
		"aliases": ["@tui.rectangle-ellipsis", "@tui.rectangle-ellipsis-filled"],
		"filled": true,
		"filledName": "rectangle-ellipsis-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rectangle-goggles",
		"tuiName": "@tui.rectangle-goggles",
		"category": "custom",
		"keywords": ["rectangle", "goggles"],
		"aliases": ["@tui.rectangle-goggles", "@tui.rectangle-goggles-filled"],
		"filled": true,
		"filledName": "rectangle-goggles-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rectangle-horizontal",
		"tuiName": "@tui.rectangle-horizontal",
		"category": "custom",
		"keywords": ["rectangle", "horizontal"],
		"aliases": ["@tui.rectangle-horizontal", "@tui.rectangle-horizontal-filled"],
		"filled": true,
		"filledName": "rectangle-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rectangle-vertical",
		"tuiName": "@tui.rectangle-vertical",
		"category": "custom",
		"keywords": ["rectangle", "vertical"],
		"aliases": ["@tui.rectangle-vertical", "@tui.rectangle-vertical-filled"],
		"filled": true,
		"filledName": "rectangle-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "recycle",
		"tuiName": "@tui.recycle",
		"category": "custom",
		"keywords": ["recycle"],
		"aliases": ["@tui.recycle", "@tui.recycle-filled"],
		"filled": true,
		"filledName": "recycle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "redo",
		"tuiName": "@tui.redo",
		"category": "arrows",
		"keywords": ["redo"],
		"aliases": ["@tui.redo", "@tui.redo-filled"],
		"filled": true,
		"filledName": "redo-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "redo-2",
		"tuiName": "@tui.redo-2",
		"category": "arrows",
		"keywords": ["redo", "2"],
		"aliases": ["@tui.redo-2", "@tui.redo-2-filled"],
		"filled": true,
		"filledName": "redo-2-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "redo-dot",
		"tuiName": "@tui.redo-dot",
		"category": "arrows",
		"keywords": ["redo", "dot"],
		"aliases": ["@tui.redo-dot", "@tui.redo-dot-filled"],
		"filled": true,
		"filledName": "redo-dot-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "refresh-ccw",
		"tuiName": "@tui.refresh-ccw",
		"category": "status-feedback",
		"keywords": ["refresh", "ccw"],
		"aliases": ["@tui.refresh-ccw", "@tui.refresh-ccw-filled"],
		"filled": true,
		"filledName": "refresh-ccw-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "refresh-ccw-dot",
		"tuiName": "@tui.refresh-ccw-dot",
		"category": "status-feedback",
		"keywords": [
			"refresh",
			"ccw",
			"dot"
		],
		"aliases": ["@tui.refresh-ccw-dot", "@tui.refresh-ccw-dot-filled"],
		"filled": true,
		"filledName": "refresh-ccw-dot-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "refresh-cw",
		"tuiName": "@tui.refresh-cw",
		"category": "status-feedback",
		"keywords": ["refresh", "cw"],
		"aliases": ["@tui.refresh-cw", "@tui.refresh-cw-filled"],
		"filled": true,
		"filledName": "refresh-cw-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "refresh-cw-off",
		"tuiName": "@tui.refresh-cw-off",
		"category": "status-feedback",
		"keywords": [
			"refresh",
			"cw",
			"off"
		],
		"aliases": ["@tui.refresh-cw-off", "@tui.refresh-cw-off-filled"],
		"filled": true,
		"filledName": "refresh-cw-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "refrigerator",
		"tuiName": "@tui.refrigerator",
		"category": "custom",
		"keywords": ["refrigerator"],
		"aliases": ["@tui.refrigerator", "@tui.refrigerator-filled"],
		"filled": true,
		"filledName": "refrigerator-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "regex",
		"tuiName": "@tui.regex",
		"category": "custom",
		"keywords": ["regex"],
		"aliases": ["@tui.regex", "@tui.regex-filled"],
		"filled": true,
		"filledName": "regex-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "remove-formatting",
		"tuiName": "@tui.remove-formatting",
		"category": "custom",
		"keywords": ["remove", "formatting"],
		"aliases": ["@tui.remove-formatting", "@tui.remove-formatting-filled"],
		"filled": true,
		"filledName": "remove-formatting-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "repeat",
		"tuiName": "@tui.repeat",
		"category": "custom",
		"keywords": ["repeat"],
		"aliases": ["@tui.repeat", "@tui.repeat-filled"],
		"filled": true,
		"filledName": "repeat-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "repeat-1",
		"tuiName": "@tui.repeat-1",
		"category": "custom",
		"keywords": ["repeat", "1"],
		"aliases": ["@tui.repeat-1", "@tui.repeat-1-filled"],
		"filled": true,
		"filledName": "repeat-1-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "repeat-2",
		"tuiName": "@tui.repeat-2",
		"category": "custom",
		"keywords": ["repeat", "2"],
		"aliases": ["@tui.repeat-2", "@tui.repeat-2-filled"],
		"filled": true,
		"filledName": "repeat-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "repeat-off",
		"tuiName": "@tui.repeat-off",
		"category": "custom",
		"keywords": ["repeat", "off"],
		"aliases": ["@tui.repeat-off", "@tui.repeat-off-filled"],
		"filled": true,
		"filledName": "repeat-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "replace",
		"tuiName": "@tui.replace",
		"category": "actions",
		"keywords": ["replace"],
		"aliases": ["@tui.replace", "@tui.replace-filled"],
		"filled": true,
		"filledName": "replace-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "replace-all",
		"tuiName": "@tui.replace-all",
		"category": "actions",
		"keywords": ["replace", "all"],
		"aliases": ["@tui.replace-all", "@tui.replace-all-filled"],
		"filled": true,
		"filledName": "replace-all-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "reply",
		"tuiName": "@tui.reply",
		"category": "arrows",
		"keywords": ["reply"],
		"aliases": ["@tui.reply", "@tui.reply-filled"],
		"filled": true,
		"filledName": "reply-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "reply-all",
		"tuiName": "@tui.reply-all",
		"category": "arrows",
		"keywords": ["reply", "all"],
		"aliases": ["@tui.reply-all", "@tui.reply-all-filled"],
		"filled": true,
		"filledName": "reply-all-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "rewind",
		"tuiName": "@tui.rewind",
		"category": "media",
		"keywords": ["rewind"],
		"aliases": ["@tui.rewind", "@tui.rewind-filled"],
		"filled": true,
		"filledName": "rewind-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ribbon",
		"tuiName": "@tui.ribbon",
		"category": "custom",
		"keywords": ["ribbon"],
		"aliases": ["@tui.ribbon", "@tui.ribbon-filled"],
		"filled": true,
		"filledName": "ribbon-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "road",
		"tuiName": "@tui.road",
		"category": "custom",
		"keywords": ["road"],
		"aliases": ["@tui.road", "@tui.road-filled"],
		"filled": true,
		"filledName": "road-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "robot-arm",
		"tuiName": "@tui.robot-arm",
		"category": "custom",
		"keywords": ["robot", "arm"],
		"aliases": ["@tui.robot-arm", "@tui.robot-arm-filled"],
		"filled": true,
		"filledName": "robot-arm-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "robot-vacuum",
		"tuiName": "@tui.robot-vacuum",
		"category": "custom",
		"keywords": ["robot", "vacuum"],
		"aliases": ["@tui.robot-vacuum", "@tui.robot-vacuum-filled"],
		"filled": true,
		"filledName": "robot-vacuum-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rocket",
		"tuiName": "@tui.rocket",
		"category": "custom",
		"keywords": ["rocket"],
		"aliases": ["@tui.rocket", "@tui.rocket-filled"],
		"filled": true,
		"filledName": "rocket-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rocking-chair",
		"tuiName": "@tui.rocking-chair",
		"category": "custom",
		"keywords": ["rocking", "chair"],
		"aliases": ["@tui.rocking-chair", "@tui.rocking-chair-filled"],
		"filled": true,
		"filledName": "rocking-chair-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "roller-coaster",
		"tuiName": "@tui.roller-coaster",
		"category": "custom",
		"keywords": ["roller", "coaster"],
		"aliases": ["@tui.roller-coaster", "@tui.roller-coaster-filled"],
		"filled": true,
		"filledName": "roller-coaster-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rose",
		"tuiName": "@tui.rose",
		"category": "custom",
		"keywords": ["rose"],
		"aliases": ["@tui.rose", "@tui.rose-filled"],
		"filled": true,
		"filledName": "rose-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rotate-3-d",
		"tuiName": "@tui.rotate-3-d",
		"category": "status-feedback",
		"keywords": [
			"rotate",
			"3",
			"d"
		],
		"aliases": ["@tui.rotate-3-d", "@tui.rotate-3-d-filled"],
		"filled": true,
		"filledName": "rotate-3-d-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rotate-3d",
		"tuiName": "@tui.rotate-3d",
		"category": "status-feedback",
		"keywords": ["rotate", "3d"],
		"aliases": ["@tui.rotate-3d", "@tui.rotate-3d-filled"],
		"filled": true,
		"filledName": "rotate-3d-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rotate-ccw",
		"tuiName": "@tui.rotate-ccw",
		"category": "status-feedback",
		"keywords": ["rotate", "ccw"],
		"aliases": ["@tui.rotate-ccw", "@tui.rotate-ccw-filled"],
		"filled": true,
		"filledName": "rotate-ccw-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rotate-ccw-clock",
		"tuiName": "@tui.rotate-ccw-clock",
		"category": "status-feedback",
		"keywords": [
			"rotate",
			"ccw",
			"clock"
		],
		"aliases": ["@tui.rotate-ccw-clock", "@tui.rotate-ccw-clock-filled"],
		"filled": true,
		"filledName": "rotate-ccw-clock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rotate-ccw-key",
		"tuiName": "@tui.rotate-ccw-key",
		"category": "status-feedback",
		"keywords": [
			"rotate",
			"ccw",
			"key"
		],
		"aliases": ["@tui.rotate-ccw-key", "@tui.rotate-ccw-key-filled"],
		"filled": true,
		"filledName": "rotate-ccw-key-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rotate-ccw-square",
		"tuiName": "@tui.rotate-ccw-square",
		"category": "status-feedback",
		"keywords": [
			"rotate",
			"ccw",
			"square"
		],
		"aliases": ["@tui.rotate-ccw-square", "@tui.rotate-ccw-square-filled"],
		"filled": true,
		"filledName": "rotate-ccw-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rotate-cw",
		"tuiName": "@tui.rotate-cw",
		"category": "status-feedback",
		"keywords": ["rotate", "cw"],
		"aliases": ["@tui.rotate-cw", "@tui.rotate-cw-filled"],
		"filled": true,
		"filledName": "rotate-cw-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rotate-cw-clock",
		"tuiName": "@tui.rotate-cw-clock",
		"category": "status-feedback",
		"keywords": [
			"rotate",
			"cw",
			"clock"
		],
		"aliases": ["@tui.rotate-cw-clock", "@tui.rotate-cw-clock-filled"],
		"filled": true,
		"filledName": "rotate-cw-clock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rotate-cw-fading-clock",
		"tuiName": "@tui.rotate-cw-fading-clock",
		"category": "status-feedback",
		"keywords": [
			"rotate",
			"cw",
			"fading",
			"clock"
		],
		"aliases": ["@tui.rotate-cw-fading-clock", "@tui.rotate-cw-fading-clock-filled"],
		"filled": true,
		"filledName": "rotate-cw-fading-clock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rotate-cw-square",
		"tuiName": "@tui.rotate-cw-square",
		"category": "status-feedback",
		"keywords": [
			"rotate",
			"cw",
			"square"
		],
		"aliases": ["@tui.rotate-cw-square", "@tui.rotate-cw-square-filled"],
		"filled": true,
		"filledName": "rotate-cw-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "route",
		"tuiName": "@tui.route",
		"category": "maps-location",
		"keywords": ["route"],
		"aliases": ["@tui.route", "@tui.route-filled"],
		"filled": true,
		"filledName": "route-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "route-off",
		"tuiName": "@tui.route-off",
		"category": "maps-location",
		"keywords": ["route", "off"],
		"aliases": ["@tui.route-off", "@tui.route-off-filled"],
		"filled": true,
		"filledName": "route-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "router",
		"tuiName": "@tui.router",
		"category": "devices",
		"keywords": ["router"],
		"aliases": ["@tui.router", "@tui.router-filled"],
		"filled": true,
		"filledName": "router-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rows",
		"tuiName": "@tui.rows",
		"category": "navigation",
		"keywords": ["rows"],
		"aliases": ["@tui.rows", "@tui.rows-filled"],
		"filled": true,
		"filledName": "rows-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rows-2",
		"tuiName": "@tui.rows-2",
		"category": "navigation",
		"keywords": ["rows", "2"],
		"aliases": ["@tui.rows-2", "@tui.rows-2-filled"],
		"filled": true,
		"filledName": "rows-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rows-3",
		"tuiName": "@tui.rows-3",
		"category": "navigation",
		"keywords": ["rows", "3"],
		"aliases": ["@tui.rows-3", "@tui.rows-3-filled"],
		"filled": true,
		"filledName": "rows-3-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rows-4",
		"tuiName": "@tui.rows-4",
		"category": "navigation",
		"keywords": ["rows", "4"],
		"aliases": ["@tui.rows-4", "@tui.rows-4-filled"],
		"filled": true,
		"filledName": "rows-4-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rss",
		"tuiName": "@tui.rss",
		"category": "communication",
		"keywords": ["rss"],
		"aliases": ["@tui.rss", "@tui.rss-filled"],
		"filled": true,
		"filledName": "rss-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ru-pay",
		"tuiName": "@tui.ru-pay",
		"category": "custom",
		"keywords": ["ru", "pay"],
		"aliases": ["@tui.ru-pay"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "rugby-ball",
		"tuiName": "@tui.rugby-ball",
		"category": "custom",
		"keywords": ["rugby", "ball"],
		"aliases": ["@tui.rugby-ball", "@tui.rugby-ball-filled"],
		"filled": true,
		"filledName": "rugby-ball-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ruler",
		"tuiName": "@tui.ruler",
		"category": "custom",
		"keywords": ["ruler"],
		"aliases": ["@tui.ruler", "@tui.ruler-filled"],
		"filled": true,
		"filledName": "ruler-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ruler-dimension-line",
		"tuiName": "@tui.ruler-dimension-line",
		"category": "custom",
		"keywords": [
			"ruler",
			"dimension",
			"line"
		],
		"aliases": ["@tui.ruler-dimension-line", "@tui.ruler-dimension-line-filled"],
		"filled": true,
		"filledName": "ruler-dimension-line-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "russian-ruble",
		"tuiName": "@tui.russian-ruble",
		"category": "custom",
		"keywords": ["russian", "ruble"],
		"aliases": ["@tui.russian-ruble", "@tui.russian-ruble-filled"],
		"filled": true,
		"filledName": "russian-ruble-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sailboat",
		"tuiName": "@tui.sailboat",
		"category": "custom",
		"keywords": ["sailboat"],
		"aliases": ["@tui.sailboat", "@tui.sailboat-filled"],
		"filled": true,
		"filledName": "sailboat-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "salad",
		"tuiName": "@tui.salad",
		"category": "custom",
		"keywords": ["salad"],
		"aliases": ["@tui.salad", "@tui.salad-filled"],
		"filled": true,
		"filledName": "salad-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "samsung-pay",
		"tuiName": "@tui.samsung-pay",
		"category": "custom",
		"keywords": ["samsung", "pay"],
		"aliases": ["@tui.samsung-pay"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sandwich",
		"tuiName": "@tui.sandwich",
		"category": "custom",
		"keywords": ["sandwich"],
		"aliases": ["@tui.sandwich", "@tui.sandwich-filled"],
		"filled": true,
		"filledName": "sandwich-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "satellite",
		"tuiName": "@tui.satellite",
		"category": "custom",
		"keywords": ["satellite"],
		"aliases": ["@tui.satellite", "@tui.satellite-filled"],
		"filled": true,
		"filledName": "satellite-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "satellite-dish",
		"tuiName": "@tui.satellite-dish",
		"category": "custom",
		"keywords": ["satellite", "dish"],
		"aliases": ["@tui.satellite-dish", "@tui.satellite-dish-filled"],
		"filled": true,
		"filledName": "satellite-dish-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "saudi-riyal",
		"tuiName": "@tui.saudi-riyal",
		"category": "custom",
		"keywords": ["saudi", "riyal"],
		"aliases": ["@tui.saudi-riyal", "@tui.saudi-riyal-filled"],
		"filled": true,
		"filledName": "saudi-riyal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "save",
		"tuiName": "@tui.save",
		"category": "actions",
		"keywords": ["save"],
		"aliases": ["@tui.save", "@tui.save-filled"],
		"filled": true,
		"filledName": "save-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "save-all",
		"tuiName": "@tui.save-all",
		"category": "actions",
		"keywords": ["save", "all"],
		"aliases": ["@tui.save-all", "@tui.save-all-filled"],
		"filled": true,
		"filledName": "save-all-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "save-check",
		"tuiName": "@tui.save-check",
		"category": "actions",
		"keywords": ["save", "check"],
		"aliases": ["@tui.save-check", "@tui.save-check-filled"],
		"filled": true,
		"filledName": "save-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "save-off",
		"tuiName": "@tui.save-off",
		"category": "actions",
		"keywords": ["save", "off"],
		"aliases": ["@tui.save-off", "@tui.save-off-filled"],
		"filled": true,
		"filledName": "save-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "save-pen",
		"tuiName": "@tui.save-pen",
		"category": "actions",
		"keywords": ["save", "pen"],
		"aliases": ["@tui.save-pen", "@tui.save-pen-filled"],
		"filled": true,
		"filledName": "save-pen-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "save-plus",
		"tuiName": "@tui.save-plus",
		"category": "actions",
		"keywords": ["save", "plus"],
		"aliases": ["@tui.save-plus", "@tui.save-plus-filled"],
		"filled": true,
		"filledName": "save-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scale",
		"tuiName": "@tui.scale",
		"category": "custom",
		"keywords": ["scale"],
		"aliases": ["@tui.scale", "@tui.scale-filled"],
		"filled": true,
		"filledName": "scale-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scale-3-d",
		"tuiName": "@tui.scale-3-d",
		"category": "custom",
		"keywords": [
			"scale",
			"3",
			"d"
		],
		"aliases": ["@tui.scale-3-d", "@tui.scale-3-d-filled"],
		"filled": true,
		"filledName": "scale-3-d-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scale-3d",
		"tuiName": "@tui.scale-3d",
		"category": "custom",
		"keywords": ["scale", "3d"],
		"aliases": ["@tui.scale-3d", "@tui.scale-3d-filled"],
		"filled": true,
		"filledName": "scale-3d-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scaling",
		"tuiName": "@tui.scaling",
		"category": "layout",
		"keywords": ["scaling"],
		"aliases": ["@tui.scaling", "@tui.scaling-filled"],
		"filled": true,
		"filledName": "scaling-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scan",
		"tuiName": "@tui.scan",
		"category": "custom",
		"keywords": ["scan"],
		"aliases": ["@tui.scan", "@tui.scan-filled"],
		"filled": true,
		"filledName": "scan-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scan-barcode",
		"tuiName": "@tui.scan-barcode",
		"category": "custom",
		"keywords": ["scan", "barcode"],
		"aliases": ["@tui.scan-barcode", "@tui.scan-barcode-filled"],
		"filled": true,
		"filledName": "scan-barcode-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scan-box",
		"tuiName": "@tui.scan-box",
		"category": "custom",
		"keywords": ["scan", "box"],
		"aliases": ["@tui.scan-box", "@tui.scan-box-filled"],
		"filled": true,
		"filledName": "scan-box-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scan-eye",
		"tuiName": "@tui.scan-eye",
		"category": "security",
		"keywords": ["scan", "eye"],
		"aliases": ["@tui.scan-eye", "@tui.scan-eye-filled"],
		"filled": true,
		"filledName": "scan-eye-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scan-face",
		"tuiName": "@tui.scan-face",
		"category": "security",
		"keywords": ["scan", "face"],
		"aliases": ["@tui.scan-face", "@tui.scan-face-filled"],
		"filled": true,
		"filledName": "scan-face-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scan-heart",
		"tuiName": "@tui.scan-heart",
		"category": "custom",
		"keywords": ["scan", "heart"],
		"aliases": ["@tui.scan-heart", "@tui.scan-heart-filled"],
		"filled": true,
		"filledName": "scan-heart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scan-line",
		"tuiName": "@tui.scan-line",
		"category": "custom",
		"keywords": ["scan", "line"],
		"aliases": ["@tui.scan-line", "@tui.scan-line-filled"],
		"filled": true,
		"filledName": "scan-line-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scan-qr-code",
		"tuiName": "@tui.scan-qr-code",
		"category": "custom",
		"keywords": [
			"scan",
			"qr",
			"code"
		],
		"aliases": ["@tui.scan-qr-code", "@tui.scan-qr-code-filled"],
		"filled": true,
		"filledName": "scan-qr-code-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scan-search",
		"tuiName": "@tui.scan-search",
		"category": "custom",
		"keywords": ["scan", "search"],
		"aliases": ["@tui.scan-search", "@tui.scan-search-filled"],
		"filled": true,
		"filledName": "scan-search-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scan-square",
		"tuiName": "@tui.scan-square",
		"category": "custom",
		"keywords": ["scan", "square"],
		"aliases": ["@tui.scan-square", "@tui.scan-square-filled"],
		"filled": true,
		"filledName": "scan-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scan-text",
		"tuiName": "@tui.scan-text",
		"category": "custom",
		"keywords": ["scan", "text"],
		"aliases": ["@tui.scan-text", "@tui.scan-text-filled"],
		"filled": true,
		"filledName": "scan-text-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scatter-chart",
		"tuiName": "@tui.scatter-chart",
		"category": "custom",
		"keywords": ["scatter", "chart"],
		"aliases": ["@tui.scatter-chart", "@tui.scatter-chart-filled"],
		"filled": true,
		"filledName": "scatter-chart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "school",
		"tuiName": "@tui.school",
		"category": "custom",
		"keywords": ["school"],
		"aliases": ["@tui.school", "@tui.school-filled"],
		"filled": true,
		"filledName": "school-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "school-2",
		"tuiName": "@tui.school-2",
		"category": "custom",
		"keywords": ["school", "2"],
		"aliases": ["@tui.school-2", "@tui.school-2-filled"],
		"filled": true,
		"filledName": "school-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scissors",
		"tuiName": "@tui.scissors",
		"category": "editing",
		"keywords": ["scissors"],
		"aliases": ["@tui.scissors", "@tui.scissors-filled"],
		"filled": true,
		"filledName": "scissors-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scissors-line-dashed",
		"tuiName": "@tui.scissors-line-dashed",
		"category": "editing",
		"keywords": [
			"scissors",
			"line",
			"dashed"
		],
		"aliases": ["@tui.scissors-line-dashed", "@tui.scissors-line-dashed-filled"],
		"filled": true,
		"filledName": "scissors-line-dashed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scissors-square",
		"tuiName": "@tui.scissors-square",
		"category": "editing",
		"keywords": ["scissors", "square"],
		"aliases": ["@tui.scissors-square", "@tui.scissors-square-filled"],
		"filled": true,
		"filledName": "scissors-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scissors-square-dashed-bottom",
		"tuiName": "@tui.scissors-square-dashed-bottom",
		"category": "editing",
		"keywords": [
			"scissors",
			"square",
			"dashed",
			"bottom"
		],
		"aliases": ["@tui.scissors-square-dashed-bottom", "@tui.scissors-square-dashed-bottom-filled"],
		"filled": true,
		"filledName": "scissors-square-dashed-bottom-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scooter",
		"tuiName": "@tui.scooter",
		"category": "custom",
		"keywords": ["scooter"],
		"aliases": ["@tui.scooter", "@tui.scooter-filled"],
		"filled": true,
		"filledName": "scooter-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scratch-blocks",
		"tuiName": "@tui.scratch-blocks",
		"category": "custom",
		"keywords": ["scratch", "blocks"],
		"aliases": ["@tui.scratch-blocks", "@tui.scratch-blocks-filled"],
		"filled": true,
		"filledName": "scratch-blocks-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "screen-share",
		"tuiName": "@tui.screen-share",
		"category": "custom",
		"keywords": ["screen", "share"],
		"aliases": ["@tui.screen-share", "@tui.screen-share-filled"],
		"filled": true,
		"filledName": "screen-share-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "screen-share-off",
		"tuiName": "@tui.screen-share-off",
		"category": "custom",
		"keywords": [
			"screen",
			"share",
			"off"
		],
		"aliases": ["@tui.screen-share-off", "@tui.screen-share-off-filled"],
		"filled": true,
		"filledName": "screen-share-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "screw",
		"tuiName": "@tui.screw",
		"category": "custom",
		"keywords": ["screw"],
		"aliases": ["@tui.screw", "@tui.screw-filled"],
		"filled": true,
		"filledName": "screw-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scroll",
		"tuiName": "@tui.scroll",
		"category": "files",
		"keywords": ["scroll"],
		"aliases": ["@tui.scroll", "@tui.scroll-filled"],
		"filled": true,
		"filledName": "scroll-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "scroll-text",
		"tuiName": "@tui.scroll-text",
		"category": "files",
		"keywords": ["scroll", "text"],
		"aliases": ["@tui.scroll-text", "@tui.scroll-text-filled"],
		"filled": true,
		"filledName": "scroll-text-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "search",
		"tuiName": "@tui.search",
		"category": "actions",
		"keywords": ["search"],
		"aliases": ["@tui.search", "@tui.search-filled"],
		"filled": true,
		"filledName": "search-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "search-alert",
		"tuiName": "@tui.search-alert",
		"category": "actions",
		"keywords": ["search", "alert"],
		"aliases": ["@tui.search-alert", "@tui.search-alert-filled"],
		"filled": true,
		"filledName": "search-alert-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "search-check",
		"tuiName": "@tui.search-check",
		"category": "actions",
		"keywords": ["search", "check"],
		"aliases": ["@tui.search-check", "@tui.search-check-filled"],
		"filled": true,
		"filledName": "search-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "search-code",
		"tuiName": "@tui.search-code",
		"category": "actions",
		"keywords": ["search", "code"],
		"aliases": ["@tui.search-code", "@tui.search-code-filled"],
		"filled": true,
		"filledName": "search-code-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "search-slash",
		"tuiName": "@tui.search-slash",
		"category": "actions",
		"keywords": ["search", "slash"],
		"aliases": ["@tui.search-slash", "@tui.search-slash-filled"],
		"filled": true,
		"filledName": "search-slash-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "search-x",
		"tuiName": "@tui.search-x",
		"category": "actions",
		"keywords": ["search", "x"],
		"aliases": ["@tui.search-x", "@tui.search-x-filled"],
		"filled": true,
		"filledName": "search-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "section",
		"tuiName": "@tui.section",
		"category": "custom",
		"keywords": ["section"],
		"aliases": ["@tui.section", "@tui.section-filled"],
		"filled": true,
		"filledName": "section-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "send",
		"tuiName": "@tui.send",
		"category": "communication",
		"keywords": ["send"],
		"aliases": ["@tui.send", "@tui.send-filled"],
		"filled": true,
		"filledName": "send-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "send-horizonal",
		"tuiName": "@tui.send-horizonal",
		"category": "communication",
		"keywords": ["send", "horizonal"],
		"aliases": ["@tui.send-horizonal", "@tui.send-horizonal-filled"],
		"filled": true,
		"filledName": "send-horizonal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "send-horizontal",
		"tuiName": "@tui.send-horizontal",
		"category": "communication",
		"keywords": ["send", "horizontal"],
		"aliases": ["@tui.send-horizontal", "@tui.send-horizontal-filled"],
		"filled": true,
		"filledName": "send-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "send-to-back",
		"tuiName": "@tui.send-to-back",
		"category": "communication",
		"keywords": [
			"send",
			"to",
			"back"
		],
		"aliases": ["@tui.send-to-back", "@tui.send-to-back-filled"],
		"filled": true,
		"filledName": "send-to-back-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "separator-horizontal",
		"tuiName": "@tui.separator-horizontal",
		"category": "navigation",
		"keywords": ["separator", "horizontal"],
		"aliases": ["@tui.separator-horizontal", "@tui.separator-horizontal-filled"],
		"filled": true,
		"filledName": "separator-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "separator-vertical",
		"tuiName": "@tui.separator-vertical",
		"category": "navigation",
		"keywords": ["separator", "vertical"],
		"aliases": ["@tui.separator-vertical", "@tui.separator-vertical-filled"],
		"filled": true,
		"filledName": "separator-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "server",
		"tuiName": "@tui.server",
		"category": "devices",
		"keywords": ["server"],
		"aliases": ["@tui.server", "@tui.server-filled"],
		"filled": true,
		"filledName": "server-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "server-cog",
		"tuiName": "@tui.server-cog",
		"category": "devices",
		"keywords": ["server", "cog"],
		"aliases": ["@tui.server-cog", "@tui.server-cog-filled"],
		"filled": true,
		"filledName": "server-cog-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "server-crash",
		"tuiName": "@tui.server-crash",
		"category": "devices",
		"keywords": ["server", "crash"],
		"aliases": ["@tui.server-crash", "@tui.server-crash-filled"],
		"filled": true,
		"filledName": "server-crash-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "server-nas",
		"tuiName": "@tui.server-nas",
		"category": "devices",
		"keywords": ["server", "nas"],
		"aliases": ["@tui.server-nas", "@tui.server-nas-filled"],
		"filled": true,
		"filledName": "server-nas-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "server-off",
		"tuiName": "@tui.server-off",
		"category": "devices",
		"keywords": ["server", "off"],
		"aliases": ["@tui.server-off", "@tui.server-off-filled"],
		"filled": true,
		"filledName": "server-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "server-plus",
		"tuiName": "@tui.server-plus",
		"category": "devices",
		"keywords": ["server", "plus"],
		"aliases": ["@tui.server-plus", "@tui.server-plus-filled"],
		"filled": true,
		"filledName": "server-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "settings",
		"tuiName": "@tui.settings",
		"category": "actions",
		"keywords": ["settings"],
		"aliases": ["@tui.settings", "@tui.settings-filled"],
		"filled": true,
		"filledName": "settings-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "settings-2",
		"tuiName": "@tui.settings-2",
		"category": "actions",
		"keywords": ["settings", "2"],
		"aliases": ["@tui.settings-2", "@tui.settings-2-filled"],
		"filled": true,
		"filledName": "settings-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shapes",
		"tuiName": "@tui.shapes",
		"category": "custom",
		"keywords": ["shapes"],
		"aliases": ["@tui.shapes", "@tui.shapes-filled"],
		"filled": true,
		"filledName": "shapes-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "share",
		"tuiName": "@tui.share",
		"category": "social",
		"keywords": ["share"],
		"aliases": ["@tui.share", "@tui.share-filled"],
		"filled": true,
		"filledName": "share-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "share-2",
		"tuiName": "@tui.share-2",
		"category": "social",
		"keywords": ["share", "2"],
		"aliases": ["@tui.share-2", "@tui.share-2-filled"],
		"filled": true,
		"filledName": "share-2-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "sheet",
		"tuiName": "@tui.sheet",
		"category": "custom",
		"keywords": ["sheet"],
		"aliases": ["@tui.sheet", "@tui.sheet-filled"],
		"filled": true,
		"filledName": "sheet-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shell",
		"tuiName": "@tui.shell",
		"category": "custom",
		"keywords": ["shell"],
		"aliases": ["@tui.shell", "@tui.shell-filled"],
		"filled": true,
		"filledName": "shell-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shelving-unit",
		"tuiName": "@tui.shelving-unit",
		"category": "custom",
		"keywords": ["shelving", "unit"],
		"aliases": ["@tui.shelving-unit", "@tui.shelving-unit-filled"],
		"filled": true,
		"filledName": "shelving-unit-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shield",
		"tuiName": "@tui.shield",
		"category": "security",
		"keywords": ["shield"],
		"aliases": ["@tui.shield", "@tui.shield-filled"],
		"filled": true,
		"filledName": "shield-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shield-alert",
		"tuiName": "@tui.shield-alert",
		"category": "security",
		"keywords": ["shield", "alert"],
		"aliases": ["@tui.shield-alert", "@tui.shield-alert-filled"],
		"filled": true,
		"filledName": "shield-alert-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shield-ban",
		"tuiName": "@tui.shield-ban",
		"category": "security",
		"keywords": ["shield", "ban"],
		"aliases": ["@tui.shield-ban", "@tui.shield-ban-filled"],
		"filled": true,
		"filledName": "shield-ban-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shield-check",
		"tuiName": "@tui.shield-check",
		"category": "security",
		"keywords": ["shield", "check"],
		"aliases": ["@tui.shield-check", "@tui.shield-check-filled"],
		"filled": true,
		"filledName": "shield-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shield-close",
		"tuiName": "@tui.shield-close",
		"category": "security",
		"keywords": ["shield", "close"],
		"aliases": ["@tui.shield-close", "@tui.shield-close-filled"],
		"filled": true,
		"filledName": "shield-close-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shield-cog",
		"tuiName": "@tui.shield-cog",
		"category": "security",
		"keywords": ["shield", "cog"],
		"aliases": ["@tui.shield-cog", "@tui.shield-cog-filled"],
		"filled": true,
		"filledName": "shield-cog-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shield-cog-corner",
		"tuiName": "@tui.shield-cog-corner",
		"category": "security",
		"keywords": [
			"shield",
			"cog",
			"corner"
		],
		"aliases": ["@tui.shield-cog-corner", "@tui.shield-cog-corner-filled"],
		"filled": true,
		"filledName": "shield-cog-corner-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shield-ellipsis",
		"tuiName": "@tui.shield-ellipsis",
		"category": "security",
		"keywords": ["shield", "ellipsis"],
		"aliases": ["@tui.shield-ellipsis", "@tui.shield-ellipsis-filled"],
		"filled": true,
		"filledName": "shield-ellipsis-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shield-half",
		"tuiName": "@tui.shield-half",
		"category": "security",
		"keywords": ["shield", "half"],
		"aliases": ["@tui.shield-half", "@tui.shield-half-filled"],
		"filled": true,
		"filledName": "shield-half-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shield-house",
		"tuiName": "@tui.shield-house",
		"category": "security",
		"keywords": ["shield", "house"],
		"aliases": ["@tui.shield-house", "@tui.shield-house-filled"],
		"filled": true,
		"filledName": "shield-house-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shield-keyhole",
		"tuiName": "@tui.shield-keyhole",
		"category": "security",
		"keywords": ["shield", "keyhole"],
		"aliases": ["@tui.shield-keyhole", "@tui.shield-keyhole-filled"],
		"filled": true,
		"filledName": "shield-keyhole-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shield-lock",
		"tuiName": "@tui.shield-lock",
		"category": "security",
		"keywords": ["shield", "lock"],
		"aliases": ["@tui.shield-lock", "@tui.shield-lock-filled"],
		"filled": true,
		"filledName": "shield-lock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shield-minus",
		"tuiName": "@tui.shield-minus",
		"category": "security",
		"keywords": ["shield", "minus"],
		"aliases": ["@tui.shield-minus", "@tui.shield-minus-filled"],
		"filled": true,
		"filledName": "shield-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shield-off",
		"tuiName": "@tui.shield-off",
		"category": "security",
		"keywords": ["shield", "off"],
		"aliases": ["@tui.shield-off", "@tui.shield-off-filled"],
		"filled": true,
		"filledName": "shield-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shield-plus",
		"tuiName": "@tui.shield-plus",
		"category": "security",
		"keywords": ["shield", "plus"],
		"aliases": ["@tui.shield-plus", "@tui.shield-plus-filled"],
		"filled": true,
		"filledName": "shield-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shield-question",
		"tuiName": "@tui.shield-question",
		"category": "security",
		"keywords": ["shield", "question"],
		"aliases": ["@tui.shield-question", "@tui.shield-question-filled"],
		"filled": true,
		"filledName": "shield-question-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shield-question-mark",
		"tuiName": "@tui.shield-question-mark",
		"category": "security",
		"keywords": [
			"shield",
			"question",
			"mark"
		],
		"aliases": ["@tui.shield-question-mark", "@tui.shield-question-mark-filled"],
		"filled": true,
		"filledName": "shield-question-mark-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shield-user",
		"tuiName": "@tui.shield-user",
		"category": "security",
		"keywords": ["shield", "user"],
		"aliases": ["@tui.shield-user", "@tui.shield-user-filled"],
		"filled": true,
		"filledName": "shield-user-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shield-x",
		"tuiName": "@tui.shield-x",
		"category": "security",
		"keywords": ["shield", "x"],
		"aliases": ["@tui.shield-x", "@tui.shield-x-filled"],
		"filled": true,
		"filledName": "shield-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ship",
		"tuiName": "@tui.ship",
		"category": "maps-location",
		"keywords": ["ship"],
		"aliases": ["@tui.ship", "@tui.ship-filled"],
		"filled": true,
		"filledName": "ship-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ship-cargo",
		"tuiName": "@tui.ship-cargo",
		"category": "maps-location",
		"keywords": ["ship", "cargo"],
		"aliases": ["@tui.ship-cargo", "@tui.ship-cargo-filled"],
		"filled": true,
		"filledName": "ship-cargo-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ship-wheel",
		"tuiName": "@tui.ship-wheel",
		"category": "maps-location",
		"keywords": ["ship", "wheel"],
		"aliases": ["@tui.ship-wheel", "@tui.ship-wheel-filled"],
		"filled": true,
		"filledName": "ship-wheel-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shirt",
		"tuiName": "@tui.shirt",
		"category": "custom",
		"keywords": ["shirt"],
		"aliases": ["@tui.shirt", "@tui.shirt-filled"],
		"filled": true,
		"filledName": "shirt-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shopping-bag",
		"tuiName": "@tui.shopping-bag",
		"category": "commerce",
		"keywords": ["shopping", "bag"],
		"aliases": ["@tui.shopping-bag", "@tui.shopping-bag-filled"],
		"filled": true,
		"filledName": "shopping-bag-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shopping-basket",
		"tuiName": "@tui.shopping-basket",
		"category": "commerce",
		"keywords": ["shopping", "basket"],
		"aliases": ["@tui.shopping-basket", "@tui.shopping-basket-filled"],
		"filled": true,
		"filledName": "shopping-basket-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shopping-cart",
		"tuiName": "@tui.shopping-cart",
		"category": "commerce",
		"keywords": ["shopping", "cart"],
		"aliases": ["@tui.shopping-cart", "@tui.shopping-cart-filled"],
		"filled": true,
		"filledName": "shopping-cart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shopping-cart-minus",
		"tuiName": "@tui.shopping-cart-minus",
		"category": "commerce",
		"keywords": [
			"shopping",
			"cart",
			"minus"
		],
		"aliases": ["@tui.shopping-cart-minus", "@tui.shopping-cart-minus-filled"],
		"filled": true,
		"filledName": "shopping-cart-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shopping-cart-plus",
		"tuiName": "@tui.shopping-cart-plus",
		"category": "commerce",
		"keywords": [
			"shopping",
			"cart",
			"plus"
		],
		"aliases": ["@tui.shopping-cart-plus", "@tui.shopping-cart-plus-filled"],
		"filled": true,
		"filledName": "shopping-cart-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shovel",
		"tuiName": "@tui.shovel",
		"category": "custom",
		"keywords": ["shovel"],
		"aliases": ["@tui.shovel", "@tui.shovel-filled"],
		"filled": true,
		"filledName": "shovel-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shower-head",
		"tuiName": "@tui.shower-head",
		"category": "custom",
		"keywords": ["shower", "head"],
		"aliases": ["@tui.shower-head", "@tui.shower-head-filled"],
		"filled": true,
		"filledName": "shower-head-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shredder",
		"tuiName": "@tui.shredder",
		"category": "custom",
		"keywords": ["shredder"],
		"aliases": ["@tui.shredder", "@tui.shredder-filled"],
		"filled": true,
		"filledName": "shredder-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shrimp",
		"tuiName": "@tui.shrimp",
		"category": "custom",
		"keywords": ["shrimp"],
		"aliases": ["@tui.shrimp", "@tui.shrimp-filled"],
		"filled": true,
		"filledName": "shrimp-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shrimp-off",
		"tuiName": "@tui.shrimp-off",
		"category": "custom",
		"keywords": ["shrimp", "off"],
		"aliases": ["@tui.shrimp-off", "@tui.shrimp-off-filled"],
		"filled": true,
		"filledName": "shrimp-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shrink",
		"tuiName": "@tui.shrink",
		"category": "arrows",
		"keywords": ["shrink"],
		"aliases": ["@tui.shrink", "@tui.shrink-filled"],
		"filled": true,
		"filledName": "shrink-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shrub",
		"tuiName": "@tui.shrub",
		"category": "custom",
		"keywords": ["shrub"],
		"aliases": ["@tui.shrub", "@tui.shrub-filled"],
		"filled": true,
		"filledName": "shrub-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "shuffle",
		"tuiName": "@tui.shuffle",
		"category": "custom",
		"keywords": ["shuffle"],
		"aliases": ["@tui.shuffle", "@tui.shuffle-filled"],
		"filled": true,
		"filledName": "shuffle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sidebar",
		"tuiName": "@tui.sidebar",
		"category": "navigation",
		"keywords": ["sidebar"],
		"aliases": ["@tui.sidebar", "@tui.sidebar-filled"],
		"filled": true,
		"filledName": "sidebar-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "sidebar-close",
		"tuiName": "@tui.sidebar-close",
		"category": "navigation",
		"keywords": ["sidebar", "close"],
		"aliases": ["@tui.sidebar-close", "@tui.sidebar-close-filled"],
		"filled": true,
		"filledName": "sidebar-close-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "sidebar-open",
		"tuiName": "@tui.sidebar-open",
		"category": "navigation",
		"keywords": ["sidebar", "open"],
		"aliases": ["@tui.sidebar-open", "@tui.sidebar-open-filled"],
		"filled": true,
		"filledName": "sidebar-open-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "sigma",
		"tuiName": "@tui.sigma",
		"category": "custom",
		"keywords": ["sigma"],
		"aliases": ["@tui.sigma", "@tui.sigma-filled"],
		"filled": true,
		"filledName": "sigma-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sigma-square",
		"tuiName": "@tui.sigma-square",
		"category": "custom",
		"keywords": ["sigma", "square"],
		"aliases": ["@tui.sigma-square", "@tui.sigma-square-filled"],
		"filled": true,
		"filledName": "sigma-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "signal",
		"tuiName": "@tui.signal",
		"category": "social",
		"keywords": ["signal"],
		"aliases": ["@tui.signal", "@tui.signal-filled"],
		"filled": true,
		"filledName": "signal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "signal-high",
		"tuiName": "@tui.signal-high",
		"category": "social",
		"keywords": ["signal", "high"],
		"aliases": ["@tui.signal-high", "@tui.signal-high-filled"],
		"filled": true,
		"filledName": "signal-high-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "signal-low",
		"tuiName": "@tui.signal-low",
		"category": "social",
		"keywords": ["signal", "low"],
		"aliases": ["@tui.signal-low", "@tui.signal-low-filled"],
		"filled": true,
		"filledName": "signal-low-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "signal-medium",
		"tuiName": "@tui.signal-medium",
		"category": "social",
		"keywords": ["signal", "medium"],
		"aliases": ["@tui.signal-medium", "@tui.signal-medium-filled"],
		"filled": true,
		"filledName": "signal-medium-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "signal-zero",
		"tuiName": "@tui.signal-zero",
		"category": "social",
		"keywords": ["signal", "zero"],
		"aliases": ["@tui.signal-zero", "@tui.signal-zero-filled"],
		"filled": true,
		"filledName": "signal-zero-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "signature",
		"tuiName": "@tui.signature",
		"category": "custom",
		"keywords": ["signature"],
		"aliases": ["@tui.signature", "@tui.signature-filled"],
		"filled": true,
		"filledName": "signature-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "signpost",
		"tuiName": "@tui.signpost",
		"category": "maps-location",
		"keywords": ["signpost"],
		"aliases": ["@tui.signpost", "@tui.signpost-filled"],
		"filled": true,
		"filledName": "signpost-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "signpost-big",
		"tuiName": "@tui.signpost-big",
		"category": "maps-location",
		"keywords": ["signpost", "big"],
		"aliases": ["@tui.signpost-big", "@tui.signpost-big-filled"],
		"filled": true,
		"filledName": "signpost-big-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "siren",
		"tuiName": "@tui.siren",
		"category": "notifications",
		"keywords": ["siren"],
		"aliases": ["@tui.siren", "@tui.siren-filled"],
		"filled": true,
		"filledName": "siren-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "skip-back",
		"tuiName": "@tui.skip-back",
		"category": "media",
		"keywords": ["skip", "back"],
		"aliases": ["@tui.skip-back", "@tui.skip-back-filled"],
		"filled": true,
		"filledName": "skip-back-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "skip-forward",
		"tuiName": "@tui.skip-forward",
		"category": "media",
		"keywords": ["skip", "forward"],
		"aliases": ["@tui.skip-forward", "@tui.skip-forward-filled"],
		"filled": true,
		"filledName": "skip-forward-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "skull",
		"tuiName": "@tui.skull",
		"category": "custom",
		"keywords": ["skull"],
		"aliases": ["@tui.skull", "@tui.skull-filled"],
		"filled": true,
		"filledName": "skull-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "slash",
		"tuiName": "@tui.slash",
		"category": "custom",
		"keywords": ["slash"],
		"aliases": ["@tui.slash", "@tui.slash-filled"],
		"filled": true,
		"filledName": "slash-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "slash-square",
		"tuiName": "@tui.slash-square",
		"category": "custom",
		"keywords": ["slash", "square"],
		"aliases": ["@tui.slash-square", "@tui.slash-square-filled"],
		"filled": true,
		"filledName": "slash-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "slice",
		"tuiName": "@tui.slice",
		"category": "custom",
		"keywords": ["slice"],
		"aliases": ["@tui.slice", "@tui.slice-filled"],
		"filled": true,
		"filledName": "slice-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sliders",
		"tuiName": "@tui.sliders",
		"category": "actions",
		"keywords": ["sliders"],
		"aliases": ["@tui.sliders", "@tui.sliders-filled"],
		"filled": true,
		"filledName": "sliders-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sliders-horizontal",
		"tuiName": "@tui.sliders-horizontal",
		"category": "actions",
		"keywords": ["sliders", "horizontal"],
		"aliases": ["@tui.sliders-horizontal", "@tui.sliders-horizontal-filled"],
		"filled": true,
		"filledName": "sliders-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sliders-vertical",
		"tuiName": "@tui.sliders-vertical",
		"category": "actions",
		"keywords": ["sliders", "vertical"],
		"aliases": ["@tui.sliders-vertical", "@tui.sliders-vertical-filled"],
		"filled": true,
		"filledName": "sliders-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "smartphone",
		"tuiName": "@tui.smartphone",
		"category": "devices",
		"keywords": ["smartphone"],
		"aliases": ["@tui.smartphone", "@tui.smartphone-filled"],
		"filled": true,
		"filledName": "smartphone-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "smartphone-charging",
		"tuiName": "@tui.smartphone-charging",
		"category": "devices",
		"keywords": ["smartphone", "charging"],
		"aliases": ["@tui.smartphone-charging", "@tui.smartphone-charging-filled"],
		"filled": true,
		"filledName": "smartphone-charging-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "smartphone-nfc",
		"tuiName": "@tui.smartphone-nfc",
		"category": "devices",
		"keywords": ["smartphone", "nfc"],
		"aliases": ["@tui.smartphone-nfc", "@tui.smartphone-nfc-filled"],
		"filled": true,
		"filledName": "smartphone-nfc-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "smile",
		"tuiName": "@tui.smile",
		"category": "status-feedback",
		"keywords": ["smile"],
		"aliases": ["@tui.smile", "@tui.smile-filled"],
		"filled": true,
		"filledName": "smile-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "smile-plus",
		"tuiName": "@tui.smile-plus",
		"category": "status-feedback",
		"keywords": ["smile", "plus"],
		"aliases": ["@tui.smile-plus", "@tui.smile-plus-filled"],
		"filled": true,
		"filledName": "smile-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "snail",
		"tuiName": "@tui.snail",
		"category": "custom",
		"keywords": ["snail"],
		"aliases": ["@tui.snail", "@tui.snail-filled"],
		"filled": true,
		"filledName": "snail-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "snowflake",
		"tuiName": "@tui.snowflake",
		"category": "custom",
		"keywords": ["snowflake"],
		"aliases": ["@tui.snowflake", "@tui.snowflake-filled"],
		"filled": true,
		"filledName": "snowflake-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "soap-dispenser-droplet",
		"tuiName": "@tui.soap-dispenser-droplet",
		"category": "custom",
		"keywords": [
			"soap",
			"dispenser",
			"droplet"
		],
		"aliases": ["@tui.soap-dispenser-droplet", "@tui.soap-dispenser-droplet-filled"],
		"filled": true,
		"filledName": "soap-dispenser-droplet-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sofa",
		"tuiName": "@tui.sofa",
		"category": "custom",
		"keywords": ["sofa"],
		"aliases": ["@tui.sofa", "@tui.sofa-filled"],
		"filled": true,
		"filledName": "sofa-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "solar-panel",
		"tuiName": "@tui.solar-panel",
		"category": "custom",
		"keywords": ["solar", "panel"],
		"aliases": ["@tui.solar-panel", "@tui.solar-panel-filled"],
		"filled": true,
		"filledName": "solar-panel-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sort-asc",
		"tuiName": "@tui.sort-asc",
		"category": "custom",
		"keywords": ["sort", "asc"],
		"aliases": ["@tui.sort-asc", "@tui.sort-asc-filled"],
		"filled": true,
		"filledName": "sort-asc-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sort-desc",
		"tuiName": "@tui.sort-desc",
		"category": "custom",
		"keywords": ["sort", "desc"],
		"aliases": ["@tui.sort-desc", "@tui.sort-desc-filled"],
		"filled": true,
		"filledName": "sort-desc-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "soup",
		"tuiName": "@tui.soup",
		"category": "custom",
		"keywords": ["soup"],
		"aliases": ["@tui.soup", "@tui.soup-filled"],
		"filled": true,
		"filledName": "soup-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "space",
		"tuiName": "@tui.space",
		"category": "custom",
		"keywords": ["space"],
		"aliases": ["@tui.space", "@tui.space-filled"],
		"filled": true,
		"filledName": "space-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "spade",
		"tuiName": "@tui.spade",
		"category": "custom",
		"keywords": ["spade"],
		"aliases": ["@tui.spade", "@tui.spade-filled"],
		"filled": true,
		"filledName": "spade-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sparkle",
		"tuiName": "@tui.sparkle",
		"category": "custom",
		"keywords": ["sparkle"],
		"aliases": ["@tui.sparkle", "@tui.sparkle-filled"],
		"filled": true,
		"filledName": "sparkle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sparkles",
		"tuiName": "@tui.sparkles",
		"category": "development",
		"keywords": ["sparkles"],
		"aliases": ["@tui.sparkles", "@tui.sparkles-filled"],
		"filled": true,
		"filledName": "sparkles-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "speaker",
		"tuiName": "@tui.speaker",
		"category": "devices",
		"keywords": ["speaker"],
		"aliases": ["@tui.speaker", "@tui.speaker-filled"],
		"filled": true,
		"filledName": "speaker-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "speech",
		"tuiName": "@tui.speech",
		"category": "communication",
		"keywords": ["speech"],
		"aliases": ["@tui.speech", "@tui.speech-filled"],
		"filled": true,
		"filledName": "speech-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "spell-check",
		"tuiName": "@tui.spell-check",
		"category": "editing",
		"keywords": ["spell", "check"],
		"aliases": ["@tui.spell-check", "@tui.spell-check-filled"],
		"filled": true,
		"filledName": "spell-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "spell-check-2",
		"tuiName": "@tui.spell-check-2",
		"category": "editing",
		"keywords": [
			"spell",
			"check",
			"2"
		],
		"aliases": ["@tui.spell-check-2", "@tui.spell-check-2-filled"],
		"filled": true,
		"filledName": "spell-check-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "spline",
		"tuiName": "@tui.spline",
		"category": "custom",
		"keywords": ["spline"],
		"aliases": ["@tui.spline", "@tui.spline-filled"],
		"filled": true,
		"filledName": "spline-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "spline-pointer",
		"tuiName": "@tui.spline-pointer",
		"category": "custom",
		"keywords": ["spline", "pointer"],
		"aliases": ["@tui.spline-pointer", "@tui.spline-pointer-filled"],
		"filled": true,
		"filledName": "spline-pointer-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "split",
		"tuiName": "@tui.split",
		"category": "navigation",
		"keywords": ["split"],
		"aliases": ["@tui.split", "@tui.split-filled"],
		"filled": true,
		"filledName": "split-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "split-square-horizontal",
		"tuiName": "@tui.split-square-horizontal",
		"category": "navigation",
		"keywords": [
			"split",
			"square",
			"horizontal"
		],
		"aliases": ["@tui.split-square-horizontal", "@tui.split-square-horizontal-filled"],
		"filled": true,
		"filledName": "split-square-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "split-square-vertical",
		"tuiName": "@tui.split-square-vertical",
		"category": "navigation",
		"keywords": [
			"split",
			"square",
			"vertical"
		],
		"aliases": ["@tui.split-square-vertical", "@tui.split-square-vertical-filled"],
		"filled": true,
		"filledName": "split-square-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "spool",
		"tuiName": "@tui.spool",
		"category": "custom",
		"keywords": ["spool"],
		"aliases": ["@tui.spool", "@tui.spool-filled"],
		"filled": true,
		"filledName": "spool-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sport-shoe",
		"tuiName": "@tui.sport-shoe",
		"category": "custom",
		"keywords": ["sport", "shoe"],
		"aliases": ["@tui.sport-shoe", "@tui.sport-shoe-filled"],
		"filled": true,
		"filledName": "sport-shoe-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "spotlight",
		"tuiName": "@tui.spotlight",
		"category": "custom",
		"keywords": ["spotlight"],
		"aliases": ["@tui.spotlight", "@tui.spotlight-filled"],
		"filled": true,
		"filledName": "spotlight-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "spray-can",
		"tuiName": "@tui.spray-can",
		"category": "custom",
		"keywords": ["spray", "can"],
		"aliases": ["@tui.spray-can", "@tui.spray-can-filled"],
		"filled": true,
		"filledName": "spray-can-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sprout",
		"tuiName": "@tui.sprout",
		"category": "custom",
		"keywords": ["sprout"],
		"aliases": ["@tui.sprout", "@tui.sprout-filled"],
		"filled": true,
		"filledName": "sprout-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square",
		"tuiName": "@tui.square",
		"category": "layout",
		"keywords": ["square"],
		"aliases": ["@tui.square", "@tui.square-filled"],
		"filled": true,
		"filledName": "square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-activity",
		"tuiName": "@tui.square-activity",
		"category": "layout",
		"keywords": ["square", "activity"],
		"aliases": ["@tui.square-activity", "@tui.square-activity-filled"],
		"filled": true,
		"filledName": "square-activity-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-arrow-down",
		"tuiName": "@tui.square-arrow-down",
		"category": "layout",
		"keywords": [
			"square",
			"arrow",
			"down"
		],
		"aliases": ["@tui.square-arrow-down", "@tui.square-arrow-down-filled"],
		"filled": true,
		"filledName": "square-arrow-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-arrow-down-left",
		"tuiName": "@tui.square-arrow-down-left",
		"category": "layout",
		"keywords": [
			"square",
			"arrow",
			"down",
			"left"
		],
		"aliases": ["@tui.square-arrow-down-left", "@tui.square-arrow-down-left-filled"],
		"filled": true,
		"filledName": "square-arrow-down-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-arrow-down-right",
		"tuiName": "@tui.square-arrow-down-right",
		"category": "layout",
		"keywords": [
			"square",
			"arrow",
			"down",
			"right"
		],
		"aliases": ["@tui.square-arrow-down-right", "@tui.square-arrow-down-right-filled"],
		"filled": true,
		"filledName": "square-arrow-down-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-arrow-left",
		"tuiName": "@tui.square-arrow-left",
		"category": "layout",
		"keywords": [
			"square",
			"arrow",
			"left"
		],
		"aliases": ["@tui.square-arrow-left", "@tui.square-arrow-left-filled"],
		"filled": true,
		"filledName": "square-arrow-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-arrow-out-down-left",
		"tuiName": "@tui.square-arrow-out-down-left",
		"category": "layout",
		"keywords": [
			"square",
			"arrow",
			"out",
			"down",
			"left"
		],
		"aliases": ["@tui.square-arrow-out-down-left", "@tui.square-arrow-out-down-left-filled"],
		"filled": true,
		"filledName": "square-arrow-out-down-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-arrow-out-down-right",
		"tuiName": "@tui.square-arrow-out-down-right",
		"category": "layout",
		"keywords": [
			"square",
			"arrow",
			"out",
			"down",
			"right"
		],
		"aliases": ["@tui.square-arrow-out-down-right", "@tui.square-arrow-out-down-right-filled"],
		"filled": true,
		"filledName": "square-arrow-out-down-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-arrow-out-up-left",
		"tuiName": "@tui.square-arrow-out-up-left",
		"category": "layout",
		"keywords": [
			"square",
			"arrow",
			"out",
			"up",
			"left"
		],
		"aliases": ["@tui.square-arrow-out-up-left", "@tui.square-arrow-out-up-left-filled"],
		"filled": true,
		"filledName": "square-arrow-out-up-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-arrow-out-up-right",
		"tuiName": "@tui.square-arrow-out-up-right",
		"category": "layout",
		"keywords": [
			"square",
			"arrow",
			"out",
			"up",
			"right"
		],
		"aliases": ["@tui.square-arrow-out-up-right", "@tui.square-arrow-out-up-right-filled"],
		"filled": true,
		"filledName": "square-arrow-out-up-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-arrow-right",
		"tuiName": "@tui.square-arrow-right",
		"category": "layout",
		"keywords": [
			"square",
			"arrow",
			"right"
		],
		"aliases": ["@tui.square-arrow-right", "@tui.square-arrow-right-filled"],
		"filled": true,
		"filledName": "square-arrow-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-arrow-right-enter",
		"tuiName": "@tui.square-arrow-right-enter",
		"category": "layout",
		"keywords": [
			"square",
			"arrow",
			"right",
			"enter"
		],
		"aliases": ["@tui.square-arrow-right-enter", "@tui.square-arrow-right-enter-filled"],
		"filled": true,
		"filledName": "square-arrow-right-enter-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-arrow-right-exit",
		"tuiName": "@tui.square-arrow-right-exit",
		"category": "layout",
		"keywords": [
			"square",
			"arrow",
			"right",
			"exit"
		],
		"aliases": ["@tui.square-arrow-right-exit", "@tui.square-arrow-right-exit-filled"],
		"filled": true,
		"filledName": "square-arrow-right-exit-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-arrow-up",
		"tuiName": "@tui.square-arrow-up",
		"category": "layout",
		"keywords": [
			"square",
			"arrow",
			"up"
		],
		"aliases": ["@tui.square-arrow-up", "@tui.square-arrow-up-filled"],
		"filled": true,
		"filledName": "square-arrow-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-arrow-up-left",
		"tuiName": "@tui.square-arrow-up-left",
		"category": "layout",
		"keywords": [
			"square",
			"arrow",
			"up",
			"left"
		],
		"aliases": ["@tui.square-arrow-up-left", "@tui.square-arrow-up-left-filled"],
		"filled": true,
		"filledName": "square-arrow-up-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-arrow-up-right",
		"tuiName": "@tui.square-arrow-up-right",
		"category": "layout",
		"keywords": [
			"square",
			"arrow",
			"up",
			"right"
		],
		"aliases": ["@tui.square-arrow-up-right", "@tui.square-arrow-up-right-filled"],
		"filled": true,
		"filledName": "square-arrow-up-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-asterisk",
		"tuiName": "@tui.square-asterisk",
		"category": "layout",
		"keywords": ["square", "asterisk"],
		"aliases": ["@tui.square-asterisk", "@tui.square-asterisk-filled"],
		"filled": true,
		"filledName": "square-asterisk-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-bookmark",
		"tuiName": "@tui.square-bookmark",
		"category": "layout",
		"keywords": ["square", "bookmark"],
		"aliases": ["@tui.square-bookmark", "@tui.square-bookmark-filled"],
		"filled": true,
		"filledName": "square-bookmark-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-bottom-dashed-scissors",
		"tuiName": "@tui.square-bottom-dashed-scissors",
		"category": "layout",
		"keywords": [
			"square",
			"bottom",
			"dashed",
			"scissors"
		],
		"aliases": ["@tui.square-bottom-dashed-scissors", "@tui.square-bottom-dashed-scissors-filled"],
		"filled": true,
		"filledName": "square-bottom-dashed-scissors-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-centerline-dashed-horizontal",
		"tuiName": "@tui.square-centerline-dashed-horizontal",
		"category": "layout",
		"keywords": [
			"square",
			"centerline",
			"dashed",
			"horizontal"
		],
		"aliases": ["@tui.square-centerline-dashed-horizontal", "@tui.square-centerline-dashed-horizontal-filled"],
		"filled": true,
		"filledName": "square-centerline-dashed-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-centerline-dashed-vertical",
		"tuiName": "@tui.square-centerline-dashed-vertical",
		"category": "layout",
		"keywords": [
			"square",
			"centerline",
			"dashed",
			"vertical"
		],
		"aliases": ["@tui.square-centerline-dashed-vertical", "@tui.square-centerline-dashed-vertical-filled"],
		"filled": true,
		"filledName": "square-centerline-dashed-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-chart-gantt",
		"tuiName": "@tui.square-chart-gantt",
		"category": "layout",
		"keywords": [
			"square",
			"chart",
			"gantt"
		],
		"aliases": ["@tui.square-chart-gantt", "@tui.square-chart-gantt-filled"],
		"filled": true,
		"filledName": "square-chart-gantt-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-check",
		"tuiName": "@tui.square-check",
		"category": "layout",
		"keywords": ["square", "check"],
		"aliases": ["@tui.square-check", "@tui.square-check-filled"],
		"filled": true,
		"filledName": "square-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-check-big",
		"tuiName": "@tui.square-check-big",
		"category": "layout",
		"keywords": [
			"square",
			"check",
			"big"
		],
		"aliases": ["@tui.square-check-big", "@tui.square-check-big-filled"],
		"filled": true,
		"filledName": "square-check-big-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-chevron-down",
		"tuiName": "@tui.square-chevron-down",
		"category": "layout",
		"keywords": [
			"square",
			"chevron",
			"down"
		],
		"aliases": ["@tui.square-chevron-down", "@tui.square-chevron-down-filled"],
		"filled": true,
		"filledName": "square-chevron-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-chevron-left",
		"tuiName": "@tui.square-chevron-left",
		"category": "layout",
		"keywords": [
			"square",
			"chevron",
			"left"
		],
		"aliases": ["@tui.square-chevron-left", "@tui.square-chevron-left-filled"],
		"filled": true,
		"filledName": "square-chevron-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-chevron-right",
		"tuiName": "@tui.square-chevron-right",
		"category": "layout",
		"keywords": [
			"square",
			"chevron",
			"right"
		],
		"aliases": ["@tui.square-chevron-right", "@tui.square-chevron-right-filled"],
		"filled": true,
		"filledName": "square-chevron-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-chevron-up",
		"tuiName": "@tui.square-chevron-up",
		"category": "layout",
		"keywords": [
			"square",
			"chevron",
			"up"
		],
		"aliases": ["@tui.square-chevron-up", "@tui.square-chevron-up-filled"],
		"filled": true,
		"filledName": "square-chevron-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-code",
		"tuiName": "@tui.square-code",
		"category": "layout",
		"keywords": ["square", "code"],
		"aliases": ["@tui.square-code", "@tui.square-code-filled"],
		"filled": true,
		"filledName": "square-code-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-dashed",
		"tuiName": "@tui.square-dashed",
		"category": "layout",
		"keywords": ["square", "dashed"],
		"aliases": ["@tui.square-dashed", "@tui.square-dashed-filled"],
		"filled": true,
		"filledName": "square-dashed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-dashed-bottom",
		"tuiName": "@tui.square-dashed-bottom",
		"category": "layout",
		"keywords": [
			"square",
			"dashed",
			"bottom"
		],
		"aliases": ["@tui.square-dashed-bottom", "@tui.square-dashed-bottom-filled"],
		"filled": true,
		"filledName": "square-dashed-bottom-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-dashed-bottom-code",
		"tuiName": "@tui.square-dashed-bottom-code",
		"category": "layout",
		"keywords": [
			"square",
			"dashed",
			"bottom",
			"code"
		],
		"aliases": ["@tui.square-dashed-bottom-code", "@tui.square-dashed-bottom-code-filled"],
		"filled": true,
		"filledName": "square-dashed-bottom-code-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-dashed-kanban",
		"tuiName": "@tui.square-dashed-kanban",
		"category": "layout",
		"keywords": [
			"square",
			"dashed",
			"kanban"
		],
		"aliases": ["@tui.square-dashed-kanban", "@tui.square-dashed-kanban-filled"],
		"filled": true,
		"filledName": "square-dashed-kanban-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-dashed-mouse-pointer",
		"tuiName": "@tui.square-dashed-mouse-pointer",
		"category": "layout",
		"keywords": [
			"square",
			"dashed",
			"mouse",
			"pointer"
		],
		"aliases": ["@tui.square-dashed-mouse-pointer", "@tui.square-dashed-mouse-pointer-filled"],
		"filled": true,
		"filledName": "square-dashed-mouse-pointer-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-dashed-plus",
		"tuiName": "@tui.square-dashed-plus",
		"category": "layout",
		"keywords": [
			"square",
			"dashed",
			"plus"
		],
		"aliases": ["@tui.square-dashed-plus", "@tui.square-dashed-plus-filled"],
		"filled": true,
		"filledName": "square-dashed-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-dashed-text",
		"tuiName": "@tui.square-dashed-text",
		"category": "layout",
		"keywords": [
			"square",
			"dashed",
			"text"
		],
		"aliases": ["@tui.square-dashed-text", "@tui.square-dashed-text-filled"],
		"filled": true,
		"filledName": "square-dashed-text-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-dashed-top-solid",
		"tuiName": "@tui.square-dashed-top-solid",
		"category": "layout",
		"keywords": [
			"square",
			"dashed",
			"top",
			"solid"
		],
		"aliases": ["@tui.square-dashed-top-solid", "@tui.square-dashed-top-solid-filled"],
		"filled": true,
		"filledName": "square-dashed-top-solid-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-dashed-x",
		"tuiName": "@tui.square-dashed-x",
		"category": "layout",
		"keywords": [
			"square",
			"dashed",
			"x"
		],
		"aliases": ["@tui.square-dashed-x", "@tui.square-dashed-x-filled"],
		"filled": true,
		"filledName": "square-dashed-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-dashed-x-corner",
		"tuiName": "@tui.square-dashed-x-corner",
		"category": "layout",
		"keywords": [
			"square",
			"dashed",
			"x",
			"corner"
		],
		"aliases": ["@tui.square-dashed-x-corner", "@tui.square-dashed-x-corner-filled"],
		"filled": true,
		"filledName": "square-dashed-x-corner-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-dimensions",
		"tuiName": "@tui.square-dimensions",
		"category": "layout",
		"keywords": ["square", "dimensions"],
		"aliases": ["@tui.square-dimensions", "@tui.square-dimensions-filled"],
		"filled": true,
		"filledName": "square-dimensions-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-divide",
		"tuiName": "@tui.square-divide",
		"category": "layout",
		"keywords": ["square", "divide"],
		"aliases": ["@tui.square-divide", "@tui.square-divide-filled"],
		"filled": true,
		"filledName": "square-divide-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-dot",
		"tuiName": "@tui.square-dot",
		"category": "layout",
		"keywords": ["square", "dot"],
		"aliases": ["@tui.square-dot", "@tui.square-dot-filled"],
		"filled": true,
		"filledName": "square-dot-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-equal",
		"tuiName": "@tui.square-equal",
		"category": "layout",
		"keywords": ["square", "equal"],
		"aliases": ["@tui.square-equal", "@tui.square-equal-filled"],
		"filled": true,
		"filledName": "square-equal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-exclamation-point",
		"tuiName": "@tui.square-exclamation-point",
		"category": "layout",
		"keywords": [
			"square",
			"exclamation",
			"point"
		],
		"aliases": ["@tui.square-exclamation-point", "@tui.square-exclamation-point-filled"],
		"filled": true,
		"filledName": "square-exclamation-point-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-function",
		"tuiName": "@tui.square-function",
		"category": "layout",
		"keywords": ["square", "function"],
		"aliases": ["@tui.square-function", "@tui.square-function-filled"],
		"filled": true,
		"filledName": "square-function-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-gantt-chart",
		"tuiName": "@tui.square-gantt-chart",
		"category": "layout",
		"keywords": [
			"square",
			"gantt",
			"chart"
		],
		"aliases": ["@tui.square-gantt-chart", "@tui.square-gantt-chart-filled"],
		"filled": true,
		"filledName": "square-gantt-chart-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-kanban",
		"tuiName": "@tui.square-kanban",
		"category": "layout",
		"keywords": ["square", "kanban"],
		"aliases": ["@tui.square-kanban", "@tui.square-kanban-filled"],
		"filled": true,
		"filledName": "square-kanban-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-library",
		"tuiName": "@tui.square-library",
		"category": "layout",
		"keywords": ["square", "library"],
		"aliases": ["@tui.square-library", "@tui.square-library-filled"],
		"filled": true,
		"filledName": "square-library-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-m",
		"tuiName": "@tui.square-m",
		"category": "layout",
		"keywords": ["square", "m"],
		"aliases": ["@tui.square-m", "@tui.square-m-filled"],
		"filled": true,
		"filledName": "square-m-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-menu",
		"tuiName": "@tui.square-menu",
		"category": "layout",
		"keywords": ["square", "menu"],
		"aliases": ["@tui.square-menu", "@tui.square-menu-filled"],
		"filled": true,
		"filledName": "square-menu-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-minus",
		"tuiName": "@tui.square-minus",
		"category": "layout",
		"keywords": ["square", "minus"],
		"aliases": ["@tui.square-minus", "@tui.square-minus-filled"],
		"filled": true,
		"filledName": "square-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-mouse-pointer",
		"tuiName": "@tui.square-mouse-pointer",
		"category": "layout",
		"keywords": [
			"square",
			"mouse",
			"pointer"
		],
		"aliases": ["@tui.square-mouse-pointer", "@tui.square-mouse-pointer-filled"],
		"filled": true,
		"filledName": "square-mouse-pointer-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-off",
		"tuiName": "@tui.square-off",
		"category": "layout",
		"keywords": ["square", "off"],
		"aliases": ["@tui.square-off", "@tui.square-off-filled"],
		"filled": true,
		"filledName": "square-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-parking",
		"tuiName": "@tui.square-parking",
		"category": "layout",
		"keywords": ["square", "parking"],
		"aliases": ["@tui.square-parking", "@tui.square-parking-filled"],
		"filled": true,
		"filledName": "square-parking-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-parking-off",
		"tuiName": "@tui.square-parking-off",
		"category": "layout",
		"keywords": [
			"square",
			"parking",
			"off"
		],
		"aliases": ["@tui.square-parking-off", "@tui.square-parking-off-filled"],
		"filled": true,
		"filledName": "square-parking-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-pause",
		"tuiName": "@tui.square-pause",
		"category": "layout",
		"keywords": ["square", "pause"],
		"aliases": ["@tui.square-pause", "@tui.square-pause-filled"],
		"filled": true,
		"filledName": "square-pause-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-pen",
		"tuiName": "@tui.square-pen",
		"category": "layout",
		"keywords": ["square", "pen"],
		"aliases": ["@tui.square-pen", "@tui.square-pen-filled"],
		"filled": true,
		"filledName": "square-pen-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-percent",
		"tuiName": "@tui.square-percent",
		"category": "layout",
		"keywords": ["square", "percent"],
		"aliases": ["@tui.square-percent", "@tui.square-percent-filled"],
		"filled": true,
		"filledName": "square-percent-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-pi",
		"tuiName": "@tui.square-pi",
		"category": "layout",
		"keywords": ["square", "pi"],
		"aliases": ["@tui.square-pi", "@tui.square-pi-filled"],
		"filled": true,
		"filledName": "square-pi-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-pilcrow",
		"tuiName": "@tui.square-pilcrow",
		"category": "layout",
		"keywords": ["square", "pilcrow"],
		"aliases": ["@tui.square-pilcrow", "@tui.square-pilcrow-filled"],
		"filled": true,
		"filledName": "square-pilcrow-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-play",
		"tuiName": "@tui.square-play",
		"category": "layout",
		"keywords": ["square", "play"],
		"aliases": ["@tui.square-play", "@tui.square-play-filled"],
		"filled": true,
		"filledName": "square-play-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-plus",
		"tuiName": "@tui.square-plus",
		"category": "layout",
		"keywords": ["square", "plus"],
		"aliases": ["@tui.square-plus", "@tui.square-plus-filled"],
		"filled": true,
		"filledName": "square-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-power",
		"tuiName": "@tui.square-power",
		"category": "layout",
		"keywords": ["square", "power"],
		"aliases": ["@tui.square-power", "@tui.square-power-filled"],
		"filled": true,
		"filledName": "square-power-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-radical",
		"tuiName": "@tui.square-radical",
		"category": "layout",
		"keywords": ["square", "radical"],
		"aliases": ["@tui.square-radical", "@tui.square-radical-filled"],
		"filled": true,
		"filledName": "square-radical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-round-corner",
		"tuiName": "@tui.square-round-corner",
		"category": "layout",
		"keywords": [
			"square",
			"round",
			"corner"
		],
		"aliases": ["@tui.square-round-corner", "@tui.square-round-corner-filled"],
		"filled": true,
		"filledName": "square-round-corner-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-scissors",
		"tuiName": "@tui.square-scissors",
		"category": "layout",
		"keywords": ["square", "scissors"],
		"aliases": ["@tui.square-scissors", "@tui.square-scissors-filled"],
		"filled": true,
		"filledName": "square-scissors-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-sigma",
		"tuiName": "@tui.square-sigma",
		"category": "layout",
		"keywords": ["square", "sigma"],
		"aliases": ["@tui.square-sigma", "@tui.square-sigma-filled"],
		"filled": true,
		"filledName": "square-sigma-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-slash",
		"tuiName": "@tui.square-slash",
		"category": "layout",
		"keywords": ["square", "slash"],
		"aliases": ["@tui.square-slash", "@tui.square-slash-filled"],
		"filled": true,
		"filledName": "square-slash-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-sparkles",
		"tuiName": "@tui.square-sparkles",
		"category": "layout",
		"keywords": ["square", "sparkles"],
		"aliases": ["@tui.square-sparkles", "@tui.square-sparkles-filled"],
		"filled": true,
		"filledName": "square-sparkles-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-split-horizontal",
		"tuiName": "@tui.square-split-horizontal",
		"category": "layout",
		"keywords": [
			"square",
			"split",
			"horizontal"
		],
		"aliases": ["@tui.square-split-horizontal", "@tui.square-split-horizontal-filled"],
		"filled": true,
		"filledName": "square-split-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-split-vertical",
		"tuiName": "@tui.square-split-vertical",
		"category": "layout",
		"keywords": [
			"square",
			"split",
			"vertical"
		],
		"aliases": ["@tui.square-split-vertical", "@tui.square-split-vertical-filled"],
		"filled": true,
		"filledName": "square-split-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-square",
		"tuiName": "@tui.square-square",
		"category": "layout",
		"keywords": ["square", "square"],
		"aliases": ["@tui.square-square", "@tui.square-square-filled"],
		"filled": true,
		"filledName": "square-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-stack",
		"tuiName": "@tui.square-stack",
		"category": "layout",
		"keywords": ["square", "stack"],
		"aliases": ["@tui.square-stack", "@tui.square-stack-filled"],
		"filled": true,
		"filledName": "square-stack-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-star",
		"tuiName": "@tui.square-star",
		"category": "layout",
		"keywords": ["square", "star"],
		"aliases": ["@tui.square-star", "@tui.square-star-filled"],
		"filled": true,
		"filledName": "square-star-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-stop",
		"tuiName": "@tui.square-stop",
		"category": "layout",
		"keywords": ["square", "stop"],
		"aliases": ["@tui.square-stop", "@tui.square-stop-filled"],
		"filled": true,
		"filledName": "square-stop-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-terminal",
		"tuiName": "@tui.square-terminal",
		"category": "layout",
		"keywords": ["square", "terminal"],
		"aliases": ["@tui.square-terminal", "@tui.square-terminal-filled"],
		"filled": true,
		"filledName": "square-terminal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-text",
		"tuiName": "@tui.square-text",
		"category": "layout",
		"keywords": ["square", "text"],
		"aliases": ["@tui.square-text", "@tui.square-text-filled"],
		"filled": true,
		"filledName": "square-text-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-user",
		"tuiName": "@tui.square-user",
		"category": "layout",
		"keywords": ["square", "user"],
		"aliases": ["@tui.square-user", "@tui.square-user-filled"],
		"filled": true,
		"filledName": "square-user-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-user-round",
		"tuiName": "@tui.square-user-round",
		"category": "layout",
		"keywords": [
			"square",
			"user",
			"round"
		],
		"aliases": ["@tui.square-user-round", "@tui.square-user-round-filled"],
		"filled": true,
		"filledName": "square-user-round-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "square-x",
		"tuiName": "@tui.square-x",
		"category": "layout",
		"keywords": ["square", "x"],
		"aliases": ["@tui.square-x", "@tui.square-x-filled"],
		"filled": true,
		"filledName": "square-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "squares-exclude",
		"tuiName": "@tui.squares-exclude",
		"category": "layout",
		"keywords": ["squares", "exclude"],
		"aliases": ["@tui.squares-exclude", "@tui.squares-exclude-filled"],
		"filled": true,
		"filledName": "squares-exclude-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "squares-intersect",
		"tuiName": "@tui.squares-intersect",
		"category": "layout",
		"keywords": ["squares", "intersect"],
		"aliases": ["@tui.squares-intersect", "@tui.squares-intersect-filled"],
		"filled": true,
		"filledName": "squares-intersect-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "squares-subtract",
		"tuiName": "@tui.squares-subtract",
		"category": "layout",
		"keywords": ["squares", "subtract"],
		"aliases": ["@tui.squares-subtract", "@tui.squares-subtract-filled"],
		"filled": true,
		"filledName": "squares-subtract-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "squares-unite",
		"tuiName": "@tui.squares-unite",
		"category": "layout",
		"keywords": ["squares", "unite"],
		"aliases": ["@tui.squares-unite", "@tui.squares-unite-filled"],
		"filled": true,
		"filledName": "squares-unite-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "squircle",
		"tuiName": "@tui.squircle",
		"category": "custom",
		"keywords": ["squircle"],
		"aliases": ["@tui.squircle", "@tui.squircle-filled"],
		"filled": true,
		"filledName": "squircle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "squircle-dashed",
		"tuiName": "@tui.squircle-dashed",
		"category": "custom",
		"keywords": ["squircle", "dashed"],
		"aliases": ["@tui.squircle-dashed", "@tui.squircle-dashed-filled"],
		"filled": true,
		"filledName": "squircle-dashed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "squirrel",
		"tuiName": "@tui.squirrel",
		"category": "custom",
		"keywords": ["squirrel"],
		"aliases": ["@tui.squirrel", "@tui.squirrel-filled"],
		"filled": true,
		"filledName": "squirrel-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "stamp",
		"tuiName": "@tui.stamp",
		"category": "custom",
		"keywords": ["stamp"],
		"aliases": ["@tui.stamp", "@tui.stamp-filled"],
		"filled": true,
		"filledName": "stamp-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "star",
		"tuiName": "@tui.star",
		"category": "status-feedback",
		"keywords": ["star"],
		"aliases": ["@tui.star", "@tui.star-filled"],
		"filled": true,
		"filledName": "star-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "star-check",
		"tuiName": "@tui.star-check",
		"category": "status-feedback",
		"keywords": ["star", "check"],
		"aliases": ["@tui.star-check", "@tui.star-check-filled"],
		"filled": true,
		"filledName": "star-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "star-half",
		"tuiName": "@tui.star-half",
		"category": "status-feedback",
		"keywords": ["star", "half"],
		"aliases": ["@tui.star-half", "@tui.star-half-filled"],
		"filled": true,
		"filledName": "star-half-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "star-minus",
		"tuiName": "@tui.star-minus",
		"category": "status-feedback",
		"keywords": ["star", "minus"],
		"aliases": ["@tui.star-minus", "@tui.star-minus-filled"],
		"filled": true,
		"filledName": "star-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "star-off",
		"tuiName": "@tui.star-off",
		"category": "status-feedback",
		"keywords": ["star", "off"],
		"aliases": ["@tui.star-off", "@tui.star-off-filled"],
		"filled": true,
		"filledName": "star-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "star-plus",
		"tuiName": "@tui.star-plus",
		"category": "status-feedback",
		"keywords": ["star", "plus"],
		"aliases": ["@tui.star-plus", "@tui.star-plus-filled"],
		"filled": true,
		"filledName": "star-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "star-x",
		"tuiName": "@tui.star-x",
		"category": "status-feedback",
		"keywords": ["star", "x"],
		"aliases": ["@tui.star-x", "@tui.star-x-filled"],
		"filled": true,
		"filledName": "star-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "stars",
		"tuiName": "@tui.stars",
		"category": "status-feedback",
		"keywords": ["stars"],
		"aliases": ["@tui.stars", "@tui.stars-filled"],
		"filled": true,
		"filledName": "stars-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "step-back",
		"tuiName": "@tui.step-back",
		"category": "custom",
		"keywords": ["step", "back"],
		"aliases": ["@tui.step-back", "@tui.step-back-filled"],
		"filled": true,
		"filledName": "step-back-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "step-forward",
		"tuiName": "@tui.step-forward",
		"category": "custom",
		"keywords": ["step", "forward"],
		"aliases": ["@tui.step-forward", "@tui.step-forward-filled"],
		"filled": true,
		"filledName": "step-forward-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "stethoscope",
		"tuiName": "@tui.stethoscope",
		"category": "custom",
		"keywords": ["stethoscope"],
		"aliases": ["@tui.stethoscope", "@tui.stethoscope-filled"],
		"filled": true,
		"filledName": "stethoscope-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sticker",
		"tuiName": "@tui.sticker",
		"category": "custom",
		"keywords": ["sticker"],
		"aliases": ["@tui.sticker", "@tui.sticker-filled"],
		"filled": true,
		"filledName": "sticker-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sticky-note",
		"tuiName": "@tui.sticky-note",
		"category": "custom",
		"keywords": ["sticky", "note"],
		"aliases": ["@tui.sticky-note", "@tui.sticky-note-filled"],
		"filled": true,
		"filledName": "sticky-note-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sticky-note-check",
		"tuiName": "@tui.sticky-note-check",
		"category": "custom",
		"keywords": [
			"sticky",
			"note",
			"check"
		],
		"aliases": ["@tui.sticky-note-check", "@tui.sticky-note-check-filled"],
		"filled": true,
		"filledName": "sticky-note-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sticky-note-minus",
		"tuiName": "@tui.sticky-note-minus",
		"category": "custom",
		"keywords": [
			"sticky",
			"note",
			"minus"
		],
		"aliases": ["@tui.sticky-note-minus", "@tui.sticky-note-minus-filled"],
		"filled": true,
		"filledName": "sticky-note-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sticky-note-off",
		"tuiName": "@tui.sticky-note-off",
		"category": "custom",
		"keywords": [
			"sticky",
			"note",
			"off"
		],
		"aliases": ["@tui.sticky-note-off", "@tui.sticky-note-off-filled"],
		"filled": true,
		"filledName": "sticky-note-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sticky-note-plus",
		"tuiName": "@tui.sticky-note-plus",
		"category": "custom",
		"keywords": [
			"sticky",
			"note",
			"plus"
		],
		"aliases": ["@tui.sticky-note-plus", "@tui.sticky-note-plus-filled"],
		"filled": true,
		"filledName": "sticky-note-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sticky-note-x",
		"tuiName": "@tui.sticky-note-x",
		"category": "custom",
		"keywords": [
			"sticky",
			"note",
			"x"
		],
		"aliases": ["@tui.sticky-note-x", "@tui.sticky-note-x-filled"],
		"filled": true,
		"filledName": "sticky-note-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sticky-notes",
		"tuiName": "@tui.sticky-notes",
		"category": "custom",
		"keywords": ["sticky", "notes"],
		"aliases": ["@tui.sticky-notes", "@tui.sticky-notes-filled"],
		"filled": true,
		"filledName": "sticky-notes-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "stone",
		"tuiName": "@tui.stone",
		"category": "custom",
		"keywords": ["stone"],
		"aliases": ["@tui.stone", "@tui.stone-filled"],
		"filled": true,
		"filledName": "stone-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "stop-circle",
		"tuiName": "@tui.stop-circle",
		"category": "custom",
		"keywords": ["stop", "circle"],
		"aliases": ["@tui.stop-circle", "@tui.stop-circle-filled"],
		"filled": true,
		"filledName": "stop-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "store",
		"tuiName": "@tui.store",
		"category": "commerce",
		"keywords": ["store"],
		"aliases": ["@tui.store", "@tui.store-filled"],
		"filled": true,
		"filledName": "store-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "stretch-horizontal",
		"tuiName": "@tui.stretch-horizontal",
		"category": "custom",
		"keywords": ["stretch", "horizontal"],
		"aliases": ["@tui.stretch-horizontal", "@tui.stretch-horizontal-filled"],
		"filled": true,
		"filledName": "stretch-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "stretch-vertical",
		"tuiName": "@tui.stretch-vertical",
		"category": "custom",
		"keywords": ["stretch", "vertical"],
		"aliases": ["@tui.stretch-vertical", "@tui.stretch-vertical-filled"],
		"filled": true,
		"filledName": "stretch-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "strikethrough",
		"tuiName": "@tui.strikethrough",
		"category": "editing",
		"keywords": ["strikethrough"],
		"aliases": ["@tui.strikethrough", "@tui.strikethrough-filled"],
		"filled": true,
		"filledName": "strikethrough-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "subscript",
		"tuiName": "@tui.subscript",
		"category": "custom",
		"keywords": ["subscript"],
		"aliases": ["@tui.subscript", "@tui.subscript-filled"],
		"filled": true,
		"filledName": "subscript-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "subtitles",
		"tuiName": "@tui.subtitles",
		"category": "custom",
		"keywords": ["subtitles"],
		"aliases": ["@tui.subtitles", "@tui.subtitles-filled"],
		"filled": true,
		"filledName": "subtitles-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "summary",
		"tuiName": "@tui.summary",
		"category": "custom",
		"keywords": ["summary"],
		"aliases": ["@tui.summary", "@tui.summary-filled"],
		"filled": true,
		"filledName": "summary-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sun",
		"tuiName": "@tui.sun",
		"category": "calendar-time",
		"keywords": ["sun"],
		"aliases": ["@tui.sun", "@tui.sun-filled"],
		"filled": true,
		"filledName": "sun-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sun-dim",
		"tuiName": "@tui.sun-dim",
		"category": "calendar-time",
		"keywords": ["sun", "dim"],
		"aliases": ["@tui.sun-dim", "@tui.sun-dim-filled"],
		"filled": true,
		"filledName": "sun-dim-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sun-medium",
		"tuiName": "@tui.sun-medium",
		"category": "calendar-time",
		"keywords": ["sun", "medium"],
		"aliases": ["@tui.sun-medium", "@tui.sun-medium-filled"],
		"filled": true,
		"filledName": "sun-medium-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sun-moon",
		"tuiName": "@tui.sun-moon",
		"category": "calendar-time",
		"keywords": ["sun", "moon"],
		"aliases": ["@tui.sun-moon", "@tui.sun-moon-filled"],
		"filled": true,
		"filledName": "sun-moon-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sun-snow",
		"tuiName": "@tui.sun-snow",
		"category": "calendar-time",
		"keywords": ["sun", "snow"],
		"aliases": ["@tui.sun-snow", "@tui.sun-snow-filled"],
		"filled": true,
		"filledName": "sun-snow-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sunrise",
		"tuiName": "@tui.sunrise",
		"category": "calendar-time",
		"keywords": ["sunrise"],
		"aliases": ["@tui.sunrise", "@tui.sunrise-filled"],
		"filled": true,
		"filledName": "sunrise-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sunset",
		"tuiName": "@tui.sunset",
		"category": "calendar-time",
		"keywords": ["sunset"],
		"aliases": ["@tui.sunset", "@tui.sunset-filled"],
		"filled": true,
		"filledName": "sunset-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "superscript",
		"tuiName": "@tui.superscript",
		"category": "custom",
		"keywords": ["superscript"],
		"aliases": ["@tui.superscript", "@tui.superscript-filled"],
		"filled": true,
		"filledName": "superscript-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "swatch-book",
		"tuiName": "@tui.swatch-book",
		"category": "custom",
		"keywords": ["swatch", "book"],
		"aliases": ["@tui.swatch-book", "@tui.swatch-book-filled"],
		"filled": true,
		"filledName": "swatch-book-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "swiss-franc",
		"tuiName": "@tui.swiss-franc",
		"category": "custom",
		"keywords": ["swiss", "franc"],
		"aliases": ["@tui.swiss-franc", "@tui.swiss-franc-filled"],
		"filled": true,
		"filledName": "swiss-franc-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "switch-camera",
		"tuiName": "@tui.switch-camera",
		"category": "custom",
		"keywords": ["switch", "camera"],
		"aliases": ["@tui.switch-camera", "@tui.switch-camera-filled"],
		"filled": true,
		"filledName": "switch-camera-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "sword",
		"tuiName": "@tui.sword",
		"category": "custom",
		"keywords": ["sword"],
		"aliases": ["@tui.sword", "@tui.sword-filled"],
		"filled": true,
		"filledName": "sword-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "swords",
		"tuiName": "@tui.swords",
		"category": "custom",
		"keywords": ["swords"],
		"aliases": ["@tui.swords", "@tui.swords-filled"],
		"filled": true,
		"filledName": "swords-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "syringe",
		"tuiName": "@tui.syringe",
		"category": "custom",
		"keywords": ["syringe"],
		"aliases": ["@tui.syringe", "@tui.syringe-filled"],
		"filled": true,
		"filledName": "syringe-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "table",
		"tuiName": "@tui.table",
		"category": "layout",
		"keywords": ["table"],
		"aliases": ["@tui.table", "@tui.table-filled"],
		"filled": true,
		"filledName": "table-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "table-2",
		"tuiName": "@tui.table-2",
		"category": "layout",
		"keywords": ["table", "2"],
		"aliases": ["@tui.table-2", "@tui.table-2-filled"],
		"filled": true,
		"filledName": "table-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "table-cells-merge",
		"tuiName": "@tui.table-cells-merge",
		"category": "layout",
		"keywords": [
			"table",
			"cells",
			"merge"
		],
		"aliases": ["@tui.table-cells-merge", "@tui.table-cells-merge-filled"],
		"filled": true,
		"filledName": "table-cells-merge-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "table-cells-split",
		"tuiName": "@tui.table-cells-split",
		"category": "layout",
		"keywords": [
			"table",
			"cells",
			"split"
		],
		"aliases": ["@tui.table-cells-split", "@tui.table-cells-split-filled"],
		"filled": true,
		"filledName": "table-cells-split-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "table-columns-split",
		"tuiName": "@tui.table-columns-split",
		"category": "layout",
		"keywords": [
			"table",
			"columns",
			"split"
		],
		"aliases": ["@tui.table-columns-split", "@tui.table-columns-split-filled"],
		"filled": true,
		"filledName": "table-columns-split-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "table-config",
		"tuiName": "@tui.table-config",
		"category": "layout",
		"keywords": ["table", "config"],
		"aliases": ["@tui.table-config", "@tui.table-config-filled"],
		"filled": true,
		"filledName": "table-config-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "table-of-contents",
		"tuiName": "@tui.table-of-contents",
		"category": "layout",
		"keywords": [
			"table",
			"of",
			"contents"
		],
		"aliases": ["@tui.table-of-contents", "@tui.table-of-contents-filled"],
		"filled": true,
		"filledName": "table-of-contents-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "table-properties",
		"tuiName": "@tui.table-properties",
		"category": "layout",
		"keywords": ["table", "properties"],
		"aliases": ["@tui.table-properties", "@tui.table-properties-filled"],
		"filled": true,
		"filledName": "table-properties-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "table-rows-split",
		"tuiName": "@tui.table-rows-split",
		"category": "layout",
		"keywords": [
			"table",
			"rows",
			"split"
		],
		"aliases": ["@tui.table-rows-split", "@tui.table-rows-split-filled"],
		"filled": true,
		"filledName": "table-rows-split-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tablet",
		"tuiName": "@tui.tablet",
		"category": "devices",
		"keywords": ["tablet"],
		"aliases": ["@tui.tablet", "@tui.tablet-filled"],
		"filled": true,
		"filledName": "tablet-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tablet-smartphone",
		"tuiName": "@tui.tablet-smartphone",
		"category": "devices",
		"keywords": ["tablet", "smartphone"],
		"aliases": ["@tui.tablet-smartphone", "@tui.tablet-smartphone-filled"],
		"filled": true,
		"filledName": "tablet-smartphone-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tablets",
		"tuiName": "@tui.tablets",
		"category": "devices",
		"keywords": ["tablets"],
		"aliases": ["@tui.tablets", "@tui.tablets-filled"],
		"filled": true,
		"filledName": "tablets-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tag",
		"tuiName": "@tui.tag",
		"category": "commerce",
		"keywords": ["tag"],
		"aliases": ["@tui.tag", "@tui.tag-filled"],
		"filled": true,
		"filledName": "tag-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tag-plus",
		"tuiName": "@tui.tag-plus",
		"category": "commerce",
		"keywords": ["tag", "plus"],
		"aliases": ["@tui.tag-plus", "@tui.tag-plus-filled"],
		"filled": true,
		"filledName": "tag-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tag-x",
		"tuiName": "@tui.tag-x",
		"category": "commerce",
		"keywords": ["tag", "x"],
		"aliases": ["@tui.tag-x", "@tui.tag-x-filled"],
		"filled": true,
		"filledName": "tag-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tags",
		"tuiName": "@tui.tags",
		"category": "commerce",
		"keywords": ["tags"],
		"aliases": ["@tui.tags", "@tui.tags-filled"],
		"filled": true,
		"filledName": "tags-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tally-1",
		"tuiName": "@tui.tally-1",
		"category": "custom",
		"keywords": ["tally", "1"],
		"aliases": ["@tui.tally-1", "@tui.tally-1-filled"],
		"filled": true,
		"filledName": "tally-1-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tally-2",
		"tuiName": "@tui.tally-2",
		"category": "custom",
		"keywords": ["tally", "2"],
		"aliases": ["@tui.tally-2", "@tui.tally-2-filled"],
		"filled": true,
		"filledName": "tally-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tally-3",
		"tuiName": "@tui.tally-3",
		"category": "custom",
		"keywords": ["tally", "3"],
		"aliases": ["@tui.tally-3", "@tui.tally-3-filled"],
		"filled": true,
		"filledName": "tally-3-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tally-4",
		"tuiName": "@tui.tally-4",
		"category": "custom",
		"keywords": ["tally", "4"],
		"aliases": ["@tui.tally-4", "@tui.tally-4-filled"],
		"filled": true,
		"filledName": "tally-4-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tally-5",
		"tuiName": "@tui.tally-5",
		"category": "custom",
		"keywords": ["tally", "5"],
		"aliases": ["@tui.tally-5", "@tui.tally-5-filled"],
		"filled": true,
		"filledName": "tally-5-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tangent",
		"tuiName": "@tui.tangent",
		"category": "custom",
		"keywords": ["tangent"],
		"aliases": ["@tui.tangent", "@tui.tangent-filled"],
		"filled": true,
		"filledName": "tangent-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "target",
		"tuiName": "@tui.target",
		"category": "custom",
		"keywords": ["target"],
		"aliases": ["@tui.target", "@tui.target-filled"],
		"filled": true,
		"filledName": "target-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "telescope",
		"tuiName": "@tui.telescope",
		"category": "custom",
		"keywords": ["telescope"],
		"aliases": ["@tui.telescope", "@tui.telescope-filled"],
		"filled": true,
		"filledName": "telescope-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tent",
		"tuiName": "@tui.tent",
		"category": "custom",
		"keywords": ["tent"],
		"aliases": ["@tui.tent", "@tui.tent-filled"],
		"filled": true,
		"filledName": "tent-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tent-tree",
		"tuiName": "@tui.tent-tree",
		"category": "custom",
		"keywords": ["tent", "tree"],
		"aliases": ["@tui.tent-tree", "@tui.tent-tree-filled"],
		"filled": true,
		"filledName": "tent-tree-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "terminal",
		"tuiName": "@tui.terminal",
		"category": "development",
		"keywords": ["terminal"],
		"aliases": ["@tui.terminal", "@tui.terminal-filled"],
		"filled": true,
		"filledName": "terminal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "terminal-square",
		"tuiName": "@tui.terminal-square",
		"category": "development",
		"keywords": ["terminal", "square"],
		"aliases": ["@tui.terminal-square", "@tui.terminal-square-filled"],
		"filled": true,
		"filledName": "terminal-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "test-tube",
		"tuiName": "@tui.test-tube",
		"category": "custom",
		"keywords": ["test", "tube"],
		"aliases": ["@tui.test-tube", "@tui.test-tube-filled"],
		"filled": true,
		"filledName": "test-tube-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "test-tube-2",
		"tuiName": "@tui.test-tube-2",
		"category": "custom",
		"keywords": [
			"test",
			"tube",
			"2"
		],
		"aliases": ["@tui.test-tube-2", "@tui.test-tube-2-filled"],
		"filled": true,
		"filledName": "test-tube-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "test-tube-diagonal",
		"tuiName": "@tui.test-tube-diagonal",
		"category": "custom",
		"keywords": [
			"test",
			"tube",
			"diagonal"
		],
		"aliases": ["@tui.test-tube-diagonal", "@tui.test-tube-diagonal-filled"],
		"filled": true,
		"filledName": "test-tube-diagonal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "test-tubes",
		"tuiName": "@tui.test-tubes",
		"category": "custom",
		"keywords": ["test", "tubes"],
		"aliases": ["@tui.test-tubes", "@tui.test-tubes-filled"],
		"filled": true,
		"filledName": "test-tubes-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "text",
		"tuiName": "@tui.text",
		"category": "editing",
		"keywords": ["text"],
		"aliases": ["@tui.text", "@tui.text-filled"],
		"filled": true,
		"filledName": "text-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "text-align-center",
		"tuiName": "@tui.text-align-center",
		"category": "editing",
		"keywords": [
			"text",
			"align",
			"center"
		],
		"aliases": ["@tui.text-align-center", "@tui.text-align-center-filled"],
		"filled": true,
		"filledName": "text-align-center-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "text-align-end",
		"tuiName": "@tui.text-align-end",
		"category": "editing",
		"keywords": [
			"text",
			"align",
			"end"
		],
		"aliases": ["@tui.text-align-end", "@tui.text-align-end-filled"],
		"filled": true,
		"filledName": "text-align-end-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "text-align-justify",
		"tuiName": "@tui.text-align-justify",
		"category": "editing",
		"keywords": [
			"text",
			"align",
			"justify"
		],
		"aliases": ["@tui.text-align-justify", "@tui.text-align-justify-filled"],
		"filled": true,
		"filledName": "text-align-justify-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "text-align-justify-center",
		"tuiName": "@tui.text-align-justify-center",
		"category": "editing",
		"keywords": [
			"text",
			"align",
			"justify",
			"center"
		],
		"aliases": ["@tui.text-align-justify-center", "@tui.text-align-justify-center-filled"],
		"filled": true,
		"filledName": "text-align-justify-center-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "text-align-justify-end",
		"tuiName": "@tui.text-align-justify-end",
		"category": "editing",
		"keywords": [
			"text",
			"align",
			"justify",
			"end"
		],
		"aliases": ["@tui.text-align-justify-end", "@tui.text-align-justify-end-filled"],
		"filled": true,
		"filledName": "text-align-justify-end-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "text-align-justify-start",
		"tuiName": "@tui.text-align-justify-start",
		"category": "editing",
		"keywords": [
			"text",
			"align",
			"justify",
			"start"
		],
		"aliases": ["@tui.text-align-justify-start", "@tui.text-align-justify-start-filled"],
		"filled": true,
		"filledName": "text-align-justify-start-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "text-align-start",
		"tuiName": "@tui.text-align-start",
		"category": "editing",
		"keywords": [
			"text",
			"align",
			"start"
		],
		"aliases": ["@tui.text-align-start", "@tui.text-align-start-filled"],
		"filled": true,
		"filledName": "text-align-start-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "text-cursor",
		"tuiName": "@tui.text-cursor",
		"category": "editing",
		"keywords": ["text", "cursor"],
		"aliases": ["@tui.text-cursor", "@tui.text-cursor-filled"],
		"filled": true,
		"filledName": "text-cursor-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "text-cursor-input",
		"tuiName": "@tui.text-cursor-input",
		"category": "editing",
		"keywords": [
			"text",
			"cursor",
			"input"
		],
		"aliases": ["@tui.text-cursor-input", "@tui.text-cursor-input-filled"],
		"filled": true,
		"filledName": "text-cursor-input-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "text-initial",
		"tuiName": "@tui.text-initial",
		"category": "editing",
		"keywords": ["text", "initial"],
		"aliases": ["@tui.text-initial", "@tui.text-initial-filled"],
		"filled": true,
		"filledName": "text-initial-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "text-quote",
		"tuiName": "@tui.text-quote",
		"category": "editing",
		"keywords": ["text", "quote"],
		"aliases": ["@tui.text-quote", "@tui.text-quote-filled"],
		"filled": true,
		"filledName": "text-quote-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "text-search",
		"tuiName": "@tui.text-search",
		"category": "editing",
		"keywords": ["text", "search"],
		"aliases": ["@tui.text-search", "@tui.text-search-filled"],
		"filled": true,
		"filledName": "text-search-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "text-select",
		"tuiName": "@tui.text-select",
		"category": "editing",
		"keywords": ["text", "select"],
		"aliases": ["@tui.text-select", "@tui.text-select-filled"],
		"filled": true,
		"filledName": "text-select-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "text-selection",
		"tuiName": "@tui.text-selection",
		"category": "editing",
		"keywords": ["text", "selection"],
		"aliases": ["@tui.text-selection", "@tui.text-selection-filled"],
		"filled": true,
		"filledName": "text-selection-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "text-wrap",
		"tuiName": "@tui.text-wrap",
		"category": "editing",
		"keywords": ["text", "wrap"],
		"aliases": ["@tui.text-wrap", "@tui.text-wrap-filled"],
		"filled": true,
		"filledName": "text-wrap-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "theater",
		"tuiName": "@tui.theater",
		"category": "custom",
		"keywords": ["theater"],
		"aliases": ["@tui.theater", "@tui.theater-filled"],
		"filled": true,
		"filledName": "theater-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "thermometer",
		"tuiName": "@tui.thermometer",
		"category": "custom",
		"keywords": ["thermometer"],
		"aliases": ["@tui.thermometer", "@tui.thermometer-filled"],
		"filled": true,
		"filledName": "thermometer-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "thermometer-snowflake",
		"tuiName": "@tui.thermometer-snowflake",
		"category": "custom",
		"keywords": ["thermometer", "snowflake"],
		"aliases": ["@tui.thermometer-snowflake", "@tui.thermometer-snowflake-filled"],
		"filled": true,
		"filledName": "thermometer-snowflake-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "thermometer-sun",
		"tuiName": "@tui.thermometer-sun",
		"category": "custom",
		"keywords": ["thermometer", "sun"],
		"aliases": ["@tui.thermometer-sun", "@tui.thermometer-sun-filled"],
		"filled": true,
		"filledName": "thermometer-sun-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "thumbs-down",
		"tuiName": "@tui.thumbs-down",
		"category": "status-feedback",
		"keywords": ["thumbs", "down"],
		"aliases": ["@tui.thumbs-down", "@tui.thumbs-down-filled"],
		"filled": true,
		"filledName": "thumbs-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "thumbs-up",
		"tuiName": "@tui.thumbs-up",
		"category": "status-feedback",
		"keywords": ["thumbs", "up"],
		"aliases": ["@tui.thumbs-up", "@tui.thumbs-up-filled"],
		"filled": true,
		"filledName": "thumbs-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tic-tac-toe",
		"tuiName": "@tui.tic-tac-toe",
		"category": "custom",
		"keywords": [
			"tic",
			"tac",
			"toe"
		],
		"aliases": ["@tui.tic-tac-toe", "@tui.tic-tac-toe-filled"],
		"filled": true,
		"filledName": "tic-tac-toe-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ticket",
		"tuiName": "@tui.ticket",
		"category": "commerce",
		"keywords": ["ticket"],
		"aliases": ["@tui.ticket", "@tui.ticket-filled"],
		"filled": true,
		"filledName": "ticket-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ticket-check",
		"tuiName": "@tui.ticket-check",
		"category": "commerce",
		"keywords": ["ticket", "check"],
		"aliases": ["@tui.ticket-check", "@tui.ticket-check-filled"],
		"filled": true,
		"filledName": "ticket-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ticket-minus",
		"tuiName": "@tui.ticket-minus",
		"category": "commerce",
		"keywords": ["ticket", "minus"],
		"aliases": ["@tui.ticket-minus", "@tui.ticket-minus-filled"],
		"filled": true,
		"filledName": "ticket-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ticket-percent",
		"tuiName": "@tui.ticket-percent",
		"category": "commerce",
		"keywords": ["ticket", "percent"],
		"aliases": ["@tui.ticket-percent", "@tui.ticket-percent-filled"],
		"filled": true,
		"filledName": "ticket-percent-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ticket-plus",
		"tuiName": "@tui.ticket-plus",
		"category": "commerce",
		"keywords": ["ticket", "plus"],
		"aliases": ["@tui.ticket-plus", "@tui.ticket-plus-filled"],
		"filled": true,
		"filledName": "ticket-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ticket-slash",
		"tuiName": "@tui.ticket-slash",
		"category": "commerce",
		"keywords": ["ticket", "slash"],
		"aliases": ["@tui.ticket-slash", "@tui.ticket-slash-filled"],
		"filled": true,
		"filledName": "ticket-slash-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ticket-x",
		"tuiName": "@tui.ticket-x",
		"category": "commerce",
		"keywords": ["ticket", "x"],
		"aliases": ["@tui.ticket-x", "@tui.ticket-x-filled"],
		"filled": true,
		"filledName": "ticket-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tickets",
		"tuiName": "@tui.tickets",
		"category": "commerce",
		"keywords": ["tickets"],
		"aliases": ["@tui.tickets", "@tui.tickets-filled"],
		"filled": true,
		"filledName": "tickets-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tickets-plane",
		"tuiName": "@tui.tickets-plane",
		"category": "commerce",
		"keywords": ["tickets", "plane"],
		"aliases": ["@tui.tickets-plane", "@tui.tickets-plane-filled"],
		"filled": true,
		"filledName": "tickets-plane-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "timeline",
		"tuiName": "@tui.timeline",
		"category": "custom",
		"keywords": ["timeline"],
		"aliases": ["@tui.timeline", "@tui.timeline-filled"],
		"filled": true,
		"filledName": "timeline-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "timer",
		"tuiName": "@tui.timer",
		"category": "calendar-time",
		"keywords": ["timer"],
		"aliases": ["@tui.timer", "@tui.timer-filled"],
		"filled": true,
		"filledName": "timer-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "timer-off",
		"tuiName": "@tui.timer-off",
		"category": "calendar-time",
		"keywords": ["timer", "off"],
		"aliases": ["@tui.timer-off", "@tui.timer-off-filled"],
		"filled": true,
		"filledName": "timer-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "timer-reset",
		"tuiName": "@tui.timer-reset",
		"category": "calendar-time",
		"keywords": ["timer", "reset"],
		"aliases": ["@tui.timer-reset", "@tui.timer-reset-filled"],
		"filled": true,
		"filledName": "timer-reset-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "toggle-left",
		"tuiName": "@tui.toggle-left",
		"category": "custom",
		"keywords": ["toggle", "left"],
		"aliases": ["@tui.toggle-left", "@tui.toggle-left-filled"],
		"filled": true,
		"filledName": "toggle-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "toggle-right",
		"tuiName": "@tui.toggle-right",
		"category": "custom",
		"keywords": ["toggle", "right"],
		"aliases": ["@tui.toggle-right", "@tui.toggle-right-filled"],
		"filled": true,
		"filledName": "toggle-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "toilet",
		"tuiName": "@tui.toilet",
		"category": "custom",
		"keywords": ["toilet"],
		"aliases": ["@tui.toilet", "@tui.toilet-filled"],
		"filled": true,
		"filledName": "toilet-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tool-case",
		"tuiName": "@tui.tool-case",
		"category": "actions",
		"keywords": ["tool", "case"],
		"aliases": ["@tui.tool-case", "@tui.tool-case-filled"],
		"filled": true,
		"filledName": "tool-case-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "toolbox",
		"tuiName": "@tui.toolbox",
		"category": "actions",
		"keywords": ["toolbox"],
		"aliases": ["@tui.toolbox", "@tui.toolbox-filled"],
		"filled": true,
		"filledName": "toolbox-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "toothbrush",
		"tuiName": "@tui.toothbrush",
		"category": "custom",
		"keywords": ["toothbrush"],
		"aliases": ["@tui.toothbrush", "@tui.toothbrush-filled"],
		"filled": true,
		"filledName": "toothbrush-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "toothbrush-sparkles",
		"tuiName": "@tui.toothbrush-sparkles",
		"category": "custom",
		"keywords": ["toothbrush", "sparkles"],
		"aliases": ["@tui.toothbrush-sparkles", "@tui.toothbrush-sparkles-filled"],
		"filled": true,
		"filledName": "toothbrush-sparkles-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tornado",
		"tuiName": "@tui.tornado",
		"category": "custom",
		"keywords": ["tornado"],
		"aliases": ["@tui.tornado", "@tui.tornado-filled"],
		"filled": true,
		"filledName": "tornado-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "torus",
		"tuiName": "@tui.torus",
		"category": "custom",
		"keywords": ["torus"],
		"aliases": ["@tui.torus", "@tui.torus-filled"],
		"filled": true,
		"filledName": "torus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "touchpad",
		"tuiName": "@tui.touchpad",
		"category": "custom",
		"keywords": ["touchpad"],
		"aliases": ["@tui.touchpad", "@tui.touchpad-filled"],
		"filled": true,
		"filledName": "touchpad-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "touchpad-off",
		"tuiName": "@tui.touchpad-off",
		"category": "custom",
		"keywords": ["touchpad", "off"],
		"aliases": ["@tui.touchpad-off", "@tui.touchpad-off-filled"],
		"filled": true,
		"filledName": "touchpad-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "towel-rack",
		"tuiName": "@tui.towel-rack",
		"category": "custom",
		"keywords": ["towel", "rack"],
		"aliases": ["@tui.towel-rack", "@tui.towel-rack-filled"],
		"filled": true,
		"filledName": "towel-rack-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tower-control",
		"tuiName": "@tui.tower-control",
		"category": "custom",
		"keywords": ["tower", "control"],
		"aliases": ["@tui.tower-control", "@tui.tower-control-filled"],
		"filled": true,
		"filledName": "tower-control-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "toy-brick",
		"tuiName": "@tui.toy-brick",
		"category": "custom",
		"keywords": ["toy", "brick"],
		"aliases": ["@tui.toy-brick", "@tui.toy-brick-filled"],
		"filled": true,
		"filledName": "toy-brick-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tractor",
		"tuiName": "@tui.tractor",
		"category": "custom",
		"keywords": ["tractor"],
		"aliases": ["@tui.tractor", "@tui.tractor-filled"],
		"filled": true,
		"filledName": "tractor-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "traffic-cone",
		"tuiName": "@tui.traffic-cone",
		"category": "custom",
		"keywords": ["traffic", "cone"],
		"aliases": ["@tui.traffic-cone", "@tui.traffic-cone-filled"],
		"filled": true,
		"filledName": "traffic-cone-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "trailer",
		"tuiName": "@tui.trailer",
		"category": "custom",
		"keywords": ["trailer"],
		"aliases": ["@tui.trailer", "@tui.trailer-filled"],
		"filled": true,
		"filledName": "trailer-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "train",
		"tuiName": "@tui.train",
		"category": "maps-location",
		"keywords": ["train"],
		"aliases": ["@tui.train", "@tui.train-filled"],
		"filled": true,
		"filledName": "train-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "train-front",
		"tuiName": "@tui.train-front",
		"category": "maps-location",
		"keywords": ["train", "front"],
		"aliases": ["@tui.train-front", "@tui.train-front-filled"],
		"filled": true,
		"filledName": "train-front-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "train-front-tunnel",
		"tuiName": "@tui.train-front-tunnel",
		"category": "maps-location",
		"keywords": [
			"train",
			"front",
			"tunnel"
		],
		"aliases": ["@tui.train-front-tunnel", "@tui.train-front-tunnel-filled"],
		"filled": true,
		"filledName": "train-front-tunnel-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "train-track",
		"tuiName": "@tui.train-track",
		"category": "maps-location",
		"keywords": ["train", "track"],
		"aliases": ["@tui.train-track", "@tui.train-track-filled"],
		"filled": true,
		"filledName": "train-track-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tram-front",
		"tuiName": "@tui.tram-front",
		"category": "custom",
		"keywords": ["tram", "front"],
		"aliases": ["@tui.tram-front", "@tui.tram-front-filled"],
		"filled": true,
		"filledName": "tram-front-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "transgender",
		"tuiName": "@tui.transgender",
		"category": "custom",
		"keywords": ["transgender"],
		"aliases": ["@tui.transgender", "@tui.transgender-filled"],
		"filled": true,
		"filledName": "transgender-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "trash",
		"tuiName": "@tui.trash",
		"category": "actions",
		"keywords": ["trash"],
		"aliases": ["@tui.trash", "@tui.trash-filled"],
		"filled": true,
		"filledName": "trash-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "trash-2",
		"tuiName": "@tui.trash-2",
		"category": "actions",
		"keywords": ["trash", "2"],
		"aliases": ["@tui.trash-2", "@tui.trash-2-filled"],
		"filled": true,
		"filledName": "trash-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "trash-off",
		"tuiName": "@tui.trash-off",
		"category": "actions",
		"keywords": ["trash", "off"],
		"aliases": ["@tui.trash-off", "@tui.trash-off-filled"],
		"filled": true,
		"filledName": "trash-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tree-deciduous",
		"tuiName": "@tui.tree-deciduous",
		"category": "custom",
		"keywords": ["tree", "deciduous"],
		"aliases": ["@tui.tree-deciduous", "@tui.tree-deciduous-filled"],
		"filled": true,
		"filledName": "tree-deciduous-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tree-palm",
		"tuiName": "@tui.tree-palm",
		"category": "custom",
		"keywords": ["tree", "palm"],
		"aliases": ["@tui.tree-palm", "@tui.tree-palm-filled"],
		"filled": true,
		"filledName": "tree-palm-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tree-pine",
		"tuiName": "@tui.tree-pine",
		"category": "custom",
		"keywords": ["tree", "pine"],
		"aliases": ["@tui.tree-pine", "@tui.tree-pine-filled"],
		"filled": true,
		"filledName": "tree-pine-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "trees",
		"tuiName": "@tui.trees",
		"category": "custom",
		"keywords": ["trees"],
		"aliases": ["@tui.trees", "@tui.trees-filled"],
		"filled": true,
		"filledName": "trees-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "trending-down",
		"tuiName": "@tui.trending-down",
		"category": "custom",
		"keywords": ["trending", "down"],
		"aliases": ["@tui.trending-down", "@tui.trending-down-filled"],
		"filled": true,
		"filledName": "trending-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "trending-up",
		"tuiName": "@tui.trending-up",
		"category": "custom",
		"keywords": ["trending", "up"],
		"aliases": ["@tui.trending-up", "@tui.trending-up-filled"],
		"filled": true,
		"filledName": "trending-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "trending-up-down",
		"tuiName": "@tui.trending-up-down",
		"category": "custom",
		"keywords": [
			"trending",
			"up",
			"down"
		],
		"aliases": ["@tui.trending-up-down", "@tui.trending-up-down-filled"],
		"filled": true,
		"filledName": "trending-up-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "triangle",
		"tuiName": "@tui.triangle",
		"category": "custom",
		"keywords": ["triangle"],
		"aliases": ["@tui.triangle", "@tui.triangle-filled"],
		"filled": true,
		"filledName": "triangle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "triangle-alert",
		"tuiName": "@tui.triangle-alert",
		"category": "status-feedback",
		"keywords": ["triangle", "alert"],
		"aliases": ["@tui.triangle-alert", "@tui.triangle-alert-filled"],
		"filled": true,
		"filledName": "triangle-alert-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "triangle-dashed",
		"tuiName": "@tui.triangle-dashed",
		"category": "custom",
		"keywords": ["triangle", "dashed"],
		"aliases": ["@tui.triangle-dashed", "@tui.triangle-dashed-filled"],
		"filled": true,
		"filledName": "triangle-dashed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "triangle-right",
		"tuiName": "@tui.triangle-right",
		"category": "custom",
		"keywords": ["triangle", "right"],
		"aliases": ["@tui.triangle-right", "@tui.triangle-right-filled"],
		"filled": true,
		"filledName": "triangle-right-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "triangles-centerline-dashed-horizontal",
		"tuiName": "@tui.triangles-centerline-dashed-horizontal",
		"category": "custom",
		"keywords": [
			"triangles",
			"centerline",
			"dashed",
			"horizontal"
		],
		"aliases": ["@tui.triangles-centerline-dashed-horizontal", "@tui.triangles-centerline-dashed-horizontal-filled"],
		"filled": true,
		"filledName": "triangles-centerline-dashed-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "triangles-centerline-dashed-vertical",
		"tuiName": "@tui.triangles-centerline-dashed-vertical",
		"category": "custom",
		"keywords": [
			"triangles",
			"centerline",
			"dashed",
			"vertical"
		],
		"aliases": ["@tui.triangles-centerline-dashed-vertical", "@tui.triangles-centerline-dashed-vertical-filled"],
		"filled": true,
		"filledName": "triangles-centerline-dashed-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "trophy",
		"tuiName": "@tui.trophy",
		"category": "custom",
		"keywords": ["trophy"],
		"aliases": ["@tui.trophy", "@tui.trophy-filled"],
		"filled": true,
		"filledName": "trophy-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "truck",
		"tuiName": "@tui.truck",
		"category": "custom",
		"keywords": ["truck"],
		"aliases": ["@tui.truck", "@tui.truck-filled"],
		"filled": true,
		"filledName": "truck-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "truck-electric",
		"tuiName": "@tui.truck-electric",
		"category": "custom",
		"keywords": ["truck", "electric"],
		"aliases": ["@tui.truck-electric", "@tui.truck-electric-filled"],
		"filled": true,
		"filledName": "truck-electric-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tube-lotion",
		"tuiName": "@tui.tube-lotion",
		"category": "custom",
		"keywords": ["tube", "lotion"],
		"aliases": ["@tui.tube-lotion", "@tui.tube-lotion-filled"],
		"filled": true,
		"filledName": "tube-lotion-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "turkish-lira",
		"tuiName": "@tui.turkish-lira",
		"category": "custom",
		"keywords": ["turkish", "lira"],
		"aliases": ["@tui.turkish-lira", "@tui.turkish-lira-filled"],
		"filled": true,
		"filledName": "turkish-lira-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "turntable",
		"tuiName": "@tui.turntable",
		"category": "custom",
		"keywords": ["turntable"],
		"aliases": ["@tui.turntable", "@tui.turntable-filled"],
		"filled": true,
		"filledName": "turntable-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "turtle",
		"tuiName": "@tui.turtle",
		"category": "custom",
		"keywords": ["turtle"],
		"aliases": ["@tui.turtle", "@tui.turtle-filled"],
		"filled": true,
		"filledName": "turtle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tv",
		"tuiName": "@tui.tv",
		"category": "devices",
		"keywords": ["tv"],
		"aliases": ["@tui.tv", "@tui.tv-filled"],
		"filled": true,
		"filledName": "tv-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tv-2",
		"tuiName": "@tui.tv-2",
		"category": "devices",
		"keywords": ["tv", "2"],
		"aliases": ["@tui.tv-2", "@tui.tv-2-filled"],
		"filled": true,
		"filledName": "tv-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tv-minimal",
		"tuiName": "@tui.tv-minimal",
		"category": "devices",
		"keywords": ["tv", "minimal"],
		"aliases": ["@tui.tv-minimal", "@tui.tv-minimal-filled"],
		"filled": true,
		"filledName": "tv-minimal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "tv-minimal-play",
		"tuiName": "@tui.tv-minimal-play",
		"category": "devices",
		"keywords": [
			"tv",
			"minimal",
			"play"
		],
		"aliases": ["@tui.tv-minimal-play", "@tui.tv-minimal-play-filled"],
		"filled": true,
		"filledName": "tv-minimal-play-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "type",
		"tuiName": "@tui.type",
		"category": "editing",
		"keywords": ["type"],
		"aliases": ["@tui.type", "@tui.type-filled"],
		"filled": true,
		"filledName": "type-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "type-outline",
		"tuiName": "@tui.type-outline",
		"category": "editing",
		"keywords": ["type", "outline"],
		"aliases": ["@tui.type-outline", "@tui.type-outline-filled"],
		"filled": true,
		"filledName": "type-outline-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "umbrella",
		"tuiName": "@tui.umbrella",
		"category": "custom",
		"keywords": ["umbrella"],
		"aliases": ["@tui.umbrella", "@tui.umbrella-filled"],
		"filled": true,
		"filledName": "umbrella-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "umbrella-off",
		"tuiName": "@tui.umbrella-off",
		"category": "custom",
		"keywords": ["umbrella", "off"],
		"aliases": ["@tui.umbrella-off", "@tui.umbrella-off-filled"],
		"filled": true,
		"filledName": "umbrella-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "underline",
		"tuiName": "@tui.underline",
		"category": "editing",
		"keywords": ["underline"],
		"aliases": ["@tui.underline", "@tui.underline-filled"],
		"filled": true,
		"filledName": "underline-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "undo",
		"tuiName": "@tui.undo",
		"category": "arrows",
		"keywords": ["undo"],
		"aliases": ["@tui.undo", "@tui.undo-filled"],
		"filled": true,
		"filledName": "undo-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "undo-2",
		"tuiName": "@tui.undo-2",
		"category": "arrows",
		"keywords": ["undo", "2"],
		"aliases": ["@tui.undo-2", "@tui.undo-2-filled"],
		"filled": true,
		"filledName": "undo-2-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "undo-dot",
		"tuiName": "@tui.undo-dot",
		"category": "arrows",
		"keywords": ["undo", "dot"],
		"aliases": ["@tui.undo-dot", "@tui.undo-dot-filled"],
		"filled": true,
		"filledName": "undo-dot-filled",
		"source": "taiga",
		"mirrorInRtl": true
	},
	{
		"name": "unfold-horizontal",
		"tuiName": "@tui.unfold-horizontal",
		"category": "arrows",
		"keywords": ["unfold", "horizontal"],
		"aliases": ["@tui.unfold-horizontal", "@tui.unfold-horizontal-filled"],
		"filled": true,
		"filledName": "unfold-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "unfold-vertical",
		"tuiName": "@tui.unfold-vertical",
		"category": "arrows",
		"keywords": ["unfold", "vertical"],
		"aliases": ["@tui.unfold-vertical", "@tui.unfold-vertical-filled"],
		"filled": true,
		"filledName": "unfold-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "ungroup",
		"tuiName": "@tui.ungroup",
		"category": "layout",
		"keywords": ["ungroup"],
		"aliases": ["@tui.ungroup", "@tui.ungroup-filled"],
		"filled": true,
		"filledName": "ungroup-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "union-pay",
		"tuiName": "@tui.union-pay",
		"category": "custom",
		"keywords": ["union", "pay"],
		"aliases": ["@tui.union-pay"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "university",
		"tuiName": "@tui.university",
		"category": "custom",
		"keywords": ["university"],
		"aliases": ["@tui.university", "@tui.university-filled"],
		"filled": true,
		"filledName": "university-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "unlink",
		"tuiName": "@tui.unlink",
		"category": "custom",
		"keywords": ["unlink"],
		"aliases": ["@tui.unlink", "@tui.unlink-filled"],
		"filled": true,
		"filledName": "unlink-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "unlink-2",
		"tuiName": "@tui.unlink-2",
		"category": "custom",
		"keywords": ["unlink", "2"],
		"aliases": ["@tui.unlink-2", "@tui.unlink-2-filled"],
		"filled": true,
		"filledName": "unlink-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "unlock",
		"tuiName": "@tui.unlock",
		"category": "security",
		"keywords": ["unlock"],
		"aliases": ["@tui.unlock", "@tui.unlock-filled"],
		"filled": true,
		"filledName": "unlock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "unlock-keyhole",
		"tuiName": "@tui.unlock-keyhole",
		"category": "security",
		"keywords": ["unlock", "keyhole"],
		"aliases": ["@tui.unlock-keyhole", "@tui.unlock-keyhole-filled"],
		"filled": true,
		"filledName": "unlock-keyhole-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "unplug",
		"tuiName": "@tui.unplug",
		"category": "custom",
		"keywords": ["unplug"],
		"aliases": ["@tui.unplug", "@tui.unplug-filled"],
		"filled": true,
		"filledName": "unplug-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "upload",
		"tuiName": "@tui.upload",
		"category": "actions",
		"keywords": ["upload"],
		"aliases": ["@tui.upload", "@tui.upload-filled"],
		"filled": true,
		"filledName": "upload-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "upload-cloud",
		"tuiName": "@tui.upload-cloud",
		"category": "actions",
		"keywords": ["upload", "cloud"],
		"aliases": ["@tui.upload-cloud", "@tui.upload-cloud-filled"],
		"filled": true,
		"filledName": "upload-cloud-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "usb",
		"tuiName": "@tui.usb",
		"category": "devices",
		"keywords": ["usb"],
		"aliases": ["@tui.usb", "@tui.usb-filled"],
		"filled": true,
		"filledName": "usb-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "usb-c-port",
		"tuiName": "@tui.usb-c-port",
		"category": "devices",
		"keywords": [
			"usb",
			"c",
			"port"
		],
		"aliases": ["@tui.usb-c-port", "@tui.usb-c-port-filled"],
		"filled": true,
		"filledName": "usb-c-port-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user",
		"tuiName": "@tui.user",
		"category": "users",
		"keywords": ["user"],
		"aliases": ["@tui.user", "@tui.user-filled"],
		"filled": true,
		"filledName": "user-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-2",
		"tuiName": "@tui.user-2",
		"category": "users",
		"keywords": ["user", "2"],
		"aliases": ["@tui.user-2", "@tui.user-2-filled"],
		"filled": true,
		"filledName": "user-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-check",
		"tuiName": "@tui.user-check",
		"category": "users",
		"keywords": ["user", "check"],
		"aliases": ["@tui.user-check", "@tui.user-check-filled"],
		"filled": true,
		"filledName": "user-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-check-2",
		"tuiName": "@tui.user-check-2",
		"category": "users",
		"keywords": [
			"user",
			"check",
			"2"
		],
		"aliases": ["@tui.user-check-2", "@tui.user-check-2-filled"],
		"filled": true,
		"filledName": "user-check-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-circle",
		"tuiName": "@tui.user-circle",
		"category": "users",
		"keywords": ["user", "circle"],
		"aliases": ["@tui.user-circle", "@tui.user-circle-filled"],
		"filled": true,
		"filledName": "user-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-circle-2",
		"tuiName": "@tui.user-circle-2",
		"category": "users",
		"keywords": [
			"user",
			"circle",
			"2"
		],
		"aliases": ["@tui.user-circle-2", "@tui.user-circle-2-filled"],
		"filled": true,
		"filledName": "user-circle-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-cog",
		"tuiName": "@tui.user-cog",
		"category": "users",
		"keywords": ["user", "cog"],
		"aliases": ["@tui.user-cog", "@tui.user-cog-filled"],
		"filled": true,
		"filledName": "user-cog-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-cog-2",
		"tuiName": "@tui.user-cog-2",
		"category": "users",
		"keywords": [
			"user",
			"cog",
			"2"
		],
		"aliases": ["@tui.user-cog-2", "@tui.user-cog-2-filled"],
		"filled": true,
		"filledName": "user-cog-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-group",
		"tuiName": "@tui.user-group",
		"category": "users",
		"keywords": ["user", "group"],
		"aliases": ["@tui.user-group", "@tui.user-group-filled"],
		"filled": true,
		"filledName": "user-group-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-key",
		"tuiName": "@tui.user-key",
		"category": "users",
		"keywords": ["user", "key"],
		"aliases": ["@tui.user-key", "@tui.user-key-filled"],
		"filled": true,
		"filledName": "user-key-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-lock",
		"tuiName": "@tui.user-lock",
		"category": "users",
		"keywords": ["user", "lock"],
		"aliases": ["@tui.user-lock", "@tui.user-lock-filled"],
		"filled": true,
		"filledName": "user-lock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-minus",
		"tuiName": "@tui.user-minus",
		"category": "users",
		"keywords": ["user", "minus"],
		"aliases": ["@tui.user-minus", "@tui.user-minus-filled"],
		"filled": true,
		"filledName": "user-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-minus-2",
		"tuiName": "@tui.user-minus-2",
		"category": "users",
		"keywords": [
			"user",
			"minus",
			"2"
		],
		"aliases": ["@tui.user-minus-2", "@tui.user-minus-2-filled"],
		"filled": true,
		"filledName": "user-minus-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-pen",
		"tuiName": "@tui.user-pen",
		"category": "users",
		"keywords": ["user", "pen"],
		"aliases": ["@tui.user-pen", "@tui.user-pen-filled"],
		"filled": true,
		"filledName": "user-pen-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-plus",
		"tuiName": "@tui.user-plus",
		"category": "users",
		"keywords": ["user", "plus"],
		"aliases": ["@tui.user-plus", "@tui.user-plus-filled"],
		"filled": true,
		"filledName": "user-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-plus-2",
		"tuiName": "@tui.user-plus-2",
		"category": "users",
		"keywords": [
			"user",
			"plus",
			"2"
		],
		"aliases": ["@tui.user-plus-2", "@tui.user-plus-2-filled"],
		"filled": true,
		"filledName": "user-plus-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-round",
		"tuiName": "@tui.user-round",
		"category": "users",
		"keywords": ["user", "round"],
		"aliases": ["@tui.user-round", "@tui.user-round-filled"],
		"filled": true,
		"filledName": "user-round-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-round-arrow-left",
		"tuiName": "@tui.user-round-arrow-left",
		"category": "users",
		"keywords": [
			"user",
			"round",
			"arrow",
			"left"
		],
		"aliases": ["@tui.user-round-arrow-left", "@tui.user-round-arrow-left-filled"],
		"filled": true,
		"filledName": "user-round-arrow-left-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-round-check",
		"tuiName": "@tui.user-round-check",
		"category": "users",
		"keywords": [
			"user",
			"round",
			"check"
		],
		"aliases": ["@tui.user-round-check", "@tui.user-round-check-filled"],
		"filled": true,
		"filledName": "user-round-check-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-round-cog",
		"tuiName": "@tui.user-round-cog",
		"category": "users",
		"keywords": [
			"user",
			"round",
			"cog"
		],
		"aliases": ["@tui.user-round-cog", "@tui.user-round-cog-filled"],
		"filled": true,
		"filledName": "user-round-cog-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-round-group",
		"tuiName": "@tui.user-round-group",
		"category": "users",
		"keywords": [
			"user",
			"round",
			"group"
		],
		"aliases": ["@tui.user-round-group", "@tui.user-round-group-filled"],
		"filled": true,
		"filledName": "user-round-group-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-round-key",
		"tuiName": "@tui.user-round-key",
		"category": "users",
		"keywords": [
			"user",
			"round",
			"key"
		],
		"aliases": ["@tui.user-round-key", "@tui.user-round-key-filled"],
		"filled": true,
		"filledName": "user-round-key-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-round-minus",
		"tuiName": "@tui.user-round-minus",
		"category": "users",
		"keywords": [
			"user",
			"round",
			"minus"
		],
		"aliases": ["@tui.user-round-minus", "@tui.user-round-minus-filled"],
		"filled": true,
		"filledName": "user-round-minus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-round-pen",
		"tuiName": "@tui.user-round-pen",
		"category": "users",
		"keywords": [
			"user",
			"round",
			"pen"
		],
		"aliases": ["@tui.user-round-pen", "@tui.user-round-pen-filled"],
		"filled": true,
		"filledName": "user-round-pen-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-round-plus",
		"tuiName": "@tui.user-round-plus",
		"category": "users",
		"keywords": [
			"user",
			"round",
			"plus"
		],
		"aliases": ["@tui.user-round-plus", "@tui.user-round-plus-filled"],
		"filled": true,
		"filledName": "user-round-plus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-round-search",
		"tuiName": "@tui.user-round-search",
		"category": "users",
		"keywords": [
			"user",
			"round",
			"search"
		],
		"aliases": ["@tui.user-round-search", "@tui.user-round-search-filled"],
		"filled": true,
		"filledName": "user-round-search-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-round-star",
		"tuiName": "@tui.user-round-star",
		"category": "users",
		"keywords": [
			"user",
			"round",
			"star"
		],
		"aliases": ["@tui.user-round-star", "@tui.user-round-star-filled"],
		"filled": true,
		"filledName": "user-round-star-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-round-x",
		"tuiName": "@tui.user-round-x",
		"category": "users",
		"keywords": [
			"user",
			"round",
			"x"
		],
		"aliases": ["@tui.user-round-x", "@tui.user-round-x-filled"],
		"filled": true,
		"filledName": "user-round-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-search",
		"tuiName": "@tui.user-search",
		"category": "users",
		"keywords": ["user", "search"],
		"aliases": ["@tui.user-search", "@tui.user-search-filled"],
		"filled": true,
		"filledName": "user-search-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-shield",
		"tuiName": "@tui.user-shield",
		"category": "users",
		"keywords": ["user", "shield"],
		"aliases": ["@tui.user-shield", "@tui.user-shield-filled"],
		"filled": true,
		"filledName": "user-shield-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-square",
		"tuiName": "@tui.user-square",
		"category": "users",
		"keywords": ["user", "square"],
		"aliases": ["@tui.user-square", "@tui.user-square-filled"],
		"filled": true,
		"filledName": "user-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-square-2",
		"tuiName": "@tui.user-square-2",
		"category": "users",
		"keywords": [
			"user",
			"square",
			"2"
		],
		"aliases": ["@tui.user-square-2", "@tui.user-square-2-filled"],
		"filled": true,
		"filledName": "user-square-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-star",
		"tuiName": "@tui.user-star",
		"category": "users",
		"keywords": ["user", "star"],
		"aliases": ["@tui.user-star", "@tui.user-star-filled"],
		"filled": true,
		"filledName": "user-star-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-x",
		"tuiName": "@tui.user-x",
		"category": "users",
		"keywords": ["user", "x"],
		"aliases": ["@tui.user-x", "@tui.user-x-filled"],
		"filled": true,
		"filledName": "user-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "user-x-2",
		"tuiName": "@tui.user-x-2",
		"category": "users",
		"keywords": [
			"user",
			"x",
			"2"
		],
		"aliases": ["@tui.user-x-2", "@tui.user-x-2-filled"],
		"filled": true,
		"filledName": "user-x-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "users",
		"tuiName": "@tui.users",
		"category": "users",
		"keywords": ["users"],
		"aliases": ["@tui.users", "@tui.users-filled"],
		"filled": true,
		"filledName": "users-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "users-2",
		"tuiName": "@tui.users-2",
		"category": "users",
		"keywords": ["users", "2"],
		"aliases": ["@tui.users-2", "@tui.users-2-filled"],
		"filled": true,
		"filledName": "users-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "users-collaboration",
		"tuiName": "@tui.users-collaboration",
		"category": "users",
		"keywords": ["users", "collaboration"],
		"aliases": ["@tui.users-collaboration", "@tui.users-collaboration-filled"],
		"filled": true,
		"filledName": "users-collaboration-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "users-round",
		"tuiName": "@tui.users-round",
		"category": "users",
		"keywords": ["users", "round"],
		"aliases": ["@tui.users-round", "@tui.users-round-filled"],
		"filled": true,
		"filledName": "users-round-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "users-round-collaboration",
		"tuiName": "@tui.users-round-collaboration",
		"category": "users",
		"keywords": [
			"users",
			"round",
			"collaboration"
		],
		"aliases": ["@tui.users-round-collaboration", "@tui.users-round-collaboration-filled"],
		"filled": true,
		"filledName": "users-round-collaboration-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "utensils",
		"tuiName": "@tui.utensils",
		"category": "custom",
		"keywords": ["utensils"],
		"aliases": ["@tui.utensils", "@tui.utensils-filled"],
		"filled": true,
		"filledName": "utensils-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "utensils-crossed",
		"tuiName": "@tui.utensils-crossed",
		"category": "custom",
		"keywords": ["utensils", "crossed"],
		"aliases": ["@tui.utensils-crossed", "@tui.utensils-crossed-filled"],
		"filled": true,
		"filledName": "utensils-crossed-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "utility-pole",
		"tuiName": "@tui.utility-pole",
		"category": "custom",
		"keywords": ["utility", "pole"],
		"aliases": ["@tui.utility-pole", "@tui.utility-pole-filled"],
		"filled": true,
		"filledName": "utility-pole-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "uzcard",
		"tuiName": "@tui.uzcard",
		"category": "custom",
		"keywords": ["uzcard"],
		"aliases": ["@tui.uzcard"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "van",
		"tuiName": "@tui.van",
		"category": "custom",
		"keywords": ["van"],
		"aliases": ["@tui.van", "@tui.van-filled"],
		"filled": true,
		"filledName": "van-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "variable",
		"tuiName": "@tui.variable",
		"category": "development",
		"keywords": ["variable"],
		"aliases": ["@tui.variable", "@tui.variable-filled"],
		"filled": true,
		"filledName": "variable-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "vault",
		"tuiName": "@tui.vault",
		"category": "security",
		"keywords": ["vault"],
		"aliases": ["@tui.vault", "@tui.vault-filled"],
		"filled": true,
		"filledName": "vault-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "vector-polygon",
		"tuiName": "@tui.vector-polygon",
		"category": "custom",
		"keywords": ["vector", "polygon"],
		"aliases": ["@tui.vector-polygon", "@tui.vector-polygon-filled"],
		"filled": true,
		"filledName": "vector-polygon-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "vector-square",
		"tuiName": "@tui.vector-square",
		"category": "custom",
		"keywords": ["vector", "square"],
		"aliases": ["@tui.vector-square", "@tui.vector-square-filled"],
		"filled": true,
		"filledName": "vector-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "vegan",
		"tuiName": "@tui.vegan",
		"category": "custom",
		"keywords": ["vegan"],
		"aliases": ["@tui.vegan", "@tui.vegan-filled"],
		"filled": true,
		"filledName": "vegan-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "venetian-mask",
		"tuiName": "@tui.venetian-mask",
		"category": "custom",
		"keywords": ["venetian", "mask"],
		"aliases": ["@tui.venetian-mask", "@tui.venetian-mask-filled"],
		"filled": true,
		"filledName": "venetian-mask-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "venus",
		"tuiName": "@tui.venus",
		"category": "custom",
		"keywords": ["venus"],
		"aliases": ["@tui.venus", "@tui.venus-filled"],
		"filled": true,
		"filledName": "venus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "venus-and-mars",
		"tuiName": "@tui.venus-and-mars",
		"category": "custom",
		"keywords": [
			"venus",
			"and",
			"mars"
		],
		"aliases": ["@tui.venus-and-mars", "@tui.venus-and-mars-filled"],
		"filled": true,
		"filledName": "venus-and-mars-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "verified",
		"tuiName": "@tui.verified",
		"category": "custom",
		"keywords": ["verified"],
		"aliases": ["@tui.verified", "@tui.verified-filled"],
		"filled": true,
		"filledName": "verified-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "verve",
		"tuiName": "@tui.verve",
		"category": "custom",
		"keywords": ["verve"],
		"aliases": ["@tui.verve"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "vibrate",
		"tuiName": "@tui.vibrate",
		"category": "custom",
		"keywords": ["vibrate"],
		"aliases": ["@tui.vibrate", "@tui.vibrate-filled"],
		"filled": true,
		"filledName": "vibrate-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "vibrate-off",
		"tuiName": "@tui.vibrate-off",
		"category": "custom",
		"keywords": ["vibrate", "off"],
		"aliases": ["@tui.vibrate-off", "@tui.vibrate-off-filled"],
		"filled": true,
		"filledName": "vibrate-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "video",
		"tuiName": "@tui.video",
		"category": "media",
		"keywords": ["video"],
		"aliases": ["@tui.video", "@tui.video-filled"],
		"filled": true,
		"filledName": "video-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "video-off",
		"tuiName": "@tui.video-off",
		"category": "media",
		"keywords": ["video", "off"],
		"aliases": ["@tui.video-off", "@tui.video-off-filled"],
		"filled": true,
		"filledName": "video-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "videotape",
		"tuiName": "@tui.videotape",
		"category": "media",
		"keywords": ["videotape"],
		"aliases": ["@tui.videotape", "@tui.videotape-filled"],
		"filled": true,
		"filledName": "videotape-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "view",
		"tuiName": "@tui.view",
		"category": "custom",
		"keywords": ["view"],
		"aliases": ["@tui.view", "@tui.view-filled"],
		"filled": true,
		"filledName": "view-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "virus",
		"tuiName": "@tui.virus",
		"category": "custom",
		"keywords": ["virus"],
		"aliases": ["@tui.virus", "@tui.virus-filled"],
		"filled": true,
		"filledName": "virus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "virus-off",
		"tuiName": "@tui.virus-off",
		"category": "custom",
		"keywords": ["virus", "off"],
		"aliases": ["@tui.virus-off", "@tui.virus-off-filled"],
		"filled": true,
		"filledName": "virus-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "visa",
		"tuiName": "@tui.visa",
		"category": "custom",
		"keywords": ["visa"],
		"aliases": ["@tui.visa"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "visa-mono",
		"tuiName": "@tui.visa-mono",
		"category": "custom",
		"keywords": ["visa", "mono"],
		"aliases": ["@tui.visa-mono"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "voicemail",
		"tuiName": "@tui.voicemail",
		"category": "communication",
		"keywords": ["voicemail"],
		"aliases": ["@tui.voicemail", "@tui.voicemail-filled"],
		"filled": true,
		"filledName": "voicemail-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "volleyball",
		"tuiName": "@tui.volleyball",
		"category": "custom",
		"keywords": ["volleyball"],
		"aliases": ["@tui.volleyball", "@tui.volleyball-filled"],
		"filled": true,
		"filledName": "volleyball-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "volume",
		"tuiName": "@tui.volume",
		"category": "media",
		"keywords": ["volume"],
		"aliases": ["@tui.volume", "@tui.volume-filled"],
		"filled": true,
		"filledName": "volume-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "volume-1",
		"tuiName": "@tui.volume-1",
		"category": "media",
		"keywords": ["volume", "1"],
		"aliases": ["@tui.volume-1", "@tui.volume-1-filled"],
		"filled": true,
		"filledName": "volume-1-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "volume-2",
		"tuiName": "@tui.volume-2",
		"category": "media",
		"keywords": ["volume", "2"],
		"aliases": ["@tui.volume-2", "@tui.volume-2-filled"],
		"filled": true,
		"filledName": "volume-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "volume-off",
		"tuiName": "@tui.volume-off",
		"category": "media",
		"keywords": ["volume", "off"],
		"aliases": ["@tui.volume-off", "@tui.volume-off-filled"],
		"filled": true,
		"filledName": "volume-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "volume-x",
		"tuiName": "@tui.volume-x",
		"category": "media",
		"keywords": ["volume", "x"],
		"aliases": ["@tui.volume-x", "@tui.volume-x-filled"],
		"filled": true,
		"filledName": "volume-x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "vote",
		"tuiName": "@tui.vote",
		"category": "custom",
		"keywords": ["vote"],
		"aliases": ["@tui.vote", "@tui.vote-filled"],
		"filled": true,
		"filledName": "vote-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wallet",
		"tuiName": "@tui.wallet",
		"category": "finance",
		"keywords": ["wallet"],
		"aliases": ["@tui.wallet", "@tui.wallet-filled"],
		"filled": true,
		"filledName": "wallet-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wallet-2",
		"tuiName": "@tui.wallet-2",
		"category": "finance",
		"keywords": ["wallet", "2"],
		"aliases": ["@tui.wallet-2", "@tui.wallet-2-filled"],
		"filled": true,
		"filledName": "wallet-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wallet-cards",
		"tuiName": "@tui.wallet-cards",
		"category": "finance",
		"keywords": ["wallet", "cards"],
		"aliases": ["@tui.wallet-cards", "@tui.wallet-cards-filled"],
		"filled": true,
		"filledName": "wallet-cards-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wallet-minimal",
		"tuiName": "@tui.wallet-minimal",
		"category": "finance",
		"keywords": ["wallet", "minimal"],
		"aliases": ["@tui.wallet-minimal", "@tui.wallet-minimal-filled"],
		"filled": true,
		"filledName": "wallet-minimal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wallpaper",
		"tuiName": "@tui.wallpaper",
		"category": "custom",
		"keywords": ["wallpaper"],
		"aliases": ["@tui.wallpaper", "@tui.wallpaper-filled"],
		"filled": true,
		"filledName": "wallpaper-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wand",
		"tuiName": "@tui.wand",
		"category": "development",
		"keywords": ["wand"],
		"aliases": ["@tui.wand", "@tui.wand-filled"],
		"filled": true,
		"filledName": "wand-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wand-2",
		"tuiName": "@tui.wand-2",
		"category": "development",
		"keywords": ["wand", "2"],
		"aliases": ["@tui.wand-2", "@tui.wand-2-filled"],
		"filled": true,
		"filledName": "wand-2-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wand-sparkles",
		"tuiName": "@tui.wand-sparkles",
		"category": "development",
		"keywords": ["wand", "sparkles"],
		"aliases": ["@tui.wand-sparkles", "@tui.wand-sparkles-filled"],
		"filled": true,
		"filledName": "wand-sparkles-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "warehouse",
		"tuiName": "@tui.warehouse",
		"category": "custom",
		"keywords": ["warehouse"],
		"aliases": ["@tui.warehouse", "@tui.warehouse-filled"],
		"filled": true,
		"filledName": "warehouse-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "washing-machine",
		"tuiName": "@tui.washing-machine",
		"category": "custom",
		"keywords": ["washing", "machine"],
		"aliases": ["@tui.washing-machine", "@tui.washing-machine-filled"],
		"filled": true,
		"filledName": "washing-machine-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "watch",
		"tuiName": "@tui.watch",
		"category": "devices",
		"keywords": ["watch"],
		"aliases": ["@tui.watch", "@tui.watch-filled"],
		"filled": true,
		"filledName": "watch-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "waves",
		"tuiName": "@tui.waves",
		"category": "custom",
		"keywords": ["waves"],
		"aliases": ["@tui.waves", "@tui.waves-filled"],
		"filled": true,
		"filledName": "waves-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "waves-arrow-down",
		"tuiName": "@tui.waves-arrow-down",
		"category": "custom",
		"keywords": [
			"waves",
			"arrow",
			"down"
		],
		"aliases": ["@tui.waves-arrow-down", "@tui.waves-arrow-down-filled"],
		"filled": true,
		"filledName": "waves-arrow-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "waves-arrow-up",
		"tuiName": "@tui.waves-arrow-up",
		"category": "custom",
		"keywords": [
			"waves",
			"arrow",
			"up"
		],
		"aliases": ["@tui.waves-arrow-up", "@tui.waves-arrow-up-filled"],
		"filled": true,
		"filledName": "waves-arrow-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "waves-horizontal",
		"tuiName": "@tui.waves-horizontal",
		"category": "custom",
		"keywords": ["waves", "horizontal"],
		"aliases": ["@tui.waves-horizontal", "@tui.waves-horizontal-filled"],
		"filled": true,
		"filledName": "waves-horizontal-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "waves-ladder",
		"tuiName": "@tui.waves-ladder",
		"category": "custom",
		"keywords": ["waves", "ladder"],
		"aliases": ["@tui.waves-ladder", "@tui.waves-ladder-filled"],
		"filled": true,
		"filledName": "waves-ladder-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "waves-vertical",
		"tuiName": "@tui.waves-vertical",
		"category": "custom",
		"keywords": ["waves", "vertical"],
		"aliases": ["@tui.waves-vertical", "@tui.waves-vertical-filled"],
		"filled": true,
		"filledName": "waves-vertical-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "waypoints",
		"tuiName": "@tui.waypoints",
		"category": "custom",
		"keywords": ["waypoints"],
		"aliases": ["@tui.waypoints", "@tui.waypoints-filled"],
		"filled": true,
		"filledName": "waypoints-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "webcam",
		"tuiName": "@tui.webcam",
		"category": "custom",
		"keywords": ["webcam"],
		"aliases": ["@tui.webcam", "@tui.webcam-filled"],
		"filled": true,
		"filledName": "webcam-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "webcam-off",
		"tuiName": "@tui.webcam-off",
		"category": "custom",
		"keywords": ["webcam", "off"],
		"aliases": ["@tui.webcam-off", "@tui.webcam-off-filled"],
		"filled": true,
		"filledName": "webcam-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "webhook",
		"tuiName": "@tui.webhook",
		"category": "development",
		"keywords": ["webhook"],
		"aliases": ["@tui.webhook", "@tui.webhook-filled"],
		"filled": true,
		"filledName": "webhook-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "webhook-off",
		"tuiName": "@tui.webhook-off",
		"category": "development",
		"keywords": ["webhook", "off"],
		"aliases": ["@tui.webhook-off", "@tui.webhook-off-filled"],
		"filled": true,
		"filledName": "webhook-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "weight",
		"tuiName": "@tui.weight",
		"category": "custom",
		"keywords": ["weight"],
		"aliases": ["@tui.weight", "@tui.weight-filled"],
		"filled": true,
		"filledName": "weight-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "weight-tilde",
		"tuiName": "@tui.weight-tilde",
		"category": "custom",
		"keywords": ["weight", "tilde"],
		"aliases": ["@tui.weight-tilde", "@tui.weight-tilde-filled"],
		"filled": true,
		"filledName": "weight-tilde-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wheat",
		"tuiName": "@tui.wheat",
		"category": "custom",
		"keywords": ["wheat"],
		"aliases": ["@tui.wheat", "@tui.wheat-filled"],
		"filled": true,
		"filledName": "wheat-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wheat-off",
		"tuiName": "@tui.wheat-off",
		"category": "custom",
		"keywords": ["wheat", "off"],
		"aliases": ["@tui.wheat-off", "@tui.wheat-off-filled"],
		"filled": true,
		"filledName": "wheat-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "whistle",
		"tuiName": "@tui.whistle",
		"category": "custom",
		"keywords": ["whistle"],
		"aliases": ["@tui.whistle", "@tui.whistle-filled"],
		"filled": true,
		"filledName": "whistle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "whole-word",
		"tuiName": "@tui.whole-word",
		"category": "custom",
		"keywords": ["whole", "word"],
		"aliases": ["@tui.whole-word", "@tui.whole-word-filled"],
		"filled": true,
		"filledName": "whole-word-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wifi",
		"tuiName": "@tui.wifi",
		"category": "social",
		"keywords": ["wifi"],
		"aliases": ["@tui.wifi", "@tui.wifi-filled"],
		"filled": true,
		"filledName": "wifi-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wifi-cog",
		"tuiName": "@tui.wifi-cog",
		"category": "social",
		"keywords": ["wifi", "cog"],
		"aliases": ["@tui.wifi-cog", "@tui.wifi-cog-filled"],
		"filled": true,
		"filledName": "wifi-cog-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wifi-high",
		"tuiName": "@tui.wifi-high",
		"category": "social",
		"keywords": ["wifi", "high"],
		"aliases": ["@tui.wifi-high", "@tui.wifi-high-filled"],
		"filled": true,
		"filledName": "wifi-high-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wifi-lock",
		"tuiName": "@tui.wifi-lock",
		"category": "social",
		"keywords": ["wifi", "lock"],
		"aliases": ["@tui.wifi-lock", "@tui.wifi-lock-filled"],
		"filled": true,
		"filledName": "wifi-lock-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wifi-low",
		"tuiName": "@tui.wifi-low",
		"category": "social",
		"keywords": ["wifi", "low"],
		"aliases": ["@tui.wifi-low", "@tui.wifi-low-filled"],
		"filled": true,
		"filledName": "wifi-low-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wifi-off",
		"tuiName": "@tui.wifi-off",
		"category": "social",
		"keywords": ["wifi", "off"],
		"aliases": ["@tui.wifi-off", "@tui.wifi-off-filled"],
		"filled": true,
		"filledName": "wifi-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wifi-pen",
		"tuiName": "@tui.wifi-pen",
		"category": "social",
		"keywords": ["wifi", "pen"],
		"aliases": ["@tui.wifi-pen", "@tui.wifi-pen-filled"],
		"filled": true,
		"filledName": "wifi-pen-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wifi-sync",
		"tuiName": "@tui.wifi-sync",
		"category": "social",
		"keywords": ["wifi", "sync"],
		"aliases": ["@tui.wifi-sync", "@tui.wifi-sync-filled"],
		"filled": true,
		"filledName": "wifi-sync-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wifi-zero",
		"tuiName": "@tui.wifi-zero",
		"category": "social",
		"keywords": ["wifi", "zero"],
		"aliases": ["@tui.wifi-zero", "@tui.wifi-zero-filled"],
		"filled": true,
		"filledName": "wifi-zero-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wind",
		"tuiName": "@tui.wind",
		"category": "custom",
		"keywords": ["wind"],
		"aliases": ["@tui.wind", "@tui.wind-filled"],
		"filled": true,
		"filledName": "wind-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wind-arrow-down",
		"tuiName": "@tui.wind-arrow-down",
		"category": "custom",
		"keywords": [
			"wind",
			"arrow",
			"down"
		],
		"aliases": ["@tui.wind-arrow-down", "@tui.wind-arrow-down-filled"],
		"filled": true,
		"filledName": "wind-arrow-down-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wind-arrow-up",
		"tuiName": "@tui.wind-arrow-up",
		"category": "custom",
		"keywords": [
			"wind",
			"arrow",
			"up"
		],
		"aliases": ["@tui.wind-arrow-up", "@tui.wind-arrow-up-filled"],
		"filled": true,
		"filledName": "wind-arrow-up-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wine",
		"tuiName": "@tui.wine",
		"category": "custom",
		"keywords": ["wine"],
		"aliases": ["@tui.wine", "@tui.wine-filled"],
		"filled": true,
		"filledName": "wine-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wine-off",
		"tuiName": "@tui.wine-off",
		"category": "custom",
		"keywords": ["wine", "off"],
		"aliases": ["@tui.wine-off", "@tui.wine-off-filled"],
		"filled": true,
		"filledName": "wine-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "workflow",
		"tuiName": "@tui.workflow",
		"category": "custom",
		"keywords": ["workflow"],
		"aliases": ["@tui.workflow", "@tui.workflow-filled"],
		"filled": true,
		"filledName": "workflow-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "world-pay",
		"tuiName": "@tui.world-pay",
		"category": "custom",
		"keywords": ["world", "pay"],
		"aliases": ["@tui.world-pay"],
		"filled": false,
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "worm",
		"tuiName": "@tui.worm",
		"category": "custom",
		"keywords": ["worm"],
		"aliases": ["@tui.worm", "@tui.worm-filled"],
		"filled": true,
		"filledName": "worm-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wrap-text",
		"tuiName": "@tui.wrap-text",
		"category": "custom",
		"keywords": ["wrap", "text"],
		"aliases": ["@tui.wrap-text", "@tui.wrap-text-filled"],
		"filled": true,
		"filledName": "wrap-text-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wrench",
		"tuiName": "@tui.wrench",
		"category": "actions",
		"keywords": ["wrench"],
		"aliases": ["@tui.wrench", "@tui.wrench-filled"],
		"filled": true,
		"filledName": "wrench-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "wrench-off",
		"tuiName": "@tui.wrench-off",
		"category": "actions",
		"keywords": ["wrench", "off"],
		"aliases": ["@tui.wrench-off", "@tui.wrench-off-filled"],
		"filled": true,
		"filledName": "wrench-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "x",
		"tuiName": "@tui.x",
		"category": "status-feedback",
		"keywords": ["x"],
		"aliases": ["@tui.x", "@tui.x-filled"],
		"filled": true,
		"filledName": "x-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "x-circle",
		"tuiName": "@tui.x-circle",
		"category": "status-feedback",
		"keywords": ["x", "circle"],
		"aliases": ["@tui.x-circle", "@tui.x-circle-filled"],
		"filled": true,
		"filledName": "x-circle-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "x-line-top",
		"tuiName": "@tui.x-line-top",
		"category": "status-feedback",
		"keywords": [
			"x",
			"line",
			"top"
		],
		"aliases": ["@tui.x-line-top", "@tui.x-line-top-filled"],
		"filled": true,
		"filledName": "x-line-top-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "x-octagon",
		"tuiName": "@tui.x-octagon",
		"category": "status-feedback",
		"keywords": ["x", "octagon"],
		"aliases": ["@tui.x-octagon", "@tui.x-octagon-filled"],
		"filled": true,
		"filledName": "x-octagon-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "x-square",
		"tuiName": "@tui.x-square",
		"category": "status-feedback",
		"keywords": ["x", "square"],
		"aliases": ["@tui.x-square", "@tui.x-square-filled"],
		"filled": true,
		"filledName": "x-square-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "zap",
		"tuiName": "@tui.zap",
		"category": "custom",
		"keywords": ["zap"],
		"aliases": ["@tui.zap", "@tui.zap-filled"],
		"filled": true,
		"filledName": "zap-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "zap-off",
		"tuiName": "@tui.zap-off",
		"category": "custom",
		"keywords": ["zap", "off"],
		"aliases": ["@tui.zap-off", "@tui.zap-off-filled"],
		"filled": true,
		"filledName": "zap-off-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "zodiac-aquarius",
		"tuiName": "@tui.zodiac-aquarius",
		"category": "custom",
		"keywords": ["zodiac", "aquarius"],
		"aliases": ["@tui.zodiac-aquarius", "@tui.zodiac-aquarius-filled"],
		"filled": true,
		"filledName": "zodiac-aquarius-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "zodiac-aries",
		"tuiName": "@tui.zodiac-aries",
		"category": "custom",
		"keywords": ["zodiac", "aries"],
		"aliases": ["@tui.zodiac-aries", "@tui.zodiac-aries-filled"],
		"filled": true,
		"filledName": "zodiac-aries-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "zodiac-cancer",
		"tuiName": "@tui.zodiac-cancer",
		"category": "custom",
		"keywords": ["zodiac", "cancer"],
		"aliases": ["@tui.zodiac-cancer", "@tui.zodiac-cancer-filled"],
		"filled": true,
		"filledName": "zodiac-cancer-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "zodiac-capricorn",
		"tuiName": "@tui.zodiac-capricorn",
		"category": "custom",
		"keywords": ["zodiac", "capricorn"],
		"aliases": ["@tui.zodiac-capricorn", "@tui.zodiac-capricorn-filled"],
		"filled": true,
		"filledName": "zodiac-capricorn-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "zodiac-gemini",
		"tuiName": "@tui.zodiac-gemini",
		"category": "custom",
		"keywords": ["zodiac", "gemini"],
		"aliases": ["@tui.zodiac-gemini", "@tui.zodiac-gemini-filled"],
		"filled": true,
		"filledName": "zodiac-gemini-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "zodiac-leo",
		"tuiName": "@tui.zodiac-leo",
		"category": "custom",
		"keywords": ["zodiac", "leo"],
		"aliases": ["@tui.zodiac-leo", "@tui.zodiac-leo-filled"],
		"filled": true,
		"filledName": "zodiac-leo-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "zodiac-libra",
		"tuiName": "@tui.zodiac-libra",
		"category": "custom",
		"keywords": ["zodiac", "libra"],
		"aliases": ["@tui.zodiac-libra", "@tui.zodiac-libra-filled"],
		"filled": true,
		"filledName": "zodiac-libra-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "zodiac-ophiuchus",
		"tuiName": "@tui.zodiac-ophiuchus",
		"category": "custom",
		"keywords": ["zodiac", "ophiuchus"],
		"aliases": ["@tui.zodiac-ophiuchus", "@tui.zodiac-ophiuchus-filled"],
		"filled": true,
		"filledName": "zodiac-ophiuchus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "zodiac-pisces",
		"tuiName": "@tui.zodiac-pisces",
		"category": "custom",
		"keywords": ["zodiac", "pisces"],
		"aliases": ["@tui.zodiac-pisces", "@tui.zodiac-pisces-filled"],
		"filled": true,
		"filledName": "zodiac-pisces-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "zodiac-sagittarius",
		"tuiName": "@tui.zodiac-sagittarius",
		"category": "custom",
		"keywords": ["zodiac", "sagittarius"],
		"aliases": ["@tui.zodiac-sagittarius", "@tui.zodiac-sagittarius-filled"],
		"filled": true,
		"filledName": "zodiac-sagittarius-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "zodiac-scorpio",
		"tuiName": "@tui.zodiac-scorpio",
		"category": "custom",
		"keywords": ["zodiac", "scorpio"],
		"aliases": ["@tui.zodiac-scorpio", "@tui.zodiac-scorpio-filled"],
		"filled": true,
		"filledName": "zodiac-scorpio-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "zodiac-taurus",
		"tuiName": "@tui.zodiac-taurus",
		"category": "custom",
		"keywords": ["zodiac", "taurus"],
		"aliases": ["@tui.zodiac-taurus", "@tui.zodiac-taurus-filled"],
		"filled": true,
		"filledName": "zodiac-taurus-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "zodiac-virgo",
		"tuiName": "@tui.zodiac-virgo",
		"category": "custom",
		"keywords": ["zodiac", "virgo"],
		"aliases": ["@tui.zodiac-virgo", "@tui.zodiac-virgo-filled"],
		"filled": true,
		"filledName": "zodiac-virgo-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "zoom-in",
		"tuiName": "@tui.zoom-in",
		"category": "actions",
		"keywords": ["zoom", "in"],
		"aliases": ["@tui.zoom-in", "@tui.zoom-in-filled"],
		"filled": true,
		"filledName": "zoom-in-filled",
		"source": "taiga",
		"mirrorInRtl": false
	},
	{
		"name": "zoom-out",
		"tuiName": "@tui.zoom-out",
		"category": "actions",
		"keywords": ["zoom", "out"],
		"aliases": ["@tui.zoom-out", "@tui.zoom-out-filled"],
		"filled": true,
		"filledName": "zoom-out-filled",
		"source": "taiga",
		"mirrorInRtl": false
	}
];
function normalize(value) {
	return value.trim().toLowerCase().replace(/^@tui\./, "");
}
function matchesQuery(entry, query) {
	if (!query) return true;
	const haystack = [
		entry.name,
		entry.tuiName,
		entry.category,
		...entry.aliases ?? [],
		...entry.keywords
	].join(" ").toLowerCase();
	return query.split(/\s+/).filter(Boolean).every((token) => haystack.includes(token));
}
function toTuiIconName(name) {
	const trimmed = name.trim();
	if (!trimmed) return trimmed;
	if (trimmed.startsWith("@tui.") || trimmed.startsWith("@img.") || trimmed.startsWith("@font.")) return trimmed;
	if (trimmed.startsWith("http://") || trimmed.startsWith("https://") || trimmed.startsWith("data:")) return trimmed;
	return `@tui.${normalize(trimmed)}`;
}
function getAtralumeIconCatalogEntry(name) {
	const key = normalize(name);
	return ATRALUME_ICON_CATALOG.find((entry) => entry.name === key || normalize(entry.tuiName) === key || entry.aliases?.some((alias) => normalize(alias) === key));
}
function listAtralumeIconCategories() {
	return ATRALUME_ICON_CATEGORIES;
}
function countAtralumeIcons(options = {}) {
	return searchAtralumeIcons({
		...options,
		query: "",
		limit: Number.POSITIVE_INFINITY
	}).length;
}
function searchAtralumeIcons(options = {}) {
	const query = normalize(options.query ?? "");
	const category = options.category ?? "all";
	const source = options.source ?? "all";
	const limit = typeof options.limit === "number" && options.limit > 0 ? options.limit : Number.POSITIVE_INFINITY;
	const results = [];
	for (const entry of ATRALUME_ICON_CATALOG) {
		if (category !== "all" && entry.category !== category) continue;
		if (source !== "all" && entry.source !== source) continue;
		if (!matchesQuery(entry, query)) continue;
		results.push(entry);
		if (results.length >= limit) break;
	}
	return results;
}
export { ATRALUME_ICON_CATALOG, ATRALUME_ICON_CATALOG_VERSION, ATRALUME_ICON_CATEGORIES, countAtralumeIcons, getAtralumeIconCatalogEntry, listAtralumeIconCategories, searchAtralumeIcons, toTuiIconName };

//# sourceMappingURL=osmanjimenez-atralume-icon-catalog.mjs.map