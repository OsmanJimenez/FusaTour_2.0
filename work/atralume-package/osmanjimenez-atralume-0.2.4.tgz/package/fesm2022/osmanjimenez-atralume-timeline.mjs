import { NgTemplateOutlet } from "@angular/common";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component } from "@angular/core";
import { TuiTimelineComponent, TuiTimelineItem as AtralumeTimelineItem } from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeTimeline = class AtralumeTimeline extends TuiTimelineComponent {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeTimeline,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeTimeline,
		isStandalone: true,
		selector: "atr-timeline",
		host: {
			properties: { "attr.data-orientation": "orientation()" },
			classAttribute: "atr-timeline"
		},
		providers: [{
			provide: TuiTimelineComponent,
			useExisting: AtralumeTimeline
		}],
		usesInheritance: true,
		ngImport: i0,
		template: "@for (_ of \"-\".repeat(value().length + 1); track value()[$index]) {\n  @let gap = gaps()[$index] ?? [0, 0];\n  @if (gap[0] < gap[1]) {\n    <span\n      class=\"atr-timeline__gap\"\n      [style.inline-size.%]=\"(gap[1] - gap[0]) * d()\"\n      [style.inset-inline-start.%]=\"gap[0] * d()\"\n    >\n      <ng-container\n        [ngTemplateOutlet]=\"template() || null\"\n        [ngTemplateOutletContext]=\"{ $implicit: $index }\"\n      />\n    </span>\n  }\n}\n<ng-content />\n",
		styles: [":host{display:block;position:relative;box-sizing:border-box;min-inline-size:0;transform:translateZ(0);color:var(--atr-comp-timeline-label-color, var(--atr-sys-color-on-surface));background:var(--atr-comp-timeline-track-color, var(--atr-sys-color-surface-container));border-radius:var(--atr-comp-timeline-shape, var(--atr-sys-shape-small));min-block-size:var(--atr-comp-timeline-track-size, var(--atr-sys-spacing-xl))}:host([data-orientation=vertical]){writing-mode:vertical-lr;min-inline-size:var(--atr-comp-timeline-track-size, var(--atr-sys-spacing-xl));min-block-size:var(--atr-comp-timeline-vertical-length, calc(var(--atr-sys-spacing-xl) * 8))}.atr-timeline__gap{position:absolute;block-size:100%}\n"],
		dependencies: [{
			kind: "directive",
			type: NgTemplateOutlet,
			selector: "[ngTemplateOutlet]",
			inputs: [
				"ngTemplateOutletContext",
				"ngTemplateOutlet",
				"ngTemplateOutletInjector"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeTimeline,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-timeline",
			standalone: true,
			imports: [NgTemplateOutlet],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: TuiTimelineComponent,
				useExisting: AtralumeTimeline
			}],
			host: {
				class: "atr-timeline",
				"[attr.data-orientation]": "orientation()"
			},
			template: "@for (_ of \"-\".repeat(value().length + 1); track value()[$index]) {\n  @let gap = gaps()[$index] ?? [0, 0];\n  @if (gap[0] < gap[1]) {\n    <span\n      class=\"atr-timeline__gap\"\n      [style.inline-size.%]=\"(gap[1] - gap[0]) * d()\"\n      [style.inset-inline-start.%]=\"gap[0] * d()\"\n    >\n      <ng-container\n        [ngTemplateOutlet]=\"template() || null\"\n        [ngTemplateOutletContext]=\"{ $implicit: $index }\"\n      />\n    </span>\n  }\n}\n<ng-content />\n",
			styles: [":host{display:block;position:relative;box-sizing:border-box;min-inline-size:0;transform:translateZ(0);color:var(--atr-comp-timeline-label-color, var(--atr-sys-color-on-surface));background:var(--atr-comp-timeline-track-color, var(--atr-sys-color-surface-container));border-radius:var(--atr-comp-timeline-shape, var(--atr-sys-shape-small));min-block-size:var(--atr-comp-timeline-track-size, var(--atr-sys-spacing-xl))}:host([data-orientation=vertical]){writing-mode:vertical-lr;min-inline-size:var(--atr-comp-timeline-track-size, var(--atr-sys-spacing-xl));min-block-size:var(--atr-comp-timeline-vertical-length, calc(var(--atr-sys-spacing-xl) * 8))}.atr-timeline__gap{position:absolute;block-size:100%}\n"]
		}]
	}]
});
var AtralumeTimelineHarness = class extends ComponentHarness {
	static hostSelector = "atr-timeline";
	async getOrientation() {
		return (await this.host()).getAttribute("data-orientation");
	}
	async getItemCount() {
		return (await this.locatorForAll("label[tuiTimelineItem]")()).length;
	}
};
export { AtralumeTimeline, AtralumeTimelineHarness, AtralumeTimelineItem };

//# sourceMappingURL=osmanjimenez-atralume-timeline.mjs.map