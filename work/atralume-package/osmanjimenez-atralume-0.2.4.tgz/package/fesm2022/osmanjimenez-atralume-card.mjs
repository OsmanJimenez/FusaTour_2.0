import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, Directive, input } from "@angular/core";
import { ComponentHarness } from "@angular/cdk/testing";
import * as i1 from "@taiga-ui/layout";
import { TuiCardLarge } from "@taiga-ui/layout";
var AtralumeCardActions = class AtralumeCardActions {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeCardActions,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeCardActions,
		isStandalone: true,
		selector: "[atrCardActions]",
		host: { classAttribute: "atr-card-actions" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeCardActions,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrCardActions]",
			standalone: true,
			host: { class: "atr-card-actions" }
		}]
	}]
});
var AtralumeCardActionsHarness = class extends ComponentHarness {
	static hostSelector = ".atr-card-actions";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeCardContent = class AtralumeCardContent {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeCardContent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeCardContent,
		isStandalone: true,
		selector: "[atrCardContent]",
		host: { classAttribute: "atr-card-content" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeCardContent,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrCardContent]",
			standalone: true,
			host: { class: "atr-card-content" }
		}]
	}]
});
var AtralumeCardContentHarness = class extends ComponentHarness {
	static hostSelector = ".atr-card-content";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeCardHeader = class AtralumeCardHeader {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeCardHeader,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeCardHeader,
		isStandalone: true,
		selector: "[atrCardHeader]",
		host: { classAttribute: "atr-card-header" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeCardHeader,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrCardHeader]",
			standalone: true,
			host: { class: "atr-card-header" }
		}]
	}]
});
var AtralumeCardHeaderHarness = class extends ComponentHarness {
	static hostSelector = ".atr-card-header";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeCardMedia = class AtralumeCardMedia {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeCardMedia,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeCardMedia,
		isStandalone: true,
		selector: "[atrCardMedia]",
		host: { classAttribute: "atr-card-media" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeCardMedia,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[atrCardMedia]",
			standalone: true,
			host: { class: "atr-card-media" }
		}]
	}]
});
var AtralumeCardMediaHarness = class extends ComponentHarness {
	static hostSelector = ".atr-card-media";
	async getText() {
		return (await this.host()).text();
	}
};
var AtralumeCard = class AtralumeCard {
	appearance = input("filled", ...ngDevMode ? [{ debugName: "appearance" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeCard,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeCard,
		isStandalone: true,
		selector: "atr-card",
		inputs: { appearance: {
			classPropertyName: "appearance",
			publicName: "appearance",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: {
			properties: {
				"attr.tuiCardLarge": "\"\"",
				"attr.data-appearance": "appearance()",
				"attr.data-atr-surface": "appearance() === \"glass\" ? \"glass\" : null"
			},
			classAttribute: "atr-card"
		},
		hostDirectives: [{ directive: i1.TuiCardLarge }],
		ngImport: i0,
		template: "<ng-content />\n",
		styles: [":host{display:block;overflow:hidden;border:var(--atr-comp-card-border-width) solid transparent;border-radius:var(--atr-comp-card-shape);background:var(--atr-comp-card-container-color);color:var(--atr-comp-card-label-color);font-family:var(--atr-comp-card-font-family)}:host([data-appearance=outlined]){border-color:var(--atr-comp-card-border-color)}:host([data-appearance=elevated]){background:var(--atr-sys-color-surface-container-high);box-shadow:var(--atr-comp-card-elevation);transition:box-shadow .16s ease,transform .16s ease}:host([data-appearance=elevated]:hover){box-shadow:0 .375rem .875rem color-mix(in srgb,#07152f 18%,transparent),0 .125rem .25rem color-mix(in srgb,#07152f 10%,transparent);transform:translateY(-1px)}:host([data-appearance=glass]){background:var(--atr-sys-glass-fallback-background);border-color:var(--atr-sys-glass-border-color);box-shadow:var(--atr-sys-glass-shadow)}@supports (backdrop-filter: blur(1px)){:host([data-appearance=glass]){background:var(--atr-sys-glass-background);-webkit-backdrop-filter:blur(var(--atr-sys-glass-blur));backdrop-filter:blur(var(--atr-sys-glass-blur))}}@media(prefers-reduced-motion:reduce){:host([data-appearance=elevated]){transition:none}:host([data-appearance=elevated]:hover){transform:none}}@media(forced-colors:active){:host{border-color:CanvasText;box-shadow:none;-webkit-backdrop-filter:none;backdrop-filter:none}:host([data-appearance=elevated]:hover){box-shadow:none;transform:none}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeCard,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-card",
			standalone: true,
			hostDirectives: [TuiCardLarge],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "atr-card",
				"[attr.tuiCardLarge]": "\"\"",
				"[attr.data-appearance]": "appearance()",
				"[attr.data-atr-surface]": "appearance() === \"glass\" ? \"glass\" : null"
			},
			template: "<ng-content />\n",
			styles: [":host{display:block;overflow:hidden;border:var(--atr-comp-card-border-width) solid transparent;border-radius:var(--atr-comp-card-shape);background:var(--atr-comp-card-container-color);color:var(--atr-comp-card-label-color);font-family:var(--atr-comp-card-font-family)}:host([data-appearance=outlined]){border-color:var(--atr-comp-card-border-color)}:host([data-appearance=elevated]){background:var(--atr-sys-color-surface-container-high);box-shadow:var(--atr-comp-card-elevation);transition:box-shadow .16s ease,transform .16s ease}:host([data-appearance=elevated]:hover){box-shadow:0 .375rem .875rem color-mix(in srgb,#07152f 18%,transparent),0 .125rem .25rem color-mix(in srgb,#07152f 10%,transparent);transform:translateY(-1px)}:host([data-appearance=glass]){background:var(--atr-sys-glass-fallback-background);border-color:var(--atr-sys-glass-border-color);box-shadow:var(--atr-sys-glass-shadow)}@supports (backdrop-filter: blur(1px)){:host([data-appearance=glass]){background:var(--atr-sys-glass-background);-webkit-backdrop-filter:blur(var(--atr-sys-glass-blur));backdrop-filter:blur(var(--atr-sys-glass-blur))}}@media(prefers-reduced-motion:reduce){:host([data-appearance=elevated]){transition:none}:host([data-appearance=elevated]:hover){transform:none}}@media(forced-colors:active){:host{border-color:CanvasText;box-shadow:none;-webkit-backdrop-filter:none;backdrop-filter:none}:host([data-appearance=elevated]:hover){box-shadow:none;transform:none}}\n"]
		}]
	}],
	propDecorators: { appearance: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "appearance",
			required: false
		}]
	}] }
});
var AtralumeCardHarness = class extends ComponentHarness {
	static hostSelector = "atr-card";
	async getText() {
		return (await this.host()).text();
	}
};
export { AtralumeCard, AtralumeCardActions, AtralumeCardActionsHarness, AtralumeCardContent, AtralumeCardContentHarness, AtralumeCardHarness, AtralumeCardHeader, AtralumeCardHeaderHarness, AtralumeCardMedia, AtralumeCardMediaHarness };

//# sourceMappingURL=osmanjimenez-atralume-card.mjs.map