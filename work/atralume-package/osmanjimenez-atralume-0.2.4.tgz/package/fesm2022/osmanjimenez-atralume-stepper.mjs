import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, Directive, ElementRef, InjectionToken, Injector, afterNextRender, booleanAttribute, computed, contentChildren, forwardRef, inject, input, model, output, viewChild } from "@angular/core";
import { NgTemplateOutlet } from "@angular/common";
import * as i1 from "@taiga-ui/kit";
import { TuiStepper } from "@taiga-ui/kit";
import { ɵAtralumeControlIds } from "@osmanjimenez/atralume";
import { ComponentHarness } from "@angular/cdk/testing";
const STEPPER_CONTEXT = new InjectionToken("AtralumeStepper");
var AtralumeStep = class AtralumeStep {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	stepId = input(inject(ɵAtralumeControlIds).create(), ...ngDevMode ? [{ debugName: "stepId" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	stepState = input("normal", ...ngDevMode ? [{ debugName: "stepState" }] : /* istanbul ignore next */ []);
	icon = input("", ...ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []);
	content = viewChild("content", ...ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []);
	owner = inject(STEPPER_CONTEXT);
	belongsTo(owner) {
		return this.owner === owner;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeStep,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.4",
		type: AtralumeStep,
		isStandalone: true,
		selector: "atr-step",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			stepId: {
				classPropertyName: "stepId",
				publicName: "stepId",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			stepState: {
				classPropertyName: "stepState",
				publicName: "stepState",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			icon: {
				classPropertyName: "icon",
				publicName: "icon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		viewQueries: [{
			propertyName: "content",
			first: true,
			predicate: ["content"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<ng-template #content><ng-content /></ng-template>\n",
		styles: [":host{display:contents}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeStep,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-step",
			standalone: true,
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-template #content><ng-content /></ng-template>\n",
			styles: [":host{display:contents}\n"]
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		stepId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "stepId",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		stepState: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "stepState",
				required: false
			}]
		}],
		icon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}],
		content: [{
			type: i0.ViewChild,
			args: ["content", { isSignal: true }]
		}]
	}
});
var AtralumeStepper = class AtralumeStepper {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	selected = model(0, ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	orientation = input("horizontal", ...ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []);
	stepChange = output();
	projected = contentChildren(AtralumeStep, {
		...ngDevMode ? { debugName: "projected" } : /* istanbul ignore next */ {},
		descendants: true
	});
	element = inject(ElementRef).nativeElement;
	injector = inject(Injector);
	steps = computed(() => {
		const steps = this.projected().filter((step) => step.belongsTo(this));
		const ids = steps.map((step) => step.stepId());
		if (new Set(ids).size !== ids.length) throw new Error("Stepper IDs must be unique.");
		return steps;
	}, ...ngDevMode ? [{ debugName: "steps" }] : /* istanbul ignore next */ []);
	activeIndex = computed(() => {
		const steps = this.steps();
		if (!steps.length) return 0;
		const requested = Math.max(0, Math.min(steps.length - 1, this.selected()));
		return steps[requested] && !steps[requested].disabled() ? requested : Math.max(0, steps.findIndex((step) => !step.disabled()));
	}, ...ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []);
	activeStep = computed(() => this.steps()[this.activeIndex()] ?? null, ...ngDevMode ? [{ debugName: "activeStep" }] : /* istanbul ignore next */ []);
	canNext = computed(() => !this.disabled() && this.activeIndex() < this.steps().length - 1 && !!this.steps()[this.activeIndex() + 1] && !this.steps()[this.activeIndex() + 1].disabled(), ...ngDevMode ? [{ debugName: "canNext" }] : /* istanbul ignore next */ []);
	canPrevious = computed(() => !this.disabled() && this.activeIndex() > 0 && !!this.steps()[this.activeIndex() - 1] && !this.steps()[this.activeIndex() - 1].disabled(), ...ngDevMode ? [{ debugName: "canPrevious" }] : /* istanbul ignore next */ []);
	activate(index) {
		const target = this.steps()[index];
		if (this.disabled() || !target || target.disabled()) return;
		const previous = this.activeIndex();
		if (index === previous) return;
		this.selected.set(index);
		this.stepChange.emit({
			previous,
			current: index
		});
		afterNextRender(() => this.element.querySelector(".atr-step-content")?.focus({ preventScroll: true }), { injector: this.injector });
	}
	next() {
		if (this.canNext()) this.activate(this.activeIndex() + 1);
	}
	previous() {
		if (this.canPrevious()) this.activate(this.activeIndex() - 1);
	}
	reset() {
		this.selected.set(0);
	}
	onIndex(index) {
		this.activate(index);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeStepper,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeStepper,
		isStandalone: true,
		selector: "atr-stepper",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			selected: {
				classPropertyName: "selected",
				publicName: "selected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			orientation: {
				classPropertyName: "orientation",
				publicName: "orientation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			selected: "selectedChange",
			stepChange: "stepChange"
		},
		host: {
			properties: { "attr.data-orientation": "orientation()" },
			classAttribute: "atr-stepper"
		},
		providers: [{
			provide: STEPPER_CONTEXT,
			useExisting: forwardRef(() => AtralumeStepper)
		}],
		queries: [{
			propertyName: "projected",
			predicate: AtralumeStep,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<div hidden>\n  <ng-content />\n</div>\n<p class=\"atr-stepper-progress\" aria-live=\"polite\">\n  Step {{ activeIndex() + 1 }} of {{ steps().length }}\n</p>\n<nav [attr.aria-label]=\"label() + ' steps'\">\n  <tui-stepper\n    [orientation]=\"orientation()\"\n    [activeItemIndex]=\"activeIndex()\"\n    (activeItemIndexChange)=\"onIndex($event)\"\n  >\n    @for (step of steps(); track step.stepId(); let index = $index) {\n      <button\n        tuiStep\n        data-step-header\n        type=\"button\"\n        [id]=\"step.stepId() + '-header'\"\n        [stepState]=\"step.stepState()\"\n        [icon]=\"step.icon()\"\n        [disabled]=\"disabled() || step.disabled()\"\n        [attr.aria-controls]=\"\n          activeIndex() === index ? step.stepId() + '-panel' : null\n        \"\n        [attr.aria-current]=\"activeIndex() === index ? 'step' : null\"\n      >\n        {{ step.label() }}\n      </button>\n    }\n  </tui-stepper>\n</nav>\n@if (activeStep(); as step) {\n  <section\n    class=\"atr-step-content\"\n    role=\"region\"\n    [id]=\"step.stepId() + '-panel'\"\n    [attr.aria-labelledby]=\"step.stepId() + '-header'\"\n    tabindex=\"-1\"\n  >\n    @if (step.content(); as content) {\n      <ng-container [ngTemplateOutlet]=\"content\" />\n    }\n  </section>\n}\n",
		styles: [":host{display:flex;flex-direction:column;gap:var(--atr-comp-stepper-gap);min-inline-size:0;color:var(--atr-comp-stepper-label-color);font-family:var(--atr-ref-font-family-plain)}.atr-stepper-progress{margin:0;color:var(--atr-sys-color-on-surface-variant);font-size:.8125rem;font-weight:500;letter-spacing:.01em}nav{min-inline-size:0}:host ::ng-deep [tuiStep],:host ::ng-deep tui-stepper button{min-block-size:var(--atr-sys-touch-target-minimum);border-radius:var(--atr-sys-shape-small);transition:background-color var(--atr-sys-motion-duration-short) var(--atr-sys-motion-easing-standard),color var(--atr-sys-motion-duration-short) var(--atr-sys-motion-easing-standard)}:host ::ng-deep [tuiStep][aria-current=step]{background:var(--atr-comp-stepper-selected-container-color);color:var(--atr-comp-stepper-selected-label-color);font-weight:600}:host ::ng-deep [tuiStep]:focus-visible{outline:var(--atr-sys-focus-ring-width) solid var(--atr-comp-stepper-focus-color);outline-offset:var(--atr-sys-focus-ring-offset)}.atr-step-content{display:flex;flex-direction:column;gap:var(--atr-sys-spacing-md);min-inline-size:0;padding:var(--atr-sys-spacing-lg);border:1px solid var(--atr-comp-stepper-border-color);border-radius:var(--atr-comp-stepper-shape);background:var(--atr-comp-stepper-container-color)}.atr-step-content:focus-visible{outline:var(--atr-sys-focus-ring-width) solid var(--atr-comp-stepper-focus-color);outline-offset:var(--atr-sys-focus-ring-offset)}:host([data-orientation=vertical]){display:grid;grid-template-columns:minmax(11rem,15rem) minmax(0,1fr);grid-template-rows:auto 1fr;column-gap:var(--atr-sys-spacing-lg);row-gap:var(--atr-comp-stepper-gap);align-items:start}:host([data-orientation=vertical]) .atr-stepper-progress{grid-column:1/-1}:host([data-orientation=vertical]) nav{grid-column:1;grid-row:2}:host([data-orientation=vertical]) .atr-step-content{grid-column:2;grid-row:2;min-block-size:100%}@media(prefers-reduced-motion:reduce){:host ::ng-deep [tuiStep],:host ::ng-deep tui-stepper button{transition:none}}\n"],
		dependencies: [
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			},
			{
				kind: "component",
				type: i1.TuiStepperComponent,
				selector: "tui-stepper",
				inputs: ["orientation", "activeItemIndex"],
				outputs: ["activeItemIndexChange"]
			},
			{
				kind: "component",
				type: i1.TuiStep,
				selector: "button[tuiStep], a[tuiStep]:not([routerLink]), a[tuiStep][routerLink][routerLinkActive]",
				inputs: ["stepState", "icon"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeStepper,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-stepper",
			standalone: true,
			imports: [NgTemplateOutlet, TuiStepper],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: STEPPER_CONTEXT,
				useExisting: forwardRef(() => AtralumeStepper)
			}],
			host: {
				class: "atr-stepper",
				"[attr.data-orientation]": "orientation()"
			},
			template: "<div hidden>\n  <ng-content />\n</div>\n<p class=\"atr-stepper-progress\" aria-live=\"polite\">\n  Step {{ activeIndex() + 1 }} of {{ steps().length }}\n</p>\n<nav [attr.aria-label]=\"label() + ' steps'\">\n  <tui-stepper\n    [orientation]=\"orientation()\"\n    [activeItemIndex]=\"activeIndex()\"\n    (activeItemIndexChange)=\"onIndex($event)\"\n  >\n    @for (step of steps(); track step.stepId(); let index = $index) {\n      <button\n        tuiStep\n        data-step-header\n        type=\"button\"\n        [id]=\"step.stepId() + '-header'\"\n        [stepState]=\"step.stepState()\"\n        [icon]=\"step.icon()\"\n        [disabled]=\"disabled() || step.disabled()\"\n        [attr.aria-controls]=\"\n          activeIndex() === index ? step.stepId() + '-panel' : null\n        \"\n        [attr.aria-current]=\"activeIndex() === index ? 'step' : null\"\n      >\n        {{ step.label() }}\n      </button>\n    }\n  </tui-stepper>\n</nav>\n@if (activeStep(); as step) {\n  <section\n    class=\"atr-step-content\"\n    role=\"region\"\n    [id]=\"step.stepId() + '-panel'\"\n    [attr.aria-labelledby]=\"step.stepId() + '-header'\"\n    tabindex=\"-1\"\n  >\n    @if (step.content(); as content) {\n      <ng-container [ngTemplateOutlet]=\"content\" />\n    }\n  </section>\n}\n",
			styles: [":host{display:flex;flex-direction:column;gap:var(--atr-comp-stepper-gap);min-inline-size:0;color:var(--atr-comp-stepper-label-color);font-family:var(--atr-ref-font-family-plain)}.atr-stepper-progress{margin:0;color:var(--atr-sys-color-on-surface-variant);font-size:.8125rem;font-weight:500;letter-spacing:.01em}nav{min-inline-size:0}:host ::ng-deep [tuiStep],:host ::ng-deep tui-stepper button{min-block-size:var(--atr-sys-touch-target-minimum);border-radius:var(--atr-sys-shape-small);transition:background-color var(--atr-sys-motion-duration-short) var(--atr-sys-motion-easing-standard),color var(--atr-sys-motion-duration-short) var(--atr-sys-motion-easing-standard)}:host ::ng-deep [tuiStep][aria-current=step]{background:var(--atr-comp-stepper-selected-container-color);color:var(--atr-comp-stepper-selected-label-color);font-weight:600}:host ::ng-deep [tuiStep]:focus-visible{outline:var(--atr-sys-focus-ring-width) solid var(--atr-comp-stepper-focus-color);outline-offset:var(--atr-sys-focus-ring-offset)}.atr-step-content{display:flex;flex-direction:column;gap:var(--atr-sys-spacing-md);min-inline-size:0;padding:var(--atr-sys-spacing-lg);border:1px solid var(--atr-comp-stepper-border-color);border-radius:var(--atr-comp-stepper-shape);background:var(--atr-comp-stepper-container-color)}.atr-step-content:focus-visible{outline:var(--atr-sys-focus-ring-width) solid var(--atr-comp-stepper-focus-color);outline-offset:var(--atr-sys-focus-ring-offset)}:host([data-orientation=vertical]){display:grid;grid-template-columns:minmax(11rem,15rem) minmax(0,1fr);grid-template-rows:auto 1fr;column-gap:var(--atr-sys-spacing-lg);row-gap:var(--atr-comp-stepper-gap);align-items:start}:host([data-orientation=vertical]) .atr-stepper-progress{grid-column:1/-1}:host([data-orientation=vertical]) nav{grid-column:1;grid-row:2}:host([data-orientation=vertical]) .atr-step-content{grid-column:2;grid-row:2;min-block-size:100%}@media(prefers-reduced-motion:reduce){:host ::ng-deep [tuiStep],:host ::ng-deep tui-stepper button{transition:none}}\n"]
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		selected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selected",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["selectedChange"]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		orientation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "orientation",
				required: false
			}]
		}],
		stepChange: [{
			type: i0.Output,
			args: ["stepChange"]
		}],
		projected: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => AtralumeStep), {
				descendants: true,
				isSignal: true
			}]
		}]
	}
});
var AtralumeStepperNext = class AtralumeStepperNext {
	stepper = inject(STEPPER_CONTEXT);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeStepperNext,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeStepperNext,
		isStandalone: true,
		selector: "button[atrStepperNext]",
		host: {
			attributes: { "type": "button" },
			listeners: { "click": "stepper.next()" }
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeStepperNext,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[atrStepperNext]",
			standalone: true,
			host: {
				type: "button",
				"(click)": "stepper.next()"
			}
		}]
	}]
});
var AtralumeStepperPrevious = class AtralumeStepperPrevious {
	stepper = inject(STEPPER_CONTEXT);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeStepperPrevious,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.4",
		type: AtralumeStepperPrevious,
		isStandalone: true,
		selector: "button[atrStepperPrevious]",
		host: {
			attributes: { "type": "button" },
			listeners: { "click": "stepper.previous()" }
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeStepperPrevious,
	decorators: [{
		type: Directive,
		args: [{
			selector: "button[atrStepperPrevious]",
			standalone: true,
			host: {
				type: "button",
				"(click)": "stepper.previous()"
			}
		}]
	}]
});
var AtralumeStepperHarness = class extends ComponentHarness {
	static hostSelector = "atr-stepper";
	headers = this.locatorForAll("button[tuiStep]");
	async getLabels() {
		return Promise.all((await this.headers()).map((header) => header.text()));
	}
	async getActiveIndex() {
		const headers = await this.headers();
		for (let index = 0; index < headers.length; index++) if (await headers[index].getAttribute("aria-current") === "step") return index;
		return -1;
	}
	async select(index) {
		const headers = await this.headers();
		if (!headers[index]) throw new Error("Step not found: " + index);
		await headers[index].click();
	}
	async next() {
		await this.select(await this.getActiveIndex() + 1);
	}
	async previous() {
		await this.select(await this.getActiveIndex() - 1);
	}
	async getContent() {
		return (await this.locatorFor("[role=\"region\"]")()).text();
	}
};
export { AtralumeStep, AtralumeStepper, AtralumeStepperHarness, AtralumeStepperNext, AtralumeStepperPrevious };

//# sourceMappingURL=osmanjimenez-atralume-stepper.mjs.map