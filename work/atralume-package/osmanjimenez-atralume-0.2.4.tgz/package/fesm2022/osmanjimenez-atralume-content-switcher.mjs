import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, booleanAttribute, input, model } from "@angular/core";
import { TuiSegmented } from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeContentSwitcher = class AtralumeContentSwitcher {
	size = input("m", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	activeItemIndex = model(0, ...ngDevMode ? [{ debugName: "activeItemIndex" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeContentSwitcher,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeContentSwitcher,
		isStandalone: true,
		selector: "atr-content-switcher",
		inputs: {
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			activeItemIndex: {
				classPropertyName: "activeItemIndex",
				publicName: "activeItemIndex",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { activeItemIndex: "activeItemIndexChange" },
		host: {
			properties: {
				"attr.data-size": "size()",
				"attr.data-disabled": "disabled() ? '' : null"
			},
			classAttribute: "atr-content-switcher"
		},
		ngImport: i0,
		template: "<tui-segmented\n  [size]=\"size()\"\n  [(activeItemIndex)]=\"activeItemIndex\"\n  [disabled]=\"disabled()\"\n>\n  <ng-content />\n</tui-segmented>\n",
		styles: [":host{display:inline-block;max-inline-size:100%;color:var(--atr-comp-content-switcher-label-color, var(--atr-sys-color-on-surface))}tui-segmented{background:var(--atr-comp-content-switcher-container-color, var(--atr-sys-color-surface-container));border-radius:var(--atr-comp-content-switcher-shape, var(--atr-sys-shape-medium))}:host([data-disabled]){opacity:var(--atr-sys-state-disabled-opacity, .38);pointer-events:none}\n"],
		dependencies: [{
			kind: "component",
			type: TuiSegmented,
			selector: "tui-segmented",
			inputs: [
				"size",
				"activeItemIndex",
				"disabled"
			],
			outputs: ["activeItemIndexChange"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeContentSwitcher,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-content-switcher",
			standalone: true,
			imports: [TuiSegmented],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "atr-content-switcher",
				"[attr.data-size]": "size()",
				"[attr.data-disabled]": "disabled() ? '' : null"
			},
			template: "<tui-segmented\n  [size]=\"size()\"\n  [(activeItemIndex)]=\"activeItemIndex\"\n  [disabled]=\"disabled()\"\n>\n  <ng-content />\n</tui-segmented>\n",
			styles: [":host{display:inline-block;max-inline-size:100%;color:var(--atr-comp-content-switcher-label-color, var(--atr-sys-color-on-surface))}tui-segmented{background:var(--atr-comp-content-switcher-container-color, var(--atr-sys-color-surface-container));border-radius:var(--atr-comp-content-switcher-shape, var(--atr-sys-shape-medium))}:host([data-disabled]){opacity:var(--atr-sys-state-disabled-opacity, .38);pointer-events:none}\n"]
		}]
	}],
	propDecorators: {
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		activeItemIndex: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "activeItemIndex",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["activeItemIndexChange"]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}]
	}
});
var AtralumeContentSwitcherHarness = class extends ComponentHarness {
	static hostSelector = "atr-content-switcher";
	async getActiveItemIndex() {
		const buttons = await this.locatorForAll("tui-segmented > button, tui-segmented > a")();
		for (let index = 0; index < buttons.length; index += 1) {
			const pressed = await buttons[index]?.getAttribute("aria-pressed");
			const current = await buttons[index]?.getAttribute("aria-current");
			if (pressed === "true" || current === "true" || current === "page") return index;
		}
		return 0;
	}
	async isDisabled() {
		return (await this.host()).getAttribute("data-disabled") !== null;
	}
	async getOptionCount() {
		return (await this.locatorForAll("tui-segmented > button, tui-segmented > a")()).length;
	}
};
export { AtralumeContentSwitcher, AtralumeContentSwitcherHarness };

//# sourceMappingURL=osmanjimenez-atralume-content-switcher.mjs.map