import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, booleanAttribute, input } from "@angular/core";
import { TuiActionBar } from "@taiga-ui/kit";
import { ComponentHarness } from "@angular/cdk/testing";
var AtralumeActionBar = class AtralumeActionBar {
	expanded = input(false, {
		...ngDevMode ? { debugName: "expanded" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	size = input("m", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeActionBar,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.4",
		type: AtralumeActionBar,
		isStandalone: true,
		selector: "atr-action-bar",
		inputs: {
			expanded: {
				classPropertyName: "expanded",
				publicName: "expanded",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: {
				"attr.data-size": "size()",
				"attr.data-expanded": "expanded() ? '' : null"
			},
			classAttribute: "atr-action-bar"
		},
		ngImport: i0,
		template: "<tui-action-bar [expanded]=\"expanded()\" [size]=\"size()\">\n  <ng-content />\n</tui-action-bar>\n",
		styles: [":host{display:block;color:var(--atr-comp-action-bar-label-color, var(--atr-sys-color-on-surface))}tui-action-bar{background:var(--atr-comp-action-bar-container-color, var(--atr-sys-color-surface-container-high));border-radius:var(--atr-comp-action-bar-shape, var(--atr-sys-shape-medium));box-shadow:var(--atr-comp-action-bar-elevation, var(--atr-sys-elevation-2))}\n"],
		dependencies: [{
			kind: "component",
			type: TuiActionBar,
			selector: "tui-action-bar",
			inputs: ["expanded", "size"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeActionBar,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-action-bar",
			standalone: true,
			imports: [TuiActionBar],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "atr-action-bar",
				"[attr.data-size]": "size()",
				"[attr.data-expanded]": "expanded() ? '' : null"
			},
			template: "<tui-action-bar [expanded]=\"expanded()\" [size]=\"size()\">\n  <ng-content />\n</tui-action-bar>\n",
			styles: [":host{display:block;color:var(--atr-comp-action-bar-label-color, var(--atr-sys-color-on-surface))}tui-action-bar{background:var(--atr-comp-action-bar-container-color, var(--atr-sys-color-surface-container-high));border-radius:var(--atr-comp-action-bar-shape, var(--atr-sys-shape-medium));box-shadow:var(--atr-comp-action-bar-elevation, var(--atr-sys-elevation-2))}\n"]
		}]
	}],
	propDecorators: {
		expanded: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "expanded",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}]
	}
});
var AtralumeActionBarHarness = class extends ComponentHarness {
	static hostSelector = "atr-action-bar";
	async isExpanded() {
		return (await this.host()).getAttribute("data-expanded") !== null;
	}
	async getSize() {
		return (await this.host()).getAttribute("data-size");
	}
	async getActionCount() {
		return (await this.locatorForAll("button, a")()).length;
	}
};
export { AtralumeActionBar, AtralumeActionBarHarness };

//# sourceMappingURL=osmanjimenez-atralume-action-bar.mjs.map