import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, ElementRef, booleanAttribute, computed, effect, inject, input, signal } from "@angular/core";
import { NgStyle } from "@angular/common";
import { AtralumeButton } from "@osmanjimenez/atralume/button";
var AtralumeImage360 = class AtralumeImage360 {
	src = input.required(...ngDevMode ? [{ debugName: "src" }] : /* istanbul ignore next */ []);
	alt = input.required(...ngDevMode ? [{ debugName: "alt" }] : /* istanbul ignore next */ []);
	label = input("Vista panorámica 360 grados", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	enableGyro = input(true, {
		...ngDevMode ? { debugName: "enableGyro" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	enableVr = input(true, {
		...ngDevMode ? { debugName: "enableVr" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	initialYaw = input(180, ...ngDevMode ? [{ debugName: "initialYaw" }] : /* istanbul ignore next */ []);
	initialPitch = input(0, ...ngDevMode ? [{ debugName: "initialPitch" }] : /* istanbul ignore next */ []);
	yaw = signal(180, ...ngDevMode ? [{ debugName: "yaw" }] : /* istanbul ignore next */ []);
	pitch = signal(0, ...ngDevMode ? [{ debugName: "pitch" }] : /* istanbul ignore next */ []);
	zoom = signal(1, ...ngDevMode ? [{ debugName: "zoom" }] : /* istanbul ignore next */ []);
	gyroActive = signal(false, ...ngDevMode ? [{ debugName: "gyroActive" }] : /* istanbul ignore next */ []);
	vr = signal(false, ...ngDevMode ? [{ debugName: "vr" }] : /* istanbul ignore next */ []);
	chromeVisible = signal(true, ...ngDevMode ? [{ debugName: "chromeVisible" }] : /* istanbul ignore next */ []);
	hintVisible = signal(true, ...ngDevMode ? [{ debugName: "hintVisible" }] : /* istanbul ignore next */ []);
	status = signal("loading", ...ngDevMode ? [{ debugName: "status" }] : /* istanbul ignore next */ []);
	gyroSupported = signal(false, ...ngDevMode ? [{ debugName: "gyroSupported" }] : /* istanbul ignore next */ []);
	gyroDenied = signal(false, ...ngDevMode ? [{ debugName: "gyroDenied" }] : /* istanbul ignore next */ []);
	yawLabel = computed(() => `${Math.round(this.yaw())}°`, ...ngDevMode ? [{ debugName: "yawLabel" }] : /* istanbul ignore next */ []);
	pitchClamp = computed(() => Math.max(-28, Math.min(28, this.pitch())), ...ngDevMode ? [{ debugName: "pitchClamp" }] : /* istanbul ignore next */ []);
	sceneStyle = computed(() => this.buildSceneStyle(0), ...ngDevMode ? [{ debugName: "sceneStyle" }] : /* istanbul ignore next */ []);
	sceneStyleRight = computed(() => this.buildSceneStyle(2.4), ...ngDevMode ? [{ debugName: "sceneStyleRight" }] : /* istanbul ignore next */ []);
	ariaDescription = computed(() => {
		const parts = [
			this.label(),
			this.alt(),
			"Arrastra para mirar. Pellizca o usa + y − para zoom."
		];
		if (this.enableGyro() && this.gyroSupported()) parts.push("Activa el giroscopio para mover el teléfono.");
		if (this.enableVr()) parts.push("VR abre una vista estereoscópica.");
		parts.push("Flechas del teclado también giran la escena.");
		return parts.join(" ");
	}, ...ngDevMode ? [{ debugName: "ariaDescription" }] : /* istanbul ignore next */ []);
	host = inject(ElementRef);
	destroyRef = inject(DestroyRef);
	pointers = /* @__PURE__ */ new Map();
	dragOrigin = null;
	pinchOrigin = null;
	samples = [];
	velocity = {
		yaw: 0,
		pitch: 0
	};
	inertiaFrame = 0;
	chromeTimer = 0;
	hintTimer = 0;
	reducedMotion = false;
	orientationHandler = null;
	gyroBase = null;
	imageProbe = null;
	constructor() {
		if (typeof window !== "undefined") {
			this.reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
			this.gyroSupported.set("DeviceOrientationEvent" in window || "ondeviceorientation" in window);
		}
		this.destroyRef.onDestroy(() => {
			this.stopInertia();
			this.detachGyro();
			window.clearTimeout(this.chromeTimer);
			window.clearTimeout(this.hintTimer);
			this.imageProbe = null;
			if (document.fullscreenElement === this.host.nativeElement) document.exitFullscreen?.();
		});
		effect(() => {
			const src = this.src();
			this.preload(src);
		});
		queueMicrotask(() => {
			this.yaw.set(this.normalizeYaw(this.initialYaw()));
			this.pitch.set(this.clampPitch(this.initialPitch()));
			if (!this.reducedMotion) this.hintTimer = window.setTimeout(() => this.hintVisible.set(false), 5200);
			else this.hintVisible.set(false);
		});
	}
	startPointer(event) {
		const target = event.currentTarget;
		if (!(target instanceof HTMLElement)) return;
		if (event.target instanceof Element && event.target.closest("button, a, input, label, .atr-image-360__chrome, .atr-image-360__state")) return;
		target.setPointerCapture(event.pointerId);
		this.pointers.set(event.pointerId, {
			id: event.pointerId,
			x: event.clientX,
			y: event.clientY
		});
		this.stopInertia();
		this.showChrome();
		this.hintVisible.set(false);
		if (this.pointers.size === 1) {
			this.dragOrigin = {
				x: event.clientX,
				y: event.clientY,
				yaw: this.yaw(),
				pitch: this.pitch()
			};
			this.samples = [{
				t: performance.now(),
				x: event.clientX,
				y: event.clientY
			}];
			this.pinchOrigin = null;
		} else if (this.pointers.size === 2) {
			this.dragOrigin = null;
			this.pinchOrigin = {
				distance: this.pointerDistance(),
				zoom: this.zoom()
			};
		}
	}
	movePointer(event) {
		if (!this.pointers.has(event.pointerId)) return;
		this.pointers.set(event.pointerId, {
			id: event.pointerId,
			x: event.clientX,
			y: event.clientY
		});
		if (this.pointers.size >= 2 && this.pinchOrigin) {
			const distance = this.pointerDistance();
			if (distance > 0 && this.pinchOrigin.distance > 0) {
				const ratio = distance / this.pinchOrigin.distance;
				this.setZoom(this.pinchOrigin.zoom * ratio);
			}
			return;
		}
		if (!this.dragOrigin) return;
		const dx = event.clientX - this.dragOrigin.x;
		const dy = event.clientY - this.dragOrigin.y;
		const sensitivity = .18 / this.zoom();
		this.yaw.set(this.normalizeYaw(this.dragOrigin.yaw - dx * sensitivity));
		this.pitch.set(this.clampPitch(this.dragOrigin.pitch + dy * sensitivity * .55));
		const now = performance.now();
		this.samples.push({
			t: now,
			x: event.clientX,
			y: event.clientY
		});
		if (this.samples.length > 5) this.samples.shift();
	}
	endPointer(event) {
		if (!this.pointers.has(event.pointerId)) return;
		this.pointers.delete(event.pointerId);
		if (this.pointers.size === 1) {
			const remaining = [...this.pointers.values()][0];
			this.dragOrigin = {
				x: remaining.x,
				y: remaining.y,
				yaw: this.yaw(),
				pitch: this.pitch()
			};
			this.pinchOrigin = null;
			this.samples = [{
				t: performance.now(),
				x: remaining.x,
				y: remaining.y
			}];
			return;
		}
		if (this.pointers.size === 0) {
			this.dragOrigin = null;
			this.pinchOrigin = null;
			this.launchInertia();
			this.scheduleChromeHide();
		}
	}
	onKey(event) {
		const step = event.shiftKey ? 12 : 4;
		const action = {
			ArrowLeft: () => this.nudgeYaw(-step),
			ArrowRight: () => this.nudgeYaw(step),
			ArrowUp: () => this.nudgePitch(-step * .45),
			ArrowDown: () => this.nudgePitch(step * .45),
			"+": () => this.changeZoom(.12),
			"=": () => this.changeZoom(.12),
			"-": () => this.changeZoom(-.12),
			Home: () => this.reset(),
			Escape: () => {
				if (this.vr()) this.toggleVr(false);
			},
			g: () => void this.toggleGyro(),
			G: () => void this.toggleGyro(),
			v: () => this.toggleVr(),
			V: () => this.toggleVr()
		}[event.key];
		if (!action) return;
		event.preventDefault();
		this.showChrome();
		this.hintVisible.set(false);
		action();
	}
	onWheel(event) {
		event.preventDefault();
		this.showChrome();
		this.changeZoom(event.deltaY > 0 ? -.1 : .1);
	}
	onSceneActivate() {
		this.showChrome();
	}
	changeZoom(delta) {
		this.setZoom(this.zoom() + delta);
	}
	reset() {
		this.stopInertia();
		this.yaw.set(this.normalizeYaw(this.initialYaw()));
		this.pitch.set(this.clampPitch(this.initialPitch()));
		this.zoom.set(1);
		this.gyroBase = null;
		this.showChrome();
	}
	async toggleGyro() {
		if (!this.enableGyro() || !this.gyroSupported()) return;
		if (this.gyroActive()) {
			this.detachGyro();
			this.gyroActive.set(false);
			this.showChrome();
			return;
		}
		const Orientation = DeviceOrientationEvent;
		if (typeof Orientation.requestPermission === "function") try {
			if (await Orientation.requestPermission() !== "granted") {
				this.gyroDenied.set(true);
				return;
			}
		} catch {
			this.gyroDenied.set(true);
			return;
		}
		this.gyroDenied.set(false);
		this.gyroBase = null;
		this.orientationHandler = (event) => {
			if (event.alpha == null || event.beta == null) return;
			if (!this.gyroBase) this.gyroBase = {
				alpha: event.alpha,
				beta: event.beta
			};
			const yawDelta = this.shortestAngle(event.alpha - this.gyroBase.alpha);
			const pitchDelta = event.beta - this.gyroBase.beta;
			this.yaw.set(this.normalizeYaw(this.initialYaw() - yawDelta));
			this.pitch.set(this.clampPitch(this.initialPitch() + pitchDelta * .35));
		};
		window.addEventListener("deviceorientation", this.orientationHandler, true);
		this.gyroActive.set(true);
		this.hintVisible.set(false);
		this.showChrome();
	}
	toggleVr(force) {
		if (!this.enableVr()) return;
		const next = force ?? !this.vr();
		this.vr.set(next);
		this.showChrome();
		if (next) this.enterFullscreen();
	}
	async fullscreen() {
		await this.enterFullscreen();
		this.showChrome();
	}
	retryLoad() {
		this.preload(this.src());
	}
	async enterFullscreen() {
		const el = this.host.nativeElement;
		try {
			if (document.fullscreenElement === el) {
				await document.exitFullscreen?.();
				return;
			}
			await el.requestFullscreen?.();
		} catch {}
	}
	preload(src) {
		this.status.set("loading");
		const img = new Image();
		this.imageProbe = img;
		img.decoding = "async";
		img.onload = () => {
			if (this.imageProbe !== img) return;
			this.status.set("ready");
		};
		img.onerror = () => {
			if (this.imageProbe !== img) return;
			this.status.set("error");
		};
		img.src = src;
	}
	buildSceneStyle(yawOffsetDeg) {
		const yaw = this.normalizeYaw(this.yaw() + yawOffsetDeg);
		const pitch = this.pitchClamp();
		const zoom = this.zoom();
		const x = yaw / 360 * 100;
		const y = 50 - pitch;
		return {
			"background-image": `url("${this.src()}")`,
			"background-position": `${x}% ${y}%`,
			"background-size": `${Math.round(220 * zoom)}% auto`
		};
	}
	pointerDistance() {
		const pts = [...this.pointers.values()];
		if (pts.length < 2) return 0;
		const [a, b] = pts;
		return Math.hypot(a.x - b.x, a.y - b.y);
	}
	launchInertia() {
		if (this.reducedMotion || this.samples.length < 2) return;
		const first = this.samples[0];
		const last = this.samples[this.samples.length - 1];
		const dt = Math.max(16, last.t - first.t);
		const sensitivity = .18 / this.zoom();
		this.velocity = {
			yaw: -((last.x - first.x) / dt) * sensitivity * 16,
			pitch: (last.y - first.y) / dt * sensitivity * .55 * 16
		};
		if (Math.abs(this.velocity.yaw) < .05 && Math.abs(this.velocity.pitch) < .03) return;
		const tick = () => {
			this.velocity.yaw *= .92;
			this.velocity.pitch *= .9;
			if (Math.abs(this.velocity.yaw) < .02 && Math.abs(this.velocity.pitch) < .015) {
				this.stopInertia();
				return;
			}
			this.yaw.set(this.normalizeYaw(this.yaw() + this.velocity.yaw));
			this.pitch.set(this.clampPitch(this.pitch() + this.velocity.pitch));
			this.inertiaFrame = requestAnimationFrame(tick);
		};
		this.inertiaFrame = requestAnimationFrame(tick);
	}
	stopInertia() {
		if (this.inertiaFrame) {
			cancelAnimationFrame(this.inertiaFrame);
			this.inertiaFrame = 0;
		}
		this.velocity = {
			yaw: 0,
			pitch: 0
		};
	}
	detachGyro() {
		if (this.orientationHandler) {
			window.removeEventListener("deviceorientation", this.orientationHandler, true);
			this.orientationHandler = null;
		}
		this.gyroBase = null;
	}
	showChrome() {
		this.chromeVisible.set(true);
		this.scheduleChromeHide();
	}
	scheduleChromeHide() {
		window.clearTimeout(this.chromeTimer);
		this.chromeTimer = window.setTimeout(() => {
			if (!this.gyroActive() && !this.vr() && this.pointers.size === 0) this.chromeVisible.set(false);
		}, 4200);
	}
	nudgeYaw(delta) {
		this.stopInertia();
		this.yaw.set(this.normalizeYaw(this.yaw() + delta));
	}
	nudgePitch(delta) {
		this.stopInertia();
		this.pitch.set(this.clampPitch(this.pitch() + delta));
	}
	setZoom(value) {
		this.zoom.set(Math.max(1, Math.min(2.6, Number(value.toFixed(2)))));
	}
	normalizeYaw(value) {
		return (value % 360 + 360) % 360;
	}
	clampPitch(value) {
		return Math.max(-28, Math.min(28, value));
	}
	shortestAngle(delta) {
		const wrapped = (delta + 180) % 360 - 180;
		return wrapped < -180 ? wrapped + 360 : wrapped;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.4",
		ngImport: i0,
		type: AtralumeImage360,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.4",
		type: AtralumeImage360,
		isStandalone: true,
		selector: "atr-image-360",
		inputs: {
			src: {
				classPropertyName: "src",
				publicName: "src",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			alt: {
				classPropertyName: "alt",
				publicName: "alt",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			enableGyro: {
				classPropertyName: "enableGyro",
				publicName: "enableGyro",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			enableVr: {
				classPropertyName: "enableVr",
				publicName: "enableVr",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			initialYaw: {
				classPropertyName: "initialYaw",
				publicName: "initialYaw",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			initialPitch: {
				classPropertyName: "initialPitch",
				publicName: "initialPitch",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			properties: {
				"class.atr-image-360--vr": "vr()",
				"class.atr-image-360--gyro": "gyroActive()",
				"class.atr-image-360--chrome-visible": "chromeVisible()",
				"attr.aria-label": "label()",
				"attr.data-status": "status()"
			},
			classAttribute: "atr-image-360"
		},
		ngImport: i0,
		template: "<figure class=\"atr-image-360__frame\">\n  <div\n    class=\"atr-image-360__stage\"\n    role=\"application\"\n    tabindex=\"0\"\n    [attr.aria-label]=\"ariaDescription()\"\n    (pointerdown)=\"startPointer($event)\"\n    (pointermove)=\"movePointer($event)\"\n    (pointerup)=\"endPointer($event)\"\n    (pointercancel)=\"endPointer($event)\"\n    (keydown)=\"onKey($event)\"\n    (wheel)=\"onWheel($event)\"\n    (focus)=\"onSceneActivate()\"\n  >\n    @if (vr()) {\n      <div class=\"atr-image-360__stereo\" aria-hidden=\"true\">\n        <div class=\"atr-image-360__scene\" [ngStyle]=\"sceneStyle()\"></div>\n        <div\n          class=\"atr-image-360__scene atr-image-360__scene--right\"\n          [ngStyle]=\"sceneStyleRight()\"\n        ></div>\n      </div>\n    } @else {\n      <div\n        class=\"atr-image-360__scene\"\n        [ngStyle]=\"sceneStyle()\"\n        aria-hidden=\"true\"\n      ></div>\n    }\n\n    <div class=\"atr-image-360__veil\" aria-hidden=\"true\"></div>\n\n    @if (status() === \"loading\") {\n      <div class=\"atr-image-360__state atr-image-360__state--loading\" role=\"status\">\n        Cargando panorama…\n      </div>\n    }\n\n    @if (status() === \"error\") {\n      <div class=\"atr-image-360__state atr-image-360__state--error\" role=\"alert\">\n        <p>No se pudo cargar la imagen 360.</p>\n        <button atrButton appearance=\"tonal\" type=\"button\" (click)=\"retryLoad()\">\n          Reintentar\n        </button>\n      </div>\n    }\n\n    @if (hintVisible() && status() === \"ready\") {\n      <p class=\"atr-image-360__hint\" aria-live=\"polite\">\n        Arrastra para explorar\n        @if (enableGyro() && gyroSupported()) {\n          <span>· Inclina el teléfono</span>\n        }\n        <span>· Pellizca para zoom</span>\n      </p>\n    }\n\n    <div class=\"atr-image-360__compass\" aria-hidden=\"true\">\n      <span class=\"atr-image-360__compass-ring\">\n        <span\n          class=\"atr-image-360__compass-needle\"\n          [style.transform]=\"'rotate(' + yaw() + 'deg)'\"\n        ></span>\n      </span>\n      <span class=\"atr-image-360__compass-label\">{{ yawLabel() }}</span>\n    </div>\n\n    <div class=\"atr-image-360__chrome\" [attr.data-visible]=\"chromeVisible() || status() !== 'ready'\">\n      <div class=\"atr-image-360__meta\">\n        <strong class=\"atr-image-360__title\">{{ label() }}</strong>\n        @if (gyroActive()) {\n          <span class=\"atr-image-360__badge\">Giroscopio</span>\n        }\n        @if (vr()) {\n          <span class=\"atr-image-360__badge\">VR</span>\n        }\n        @if (gyroDenied()) {\n          <span class=\"atr-image-360__badge atr-image-360__badge--warn\">Permiso denegado</span>\n        }\n      </div>\n\n      <div class=\"atr-image-360__actions\" role=\"toolbar\" [attr.aria-label]=\"'Controles de ' + label()\">\n        @if (enableGyro() && gyroSupported()) {\n          <button\n            atrButton\n            appearance=\"text\"\n            type=\"button\"\n            class=\"atr-image-360__tool\"\n            [attr.aria-pressed]=\"gyroActive()\"\n            [attr.aria-label]=\"gyroActive() ? 'Desactivar giroscopio' : 'Activar giroscopio'\"\n            (click)=\"toggleGyro()\"\n          >\n            <svg viewBox=\"0 0 24 24\" aria-hidden=\"true\" focusable=\"false\">\n              <path\n                fill=\"currentColor\"\n                d=\"M12 2a3 3 0 0 1 3 3v1.1a7 7 0 0 1 4.9 4.9H21a1 1 0 1 1 0 2h-1.1A7 7 0 0 1 15 17.9V19a3 3 0 1 1-6 0v-1.1A7 7 0 0 1 4.1 13H3a1 1 0 1 1 0-2h1.1A7 7 0 0 1 9 6.1V5a3 3 0 0 1 3-3Zm0 6a4 4 0 1 0 0 8 4 4 0 0 0 0-8Z\"\n              />\n            </svg>\n            <span class=\"atr-image-360__tool-label\">Giro</span>\n          </button>\n        }\n\n        @if (enableVr()) {\n          <button\n            atrButton\n            appearance=\"text\"\n            type=\"button\"\n            class=\"atr-image-360__tool\"\n            [attr.aria-pressed]=\"vr()\"\n            [attr.aria-label]=\"vr() ? 'Salir de VR' : 'Entrar en VR estereoscópico'\"\n            (click)=\"toggleVr()\"\n          >\n            <svg viewBox=\"0 0 24 24\" aria-hidden=\"true\" focusable=\"false\">\n              <path\n                fill=\"currentColor\"\n                d=\"M4 7.5A2.5 2.5 0 0 1 6.5 5h11A2.5 2.5 0 0 1 20 7.5v6A3.5 3.5 0 0 1 16.5 17h-1.2a2 2 0 0 1-1.7-.9l-.7-1a1 1 0 0 0-.8-.4h-1.2a1 1 0 0 0-.8.4l-.7 1a2 2 0 0 1-1.7.9H7.5A3.5 3.5 0 0 1 4 13.5v-6ZM8.5 12a1.75 1.75 0 1 0 0-3.5 1.75 1.75 0 0 0 0 3.5Zm7 0a1.75 1.75 0 1 0 0-3.5 1.75 1.75 0 0 0 0 3.5Z\"\n              />\n            </svg>\n            <span class=\"atr-image-360__tool-label\">VR</span>\n          </button>\n        }\n\n        <button\n          atrButton\n          appearance=\"text\"\n          type=\"button\"\n          class=\"atr-image-360__tool\"\n          aria-label=\"Alejar\"\n          (click)=\"changeZoom(-0.15)\"\n        >\n          <svg viewBox=\"0 0 24 24\" aria-hidden=\"true\" focusable=\"false\">\n            <path fill=\"currentColor\" d=\"M5 11h14v2H5z\" />\n          </svg>\n        </button>\n\n        <button\n          atrButton\n          appearance=\"text\"\n          type=\"button\"\n          class=\"atr-image-360__tool\"\n          aria-label=\"Acercar\"\n          (click)=\"changeZoom(0.15)\"\n        >\n          <svg viewBox=\"0 0 24 24\" aria-hidden=\"true\" focusable=\"false\">\n            <path fill=\"currentColor\" d=\"M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6z\" />\n          </svg>\n        </button>\n\n        <button\n          atrButton\n          appearance=\"text\"\n          type=\"button\"\n          class=\"atr-image-360__tool\"\n          aria-label=\"Restablecer vista\"\n          (click)=\"reset()\"\n        >\n          <svg viewBox=\"0 0 24 24\" aria-hidden=\"true\" focusable=\"false\">\n            <path\n              fill=\"currentColor\"\n              d=\"M12 5V2L8 6l4 4V7a5 5 0 1 1-4.9 6.1l-1.96.4A7 7 0 1 0 12 5Z\"\n            />\n          </svg>\n          <span class=\"atr-image-360__tool-label\">Inicio</span>\n        </button>\n\n        <button\n          atrButton\n          appearance=\"text\"\n          type=\"button\"\n          class=\"atr-image-360__tool\"\n          aria-label=\"Pantalla completa\"\n          (click)=\"fullscreen()\"\n        >\n          <svg viewBox=\"0 0 24 24\" aria-hidden=\"true\" focusable=\"false\">\n            <path\n              fill=\"currentColor\"\n              d=\"M4 4h6v2H6v4H4V4Zm10 0h6v6h-2V6h-4V4ZM4 14h2v4h4v2H4v-6Zm14 0h2v6h-6v-2h4v-4Z\"\n            />\n          </svg>\n        </button>\n      </div>\n    </div>\n  </div>\n</figure>\n",
		styles: [":host{display:block;color:var(--atr-sys-color-on-surface)}.atr-image-360__frame{margin:0;overflow:hidden;border-radius:var(--atr-sys-shape-corner-large, 1.25rem);background:color-mix(in srgb,var(--atr-sys-color-surface-container-highest) 88%,#000 12%);box-shadow:0 .5rem 1.5rem color-mix(in srgb,#000 18%,transparent),inset 0 0 0 1px color-mix(in srgb,var(--atr-sys-color-outline-variant) 55%,transparent)}.atr-image-360__stage{position:relative;isolation:isolate;aspect-ratio:16/9;min-block-size:16rem;outline:none;touch-action:none;cursor:grab;-webkit-user-select:none;user-select:none;background:#0b1218}.atr-image-360__stage:active{cursor:grabbing}.atr-image-360__stage:focus-visible{outline:3px solid var(--atr-sys-color-primary);outline-offset:2px}.atr-image-360__scene{position:absolute;inset:0;background-repeat:repeat-x;background-position:50% 50%;background-size:220% auto;will-change:background-position,background-size}.atr-image-360__stereo{position:absolute;inset:0;display:grid;grid-template-columns:1fr 1fr;gap:.125rem;background:#000}.atr-image-360__stereo .atr-image-360__scene{position:relative;inset:auto;block-size:100%}.atr-image-360__veil{position:absolute;inset:0;pointer-events:none;background:linear-gradient(to top,color-mix(in srgb,#000 52%,transparent) 0%,transparent 42%),linear-gradient(to bottom,color-mix(in srgb,#000 28%,transparent) 0%,transparent 28%);opacity:.9}.atr-image-360__hint{position:absolute;inset-inline:1rem;inset-block-end:5.5rem;margin:0 auto;max-inline-size:28rem;padding:.65rem .9rem;border-radius:var(--atr-sys-shape-full, 999px);text-align:center;font-size:.8125rem;line-height:1.35;color:#f4f7fb;background:color-mix(in srgb,#0b1218 72%,transparent);border:1px solid color-mix(in srgb,#fff 18%,transparent);pointer-events:none;animation:atr-image-360-hint-in .42s ease-out both}.atr-image-360__compass{position:absolute;inset-block-start:.85rem;inset-inline-start:50%;translate:-50% 0;display:grid;justify-items:center;gap:.3rem;pointer-events:none;opacity:0;transition:opacity .18s ease}:host(.atr-image-360--chrome-visible) .atr-image-360__compass,:host(.atr-image-360--gyro) .atr-image-360__compass,:host(.atr-image-360--vr) .atr-image-360__compass{opacity:1}.atr-image-360__compass-ring{display:grid;place-items:center;inline-size:2.35rem;block-size:2.35rem;border-radius:50%;border:1px solid color-mix(in srgb,#fff 35%,transparent);background:color-mix(in srgb,#0b1218 55%,transparent)}.atr-image-360__compass-needle{display:block;inline-size:.14rem;block-size:.85rem;border-radius:999px;background:var(--atr-sys-color-primary, #8ab4ff);transform-origin:50% 100%;translate:0 -.15rem}.atr-image-360__compass-label{font-size:.6875rem;font-variant-numeric:tabular-nums;letter-spacing:.04em;color:color-mix(in srgb,#fff 82%,transparent);text-shadow:0 1px 2px rgba(0,0,0,.45)}.atr-image-360__chrome{position:absolute;inset-inline:.75rem;inset-block-end:.75rem;display:flex;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;gap:.75rem;opacity:.42;translate:0 .2rem;pointer-events:none;transition:opacity .2s ease,translate .2s ease}.atr-image-360__chrome[data-visible=true]{opacity:1;translate:0 0}.atr-image-360__meta{display:flex;flex-wrap:wrap;align-items:center;gap:.4rem .55rem;min-inline-size:0;max-inline-size:min(100%,18rem)}.atr-image-360__title{margin:0;font-size:.875rem;font-weight:600;color:#f7fafc;text-shadow:0 1px 2px rgba(0,0,0,.4);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.atr-image-360__badge{display:inline-flex;align-items:center;min-block-size:1.35rem;padding-inline:.45rem;border-radius:var(--atr-sys-shape-full, 999px);font-size:.6875rem;font-weight:600;letter-spacing:.02em;color:#061018;background:color-mix(in srgb,var(--atr-sys-color-primary, #8ab4ff) 88%,#fff)}.atr-image-360__badge--warn{color:#1a1000;background:color-mix(in srgb,var(--atr-sys-color-error, #ffb4ab) 80%,#fff)}.atr-image-360__actions{display:flex;flex-wrap:wrap;gap:.35rem;padding:.3rem;border-radius:var(--atr-sys-shape-corner-large, 1rem);background:color-mix(in srgb,#0b1218 72%,transparent);border:1px solid color-mix(in srgb,#fff 14%,transparent);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);pointer-events:auto}.atr-image-360__tool{display:inline-flex;align-items:center;justify-content:center;gap:.3rem;min-inline-size:2.5rem;min-block-size:2.5rem;padding-inline:.55rem;border:0;border-radius:var(--atr-sys-shape-full, 999px);color:#f4f7fb;background:transparent;cursor:pointer}.atr-image-360__tool svg{inline-size:1.15rem;block-size:1.15rem}.atr-image-360__tool:hover{background:color-mix(in srgb,#fff 14%,transparent)}.atr-image-360__tool:focus-visible{outline:2px solid var(--atr-sys-color-primary);outline-offset:2px}.atr-image-360__tool[aria-pressed=true]{background:color-mix(in srgb,var(--atr-sys-color-primary, #8ab4ff) 34%,transparent);color:#fff}.atr-image-360__tool-label{font-size:.75rem;font-weight:600}.atr-image-360__state{position:absolute;inset:0;z-index:2;display:grid;place-content:center;gap:.75rem;padding:1.25rem;text-align:center;color:#eef3f8;background:color-mix(in srgb,#0b1218 72%,transparent)}.atr-image-360__state p{margin:0}.atr-image-360__state--loading{font-size:.875rem}:host(.atr-image-360--vr) .atr-image-360__stage{aspect-ratio:2/1}:host(.atr-image-360--vr) .atr-image-360__hint{display:none}:host(:fullscreen){background:#000}:host(:fullscreen) .atr-image-360__frame{border-radius:0;block-size:100%;box-shadow:none}:host(:fullscreen) .atr-image-360__stage{aspect-ratio:auto;block-size:100dvh}@media(max-width:40rem){.atr-image-360__stage{aspect-ratio:4/5;min-block-size:20rem}.atr-image-360__chrome{inset-inline:.55rem;inset-block-end:.55rem}.atr-image-360__tool-label{display:none}.atr-image-360__hint{inset-block-end:4.75rem;font-size:.75rem}:host(.atr-image-360--vr) .atr-image-360__stage{aspect-ratio:auto;block-size:min(70dvh,28rem)}}@media(prefers-reduced-motion:reduce){.atr-image-360__hint,.atr-image-360__chrome,.atr-image-360__compass{animation:none;transition:none}}@keyframes atr-image-360-hint-in{0%{opacity:0;transform:translateY(.4rem)}to{opacity:1;transform:translateY(0)}}\n"],
		dependencies: [{
			kind: "directive",
			type: NgStyle,
			selector: "[ngStyle]",
			inputs: ["ngStyle"]
		}, {
			kind: "component",
			type: AtralumeButton,
			selector: "button[atrButton], a[atrButton]",
			inputs: [
				"appearance",
				"size",
				"disabled",
				"loading",
				"fullWidth",
				"tabindex"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.4",
	ngImport: i0,
	type: AtralumeImage360,
	decorators: [{
		type: Component,
		args: [{
			selector: "atr-image-360",
			standalone: true,
			imports: [NgStyle, AtralumeButton],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "atr-image-360",
				"[class.atr-image-360--vr]": "vr()",
				"[class.atr-image-360--gyro]": "gyroActive()",
				"[class.atr-image-360--chrome-visible]": "chromeVisible()",
				"[attr.aria-label]": "label()",
				"[attr.data-status]": "status()"
			},
			template: "<figure class=\"atr-image-360__frame\">\n  <div\n    class=\"atr-image-360__stage\"\n    role=\"application\"\n    tabindex=\"0\"\n    [attr.aria-label]=\"ariaDescription()\"\n    (pointerdown)=\"startPointer($event)\"\n    (pointermove)=\"movePointer($event)\"\n    (pointerup)=\"endPointer($event)\"\n    (pointercancel)=\"endPointer($event)\"\n    (keydown)=\"onKey($event)\"\n    (wheel)=\"onWheel($event)\"\n    (focus)=\"onSceneActivate()\"\n  >\n    @if (vr()) {\n      <div class=\"atr-image-360__stereo\" aria-hidden=\"true\">\n        <div class=\"atr-image-360__scene\" [ngStyle]=\"sceneStyle()\"></div>\n        <div\n          class=\"atr-image-360__scene atr-image-360__scene--right\"\n          [ngStyle]=\"sceneStyleRight()\"\n        ></div>\n      </div>\n    } @else {\n      <div\n        class=\"atr-image-360__scene\"\n        [ngStyle]=\"sceneStyle()\"\n        aria-hidden=\"true\"\n      ></div>\n    }\n\n    <div class=\"atr-image-360__veil\" aria-hidden=\"true\"></div>\n\n    @if (status() === \"loading\") {\n      <div class=\"atr-image-360__state atr-image-360__state--loading\" role=\"status\">\n        Cargando panorama…\n      </div>\n    }\n\n    @if (status() === \"error\") {\n      <div class=\"atr-image-360__state atr-image-360__state--error\" role=\"alert\">\n        <p>No se pudo cargar la imagen 360.</p>\n        <button atrButton appearance=\"tonal\" type=\"button\" (click)=\"retryLoad()\">\n          Reintentar\n        </button>\n      </div>\n    }\n\n    @if (hintVisible() && status() === \"ready\") {\n      <p class=\"atr-image-360__hint\" aria-live=\"polite\">\n        Arrastra para explorar\n        @if (enableGyro() && gyroSupported()) {\n          <span>· Inclina el teléfono</span>\n        }\n        <span>· Pellizca para zoom</span>\n      </p>\n    }\n\n    <div class=\"atr-image-360__compass\" aria-hidden=\"true\">\n      <span class=\"atr-image-360__compass-ring\">\n        <span\n          class=\"atr-image-360__compass-needle\"\n          [style.transform]=\"'rotate(' + yaw() + 'deg)'\"\n        ></span>\n      </span>\n      <span class=\"atr-image-360__compass-label\">{{ yawLabel() }}</span>\n    </div>\n\n    <div class=\"atr-image-360__chrome\" [attr.data-visible]=\"chromeVisible() || status() !== 'ready'\">\n      <div class=\"atr-image-360__meta\">\n        <strong class=\"atr-image-360__title\">{{ label() }}</strong>\n        @if (gyroActive()) {\n          <span class=\"atr-image-360__badge\">Giroscopio</span>\n        }\n        @if (vr()) {\n          <span class=\"atr-image-360__badge\">VR</span>\n        }\n        @if (gyroDenied()) {\n          <span class=\"atr-image-360__badge atr-image-360__badge--warn\">Permiso denegado</span>\n        }\n      </div>\n\n      <div class=\"atr-image-360__actions\" role=\"toolbar\" [attr.aria-label]=\"'Controles de ' + label()\">\n        @if (enableGyro() && gyroSupported()) {\n          <button\n            atrButton\n            appearance=\"text\"\n            type=\"button\"\n            class=\"atr-image-360__tool\"\n            [attr.aria-pressed]=\"gyroActive()\"\n            [attr.aria-label]=\"gyroActive() ? 'Desactivar giroscopio' : 'Activar giroscopio'\"\n            (click)=\"toggleGyro()\"\n          >\n            <svg viewBox=\"0 0 24 24\" aria-hidden=\"true\" focusable=\"false\">\n              <path\n                fill=\"currentColor\"\n                d=\"M12 2a3 3 0 0 1 3 3v1.1a7 7 0 0 1 4.9 4.9H21a1 1 0 1 1 0 2h-1.1A7 7 0 0 1 15 17.9V19a3 3 0 1 1-6 0v-1.1A7 7 0 0 1 4.1 13H3a1 1 0 1 1 0-2h1.1A7 7 0 0 1 9 6.1V5a3 3 0 0 1 3-3Zm0 6a4 4 0 1 0 0 8 4 4 0 0 0 0-8Z\"\n              />\n            </svg>\n            <span class=\"atr-image-360__tool-label\">Giro</span>\n          </button>\n        }\n\n        @if (enableVr()) {\n          <button\n            atrButton\n            appearance=\"text\"\n            type=\"button\"\n            class=\"atr-image-360__tool\"\n            [attr.aria-pressed]=\"vr()\"\n            [attr.aria-label]=\"vr() ? 'Salir de VR' : 'Entrar en VR estereoscópico'\"\n            (click)=\"toggleVr()\"\n          >\n            <svg viewBox=\"0 0 24 24\" aria-hidden=\"true\" focusable=\"false\">\n              <path\n                fill=\"currentColor\"\n                d=\"M4 7.5A2.5 2.5 0 0 1 6.5 5h11A2.5 2.5 0 0 1 20 7.5v6A3.5 3.5 0 0 1 16.5 17h-1.2a2 2 0 0 1-1.7-.9l-.7-1a1 1 0 0 0-.8-.4h-1.2a1 1 0 0 0-.8.4l-.7 1a2 2 0 0 1-1.7.9H7.5A3.5 3.5 0 0 1 4 13.5v-6ZM8.5 12a1.75 1.75 0 1 0 0-3.5 1.75 1.75 0 0 0 0 3.5Zm7 0a1.75 1.75 0 1 0 0-3.5 1.75 1.75 0 0 0 0 3.5Z\"\n              />\n            </svg>\n            <span class=\"atr-image-360__tool-label\">VR</span>\n          </button>\n        }\n\n        <button\n          atrButton\n          appearance=\"text\"\n          type=\"button\"\n          class=\"atr-image-360__tool\"\n          aria-label=\"Alejar\"\n          (click)=\"changeZoom(-0.15)\"\n        >\n          <svg viewBox=\"0 0 24 24\" aria-hidden=\"true\" focusable=\"false\">\n            <path fill=\"currentColor\" d=\"M5 11h14v2H5z\" />\n          </svg>\n        </button>\n\n        <button\n          atrButton\n          appearance=\"text\"\n          type=\"button\"\n          class=\"atr-image-360__tool\"\n          aria-label=\"Acercar\"\n          (click)=\"changeZoom(0.15)\"\n        >\n          <svg viewBox=\"0 0 24 24\" aria-hidden=\"true\" focusable=\"false\">\n            <path fill=\"currentColor\" d=\"M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6z\" />\n          </svg>\n        </button>\n\n        <button\n          atrButton\n          appearance=\"text\"\n          type=\"button\"\n          class=\"atr-image-360__tool\"\n          aria-label=\"Restablecer vista\"\n          (click)=\"reset()\"\n        >\n          <svg viewBox=\"0 0 24 24\" aria-hidden=\"true\" focusable=\"false\">\n            <path\n              fill=\"currentColor\"\n              d=\"M12 5V2L8 6l4 4V7a5 5 0 1 1-4.9 6.1l-1.96.4A7 7 0 1 0 12 5Z\"\n            />\n          </svg>\n          <span class=\"atr-image-360__tool-label\">Inicio</span>\n        </button>\n\n        <button\n          atrButton\n          appearance=\"text\"\n          type=\"button\"\n          class=\"atr-image-360__tool\"\n          aria-label=\"Pantalla completa\"\n          (click)=\"fullscreen()\"\n        >\n          <svg viewBox=\"0 0 24 24\" aria-hidden=\"true\" focusable=\"false\">\n            <path\n              fill=\"currentColor\"\n              d=\"M4 4h6v2H6v4H4V4Zm10 0h6v6h-2V6h-4V4ZM4 14h2v4h4v2H4v-6Zm14 0h2v6h-6v-2h4v-4Z\"\n            />\n          </svg>\n        </button>\n      </div>\n    </div>\n  </div>\n</figure>\n",
			styles: [":host{display:block;color:var(--atr-sys-color-on-surface)}.atr-image-360__frame{margin:0;overflow:hidden;border-radius:var(--atr-sys-shape-corner-large, 1.25rem);background:color-mix(in srgb,var(--atr-sys-color-surface-container-highest) 88%,#000 12%);box-shadow:0 .5rem 1.5rem color-mix(in srgb,#000 18%,transparent),inset 0 0 0 1px color-mix(in srgb,var(--atr-sys-color-outline-variant) 55%,transparent)}.atr-image-360__stage{position:relative;isolation:isolate;aspect-ratio:16/9;min-block-size:16rem;outline:none;touch-action:none;cursor:grab;-webkit-user-select:none;user-select:none;background:#0b1218}.atr-image-360__stage:active{cursor:grabbing}.atr-image-360__stage:focus-visible{outline:3px solid var(--atr-sys-color-primary);outline-offset:2px}.atr-image-360__scene{position:absolute;inset:0;background-repeat:repeat-x;background-position:50% 50%;background-size:220% auto;will-change:background-position,background-size}.atr-image-360__stereo{position:absolute;inset:0;display:grid;grid-template-columns:1fr 1fr;gap:.125rem;background:#000}.atr-image-360__stereo .atr-image-360__scene{position:relative;inset:auto;block-size:100%}.atr-image-360__veil{position:absolute;inset:0;pointer-events:none;background:linear-gradient(to top,color-mix(in srgb,#000 52%,transparent) 0%,transparent 42%),linear-gradient(to bottom,color-mix(in srgb,#000 28%,transparent) 0%,transparent 28%);opacity:.9}.atr-image-360__hint{position:absolute;inset-inline:1rem;inset-block-end:5.5rem;margin:0 auto;max-inline-size:28rem;padding:.65rem .9rem;border-radius:var(--atr-sys-shape-full, 999px);text-align:center;font-size:.8125rem;line-height:1.35;color:#f4f7fb;background:color-mix(in srgb,#0b1218 72%,transparent);border:1px solid color-mix(in srgb,#fff 18%,transparent);pointer-events:none;animation:atr-image-360-hint-in .42s ease-out both}.atr-image-360__compass{position:absolute;inset-block-start:.85rem;inset-inline-start:50%;translate:-50% 0;display:grid;justify-items:center;gap:.3rem;pointer-events:none;opacity:0;transition:opacity .18s ease}:host(.atr-image-360--chrome-visible) .atr-image-360__compass,:host(.atr-image-360--gyro) .atr-image-360__compass,:host(.atr-image-360--vr) .atr-image-360__compass{opacity:1}.atr-image-360__compass-ring{display:grid;place-items:center;inline-size:2.35rem;block-size:2.35rem;border-radius:50%;border:1px solid color-mix(in srgb,#fff 35%,transparent);background:color-mix(in srgb,#0b1218 55%,transparent)}.atr-image-360__compass-needle{display:block;inline-size:.14rem;block-size:.85rem;border-radius:999px;background:var(--atr-sys-color-primary, #8ab4ff);transform-origin:50% 100%;translate:0 -.15rem}.atr-image-360__compass-label{font-size:.6875rem;font-variant-numeric:tabular-nums;letter-spacing:.04em;color:color-mix(in srgb,#fff 82%,transparent);text-shadow:0 1px 2px rgba(0,0,0,.45)}.atr-image-360__chrome{position:absolute;inset-inline:.75rem;inset-block-end:.75rem;display:flex;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;gap:.75rem;opacity:.42;translate:0 .2rem;pointer-events:none;transition:opacity .2s ease,translate .2s ease}.atr-image-360__chrome[data-visible=true]{opacity:1;translate:0 0}.atr-image-360__meta{display:flex;flex-wrap:wrap;align-items:center;gap:.4rem .55rem;min-inline-size:0;max-inline-size:min(100%,18rem)}.atr-image-360__title{margin:0;font-size:.875rem;font-weight:600;color:#f7fafc;text-shadow:0 1px 2px rgba(0,0,0,.4);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.atr-image-360__badge{display:inline-flex;align-items:center;min-block-size:1.35rem;padding-inline:.45rem;border-radius:var(--atr-sys-shape-full, 999px);font-size:.6875rem;font-weight:600;letter-spacing:.02em;color:#061018;background:color-mix(in srgb,var(--atr-sys-color-primary, #8ab4ff) 88%,#fff)}.atr-image-360__badge--warn{color:#1a1000;background:color-mix(in srgb,var(--atr-sys-color-error, #ffb4ab) 80%,#fff)}.atr-image-360__actions{display:flex;flex-wrap:wrap;gap:.35rem;padding:.3rem;border-radius:var(--atr-sys-shape-corner-large, 1rem);background:color-mix(in srgb,#0b1218 72%,transparent);border:1px solid color-mix(in srgb,#fff 14%,transparent);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);pointer-events:auto}.atr-image-360__tool{display:inline-flex;align-items:center;justify-content:center;gap:.3rem;min-inline-size:2.5rem;min-block-size:2.5rem;padding-inline:.55rem;border:0;border-radius:var(--atr-sys-shape-full, 999px);color:#f4f7fb;background:transparent;cursor:pointer}.atr-image-360__tool svg{inline-size:1.15rem;block-size:1.15rem}.atr-image-360__tool:hover{background:color-mix(in srgb,#fff 14%,transparent)}.atr-image-360__tool:focus-visible{outline:2px solid var(--atr-sys-color-primary);outline-offset:2px}.atr-image-360__tool[aria-pressed=true]{background:color-mix(in srgb,var(--atr-sys-color-primary, #8ab4ff) 34%,transparent);color:#fff}.atr-image-360__tool-label{font-size:.75rem;font-weight:600}.atr-image-360__state{position:absolute;inset:0;z-index:2;display:grid;place-content:center;gap:.75rem;padding:1.25rem;text-align:center;color:#eef3f8;background:color-mix(in srgb,#0b1218 72%,transparent)}.atr-image-360__state p{margin:0}.atr-image-360__state--loading{font-size:.875rem}:host(.atr-image-360--vr) .atr-image-360__stage{aspect-ratio:2/1}:host(.atr-image-360--vr) .atr-image-360__hint{display:none}:host(:fullscreen){background:#000}:host(:fullscreen) .atr-image-360__frame{border-radius:0;block-size:100%;box-shadow:none}:host(:fullscreen) .atr-image-360__stage{aspect-ratio:auto;block-size:100dvh}@media(max-width:40rem){.atr-image-360__stage{aspect-ratio:4/5;min-block-size:20rem}.atr-image-360__chrome{inset-inline:.55rem;inset-block-end:.55rem}.atr-image-360__tool-label{display:none}.atr-image-360__hint{inset-block-end:4.75rem;font-size:.75rem}:host(.atr-image-360--vr) .atr-image-360__stage{aspect-ratio:auto;block-size:min(70dvh,28rem)}}@media(prefers-reduced-motion:reduce){.atr-image-360__hint,.atr-image-360__chrome,.atr-image-360__compass{animation:none;transition:none}}@keyframes atr-image-360-hint-in{0%{opacity:0;transform:translateY(.4rem)}to{opacity:1;transform:translateY(0)}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		src: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "src",
				required: true
			}]
		}],
		alt: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "alt",
				required: true
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		enableGyro: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "enableGyro",
				required: false
			}]
		}],
		enableVr: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "enableVr",
				required: false
			}]
		}],
		initialYaw: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "initialYaw",
				required: false
			}]
		}],
		initialPitch: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "initialPitch",
				required: false
			}]
		}]
	}
});
export { AtralumeImage360 };

//# sourceMappingURL=osmanjimenez-atralume-image-360.mjs.map